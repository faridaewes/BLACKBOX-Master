# BLACKBOX Crypto v16.0.0 — Zero-Touch Deployment Hardening

## Changes

- Fixed staging setup credential wiring: staging now uses the generated strong passwords instead of undefined demo variables.
- Reworked Linux auto-deploy so a missing `.env` is provisioned automatically through `scripts/setup.mjs`; it no longer copies `.env.example` and asks the operator to edit secrets manually.
- Added `scripts/deploy-anywhere.mjs` as the canonical single-command launcher.
- Added Windows `Deploy-Auto.ps1` and `Install-Autostart.ps1`.
- Windows autostart registers a SYSTEM startup task with retries and configures Docker service startup when available.
- Updated Linux systemd service branding to v16.
- Added zero-touch regression tests.
- Documented the supported Docker-capable deployment contract and the unavoidable shared-hosting limitation.

## Automatic database lifecycle

Docker Compose owns PostgreSQL 16, persistent storage, migration, seed, and startup ordering. The application is not considered ready until `/api/health` confirms readiness.

## Recovery lifecycle

Host reboot -> Docker starts -> Compose starts -> PostgreSQL becomes healthy -> Prisma migrations/seed complete -> app starts -> workers start -> health gate passes.

Individual container crash -> Docker restart policy -> health recovery.

Migration/database failure -> dependent services remain stopped; deployment reports failure instead of serving a blank or partially initialized application.

## Certification boundary

Static/contract verification can be performed in the release artifact. Actual production runtime certification still requires the target VPS/hosting environment to execute the full dependency, database, browser, Android, exchange sandbox, recovery and DR gates. No artifact-only test is represented as live production certification.
