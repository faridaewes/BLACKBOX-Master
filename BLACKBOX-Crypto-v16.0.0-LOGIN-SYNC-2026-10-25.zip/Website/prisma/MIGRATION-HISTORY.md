# Prisma migration history and the legacy numeric-prefix collisions

The migration folders with prefixes `0007`, `0008`, and `0010` are historical names retained from earlier releases:

- `0007_certification_evidence`
- `0007_wallet_tier_upgrade`
- `0008_security_sessions_archive`
- `0008_subscription_entitlement_override`
- `0010_audit_evidence`
- `0010_wallet_chain_id`

These are **not duplicate Prisma migration identifiers** because Prisma records each full directory name and a checksum in `_prisma_migrations`. The four-digit prefix alone is not the identifier. The full names are distinct, and each has its own `migration.sql`.

## Safety decision

Do **not** rename or rewrite these historical directories to make the numeric prefixes unique. Doing so can make an already-used database report the old migrations as missing or detect checksum/history differences. The collision is resolved operationally by retaining the immutable full names and checking the known collision set through `npm run migration:history-audit`.

## Required database validation before release

On an isolated PostgreSQL database with the same supported PostgreSQL major version:

1. Back up any database that already contains data; never test migrations against the only copy.
2. Run `npx prisma validate` and `npx prisma migrate deploy` against a **fresh test database**.
3. Run `npx prisma migrate status` and inspect `_prisma_migrations` for failed rows, missing applied migrations, and checksum differences.
4. Compare this history with a copy of every existing/staging database before deploying to it. Do not use `prisma db push` as a production migration substitute.
5. Run a restore drill from a known backup and verify required tables and row counts before accepting the release.

This archive's static checks do not claim that PostgreSQL migration execution, migration recovery, or backup restoration passed; those require an available database and recorded runtime evidence.
