ALTER TABLE "User" ADD COLUMN "username" TEXT;
ALTER TABLE "User" ADD COLUMN "referralCode" TEXT;
ALTER TABLE "User" ADD COLUMN "referredById" TEXT;
ALTER TABLE "User" ADD COLUMN "hasEverActivated" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "User" ADD COLUMN "referralPro" BOOLEAN NOT NULL DEFAULT false;

UPDATE "User"
SET "username" = 'bbx_' || lower(substr(replace("id", '-', ''), 1, 12))
WHERE "username" IS NULL;

CREATE UNIQUE INDEX "User_username_key" ON "User"("username");
CREATE UNIQUE INDEX "User_referralCode_key" ON "User"("referralCode");
CREATE INDEX "User_referredById_idx" ON "User"("referredById");

ALTER TABLE "User" ALTER COLUMN "username" SET NOT NULL;
ALTER TABLE "User" ADD CONSTRAINT "User_referredById_fkey" FOREIGN KEY ("referredById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

CREATE TABLE "ReferralPointLedger" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "amount" INTEGER NOT NULL,
  "kind" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'AVAILABLE',
  "referenceType" TEXT,
  "referenceId" TEXT,
  "counterpartyUserId" TEXT,
  "description" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ReferralPointLedger_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "ReferralPointLedger_userId_kind_referenceId_key" ON "ReferralPointLedger"("userId", "kind", "referenceId");
CREATE INDEX "ReferralPointLedger_userId_createdAt_idx" ON "ReferralPointLedger"("userId", "createdAt");
CREATE INDEX "ReferralPointLedger_counterpartyUserId_createdAt_idx" ON "ReferralPointLedger"("counterpartyUserId", "createdAt");
ALTER TABLE "ReferralPointLedger" ADD CONSTRAINT "ReferralPointLedger_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ReferralPointLedger" ADD CONSTRAINT "ReferralPointLedger_counterpartyUserId_fkey" FOREIGN KEY ("counterpartyUserId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

CREATE TABLE "ReferralRedemption" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "tier" TEXT NOT NULL,
  "pointsSpent" INTEGER NOT NULL,
  "durationDays" INTEGER NOT NULL,
  "subscriptionId" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ReferralRedemption_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ReferralRedemption_userId_createdAt_idx" ON "ReferralRedemption"("userId", "createdAt");
ALTER TABLE "ReferralRedemption" ADD CONSTRAINT "ReferralRedemption_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "ReferralProfile" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "customCode" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ReferralProfile_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "ReferralProfile_userId_key" ON "ReferralProfile"("userId");
CREATE UNIQUE INDEX "ReferralProfile_customCode_key" ON "ReferralProfile"("customCode");
ALTER TABLE "ReferralProfile" ADD CONSTRAINT "ReferralProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Backfill the new PRO activation marker and one-time onboarding points for users who already completed the corresponding events.
UPDATE "User" u SET "hasEverActivated" = true, "referralPro" = true
WHERE EXISTS (SELECT 1 FROM "CodeRedemption" r WHERE r."userId" = u."id");

INSERT INTO "ReferralPointLedger" ("id","userId","amount","kind","status","referenceType","referenceId","description")
SELECT 'backfill_activation_' || r."id", r."userId", 20, 'ACTIVATION_FIRST', 'AVAILABLE', 'CODE_REDEMPTION', r."id", 'Aktivasi code pertama kali (backfill v9.1)'
FROM "CodeRedemption" r
WHERE r."id" = (SELECT r2."id" FROM "CodeRedemption" r2 WHERE r2."userId" = r."userId" ORDER BY r2."redeemedAt" ASC, r2."id" ASC LIMIT 1)
AND NOT EXISTS (SELECT 1 FROM "ReferralPointLedger" l WHERE l."userId" = r."userId" AND l."kind" = 'ACTIVATION_FIRST' AND l."referenceId" = r."id");

INSERT INTO "ReferralPointLedger" ("id","userId","amount","kind","status","referenceType","referenceId","description")
SELECT 'backfill_email_' || u."id", u."id", 30, 'VERIFIED_EMAIL', 'AVAILABLE', 'VERIFICATION', u."id" || ':EMAIL', 'Email terverifikasi (backfill v9.1)'
FROM "User" u WHERE u."emailVerifiedAt" IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM "ReferralPointLedger" l WHERE l."userId"=u."id" AND l."kind"='VERIFIED_EMAIL');

INSERT INTO "ReferralPointLedger" ("id","userId","amount","kind","status","referenceType","referenceId","description")
SELECT 'backfill_phone_' || u."id", u."id", 20, 'VERIFIED_PHONE', 'AVAILABLE', 'VERIFICATION', u."id" || ':PHONE', 'Nomor HP/WhatsApp terverifikasi (backfill v9.1)'
FROM "User" u WHERE u."phoneVerifiedAt" IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM "ReferralPointLedger" l WHERE l."userId"=u."id" AND l."kind"='VERIFIED_PHONE');

INSERT INTO "ReferralPointLedger" ("id","userId","amount","kind","status","referenceType","referenceId","description")
SELECT 'backfill_kyc_' || u."id", u."id", 30, 'KYC_IDENTITY', 'AVAILABLE', 'VERIFICATION', u."id", 'KTP/SIM terverifikasi (backfill v9.1)'
FROM "User" u WHERE u."kycStatus"='APPROVED'
AND NOT EXISTS (SELECT 1 FROM "ReferralPointLedger" l WHERE l."userId"=u."id" AND l."kind"='KYC_IDENTITY');
