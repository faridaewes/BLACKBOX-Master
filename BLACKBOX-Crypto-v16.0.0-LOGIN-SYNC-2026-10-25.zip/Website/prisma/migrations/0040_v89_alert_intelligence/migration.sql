-- BLACKBOX Crypto v8.9.0 — Alert Intelligence
CREATE TABLE "AlertIntelligenceEvent" (
  "id" TEXT NOT NULL,
  "userId" TEXT,
  "alertKey" TEXT NOT NULL,
  "dedupeKey" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "severity" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "body" TEXT NOT NULL,
  "reason" TEXT NOT NULL,
  "source" TEXT,
  "metadata" JSONB,
  "observedAt" TIMESTAMP(3) NOT NULL,
  "deliveredAt" TIMESTAMP(3),
  "resolvedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AlertIntelligenceEvent_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "AlertIntelligenceEvent_alertKey_createdAt_idx" ON "AlertIntelligenceEvent"("alertKey", "createdAt");
CREATE INDEX "AlertIntelligenceEvent_dedupeKey_createdAt_idx" ON "AlertIntelligenceEvent"("dedupeKey", "createdAt");
CREATE INDEX "AlertIntelligenceEvent_status_createdAt_idx" ON "AlertIntelligenceEvent"("status", "createdAt");
CREATE INDEX "AlertIntelligenceEvent_userId_createdAt_idx" ON "AlertIntelligenceEvent"("userId", "createdAt");
ALTER TABLE "AlertIntelligenceEvent" ADD CONSTRAINT "AlertIntelligenceEvent_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
