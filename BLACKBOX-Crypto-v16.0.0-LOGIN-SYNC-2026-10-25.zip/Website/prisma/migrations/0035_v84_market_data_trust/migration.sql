CREATE TABLE "MarketDataTrustSnapshot" (
  "id" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "score" INTEGER NOT NULL,
  "status" TEXT NOT NULL,
  "freshnessScore" INTEGER NOT NULL,
  "providerHealthScore" INTEGER NOT NULL,
  "completenessScore" INTEGER NOT NULL,
  "consistencyScore" INTEGER NOT NULL,
  "latencyScore" INTEGER NOT NULL,
  "medianPriceUsd" DOUBLE PRECISION,
  "dispersionPct" DOUBLE PRECISION,
  "providerCount" INTEGER NOT NULL DEFAULT 1,
  "blockers" JSONB NOT NULL,
  "warnings" JSONB NOT NULL,
  "assessedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "MarketDataTrustSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "MarketDataTrustSnapshot_marketKey_assessedAt_idx" ON "MarketDataTrustSnapshot"("marketKey", "assessedAt");
CREATE INDEX "MarketDataTrustSnapshot_status_assessedAt_idx" ON "MarketDataTrustSnapshot"("status", "assessedAt");
CREATE INDEX "MarketDataTrustSnapshot_provider_marketType_assessedAt_idx" ON "MarketDataTrustSnapshot"("provider", "marketType", "assessedAt");
