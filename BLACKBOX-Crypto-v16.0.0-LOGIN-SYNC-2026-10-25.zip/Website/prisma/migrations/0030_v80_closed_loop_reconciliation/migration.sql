CREATE OR REPLACE FUNCTION bbx_sync_autonomous_cycle() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE ex RECORD; rec RECORD; execution_payload JSONB; reconciliation_payload JSONB;
BEGIN
  SELECT e."id",e."status",e."filledQuantity",e."averagePrice",e."fee",e."updatedAt" INTO ex FROM "Execution" e WHERE e."signalId"=NEW."id" ORDER BY e."updatedAt" DESC LIMIT 1;
  IF ex."id" IS NULL THEN execution_payload:=jsonb_build_object('status','NOT_EXECUTED'); reconciliation_payload:=jsonb_build_object('status','PENDING_UNTIL_EXECUTION');
  ELSE
    execution_payload:=jsonb_build_object('executionId',ex."id",'status',ex."status",'filledQuantity',ex."filledQuantity",'averagePrice',ex."averagePrice",'fee',ex."fee",'updatedAt',ex."updatedAt");
    SELECT r."status",r."checkedAt",r."discrepancy",r."error" INTO rec FROM "Reconciliation" r WHERE r."executionId"=ex."id" ORDER BY r."checkedAt" DESC LIMIT 1;
    IF rec."status" IS NULL THEN reconciliation_payload:=jsonb_build_object('status','PENDING_RECONCILIATION');
    ELSE reconciliation_payload:=jsonb_build_object('status',rec."status",'checkedAt',rec."checkedAt",'discrepancy',rec."discrepancy",'error',rec."error"); END IF;
  END IF;
  INSERT INTO "AutonomousDecisionCycle" ("id","userId","signalId","version","marketState","analysisState","aiState","riskState","precisionGate","executionState","reconciliationState","learningState","outcome")
  VALUES (md5(clock_timestamp()::text || random()::text || NEW."id"), NEW."userId", NEW."id", '8.0.0', jsonb_build_object('symbol',NEW."symbol",'regime',NEW."regime",'timeframe',NEW."timeframe"), jsonb_build_object('score',NEW."score",'qualityScore',NEW."qualityScore",'action',NEW."action",'reasons',NEW."reasons"), jsonb_build_object('score',NEW."aiScore",'confidence',NEW."confidence"), jsonb_build_object('riskFlags',NEW."riskFlags"), jsonb_build_object('passed',COALESCE(NEW."qualityScore",NEW."score") >= 90,'qualityScore',COALESCE(NEW."qualityScore",NEW."score")), execution_payload,reconciliation_payload,jsonb_build_object('result',NEW."result",'resultPnl',NEW."resultPnl"), COALESCE(NEW."result",ex."status",NEW."lifecycle",'DECISION_RECORDED'))
  ON CONFLICT ("signalId") DO UPDATE SET "analysisState"=EXCLUDED."analysisState", "aiState"=EXCLUDED."aiState", "riskState"=EXCLUDED."riskState", "precisionGate"=EXCLUDED."precisionGate", "executionState"=EXCLUDED."executionState", "reconciliationState"=EXCLUDED."reconciliationState", "learningState"=EXCLUDED."learningState", "outcome"=EXCLUDED."outcome";
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS bbx_signal_autonomous_cycle ON "Signal";
CREATE TRIGGER bbx_signal_autonomous_cycle AFTER INSERT OR UPDATE OF "score","qualityScore","aiScore","riskFlags","lifecycle","result","resultPnl" ON "Signal" FOR EACH ROW EXECUTE FUNCTION bbx_sync_autonomous_cycle();
