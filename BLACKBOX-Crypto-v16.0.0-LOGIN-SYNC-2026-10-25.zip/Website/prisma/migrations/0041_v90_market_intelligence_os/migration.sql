-- BLACKBOX Crypto v9.0.0 — Market Intelligence OS
CREATE TABLE "MarketIntelligenceOsSnapshot" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "overallStatus" TEXT NOT NULL,
  "confidence" INTEGER NOT NULL,
  "bias" TEXT NOT NULL,
  "trustScore" DOUBLE PRECISION,
  "dexScore" DOUBLE PRECISION,
  "executionScore" DOUBLE PRECISION,
  "alertCount" INTEGER NOT NULL DEFAULT 0,
  "activeAlertCount" INTEGER NOT NULL DEFAULT 0,
  "blockers" JSONB NOT NULL,
  "warnings" JSONB NOT NULL,
  "evidence" JSONB NOT NULL,
  "components" JSONB NOT NULL,
  "resultHash" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "MarketIntelligenceOsSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "MarketIntelligenceOsSnapshot_userId_createdAt_idx" ON "MarketIntelligenceOsSnapshot"("userId","createdAt");
CREATE INDEX "MarketIntelligenceOsSnapshot_marketKey_createdAt_idx" ON "MarketIntelligenceOsSnapshot"("marketKey","createdAt");
CREATE INDEX "MarketIntelligenceOsSnapshot_overallStatus_createdAt_idx" ON "MarketIntelligenceOsSnapshot"("overallStatus","createdAt");
CREATE INDEX "MarketIntelligenceOsSnapshot_resultHash_idx" ON "MarketIntelligenceOsSnapshot"("resultHash");
ALTER TABLE "MarketIntelligenceOsSnapshot" ADD CONSTRAINT "MarketIntelligenceOsSnapshot_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
