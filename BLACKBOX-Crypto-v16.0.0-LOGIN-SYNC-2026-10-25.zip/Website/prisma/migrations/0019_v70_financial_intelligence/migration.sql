CREATE TABLE IF NOT EXISTS "FinancialIntelligenceSnapshot" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "health" TEXT NOT NULL,
  "action" TEXT NOT NULL,
  "score" INTEGER NOT NULL,
  "equity" DOUBLE PRECISION NOT NULL,
  "realizedPnl" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "unrealizedPnl" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "drawdownPct" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "exposureUsd" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "exposurePct" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "concentrationPct" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "openPositions" INTEGER NOT NULL DEFAULT 0,
  "winRatePct" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "completedTrades" INTEGER NOT NULL DEFAULT 0,
  "profitFactor" DOUBLE PRECISION,
  "riskBudgetPct" DOUBLE PRECISION NOT NULL DEFAULT 10,
  "riskUsedPct" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "liquidityCoveragePct" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "warnings" JSONB,
  "recommendations" JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "FinancialIntelligenceSnapshot_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS "FinancialIntelligenceSnapshot_userId_createdAt_idx" ON "FinancialIntelligenceSnapshot"("userId","createdAt");
CREATE INDEX IF NOT EXISTS "FinancialIntelligenceSnapshot_health_createdAt_idx" ON "FinancialIntelligenceSnapshot"("health","createdAt");
