ALTER TABLE "Signal" ADD COLUMN "qualityScore" INTEGER;
ALTER TABLE "Signal" ADD COLUMN "confirmationCount" INTEGER;
ALTER TABLE "Signal" ADD COLUMN "noTradeReason" TEXT;
ALTER TABLE "Signal" ADD COLUMN "strategyVersion" TEXT;
CREATE INDEX "Signal_strategyVersion_createdAt_idx" ON "Signal"("strategyVersion", "createdAt");
