-- BLACKBOX v16.0.0 — Non-tier service catalog and MQ4/MQ5 email fulfillment.
CREATE TABLE "ServiceCatalogItem" (
  "id" TEXT NOT NULL,
  "slug" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "category" TEXT NOT NULL,
  "deliveryMode" TEXT NOT NULL DEFAULT 'FILE_EMAIL',
  "description" TEXT NOT NULL,
  "imageUrl" TEXT,
  "active" BOOLEAN NOT NULL DEFAULT false,
  "publicEnabled" BOOLEAN NOT NULL DEFAULT false,
  "validityDays" INTEGER,
  "priceMinor" INTEGER,
  "currency" TEXT NOT NULL DEFAULT 'IDR',
  "maxFileSize" INTEGER NOT NULL DEFAULT 10485760,
  "allowedExtensions" JSONB NOT NULL DEFAULT '["mq4","mq5"]',
  "createdById" TEXT NOT NULL,
  "updatedById" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ServiceCatalogItem_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "ServiceCatalogItem_slug_key" ON "ServiceCatalogItem"("slug");
CREATE INDEX "ServiceCatalogItem_active_publicEnabled_idx" ON "ServiceCatalogItem"("active", "publicEnabled");
CREATE INDEX "ServiceCatalogItem_category_active_idx" ON "ServiceCatalogItem"("category", "active");

CREATE TABLE "ServiceOrder" (
  "id" TEXT NOT NULL,
  "serviceId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'REQUESTED',
  "requestedEmail" TEXT NOT NULL,
  "validityStartsAt" TIMESTAMP(3),
  "validityExpiresAt" TIMESTAMP(3),
  "requestedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "fulfilledAt" TIMESTAMP(3),
  "cancelledAt" TIMESTAMP(3),
  "fulfilledById" TEXT,
  "notes" TEXT,
  CONSTRAINT "ServiceOrder_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ServiceOrder_userId_status_requestedAt_idx" ON "ServiceOrder"("userId", "status", "requestedAt");
CREATE INDEX "ServiceOrder_serviceId_status_requestedAt_idx" ON "ServiceOrder"("serviceId", "status", "requestedAt");
ALTER TABLE "ServiceOrder" ADD CONSTRAINT "ServiceOrder_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "ServiceCatalogItem"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "ServiceOrder" ADD CONSTRAINT "ServiceOrder_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "ServiceDelivery" (
  "id" TEXT NOT NULL,
  "orderId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "fileName" TEXT NOT NULL,
  "storageKey" TEXT NOT NULL,
  "mimeType" TEXT NOT NULL,
  "fileSize" INTEGER NOT NULL,
  "sha256" TEXT NOT NULL,
  "email" TEXT NOT NULL,
  "emailStatus" TEXT NOT NULL DEFAULT 'PENDING',
  "emailAttempts" INTEGER NOT NULL DEFAULT 0,
  "emailSentAt" TIMESTAMP(3),
  "emailError" TEXT,
  "expiresAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ServiceDelivery_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ServiceDelivery_orderId_createdAt_idx" ON "ServiceDelivery"("orderId", "createdAt");
CREATE INDEX "ServiceDelivery_userId_emailStatus_createdAt_idx" ON "ServiceDelivery"("userId", "emailStatus", "createdAt");
ALTER TABLE "ServiceDelivery" ADD CONSTRAINT "ServiceDelivery_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "ServiceOrder"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ServiceDelivery" ADD CONSTRAINT "ServiceDelivery_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
