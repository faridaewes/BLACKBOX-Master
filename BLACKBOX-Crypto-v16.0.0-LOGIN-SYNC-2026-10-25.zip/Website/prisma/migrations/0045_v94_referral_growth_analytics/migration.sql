-- v9.4 Referral Growth Analytics: optimize time-window and network traversal queries.
CREATE INDEX IF NOT EXISTS "User_referredById_createdAt_idx" ON "User"("referredById", "createdAt");
CREATE INDEX IF NOT EXISTS "User_createdAt_status_idx" ON "User"("createdAt", "status");
CREATE INDEX IF NOT EXISTS "Subscription_userId_status_expiresAt_createdAt_idx" ON "Subscription"("userId", "status", "expiresAt", "createdAt");
