ALTER TABLE "MarketDataTruthSnapshot" ALTER COLUMN "observedAt" DROP NOT NULL;

CREATE TABLE "ScannerIntelligenceSnapshot" (
  "id" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "scannerVersion" TEXT NOT NULL,
  "riskEngineVersion" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "stage" TEXT NOT NULL,
  "precisionScore" INTEGER NOT NULL,
  "dataTrustScore" INTEGER NOT NULL,
  "truthStatus" TEXT NOT NULL,
  "truthScore" INTEGER NOT NULL,
  "riskStatus" TEXT NOT NULL,
  "riskScore" INTEGER NOT NULL,
  "riskPositionSizeMultiplier" DOUBLE PRECISION NOT NULL,
  "intelligenceStatus" TEXT NOT NULL,
  "intelligenceAllowed" BOOLEAN NOT NULL,
  "executionAllowed" BOOLEAN NOT NULL DEFAULT false,
  "liquidityUsd" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "volume24h" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "spreadBps" DOUBLE PRECISION,
  "priceImpactPct" DOUBLE PRECISION,
  "volatilityPct" DOUBLE PRECISION,
  "reasons" JSONB NOT NULL,
  "riskFlags" JSONB NOT NULL,
  "observedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ScannerIntelligenceSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ScannerIntelligenceSnapshot_marketKey_createdAt_idx" ON "ScannerIntelligenceSnapshot"("marketKey","createdAt");
CREATE INDEX "ScannerIntelligenceSnapshot_status_createdAt_idx" ON "ScannerIntelligenceSnapshot"("status","createdAt");
CREATE INDEX "ScannerIntelligenceSnapshot_riskStatus_createdAt_idx" ON "ScannerIntelligenceSnapshot"("riskStatus","createdAt");
CREATE INDEX "ScannerIntelligenceSnapshot_intelligenceStatus_createdAt_idx" ON "ScannerIntelligenceSnapshot"("intelligenceStatus","createdAt");

CREATE TABLE "MarketRiskSnapshot" (
  "id" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "truthStatus" TEXT NOT NULL,
  "truthScore" INTEGER NOT NULL,
  "riskStatus" TEXT NOT NULL,
  "riskScore" INTEGER NOT NULL,
  "positionSizeMultiplier" DOUBLE PRECISION NOT NULL,
  "liquidityUsd" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "volume24h" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "spreadBps" DOUBLE PRECISION,
  "priceImpactPct" DOUBLE PRECISION,
  "volatilityPct" DOUBLE PRECISION,
  "scannerScore" INTEGER,
  "fundingRatePct" DOUBLE PRECISION,
  "basisPct" DOUBLE PRECISION,
  "openInterestUsd" DOUBLE PRECISION,
  "reasons" JSONB NOT NULL,
  "evidence" JSONB NOT NULL,
  "observedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "MarketRiskSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "MarketRiskSnapshot_marketKey_createdAt_idx" ON "MarketRiskSnapshot"("marketKey","createdAt");
CREATE INDEX "MarketRiskSnapshot_riskStatus_createdAt_idx" ON "MarketRiskSnapshot"("riskStatus","createdAt");
CREATE INDEX "MarketRiskSnapshot_marketType_createdAt_idx" ON "MarketRiskSnapshot"("marketType","createdAt");

CREATE TABLE "IntelligenceControlSnapshot" (
  "id" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "truthAllowed" BOOLEAN NOT NULL,
  "truthStatus" TEXT NOT NULL,
  "truthScore" INTEGER NOT NULL,
  "truthBlockers" JSONB NOT NULL,
  "riskStatus" TEXT NOT NULL,
  "riskScore" INTEGER NOT NULL,
  "riskPositionSizeMultiplier" DOUBLE PRECISION NOT NULL,
  "intelligenceStatus" TEXT NOT NULL,
  "intelligenceAllowed" BOOLEAN NOT NULL,
  "executionAllowed" BOOLEAN NOT NULL DEFAULT false,
  "noOrderSigning" BOOLEAN NOT NULL DEFAULT true,
  "noOrderSubmission" BOOLEAN NOT NULL DEFAULT true,
  "noRouterAuthorization" BOOLEAN NOT NULL DEFAULT true,
  "reasons" JSONB NOT NULL,
  "observedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "IntelligenceControlSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "IntelligenceControlSnapshot_marketKey_createdAt_idx" ON "IntelligenceControlSnapshot"("marketKey","createdAt");
CREATE INDEX "IntelligenceControlSnapshot_intelligenceStatus_createdAt_idx" ON "IntelligenceControlSnapshot"("intelligenceStatus","createdAt");
CREATE INDEX "IntelligenceControlSnapshot_executionAllowed_createdAt_idx" ON "IntelligenceControlSnapshot"("executionAllowed","createdAt");
