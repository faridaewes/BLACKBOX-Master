-- BLACKBOX v11.8 P7 — AI Confirmation / Intelligence Decision Layer
CREATE TABLE "AiConfirmationSnapshot" (
  "id" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "symbol" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "confirmationStrength" INTEGER NOT NULL,
  "direction" TEXT NOT NULL,
  "regime" TEXT NOT NULL,
  "reasons" JSONB NOT NULL,
  "blockers" JSONB NOT NULL,
  "risks" JSONB NOT NULL,
  "invalidation" JSONB NOT NULL,
  "evidenceRefs" JSONB NOT NULL,
  "source" JSONB NOT NULL,
  "contract" JSONB NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AiConfirmationSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "AiConfirmationSnapshot_marketKey_createdAt_idx" ON "AiConfirmationSnapshot"("marketKey", "createdAt");
CREATE INDEX "AiConfirmationSnapshot_status_confirmationStrength_createdAt_idx" ON "AiConfirmationSnapshot"("status", "confirmationStrength", "createdAt");
CREATE INDEX "AiConfirmationSnapshot_marketType_createdAt_idx" ON "AiConfirmationSnapshot"("marketType", "createdAt");

CREATE TABLE "AiConfirmationRun" (
  "id" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "workerId" TEXT NOT NULL,
  "inventoryCount" INTEGER NOT NULL,
  "eligibleCount" INTEGER NOT NULL,
  "confirmedCount" INTEGER NOT NULL,
  "conditionalCount" INTEGER NOT NULL,
  "blockedCount" INTEGER NOT NULL,
  "rejectedCount" INTEGER NOT NULL,
  "status" TEXT NOT NULL,
  "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "completedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AiConfirmationRun_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "AiConfirmationRun_status_startedAt_idx" ON "AiConfirmationRun"("status", "startedAt");
