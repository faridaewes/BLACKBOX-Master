-- BLACKBOX Crypto v6.1.1 baseline schema. Idempotent adoption migration for Railway/VPS.

DO $$ BEGIN CREATE TYPE "Role" AS ENUM ('DEVELOPER','ADMIN','USER'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE "UserStatus" AS ENUM ('PENDING','ACTIVE','SUSPENDED','DISABLED'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE "KycStatus" AS ENUM ('NOT_STARTED','PENDING','REVIEW','APPROVED','REJECTED'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE "BotStatus" AS ENUM ('STOPPED','RUNNING','PAUSED','ERROR','GLOBAL_HALT'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE "AccessStatus" AS ENUM ('ACTIVE','EXPIRED','REVOKED'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE "PositionStatus" AS ENUM ('OPEN','CLOSED'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE "OrderSide" AS ENUM ('BUY','SELL'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE "OrderStatus" AS ENUM ('PENDING','PARTIALLY_FILLED','FILLED','CANCELED','REJECTED'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE "TradingMode" AS ENUM ('DEMO','REAL'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE "ConnectionType" AS ENUM ('CEX','WALLET'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE "ConnectionStatus" AS ENUM ('CONNECTED','DISCONNECTED','REVOKED','ERROR'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS "User" (
  "id" TEXT NOT NULL,
  "email" TEXT NOT NULL,
  "phone" TEXT NOT NULL,
  "passwordHash" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "role" "Role" NOT NULL DEFAULT 'USER',
  "status" "UserStatus" NOT NULL DEFAULT 'PENDING',
  "emailVerifiedAt" TIMESTAMP(3),
  "phoneVerifiedAt" TIMESTAMP(3),
  "mfaEnabled" BOOLEAN NOT NULL DEFAULT false,
  "mfaSecretEnc" TEXT,
  "kycStatus" "KycStatus" NOT NULL DEFAULT 'NOT_STARTED',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "sessionVersion" INTEGER NOT NULL DEFAULT 0,
  CONSTRAINT "User_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "User_email_key" UNIQUE ("email"),
  CONSTRAINT "User_phone_key" UNIQUE ("phone")
);

CREATE TABLE IF NOT EXISTS "VerificationToken" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "channel" TEXT NOT NULL,
  "tokenHash" TEXT NOT NULL,
  "expiresAt" TIMESTAMP(3) NOT NULL,
  "consumedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "VerificationToken_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "VerificationToken_tokenHash_key" UNIQUE ("tokenHash")
);

CREATE INDEX IF NOT EXISTS "VerificationToken_userId_channel_idx" ON "VerificationToken" ("userId","channel");

CREATE INDEX IF NOT EXISTS "VerificationToken_expiresAt_idx" ON "VerificationToken" ("expiresAt");

CREATE TABLE IF NOT EXISTS "KycDocument" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "type" TEXT NOT NULL,
  "storageRef" TEXT NOT NULL,
  "mimeType" TEXT NOT NULL DEFAULT 'application/octet-stream',
  "status" TEXT NOT NULL DEFAULT 'PENDING',
  "note" TEXT,
  "uploadedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "reviewedAt" TIMESTAMP(3),
  "reviewerId" TEXT,
  CONSTRAINT "KycDocument_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "KycDocument_userId_status_idx" ON "KycDocument" ("userId","status");

CREATE TABLE IF NOT EXISTS "KycProfile" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "legalName" TEXT,
  "dob" TIMESTAMP(3),
  "country" TEXT,
  "address" TEXT,
  "documentRef" TEXT,
  "reviewedAt" TIMESTAMP(3),
  "reviewerId" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "KycProfile_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "KycProfile_userId_key" UNIQUE ("userId")
);

CREATE TABLE IF NOT EXISTS "LegalDocument" (
  "id" TEXT NOT NULL,
  "type" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "body" TEXT NOT NULL,
  "active" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "LegalDocument_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "Consent" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "documentId" TEXT NOT NULL,
  "acceptedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "ipHash" TEXT,
  "userAgent" TEXT,
  "metadata" JSONB,
  CONSTRAINT "Consent_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "AccessPlan" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "description" TEXT,
  "active" BOOLEAN NOT NULL DEFAULT true,
  "entitlements" JSONB NOT NULL,
  CONSTRAINT "AccessPlan_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "AccessPlan_name_key" UNIQUE ("name")
);

CREATE TABLE IF NOT EXISTS "AccessCode" (
  "id" TEXT NOT NULL,
  "codeHash" TEXT NOT NULL,
  "displayPrefix" TEXT NOT NULL,
  "planId" TEXT NOT NULL,
  "status" "AccessStatus" NOT NULL DEFAULT 'ACTIVE',
  "startsAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "expiresAt" TIMESTAMP(3) NOT NULL,
  "maxRedemptions" INTEGER NOT NULL DEFAULT 1,
  "redemptionCount" INTEGER NOT NULL DEFAULT 0,
  "complimentary" BOOLEAN NOT NULL DEFAULT false,
  "createdById" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AccessCode_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "AccessCode_codeHash_key" UNIQUE ("codeHash")
);

CREATE TABLE IF NOT EXISTS "CodeRedemption" (
  "id" TEXT NOT NULL,
  "codeId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "redeemedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "CodeRedemption_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "CodeRedemption_codeId_userId_key" UNIQUE ("codeId","userId")
);

CREATE TABLE IF NOT EXISTS "Subscription" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "planId" TEXT NOT NULL,
  "status" "AccessStatus" NOT NULL DEFAULT 'ACTIVE',
  "startsAt" TIMESTAMP(3) NOT NULL,
  "expiresAt" TIMESTAMP(3) NOT NULL,
  "grantedById" TEXT,
  "complimentary" BOOLEAN NOT NULL DEFAULT false,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Subscription_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "Bot" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "status" "BotStatus" NOT NULL DEFAULT 'STOPPED',
  "mode" TEXT NOT NULL DEFAULT 'PAPER',
  "exchangeId" TEXT,
  "config" JSONB NOT NULL,
  "state" JSONB,
  "startedAt" TIMESTAMP(3),
  "stoppedAt" TIMESTAMP(3),
  "executionLockToken" TEXT,
  "executionLockUntil" TIMESTAMP(3),
  CONSTRAINT "Bot_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "Bot_status_idx" ON "Bot" ("status");

CREATE TABLE IF NOT EXISTS "ExchangeAccount" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "label" TEXT NOT NULL,
  "type" "ConnectionType" NOT NULL DEFAULT 'CEX',
  "status" "ConnectionStatus" NOT NULL DEFAULT 'DISCONNECTED',
  "encryptedRef" TEXT,
  "permissions" JSONB NOT NULL,
  "testnet" BOOLEAN NOT NULL DEFAULT false,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "marketType" TEXT NOT NULL DEFAULT 'SPOT',
  "maxLeverage" INTEGER NOT NULL DEFAULT 1,
  "realTradingCertifiedAt" TIMESTAMP(3),
  "certificationVersion" TEXT,
  "lastHealthCheckAt" TIMESTAMP(3),
  CONSTRAINT "ExchangeAccount_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "Wallet" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "chain" TEXT NOT NULL,
  "address" TEXT NOT NULL,
  "connector" TEXT,
  "status" "ConnectionStatus" NOT NULL DEFAULT 'CONNECTED',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Wallet_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "Wallet_userId_chain_address_key" UNIQUE ("userId","chain","address")
);

CREATE TABLE IF NOT EXISTS "Position" (
  "id" TEXT NOT NULL,
  "botId" TEXT NOT NULL,
  "symbol" TEXT NOT NULL,
  "side" "OrderSide" NOT NULL,
  "entryPrice" DOUBLE PRECISION NOT NULL,
  "exitPrice" DOUBLE PRECISION,
  "currentPrice" DOUBLE PRECISION NOT NULL,
  "quantity" DOUBLE PRECISION NOT NULL,
  "stopLoss" DOUBLE PRECISION,
  "takeProfit" DOUBLE PRECISION,
  "pnl" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "status" "PositionStatus" NOT NULL DEFAULT 'OPEN',
  "openedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "closedAt" TIMESTAMP(3),
  "durationSec" INTEGER,
  "closeReason" TEXT,
  "chainId" TEXT,
  "pairAddress" TEXT,
  "dex" TEXT,
  "sizeUsd" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "entryFee" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "liquidityUsd" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "aiScore" INTEGER,
  "rugRisk" INTEGER,
  "openReason" TEXT,
  CONSTRAINT "Position_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "Position_botId_status_idx" ON "Position" ("botId","status");

CREATE TABLE IF NOT EXISTS "Order" (
  "id" TEXT NOT NULL,
  "botId" TEXT NOT NULL,
  "symbol" TEXT NOT NULL,
  "side" "OrderSide" NOT NULL,
  "quantity" DOUBLE PRECISION NOT NULL,
  "filledQuantity" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "averagePrice" DOUBLE PRECISION,
  "price" DOUBLE PRECISION,
  "status" "OrderStatus" NOT NULL DEFAULT 'PENDING',
  "externalId" TEXT,
  "clientOrderId" TEXT,
  "fee" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Order_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "Order_botId_clientOrderId_key" UNIQUE ("botId","clientOrderId")
);

CREATE INDEX IF NOT EXISTS "Order_botId_createdAt_idx" ON "Order" ("botId","createdAt");

CREATE INDEX IF NOT EXISTS "Order_externalId_idx" ON "Order" ("externalId");

CREATE TABLE IF NOT EXISTS "AiCall" (
  "id" TEXT NOT NULL,
  "userId" TEXT,
  "botId" TEXT,
  "provider" TEXT NOT NULL,
  "model" TEXT NOT NULL,
  "latencyMs" INTEGER,
  "inputTokens" INTEGER,
  "outputTokens" INTEGER,
  "estimatedCost" DOUBLE PRECISION,
  "decision" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AiCall_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "AiCall_createdAt_idx" ON "AiCall" ("createdAt");

CREATE TABLE IF NOT EXISTS "AgentLog" (
  "id" TEXT NOT NULL,
  "userId" TEXT,
  "botId" TEXT,
  "stage" TEXT NOT NULL,
  "level" TEXT NOT NULL DEFAULT 'INFO',
  "message" TEXT NOT NULL,
  "metadata" JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AgentLog_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "AgentLog_botId_createdAt_idx" ON "AgentLog" ("botId","createdAt");

CREATE TABLE IF NOT EXISTS "RiskEvent" (
  "id" TEXT NOT NULL,
  "botId" TEXT,
  "type" TEXT NOT NULL,
  "decision" TEXT NOT NULL,
  "reason" TEXT NOT NULL,
  "metadata" JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "RiskEvent_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "Broadcast" (
  "id" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "body" TEXT NOT NULL,
  "priority" TEXT NOT NULL DEFAULT 'NORMAL',
  "audience" JSONB NOT NULL,
  "channels" JSONB NOT NULL,
  "scheduledAt" TIMESTAMP(3),
  "createdById" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Broadcast_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "Notification" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "body" TEXT NOT NULL,
  "priority" TEXT NOT NULL DEFAULT 'NORMAL',
  "readAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Notification_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "SupportTicket" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "category" TEXT NOT NULL,
  "priority" TEXT NOT NULL DEFAULT 'NORMAL',
  "subject" TEXT NOT NULL,
  "body" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'OPEN',
  "handledById" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "SupportTicket_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "SystemControl" (
  "key" TEXT NOT NULL,
  "value" JSONB NOT NULL,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedBy" TEXT,
  CONSTRAINT "SystemControl_pkey" PRIMARY KEY ("key")
);

CREATE TABLE IF NOT EXISTS "AuditLog" (
  "id" TEXT NOT NULL,
  "actorId" TEXT,
  "action" TEXT NOT NULL,
  "targetType" TEXT,
  "targetId" TEXT,
  "metadata" JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "PortfolioSnapshot" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "snapshotDate" TIMESTAMP(3) NOT NULL,
  "period" TEXT NOT NULL,
  "equity" DOUBLE PRECISION NOT NULL,
  "balance" DOUBLE PRECISION NOT NULL,
  "realizedPnl" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "unrealizedPnl" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "pnl" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "pnlPercent" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "drawdown" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "winRate" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "trades" INTEGER NOT NULL DEFAULT 0,
  "winningTrades" INTEGER NOT NULL DEFAULT 0,
  "losingTrades" INTEGER NOT NULL DEFAULT 0,
  "fees" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "PortfolioSnapshot_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "PortfolioSnapshot_userId_snapshotDate_period_key" UNIQUE ("userId","snapshotDate","period")
);

CREATE INDEX IF NOT EXISTS "PortfolioSnapshot_userId_snapshotDate_idx" ON "PortfolioSnapshot" ("userId","snapshotDate");

CREATE TABLE IF NOT EXISTS "PortfolioEvent" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "botId" TEXT,
  "occurredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "type" TEXT NOT NULL,
  "symbol" TEXT,
  "side" "OrderSide",
  "quantity" DOUBLE PRECISION,
  "price" DOUBLE PRECISION,
  "pnl" DOUBLE PRECISION,
  "fee" DOUBLE PRECISION,
  "note" TEXT,
  "metadata" JSONB,
  CONSTRAINT "PortfolioEvent_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "PortfolioEvent_userId_occurredAt_idx" ON "PortfolioEvent" ("userId","occurredAt");

CREATE TABLE IF NOT EXISTS "PortfolioShare" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "tokenHash" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "period" TEXT NOT NULL,
  "fromDate" TIMESTAMP(3) NOT NULL,
  "toDate" TIMESTAMP(3) NOT NULL,
  "equity" DOUBLE PRECISION NOT NULL,
  "pnl" DOUBLE PRECISION NOT NULL,
  "pnlPercent" DOUBLE PRECISION NOT NULL,
  "trades" INTEGER NOT NULL,
  "winRate" DOUBLE PRECISION NOT NULL,
  "showIdentity" BOOLEAN NOT NULL DEFAULT false,
  "expiresAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "PortfolioShare_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "PortfolioShare_tokenHash_key" UNIQUE ("tokenHash")
);

CREATE INDEX IF NOT EXISTS "PortfolioShare_userId_createdAt_idx" ON "PortfolioShare" ("userId","createdAt");

CREATE TABLE IF NOT EXISTS "AdminAssignment" (
  "id" TEXT NOT NULL,
  "adminId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "assignedById" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AdminAssignment_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "AdminAssignment_adminId_userId_key" UNIQUE ("adminId","userId")
);

CREATE INDEX IF NOT EXISTS "AdminAssignment_adminId_createdAt_idx" ON "AdminAssignment" ("adminId","createdAt");

CREATE INDEX IF NOT EXISTS "AdminAssignment_userId_createdAt_idx" ON "AdminAssignment" ("userId","createdAt");

CREATE TABLE IF NOT EXISTS "AdminActivity" (
  "id" TEXT NOT NULL,
  "adminId" TEXT NOT NULL,
  "action" TEXT NOT NULL,
  "module" TEXT NOT NULL,
  "targetType" TEXT,
  "targetId" TEXT,
  "usersHandled" INTEGER NOT NULL DEFAULT 0,
  "metadata" JSONB,
  "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "endedAt" TIMESTAMP(3),
  "lastSeenAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AdminActivity_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "AdminActivity_adminId_lastSeenAt_idx" ON "AdminActivity" ("adminId","lastSeenAt");

CREATE INDEX IF NOT EXISTS "AdminActivity_module_lastSeenAt_idx" ON "AdminActivity" ("module","lastSeenAt");

CREATE TABLE IF NOT EXISTS "UserActivityEvent" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "type" TEXT NOT NULL,
  "path" TEXT,
  "metadata" JSONB,
  "occurredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "UserActivityEvent_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "UserActivityEvent_userId_occurredAt_idx" ON "UserActivityEvent" ("userId","occurredAt");

CREATE INDEX IF NOT EXISTS "UserActivityEvent_type_occurredAt_idx" ON "UserActivityEvent" ("type","occurredAt");

CREATE TABLE IF NOT EXISTS "Signal" (
  "id" TEXT NOT NULL,
  "botId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "symbol" TEXT NOT NULL,
  "action" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "score" INTEGER NOT NULL,
  "confidence" INTEGER NOT NULL,
  "deterministicScore" INTEGER NOT NULL,
  "aiScore" INTEGER,
  "liquidityUsd" DOUBLE PRECISION,
  "rugRisk" INTEGER,
  "regime" TEXT,
  "timeframe" TEXT,
  "entry" DOUBLE PRECISION,
  "stopLoss" DOUBLE PRECISION,
  "takeProfit1" DOUBLE PRECISION,
  "takeProfit2" DOUBLE PRECISION,
  "riskReward" DOUBLE PRECISION,
  "reasons" JSONB,
  "riskFlags" JSONB,
  "lifecycle" TEXT NOT NULL DEFAULT 'CREATED',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "confirmedAt" TIMESTAMP(3),
  "triggeredAt" TIMESTAMP(3),
  "executedAt" TIMESTAMP(3),
  "resolvedAt" TIMESTAMP(3),
  "expiresAt" TIMESTAMP(3),
  "result" TEXT,
  "resultPnl" DOUBLE PRECISION,
  CONSTRAINT "Signal_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "Signal_botId_createdAt_idx" ON "Signal" ("botId","createdAt");

CREATE INDEX IF NOT EXISTS "Signal_userId_createdAt_idx" ON "Signal" ("userId","createdAt");

CREATE INDEX IF NOT EXISTS "Signal_symbol_createdAt_idx" ON "Signal" ("symbol","createdAt");

CREATE INDEX IF NOT EXISTS "Signal_lifecycle_createdAt_idx" ON "Signal" ("lifecycle","createdAt");

CREATE TABLE IF NOT EXISTS "Execution" (
  "id" TEXT NOT NULL,
  "botId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "signalId" TEXT,
  "orderId" TEXT,
  "provider" TEXT NOT NULL,
  "symbol" TEXT NOT NULL,
  "side" "OrderSide" NOT NULL,
  "type" TEXT NOT NULL,
  "quantity" DOUBLE PRECISION NOT NULL,
  "requestedPrice" DOUBLE PRECISION,
  "filledQuantity" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "averagePrice" DOUBLE PRECISION,
  "fee" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "status" TEXT NOT NULL DEFAULT 'PRECHECK',
  "idempotencyKey" TEXT NOT NULL,
  "externalId" TEXT,
  "lastError" TEXT,
  "attempts" INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Execution_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "Execution_idempotencyKey_key" UNIQUE ("idempotencyKey")
);

CREATE INDEX IF NOT EXISTS "Execution_botId_createdAt_idx" ON "Execution" ("botId","createdAt");

CREATE INDEX IF NOT EXISTS "Execution_externalId_idx" ON "Execution" ("externalId");

CREATE INDEX IF NOT EXISTS "Execution_status_updatedAt_idx" ON "Execution" ("status","updatedAt");

CREATE TABLE IF NOT EXISTS "Reconciliation" (
  "id" TEXT NOT NULL,
  "executionId" TEXT,
  "exchangeAccountId" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "balanceSnapshot" JSONB,
  "orderSnapshot" JSONB,
  "fillSnapshot" JSONB,
  "discrepancy" JSONB,
  "error" TEXT,
  "checkedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Reconciliation_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "Reconciliation_exchangeAccountId_checkedAt_idx" ON "Reconciliation" ("exchangeAccountId","checkedAt");

CREATE INDEX IF NOT EXISTS "Reconciliation_executionId_checkedAt_idx" ON "Reconciliation" ("executionId","checkedAt");

CREATE TABLE IF NOT EXISTS "BacktestRun" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "botId" TEXT,
  "symbol" TEXT NOT NULL,
  "timeframe" TEXT NOT NULL,
  "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "finishedAt" TIMESTAMP(3),
  "status" TEXT NOT NULL DEFAULT 'RUNNING',
  "initialCapital" DOUBLE PRECISION NOT NULL,
  "finalCapital" DOUBLE PRECISION,
  "pnl" DOUBLE PRECISION,
  "pnlPercent" DOUBLE PRECISION,
  "trades" INTEGER NOT NULL DEFAULT 0,
  "wins" INTEGER NOT NULL DEFAULT 0,
  "losses" INTEGER NOT NULL DEFAULT 0,
  "maxDrawdown" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "profitFactor" DOUBLE PRECISION,
  "winRate" DOUBLE PRECISION,
  "parameters" JSONB,
  "result" JSONB,
  "error" TEXT,
  CONSTRAINT "BacktestRun_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "BacktestRun_userId_startedAt_idx" ON "BacktestRun" ("userId","startedAt");

CREATE TABLE IF NOT EXISTS "WorkerLease" (
  "id" TEXT NOT NULL,
  "ownerToken" TEXT NOT NULL,
  "expiresAt" TIMESTAMP(3) NOT NULL,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "WorkerLease_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "WorkerLease_ownerToken_key" UNIQUE ("ownerToken")
);

CREATE INDEX IF NOT EXISTS "WorkerLease_expiresAt_idx" ON "WorkerLease"("expiresAt");

DO $$ BEGIN ALTER TABLE "VerificationToken" ADD CONSTRAINT "VerificationToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "KycDocument" ADD CONSTRAINT "KycDocument_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "KycProfile" ADD CONSTRAINT "KycProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "Consent" ADD CONSTRAINT "Consent_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "Consent" ADD CONSTRAINT "Consent_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES "LegalDocument" ("id") ON DELETE RESTRICT ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "AccessCode" ADD CONSTRAINT "AccessCode_planId_fkey" FOREIGN KEY ("planId") REFERENCES "AccessPlan" ("id") ON DELETE RESTRICT ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "CodeRedemption" ADD CONSTRAINT "CodeRedemption_codeId_fkey" FOREIGN KEY ("codeId") REFERENCES "AccessCode" ("id") ON DELETE RESTRICT ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "CodeRedemption" ADD CONSTRAINT "CodeRedemption_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "Subscription" ADD CONSTRAINT "Subscription_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "Subscription" ADD CONSTRAINT "Subscription_planId_fkey" FOREIGN KEY ("planId") REFERENCES "AccessPlan" ("id") ON DELETE RESTRICT ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "Bot" ADD CONSTRAINT "Bot_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "ExchangeAccount" ADD CONSTRAINT "ExchangeAccount_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "Wallet" ADD CONSTRAINT "Wallet_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "Position" ADD CONSTRAINT "Position_botId_fkey" FOREIGN KEY ("botId") REFERENCES "Bot" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "Order" ADD CONSTRAINT "Order_botId_fkey" FOREIGN KEY ("botId") REFERENCES "Bot" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "Notification" ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "SupportTicket" ADD CONSTRAINT "SupportTicket_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "SupportTicket" ADD CONSTRAINT "SupportTicket_handledById_fkey" FOREIGN KEY ("handledById") REFERENCES "User" ("id") ON DELETE RESTRICT ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "AuditLog" ADD CONSTRAINT "AuditLog_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES "User" ("id") ON DELETE RESTRICT ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "PortfolioSnapshot" ADD CONSTRAINT "PortfolioSnapshot_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "PortfolioEvent" ADD CONSTRAINT "PortfolioEvent_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "PortfolioEvent" ADD CONSTRAINT "PortfolioEvent_botId_fkey" FOREIGN KEY ("botId") REFERENCES "Bot" ("id") ON DELETE SET NULL ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "PortfolioShare" ADD CONSTRAINT "PortfolioShare_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "AdminAssignment" ADD CONSTRAINT "AdminAssignment_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "AdminAssignment" ADD CONSTRAINT "AdminAssignment_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "AdminAssignment" ADD CONSTRAINT "AdminAssignment_assignedById_fkey" FOREIGN KEY ("assignedById") REFERENCES "User" ("id") ON DELETE RESTRICT ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "AdminActivity" ADD CONSTRAINT "AdminActivity_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "UserActivityEvent" ADD CONSTRAINT "UserActivityEvent_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "Signal" ADD CONSTRAINT "Signal_botId_fkey" FOREIGN KEY ("botId") REFERENCES "Bot" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "Signal" ADD CONSTRAINT "Signal_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "Execution" ADD CONSTRAINT "Execution_botId_fkey" FOREIGN KEY ("botId") REFERENCES "Bot" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "Execution" ADD CONSTRAINT "Execution_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "Reconciliation" ADD CONSTRAINT "Reconciliation_exchangeAccountId_fkey" FOREIGN KEY ("exchangeAccountId") REFERENCES "ExchangeAccount" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "Reconciliation" ADD CONSTRAINT "Reconciliation_executionId_fkey" FOREIGN KEY ("executionId") REFERENCES "Execution" ("id") ON DELETE SET NULL ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE "BacktestRun" ADD CONSTRAINT "BacktestRun_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
