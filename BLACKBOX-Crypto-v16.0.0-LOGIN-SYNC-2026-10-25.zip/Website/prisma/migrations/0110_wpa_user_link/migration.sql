-- BLACKBOX v11.12.1 — PublicAdvisor WPA user-link migration.
-- Link PublicAdvisor to platform User for WPA role
ALTER TABLE "PublicAdvisor" ADD COLUMN IF NOT EXISTS "userId" TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS "PublicAdvisor_userId_key" ON "PublicAdvisor"("userId");
CREATE INDEX IF NOT EXISTS "PublicAdvisor_userId_idx" ON "PublicAdvisor"("userId");
DO $$ BEGIN
  ALTER TABLE "PublicAdvisor" ADD CONSTRAINT "PublicAdvisor_userId_fkey"
    FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;
