-- BLACKBOX P2: canonical market-data quality / universe gate.
CREATE TABLE "MarketDataQualitySnapshot" (
  "id" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "symbol" TEXT NOT NULL,
  "source" TEXT,
  "qualityScore" INTEGER NOT NULL,
  "status" TEXT NOT NULL,
  "freshnessScore" INTEGER NOT NULL,
  "completenessScore" INTEGER NOT NULL,
  "consistencyScore" INTEGER NOT NULL,
  "latencyScore" INTEGER NOT NULL,
  "liquidityScore" INTEGER NOT NULL,
  "universeEligible" BOOLEAN NOT NULL DEFAULT false,
  "intelligenceAllowed" BOOLEAN NOT NULL DEFAULT false,
  "blockers" JSONB NOT NULL,
  "warnings" JSONB NOT NULL,
  "observedAt" TIMESTAMP(3),
  "capturedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "MarketDataQualitySnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "MarketDataQualitySnapshot_marketKey_capturedAt_idx" ON "MarketDataQualitySnapshot"("marketKey","capturedAt");
CREATE INDEX "MarketDataQualitySnapshot_status_capturedAt_idx" ON "MarketDataQualitySnapshot"("status","capturedAt");
CREATE INDEX "MarketDataQualitySnapshot_marketType_universeEligible_capturedAt_idx" ON "MarketDataQualitySnapshot"("marketType","universeEligible","capturedAt");
CREATE INDEX "MarketDataQualitySnapshot_provider_capturedAt_idx" ON "MarketDataQualitySnapshot"("provider","capturedAt");
