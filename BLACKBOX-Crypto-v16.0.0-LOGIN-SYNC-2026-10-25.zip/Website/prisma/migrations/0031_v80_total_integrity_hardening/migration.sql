DROP INDEX IF EXISTS "PositionFill_executionId_key";
ALTER TABLE "PositionFill" ADD COLUMN IF NOT EXISTS "externalTradeId" TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS "PositionFill_externalTradeId_key" ON "PositionFill"("externalTradeId") WHERE "externalTradeId" IS NOT NULL;
CREATE INDEX IF NOT EXISTS "PositionFill_positionId_executionId_idx" ON "PositionFill"("positionId","executionId");
ALTER TABLE "Signal" ADD COLUMN IF NOT EXISTS "marketObservedAt" TIMESTAMP(3);
CREATE INDEX IF NOT EXISTS "Signal_marketObservedAt_idx" ON "Signal"("marketObservedAt");
