-- BLACKBOX v16.0.0 — DEX autonomous smart-account/session-key architecture.
CREATE TABLE IF NOT EXISTS "DexSmartAccount" (
  "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "walletId" TEXT NOT NULL, "chain" TEXT NOT NULL, "chainId" INTEGER,
  "accountAddress" TEXT NOT NULL, "standard" TEXT NOT NULL DEFAULT 'ERC-4337', "entryPoint" TEXT, "bundlerUrl" TEXT,
  "signerMode" TEXT NOT NULL DEFAULT 'EXTERNAL_SIGNER', "status" TEXT NOT NULL DEFAULT 'PENDING',
  "authorizationTxHash" TEXT, "authorizedAt" TIMESTAMP(3), "lastHealthCheckAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "DexSmartAccount_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "DexSmartAccount_walletId_key" ON "DexSmartAccount"("walletId");
CREATE UNIQUE INDEX IF NOT EXISTS "DexSmartAccount_userId_chain_accountAddress_key" ON "DexSmartAccount"("userId","chain","accountAddress");
CREATE INDEX IF NOT EXISTS "DexSmartAccount_userId_status_idx" ON "DexSmartAccount"("userId","status");
CREATE INDEX IF NOT EXISTS "DexSmartAccount_chain_chainId_status_idx" ON "DexSmartAccount"("chain","chainId","status");
CREATE TABLE IF NOT EXISTS "DexSessionKey" (
  "id" TEXT NOT NULL, "smartAccountId" TEXT NOT NULL, "keyId" TEXT NOT NULL, "publicKey" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'PENDING', "validAfter" TIMESTAMP(3) NOT NULL, "validUntil" TIMESTAMP(3) NOT NULL,
  "maxNotionalUsd" DOUBLE PRECISION, "maxSlippageBps" INTEGER NOT NULL DEFAULT 100, "allowedChains" JSONB NOT NULL,
  "allowedDexes" JSONB NOT NULL, "allowedTargets" JSONB NOT NULL, "allowedMethods" JSONB NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "revokedAt" TIMESTAMP(3), "lastUsedAt" TIMESTAMP(3),
  CONSTRAINT "DexSessionKey_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "DexSessionKey_keyId_key" ON "DexSessionKey"("keyId");
CREATE INDEX IF NOT EXISTS "DexSessionKey_smartAccountId_status_idx" ON "DexSessionKey"("smartAccountId","status");
CREATE INDEX IF NOT EXISTS "DexSessionKey_validUntil_status_idx" ON "DexSessionKey"("validUntil","status");
CREATE TABLE IF NOT EXISTS "DexAutonomousPolicy" (
  "id" TEXT NOT NULL, "smartAccountId" TEXT NOT NULL, "name" TEXT NOT NULL, "enabled" BOOLEAN NOT NULL DEFAULT false,
  "maxOrderNotionalUsd" DOUBLE PRECISION NOT NULL, "maxDailyNotionalUsd" DOUBLE PRECISION NOT NULL, "maxSlippageBps" INTEGER NOT NULL,
  "maxPriceImpactPct" DOUBLE PRECISION NOT NULL, "maxOpenPositions" INTEGER NOT NULL, "stopLossRequired" BOOLEAN NOT NULL DEFAULT true,
  "takeProfitRequired" BOOLEAN NOT NULL DEFAULT true, "allowedChains" JSONB NOT NULL, "allowedDexes" JSONB NOT NULL,
  "allowedRouters" JSONB NOT NULL, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "DexAutonomousPolicy_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "DexAutonomousPolicy_smartAccountId_name_key" ON "DexAutonomousPolicy"("smartAccountId","name");
CREATE INDEX IF NOT EXISTS "DexAutonomousPolicy_smartAccountId_enabled_idx" ON "DexAutonomousPolicy"("smartAccountId","enabled");
ALTER TABLE "DexTradeIntent" ADD COLUMN IF NOT EXISTS "smartAccountId" TEXT;
ALTER TABLE "DexTradeIntent" ADD COLUMN IF NOT EXISTS "userOperation" JSONB;
CREATE INDEX IF NOT EXISTS "DexTradeIntent_smartAccountId_createdAt_idx" ON "DexTradeIntent"("smartAccountId","createdAt");
DO $$ BEGIN ALTER TABLE "DexSmartAccount" ADD CONSTRAINT "DexSmartAccount_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "DexSmartAccount" ADD CONSTRAINT "DexSmartAccount_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES "Wallet"("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "DexSessionKey" ADD CONSTRAINT "DexSessionKey_smartAccountId_fkey" FOREIGN KEY ("smartAccountId") REFERENCES "DexSmartAccount"("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "DexAutonomousPolicy" ADD CONSTRAINT "DexAutonomousPolicy_smartAccountId_fkey" FOREIGN KEY ("smartAccountId") REFERENCES "DexSmartAccount"("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "DexTradeIntent" ADD CONSTRAINT "DexTradeIntent_smartAccountId_fkey" FOREIGN KEY ("smartAccountId") REFERENCES "DexSmartAccount"("id") ON DELETE SET NULL ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
