-- v6.7.1: explicit daily growth delta for History Growth Calendar
ALTER TABLE "PortfolioSnapshot" ADD COLUMN IF NOT EXISTS "growthUsd" DOUBLE PRECISION NOT NULL DEFAULT 0;
ALTER TABLE "PortfolioSnapshot" ADD COLUMN IF NOT EXISTS "growthPercent" DOUBLE PRECISION NOT NULL DEFAULT 0;
