DO $$ BEGIN CREATE TYPE "DeveloperLevel" AS ENUM ('PRINCIPAL','REPRESENTATIVE'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "developerLevel" "DeveloperLevel";
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "accessKilled" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "accessKillReason" TEXT;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "accessKilledAt" TIMESTAMP(3);
UPDATE "User" SET "developerLevel"='PRINCIPAL' WHERE "role"='DEVELOPER' AND "developerLevel" IS NULL;

CREATE TABLE IF NOT EXISTS "AccessTeam" (
  "id" TEXT NOT NULL,
  "code" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "description" TEXT,
  "active" BOOLEAN NOT NULL DEFAULT true,
  "accessKilled" BOOLEAN NOT NULL DEFAULT false,
  "accessKillReason" TEXT,
  "accessKilledAt" TIMESTAMP(3),
  "createdById" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "AccessTeam_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "AccessTeam_code_key" ON "AccessTeam"("code");
CREATE INDEX IF NOT EXISTS "AccessTeam_active_accessKilled_idx" ON "AccessTeam"("active","accessKilled");

CREATE TABLE IF NOT EXISTS "AccessTeamMember" (
  "id" TEXT NOT NULL,
  "teamId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "assignedById" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AccessTeamMember_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "AccessTeamMember_teamId_userId_key" ON "AccessTeamMember"("teamId","userId");
CREATE INDEX IF NOT EXISTS "AccessTeamMember_userId_createdAt_idx" ON "AccessTeamMember"("userId","createdAt");

CREATE TABLE IF NOT EXISTS "UserAccessGrant" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "permissionCode" TEXT NOT NULL,
  "scope" TEXT NOT NULL DEFAULT 'GLOBAL',
  "expiresAt" TIMESTAMP(3),
  "revokedAt" TIMESTAMP(3),
  "reason" TEXT,
  "grantedById" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "UserAccessGrant_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "UserAccessGrant_userId_permissionCode_revokedAt_idx" ON "UserAccessGrant"("userId","permissionCode","revokedAt");

CREATE TABLE IF NOT EXISTS "TeamAccessGrant" (
  "id" TEXT NOT NULL,
  "teamId" TEXT NOT NULL,
  "permissionCode" TEXT NOT NULL,
  "scope" TEXT NOT NULL DEFAULT 'GLOBAL',
  "expiresAt" TIMESTAMP(3),
  "revokedAt" TIMESTAMP(3),
  "reason" TEXT,
  "grantedById" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "TeamAccessGrant_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "TeamAccessGrant_teamId_permissionCode_revokedAt_idx" ON "TeamAccessGrant"("teamId","permissionCode","revokedAt");

CREATE TABLE IF NOT EXISTS "AccessKillEvent" (
  "id" TEXT NOT NULL,
  "actorId" TEXT NOT NULL,
  "targetUserId" TEXT,
  "targetTeamId" TEXT,
  "targetRole" TEXT,
  "action" TEXT NOT NULL,
  "reason" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AccessKillEvent_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "AccessKillEvent_createdAt_idx" ON "AccessKillEvent"("createdAt");
CREATE INDEX IF NOT EXISTS "AccessKillEvent_targetUserId_createdAt_idx" ON "AccessKillEvent"("targetUserId","createdAt");
CREATE INDEX IF NOT EXISTS "AccessKillEvent_targetTeamId_createdAt_idx" ON "AccessKillEvent"("targetTeamId","createdAt");
CREATE INDEX IF NOT EXISTS "AccessKillEvent_targetRole_createdAt_idx" ON "AccessKillEvent"("targetRole","createdAt");

ALTER TABLE "AccessTeam" ADD CONSTRAINT "AccessTeam_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "AccessTeamMember" ADD CONSTRAINT "AccessTeamMember_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES "AccessTeam"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "AccessTeamMember" ADD CONSTRAINT "AccessTeamMember_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "AccessTeamMember" ADD CONSTRAINT "AccessTeamMember_assignedById_fkey" FOREIGN KEY ("assignedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "UserAccessGrant" ADD CONSTRAINT "UserAccessGrant_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "UserAccessGrant" ADD CONSTRAINT "UserAccessGrant_grantedById_fkey" FOREIGN KEY ("grantedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "TeamAccessGrant" ADD CONSTRAINT "TeamAccessGrant_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES "AccessTeam"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "TeamAccessGrant" ADD CONSTRAINT "TeamAccessGrant_grantedById_fkey" FOREIGN KEY ("grantedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "AccessKillEvent" ADD CONSTRAINT "AccessKillEvent_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "AccessKillEvent" ADD CONSTRAINT "AccessKillEvent_targetUserId_fkey" FOREIGN KEY ("targetUserId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

INSERT INTO "AccessTeam" ("id","code","name","description","createdById","updatedAt")
SELECT 'team-customer-support','CUSTOMER_SUPPORT','Customer Support','Live chat dan bantuan teknis user',id,CURRENT_TIMESTAMP FROM "User" WHERE "role"='DEVELOPER' ORDER BY "createdAt" ASC LIMIT 1
ON CONFLICT ("code") DO NOTHING;
INSERT INTO "AccessTeam" ("id","code","name","description","createdById","updatedAt")
SELECT 'team-tier-admin','TIER_ADMIN','Tier Administration','Access code dan tier',id,CURRENT_TIMESTAMP FROM "User" WHERE "role"='DEVELOPER' ORDER BY "createdAt" ASC LIMIT 1
ON CONFLICT ("code") DO NOTHING;
INSERT INTO "AccessTeam" ("id","code","name","description","createdById","updatedAt")
SELECT 'team-audit','AUDIT','Audit','Read-only audit dan export',id,CURRENT_TIMESTAMP FROM "User" WHERE "role"='DEVELOPER' ORDER BY "createdAt" ASC LIMIT 1
ON CONFLICT ("code") DO NOTHING;

INSERT INTO "UserAccessGrant" ("id","userId","permissionCode","scope","grantedById","reason")
SELECT 'legacy-admin-'||u."id",u."id",'ADMIN_LEGACY','GLOBAL',d."id",'Backward-compatible migration; Developer must assign least-privilege team/profile'
FROM "User" u CROSS JOIN LATERAL (SELECT "id" FROM "User" WHERE "role"='DEVELOPER' ORDER BY "createdAt" ASC LIMIT 1) d
WHERE u."role"='ADMIN'
ON CONFLICT ("id") DO NOTHING;

