-- Support category routing + multi-team coverage
ALTER TABLE "AccessTeam" ADD COLUMN IF NOT EXISTS "supportCategories" TEXT[] DEFAULT ARRAY[]::TEXT[];
