CREATE TABLE "MarketIntelligenceRegistry" (
  "id" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "symbol" TEXT,
  "venue" TEXT,
  "version" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "p4Score" INTEGER NOT NULL DEFAULT 0,
  "timeframeCoverage" INTEGER NOT NULL DEFAULT 0,
  "regime" TEXT NOT NULL,
  "regimeScore" INTEGER NOT NULL DEFAULT 0,
  "breakout" BOOLEAN NOT NULL DEFAULT false,
  "doji" BOOLEAN NOT NULL DEFAULT false,
  "liquidityUsd" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "volume24h" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "spreadBps" DOUBLE PRECISION,
  "orderBookScore" INTEGER,
  "derivatives" JSONB,
  "dexPool" JSONB,
  "timeframes" JSONB NOT NULL,
  "timeframeFreshness" JSONB NOT NULL,
  "blockers" JSONB NOT NULL,
  "warnings" JSONB NOT NULL,
  "evidenceComplete" BOOLEAN NOT NULL DEFAULT false,
  "marketPayload" JSONB,
  "lastObservedAt" TIMESTAMP(3),
  "lastCertifiedAt" TIMESTAMP(3),
  "updatedAt" TIMESTAMP(3) NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "MarketIntelligenceRegistry_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "MarketIntelligenceRegistry_marketKey_marketType_provider_key" ON "MarketIntelligenceRegistry"("marketKey","marketType","provider");
CREATE INDEX "MarketIntelligenceRegistry_status_lastCertifiedAt_idx" ON "MarketIntelligenceRegistry"("status","lastCertifiedAt");
CREATE INDEX "MarketIntelligenceRegistry_marketType_provider_status_idx" ON "MarketIntelligenceRegistry"("marketType","provider","status");
CREATE INDEX "MarketIntelligenceRegistry_lastObservedAt_idx" ON "MarketIntelligenceRegistry"("lastObservedAt");
CREATE TABLE "MarketIntelligenceRegistryRun" (
  "id" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "workerId" TEXT NOT NULL,
  "inventoryCount" INTEGER NOT NULL,
  "certifiedCount" INTEGER NOT NULL,
  "blockedCount" INTEGER NOT NULL,
  "providerFailures" JSONB NOT NULL,
  "durationMs" INTEGER NOT NULL,
  "status" TEXT NOT NULL,
  "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "completedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "MarketIntelligenceRegistryRun_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "MarketIntelligenceRegistryRun_status_startedAt_idx" ON "MarketIntelligenceRegistryRun"("status","startedAt");
CREATE TABLE "MarketCoverageAnomaly" (
  "id" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "marketKey" TEXT,
  "anomalyType" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "details" JSONB NOT NULL,
  "detectedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "resolvedAt" TIMESTAMP(3),
  CONSTRAINT "MarketCoverageAnomaly_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "MarketCoverageAnomaly_marketType_provider_detectedAt_idx" ON "MarketCoverageAnomaly"("marketType","provider","detectedAt");
CREATE INDEX "MarketCoverageAnomaly_anomalyType_status_idx" ON "MarketCoverageAnomaly"("anomalyType","status");
