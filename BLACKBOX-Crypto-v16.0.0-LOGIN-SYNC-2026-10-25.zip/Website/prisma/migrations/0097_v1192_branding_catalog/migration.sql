ALTER TABLE "AccessPlan" ADD COLUMN "imageUrl" TEXT;
ALTER TABLE "AccessPlan" ADD COLUMN "imageAlt" TEXT;
