-- BLACKBOX v12.0.9
-- Trading Connection / Readiness UX: persisted latest readiness snapshot per connection.
CREATE TABLE IF NOT EXISTS "ConnectionReadinessSnapshot" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "connectionId" TEXT NOT NULL,
  "connectionType" "ConnectionType" NOT NULL,
  "provider" TEXT NOT NULL,
  "marketType" TEXT,
  "chain" TEXT,
  "state" TEXT NOT NULL,
  "ready" BOOLEAN NOT NULL DEFAULT false,
  "summary" TEXT NOT NULL,
  "observed" JSONB NOT NULL,
  "guidance" JSONB NOT NULL,
  "checkedAt" TIMESTAMP(3) NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ConnectionReadinessSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "ConnectionReadinessSnapshot_connectionId_key" ON "ConnectionReadinessSnapshot"("connectionId");
CREATE INDEX IF NOT EXISTS "ConnectionReadinessSnapshot_userId_connectionType_state_idx" ON "ConnectionReadinessSnapshot"("userId","connectionType","state");
CREATE INDEX IF NOT EXISTS "ConnectionReadinessSnapshot_provider_marketType_chain_checkedAt_idx" ON "ConnectionReadinessSnapshot"("provider","marketType","chain","checkedAt");
DO $$ BEGIN
  ALTER TABLE "ConnectionReadinessSnapshot" ADD CONSTRAINT "ConnectionReadinessSnapshot_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
