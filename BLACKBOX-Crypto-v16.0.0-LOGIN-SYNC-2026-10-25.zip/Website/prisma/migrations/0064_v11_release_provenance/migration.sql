-- BLACKBOX v11.0.0 release provenance evidence; development/hardening only.
CREATE TABLE "ReleaseProvenanceSnapshotV11" (
  "id" TEXT NOT NULL,
  "release" TEXT NOT NULL,
  "environment" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "sourceDigest" TEXT NOT NULL,
  "manifestDigest" TEXT NOT NULL,
  "dependencyDigest" TEXT NOT NULL,
  "evidenceDigest" TEXT NOT NULL,
  "productionCertification" TEXT NOT NULL,
  "tradingAuthorization" TEXT NOT NULL,
  "blockers" JSONB NOT NULL,
  "checks" JSONB NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ReleaseProvenanceSnapshotV11_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ReleaseProvenanceSnapshotV11_release_createdAt_idx" ON "ReleaseProvenanceSnapshotV11"("release", "createdAt");
CREATE INDEX "ReleaseProvenanceSnapshotV11_status_createdAt_idx" ON "ReleaseProvenanceSnapshotV11"("status", "createdAt");
