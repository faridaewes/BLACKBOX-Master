CREATE TABLE "IdempotencyRecord" (
  "id" TEXT NOT NULL,
  "key" TEXT NOT NULL,
  "scope" TEXT NOT NULL,
  "requestHash" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'IN_PROGRESS',
  "response" JSONB,
  "error" TEXT,
  "expiresAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "IdempotencyRecord_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "IdempotencyRecord_key_key" ON "IdempotencyRecord"("key");
CREATE INDEX "IdempotencyRecord_scope_createdAt_idx" ON "IdempotencyRecord"("scope", "createdAt");
CREATE INDEX "IdempotencyRecord_status_updatedAt_idx" ON "IdempotencyRecord"("status", "updatedAt");

CREATE TABLE "ConsistencyCheck" (
  "id" TEXT NOT NULL,
  "scope" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "score" INTEGER NOT NULL DEFAULT 100,
  "checkedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "findings" JSONB NOT NULL,
  "repaired" BOOLEAN NOT NULL DEFAULT false,
  "repairRef" TEXT,
  CONSTRAINT "ConsistencyCheck_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ConsistencyCheck_scope_checkedAt_idx" ON "ConsistencyCheck"("scope", "checkedAt");
CREATE INDEX "ConsistencyCheck_status_checkedAt_idx" ON "ConsistencyCheck"("status", "checkedAt");

CREATE TABLE "ReleaseEvidence" (
  "id" TEXT NOT NULL,
  "release" TEXT NOT NULL,
  "commit" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "manifest" JSONB NOT NULL,
  "sha256" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ReleaseEvidence_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ReleaseEvidence_release_createdAt_idx" ON "ReleaseEvidence"("release", "createdAt");
CREATE INDEX "ReleaseEvidence_commit_idx" ON "ReleaseEvidence"("commit");
