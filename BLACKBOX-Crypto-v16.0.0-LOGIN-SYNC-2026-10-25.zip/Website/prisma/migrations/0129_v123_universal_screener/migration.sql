-- BLACKBOX v12.3.0
CREATE TABLE IF NOT EXISTS "MarketScreenerV123Snapshot" ("id" TEXT NOT NULL,"marketKey" TEXT NOT NULL,"marketType" TEXT NOT NULL,"provider" TEXT NOT NULL,"score" INTEGER NOT NULL,"qualityScore" INTEGER NOT NULL,"trustScore" INTEGER NOT NULL,"riskScore" INTEGER NOT NULL,"status" TEXT NOT NULL,"blockers" JSONB NOT NULL,"capturedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,CONSTRAINT "MarketScreenerV123Snapshot_pkey" PRIMARY KEY ("id"));
CREATE INDEX IF NOT EXISTS "MarketScreenerV123Snapshot_marketType_score_capturedAt_idx" ON "MarketScreenerV123Snapshot"("marketType","score","capturedAt");
CREATE INDEX IF NOT EXISTS "MarketScreenerV123Snapshot_marketKey_capturedAt_idx" ON "MarketScreenerV123Snapshot"("marketKey","capturedAt");
