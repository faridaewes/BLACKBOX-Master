ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "avatarUrl" TEXT;

CREATE TABLE IF NOT EXISTS "DashboardAnnouncement" (
  "id" TEXT NOT NULL, "title" TEXT NOT NULL, "body" TEXT NOT NULL, "imageUrl" TEXT, "linkUrl" TEXT,
  "active" BOOLEAN NOT NULL DEFAULT true, "priority" INTEGER NOT NULL DEFAULT 0, "startsAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "endsAt" TIMESTAMP(3), "createdById" TEXT NOT NULL, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "DashboardAnnouncement_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "DashboardAnnouncement_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS "DashboardAnnouncement_active_startsAt_endsAt_priority_idx" ON "DashboardAnnouncement"("active","startsAt","endsAt","priority");

CREATE TABLE IF NOT EXISTS "PublicAdvisor" (
  "id" TEXT NOT NULL, "name" TEXT NOT NULL, "title" TEXT NOT NULL, "licenseNumber" TEXT, "company" TEXT, "photoUrl" TEXT, "bio" TEXT NOT NULL,
  "phone" TEXT, "whatsapp" TEXT, "telegram" TEXT, "active" BOOLEAN NOT NULL DEFAULT true, "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "createdById" TEXT NOT NULL, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "PublicAdvisor_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "PublicAdvisor_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS "PublicAdvisor_active_sortOrder_idx" ON "PublicAdvisor"("active","sortOrder");

CREATE TABLE IF NOT EXISTS "PointDeposit" (
  "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "amount" INTEGER NOT NULL, "referenceId" TEXT NOT NULL, "description" TEXT NOT NULL,
  "createdById" TEXT NOT NULL, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "PointDeposit_pkey" PRIMARY KEY ("id"), CONSTRAINT "PointDeposit_referenceId_key" UNIQUE ("referenceId"),
  CONSTRAINT "PointDeposit_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "PointDeposit_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS "PointDeposit_userId_createdAt_idx" ON "PointDeposit"("userId","createdAt");
