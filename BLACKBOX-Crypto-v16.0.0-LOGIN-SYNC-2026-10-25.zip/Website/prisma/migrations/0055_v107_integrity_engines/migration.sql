CREATE TABLE IF NOT EXISTS "TruthEngineSnapshot" (
  "id" TEXT NOT NULL, "scope" TEXT NOT NULL, "status" TEXT NOT NULL, "score" INTEGER NOT NULL,
  "blockers" JSONB NOT NULL, "warnings" JSONB NOT NULL, "mismatches" JSONB NOT NULL,
  "capturedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "TruthEngineSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "TruthEngineSnapshot_scope_capturedAt_idx" ON "TruthEngineSnapshot"("scope","capturedAt");
CREATE INDEX IF NOT EXISTS "TruthEngineSnapshot_status_capturedAt_idx" ON "TruthEngineSnapshot"("status","capturedAt");
CREATE TABLE IF NOT EXISTS "SafetyCircuitBreakerEvent" (
  "id" TEXT NOT NULL, "scope" TEXT NOT NULL, "state" TEXT NOT NULL, "blockers" JSONB NOT NULL,
  "warnings" JSONB NOT NULL, "reason" TEXT, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "SafetyCircuitBreakerEvent_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "SafetyCircuitBreakerEvent_scope_createdAt_idx" ON "SafetyCircuitBreakerEvent"("scope","createdAt");
CREATE INDEX IF NOT EXISTS "SafetyCircuitBreakerEvent_state_createdAt_idx" ON "SafetyCircuitBreakerEvent"("state","createdAt");
CREATE TABLE IF NOT EXISTS "MarketRegimeSnapshot" (
  "id" TEXT NOT NULL, "marketKey" TEXT NOT NULL, "regime" TEXT NOT NULL, "qualityScore" INTEGER NOT NULL,
  "usable" BOOLEAN NOT NULL, "blockers" JSONB NOT NULL, "warnings" JSONB NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "MarketRegimeSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "MarketRegimeSnapshot_marketKey_createdAt_idx" ON "MarketRegimeSnapshot"("marketKey","createdAt");
CREATE TABLE IF NOT EXISTS "AiDecisionReplay" (
  "id" TEXT NOT NULL, "decisionId" TEXT NOT NULL, "originalScore" INTEGER NOT NULL, "replayScore" INTEGER NOT NULL,
  "scoreDelta" INTEGER NOT NULL, "confidenceDelta" DOUBLE PRECISION NOT NULL, "changed" BOOLEAN NOT NULL,
  "reasons" JSONB NOT NULL, "evidenceHash" TEXT NOT NULL, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AiDecisionReplay_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "AiDecisionReplay_decisionId_createdAt_idx" ON "AiDecisionReplay"("decisionId","createdAt");
CREATE TABLE IF NOT EXISTS "AiFailureObservation" (
  "id" TEXT NOT NULL, "decisionId" TEXT, "symbol" TEXT NOT NULL, "failureClass" TEXT NOT NULL,
  "severity" TEXT NOT NULL, "pnl" DOUBLE PRECISION, "evidence" JSONB NOT NULL,
  "occurredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AiFailureObservation_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "AiFailureObservation_symbol_occurredAt_idx" ON "AiFailureObservation"("symbol","occurredAt");
CREATE INDEX IF NOT EXISTS "AiFailureObservation_failureClass_occurredAt_idx" ON "AiFailureObservation"("failureClass","occurredAt");
CREATE TABLE IF NOT EXISTS "DigitalTradingTwinRun" (
  "id" TEXT NOT NULL, "name" TEXT NOT NULL, "marketKey" TEXT, "status" TEXT NOT NULL,
  "bars" INTEGER NOT NULL, "orders" INTEGER NOT NULL, "filled" INTEGER NOT NULL, "rejected" INTEGER NOT NULL,
  "totalFees" DOUBLE PRECISION NOT NULL, "avgSlippageBps" DOUBLE PRECISION NOT NULL, "config" JSONB NOT NULL,
  "result" JSONB, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "DigitalTradingTwinRun_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "DigitalTradingTwinRun_createdAt_idx" ON "DigitalTradingTwinRun"("createdAt");
CREATE INDEX IF NOT EXISTS "DigitalTradingTwinRun_marketKey_createdAt_idx" ON "DigitalTradingTwinRun"("marketKey","createdAt");
