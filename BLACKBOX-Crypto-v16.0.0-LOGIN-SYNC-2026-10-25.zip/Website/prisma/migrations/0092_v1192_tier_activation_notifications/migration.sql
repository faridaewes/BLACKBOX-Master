ALTER TABLE "Notification" ADD COLUMN "eventKey" TEXT;
CREATE UNIQUE INDEX "Notification_eventKey_key" ON "Notification"("eventKey");
CREATE INDEX "Notification_userId_createdAt_idx" ON "Notification"("userId", "createdAt");

CREATE TABLE "TierActivationDelivery" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "subscriptionId" TEXT NOT NULL,
  "source" TEXT NOT NULL,
  "eventKey" TEXT NOT NULL,
  "tier" TEXT NOT NULL,
  "pointsSpent" INTEGER,
  "startsAt" TIMESTAMP(3) NOT NULL,
  "expiresAt" TIMESTAMP(3) NOT NULL,
  "balanceAfter" INTEGER,
  "dashboardStatus" TEXT NOT NULL DEFAULT 'PENDING',
  "emailStatus" TEXT NOT NULL DEFAULT 'PENDING',
  "emailError" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "TierActivationDelivery_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "TierActivationDelivery_eventKey_key" ON "TierActivationDelivery"("eventKey");
CREATE INDEX "TierActivationDelivery_userId_createdAt_idx" ON "TierActivationDelivery"("userId", "createdAt");
CREATE INDEX "TierActivationDelivery_subscriptionId_idx" ON "TierActivationDelivery"("subscriptionId");
ALTER TABLE "TierActivationDelivery" ADD CONSTRAINT "TierActivationDelivery_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "TierActivationDelivery" ADD CONSTRAINT "TierActivationDelivery_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES "Subscription"("id") ON DELETE CASCADE ON UPDATE CASCADE;
