ALTER TABLE "Wallet" ADD COLUMN IF NOT EXISTS "chainId" INTEGER;
ALTER TABLE "WalletChallenge" ADD COLUMN IF NOT EXISTS "chainId" INTEGER;
CREATE INDEX IF NOT EXISTS "Wallet_chainId_idx" ON "Wallet"("chainId");
CREATE INDEX IF NOT EXISTS "WalletChallenge_chainId_idx" ON "WalletChallenge"("chainId");
