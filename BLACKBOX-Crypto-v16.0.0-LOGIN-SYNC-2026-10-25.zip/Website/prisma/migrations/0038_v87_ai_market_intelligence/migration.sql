CREATE TABLE "AiMarketIntelligenceSnapshot" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "bias" TEXT NOT NULL,
  "confidence" INTEGER NOT NULL,
  "what" TEXT NOT NULL,
  "why" JSONB NOT NULL,
  "invalidation" JSONB NOT NULL,
  "risks" JSONB NOT NULL,
  "missingData" JSONB NOT NULL,
  "monitor" JSONB NOT NULL,
  "evidence" JSONB NOT NULL,
  "resultHash" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AiMarketIntelligenceSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "AiMarketIntelligenceSnapshot_userId_createdAt_idx" ON "AiMarketIntelligenceSnapshot"("userId", "createdAt");
CREATE INDEX "AiMarketIntelligenceSnapshot_marketKey_createdAt_idx" ON "AiMarketIntelligenceSnapshot"("marketKey", "createdAt");
CREATE INDEX "AiMarketIntelligenceSnapshot_status_createdAt_idx" ON "AiMarketIntelligenceSnapshot"("status", "createdAt");
CREATE INDEX "AiMarketIntelligenceSnapshot_resultHash_idx" ON "AiMarketIntelligenceSnapshot"("resultHash");
ALTER TABLE "AiMarketIntelligenceSnapshot" ADD CONSTRAINT "AiMarketIntelligenceSnapshot_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
