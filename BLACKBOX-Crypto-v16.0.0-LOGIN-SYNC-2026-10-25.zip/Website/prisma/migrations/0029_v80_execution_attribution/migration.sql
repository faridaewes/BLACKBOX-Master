ALTER TABLE "Position" ADD COLUMN IF NOT EXISTS "maxFavorablePrice" DOUBLE PRECISION;
ALTER TABLE "Position" ADD COLUMN IF NOT EXISTS "maxAdversePrice" DOUBLE PRECISION;

CREATE TABLE IF NOT EXISTS "PositionFill" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "positionId" TEXT NOT NULL,
  "executionId" TEXT UNIQUE,
  "sourceKey" TEXT NOT NULL UNIQUE,
  "role" TEXT NOT NULL,
  "quantity" DOUBLE PRECISION NOT NULL,
  "benchmarkPrice" DOUBLE PRECISION,
  "fillPrice" DOUBLE PRECISION NOT NULL,
  "fee" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "slippageBps" DOUBLE PRECISION,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "PositionFill_positionId_fkey" FOREIGN KEY ("positionId") REFERENCES "Position"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "PositionFill_executionId_fkey" FOREIGN KEY ("executionId") REFERENCES "Execution"("id") ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS "PositionFill_positionId_role_createdAt_idx" ON "PositionFill"("positionId","role","createdAt");
CREATE INDEX IF NOT EXISTS "PositionFill_executionId_idx" ON "PositionFill"("executionId");
