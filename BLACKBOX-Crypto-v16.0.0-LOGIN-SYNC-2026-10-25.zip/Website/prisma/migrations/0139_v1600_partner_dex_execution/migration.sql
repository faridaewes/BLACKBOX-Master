-- BLACKBOX v16.0.0
-- Partner transfer cooldown + DEX live execution intent ledger.
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "partnerTransferLastAt" TIMESTAMP(3);
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "partnerTransferNextAt" TIMESTAMP(3);
CREATE INDEX IF NOT EXISTS "User_partnerTransferNextAt_idx" ON "User"("partnerTransferNextAt");

ALTER TABLE "Signal" ADD COLUMN IF NOT EXISTS "chain" TEXT;
ALTER TABLE "Signal" ADD COLUMN IF NOT EXISTS "dex" TEXT;
ALTER TABLE "Signal" ADD COLUMN IF NOT EXISTS "pairAddress" TEXT;
ALTER TABLE "Signal" ADD COLUMN IF NOT EXISTS "baseTokenAddress" TEXT;
ALTER TABLE "Signal" ADD COLUMN IF NOT EXISTS "quoteTokenAddress" TEXT;
CREATE INDEX IF NOT EXISTS "Signal_chain_dex_pairAddress_idx" ON "Signal"("chain","dex","pairAddress");

CREATE TABLE IF NOT EXISTS "DexTradeIntent" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "botId" TEXT NOT NULL,
  "signalId" TEXT,
  "walletId" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "chain" TEXT NOT NULL,
  "chainId" INTEGER,
  "dex" TEXT,
  "pairAddress" TEXT,
  "symbol" TEXT NOT NULL,
  "side" "OrderSide" NOT NULL,
  "sellToken" TEXT NOT NULL,
  "buyToken" TEXT NOT NULL,
  "sellAmountBaseUnits" TEXT NOT NULL,
  "expectedBuyAmountBaseUnits" TEXT,
  "minBuyAmountBaseUnits" TEXT,
  "slippageBps" INTEGER NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'PREPARED',
  "transactionTo" TEXT,
  "transactionData" TEXT,
  "transactionValue" TEXT,
  "unsignedTransaction" TEXT,
  "signature" TEXT,
  "txHash" TEXT,
  "externalStatus" TEXT,
  "quoteEvidence" JSONB,
  "fillEvidence" JSONB,
  "error" TEXT,
  "correlationId" TEXT NOT NULL,
  "preparedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "expiresAt" TIMESTAMP(3),
  "signedAt" TIMESTAMP(3),
  "submittedAt" TIMESTAMP(3),
  "confirmedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "DexTradeIntent_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "DexTradeIntent_correlationId_key" UNIQUE ("correlationId"),
  CONSTRAINT "DexTradeIntent_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "DexTradeIntent_botId_fkey" FOREIGN KEY ("botId") REFERENCES "Bot"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "DexTradeIntent_signalId_fkey" FOREIGN KEY ("signalId") REFERENCES "Signal"("id") ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT "DexTradeIntent_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES "Wallet"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS "DexTradeIntent_userId_status_createdAt_idx" ON "DexTradeIntent"("userId","status","createdAt");
CREATE INDEX IF NOT EXISTS "DexTradeIntent_botId_createdAt_idx" ON "DexTradeIntent"("botId","createdAt");
CREATE INDEX IF NOT EXISTS "DexTradeIntent_walletId_status_createdAt_idx" ON "DexTradeIntent"("walletId","status","createdAt");
CREATE INDEX IF NOT EXISTS "DexTradeIntent_txHash_idx" ON "DexTradeIntent"("txHash");
