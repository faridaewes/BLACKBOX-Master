-- BLACKBOX v12.0.5
-- Trading Rules + Exchange/Wallet Connection Authorization + Legal Evidence Hardening

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1205_01_terms','TERMS','v12.0.5','Syarat Penggunaan BLACKBOX Technology','BLACKBOX Technology / BLACKBOX Crypto adalah platform teknologi pendukung aktivitas trader. Platform ini membantu pengguna memperoleh informasi pasar, analisis, edukasi, simulasi, pengaturan dan pemantauan bot, pencatatan aktivitas, serta integrasi dengan layanan pihak ketiga yang dipilih pengguna. BLACKBOX bukan tempat penyimpanan dana nasabah, bukan kustodian, dan tidak menghimpun, menerima, menyimpan, menguasai, atau mengelola dana maupun aset pengguna untuk kepentingan transaksi. BLACKBOX juga tidak menjamin keuntungan, win rate, tingkat keberhasilan, pendapatan, atau hasil trading tertentu.

Seluruh kendali atas akun, koneksi pihak ketiga, parameter trading, modal, batas risiko, persetujuan order, dan keputusan transaksi tetap berada pada pengguna. BLACKBOX dan komponen AI tidak boleh memperluas mandat, menaikkan risiko, mengganti parameter material, atau mengambil keputusan di luar ruang lingkup yang secara aktif dipilih dan disetujui pengguna melalui konfigurasi, agreement, dan control yang tersedia. Pengguna wajib memahami setiap instruksi yang diberikan, memeriksa konfigurasi sebelum menjalankan bot, dan menggunakan hanya dana yang secara finansial mampu ditanggung risikonya. Trading aset kripto, derivatif, valuta asing, dan instrumen berisiko lainnya dapat menyebabkan kerugian nyata, termasuk kehilangan sebagian atau seluruh dana yang digunakan.

Untuk fitur atau layanan BLACKBOX yang secara eksplisit terhubung dengan layanan Penasihat Berjangka PT Alma Indonesia Raya, pengguna wajib menyelesaikan pendaftaran/registrasi, verifikasi, dan penerimaan dokumen layanan PT Alma Indonesia Raya melalui kanal resminya sebelum menggunakan fitur yang mensyaratkan hubungan tersebut. Akun BLACKBOX tidak dengan sendirinya menjadikan seseorang sebagai klien Penasihat Berjangka PT Alma Indonesia Raya dan tidak menggantikan perjanjian, kewajiban, atau persetujuan yang harus dibuat dengan PT Alma Indonesia Raya.

Kerugian trading yang timbul dari keputusan pengguna, kondisi pasar, leverage, slippage, partial fill, rejection, latency, biaya, likuiditas, gangguan jaringan, blockchain, exchange/provider, atau kegagalan teknologi tidak merupakan jaminan atau kewajiban penggantian oleh BLACKBOX. Namun, tidak ada klausul dalam disclaimer ini yang dimaksudkan untuk menghapus, membatasi, atau mengesampingkan hak pengguna atau tanggung jawab pihak mana pun yang menurut hukum wajib tetap berlaku. Pengguna tetap memiliki hak untuk menyampaikan pengaduan dan menggunakan mekanisme penyelesaian sengketa yang tersedia berdasarkan hukum yang berlaku.

Gunakan BLACKBOX dan layanan terkait hanya melalui kanal resmi. Jangan memberikan password, OTP, seed phrase, private key, atau secret credential kepada siapa pun.

BLACKBOX berfungsi sebagai perangkat lunak/platform teknologi pendukung. Pengguna tetap menjadi pihak yang menentukan apakah, kapan, dan dengan parameter apa akun digunakan. TRADING RULES & USER CONTROL AGREEMENT serta CONNECTION AUTHORIZATION AGREEMENT merupakan bagian dari kerangka persetujuan operasional BLACKBOX untuk aktivitas trading dan koneksi pihak ketiga. Integrasi exchange, broker, wallet, AI provider, data provider, atau layanan pihak ketiga tunduk pada syarat dan ketentuan pihak tersebut. BLACKBOX tidak menggantikan perjanjian dengan pihak ketiga dan tidak menjanjikan ketersediaan atau hasil transaksi.

Untuk layanan yang memerlukan hubungan dengan Penasihat Berjangka PT Alma Indonesia Raya, pengguna wajib mengikuti proses resmi PT Alma Indonesia Raya. Jika suatu fitur memerlukan status klien/registrasi pada PT Alma Indonesia Raya, BLACKBOX wajib menahan akses sampai persyaratan tersebut terverifikasi.

Persetujuan ini merupakan pernyataan bahwa pengguna telah membaca, memahami, dan secara sadar menyetujui isi dokumen pada versi yang tercantum pada saat persetujuan. Persetujuan tidak merupakan pelepasan hak hukum yang tidak dapat dikesampingkan dan tidak mengubah kewajiban pihak mana pun berdasarkan peraturan perundang-undangan.','2a17832de94f8a4b70461b7674d7df0198b9af3e8c33bf491b2bc52f40e677aa',true,'PUBLISHED','v12.0.5 Trading Rules + connection authorization hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1205_02_privacy','PRIVACY','v12.0.5','Kebijakan Privasi dan Bukti Persetujuan BLACKBOX','BLACKBOX memproses data pribadi untuk pembuatan dan pengamanan akun, verifikasi, penyediaan fitur, pencatatan persetujuan, audit, dukungan, pencegahan penyalahgunaan, keamanan sistem, kepatuhan, dan kewajiban hukum. Pemrosesan dilakukan secara terbatas, relevan, transparan, dan sesuai tujuan yang diberitahukan.

Untuk menjaga bukti persetujuan, sistem dapat menyimpan snapshot identitas yang relevan, versi dan hash dokumen, snapshot isi dokumen saat disetujui, waktu UTC, waktu lokal berdasarkan zona waktu yang dikirim perangkat, locale, sumber persetujuan, user-agent, hash alamat IP, konteks fitur, metode persetujuan, teks acknowledgement, dan metadata teknis yang diperlukan. Password, OTP, seed phrase, private key, dan API secret tidak dicatat sebagai isi persetujuan.

Bukti persetujuan bersifat audit evidence dan tidak boleh diubah secara diam-diam. Jika dokumen diperbarui, sistem menerbitkan versi baru; persetujuan lama tetap disimpan sebagai histori sesuai kewajiban retensi. Akses staf dibatasi berdasarkan role/permission dan setiap pencarian maupun ekspor agreement dicatat dalam audit log. Pengguna dapat mengunduh bukti persetujuannya sendiri melalui Legal & Agreement Center, dengan tetap memperhatikan kewajiban penyimpanan berdasarkan hukum yang berlaku.

Persetujuan ini merupakan pernyataan bahwa pengguna telah membaca, memahami, dan secara sadar menyetujui isi dokumen pada versi yang tercantum pada saat persetujuan. Persetujuan tidak merupakan pelepasan hak hukum yang tidak dapat dikesampingkan dan tidak mengubah kewajiban pihak mana pun berdasarkan peraturan perundang-undangan.','e30f226f9e0ccfc6ab790e433bc31a81f5a649388efd9f14d310711f5888d0ff',true,'PUBLISHED','v12.0.5 Trading Rules + connection authorization hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1205_03_risk','RISK','v12.0.5','Pemberitahuan Risiko Perdagangan dan Penggunaan BLACKBOX','Trading aset kripto, derivatif, valuta asing, dan/atau instrumen berisiko lainnya memiliki risiko tinggi. Harga dapat bergerak cepat dan pengguna dapat kehilangan sebagian atau seluruh modal yang digunakan. Tidak ada jaminan keuntungan, win rate, pendapatan, tingkat keberhasilan, atau hasil tertentu.

Bot, AI, automation, router, signal, backtest, dan teknologi pendukung tidak menghilangkan risiko. Kesalahan konfigurasi, data yang tidak akurat, keterlambatan, slippage, partial fill, rejection, biaya, likuiditas, leverage, gangguan koneksi, blockchain, exchange/provider, perubahan kebijakan, maupun kondisi pasar ekstrem dapat menyebabkan kerugian nyata.

Pengguna wajib memeriksa modal, market, pair, leverage bila berlaku, ukuran posisi, stop loss/take profit, daily loss, drawdown, max positions, biaya, koneksi, dan parameter lain sebelum memberikan instruksi. Pengguna memahami bahwa hasil aktual dapat berbeda dari simulasi, backtest, sinyal, AI, atau ekspektasi sebelumnya. Risiko finansial dari keputusan trading berada pada pengguna sesuai penggunaan dan instruksi akunnya, tanpa menghapus tanggung jawab hukum pihak mana pun yang memang wajib menurut hukum.

Persetujuan ini merupakan pernyataan bahwa pengguna telah membaca, memahami, dan secara sadar menyetujui isi dokumen pada versi yang tercantum pada saat persetujuan. Persetujuan tidak merupakan pelepasan hak hukum yang tidak dapat dikesampingkan dan tidak mengubah kewajiban pihak mana pun berdasarkan peraturan perundang-undangan.','fe1b742787b6a71c7ad369e4392d7dd40ba5d5a13e00169d91b9d35c04f69a61',true,'PUBLISHED','v12.0.5 Trading Rules + connection authorization hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1205_04_bot_start','BOT_START','v12.0.5','Persetujuan Pengaturan dan Menjalankan Bot','Sebelum menekan START, pengguna wajib membaca dan memahami Syarat Penggunaan, Kebijakan Privasi, Pemberitahuan Risiko, dan ketentuan bot. Pengguna wajib memeriksa mode, market, pair, koneksi, modal, ukuran posisi, stop loss/take profit, daily loss, drawdown, max positions, biaya, dan parameter lain yang ditampilkan.

DEMO/PAPER menggunakan modal virtual. REAL, apabila seluruh gate produksi terpenuhi, dapat berdampak pada dana nyata pada akun pihak ketiga. Tidak ada jaminan bot akan menghasilkan profit, mencapai win rate tertentu, atau mencegah kerugian.

START hanya boleh diterima jika persetujuan eksplisit telah diberikan. Server mencatat versi dokumen, hash dokumen, identitas pengguna, waktu persetujuan, konteks, dan bukti teknis. Untuk REAL, persetujuan ini tidak menggantikan gate verifikasi, otorisasi, sertifikasi, keamanan, risk control, dan kesiapan produksi.

Persetujuan ini merupakan pernyataan bahwa pengguna telah membaca, memahami, dan secara sadar menyetujui isi dokumen pada versi yang tercantum pada saat persetujuan. Persetujuan tidak merupakan pelepasan hak hukum yang tidak dapat dikesampingkan dan tidak mengubah kewajiban pihak mana pun berdasarkan peraturan perundang-undangan.','6b62ff9f3448a441e25192ba23b8982b9a56afb4e4d136e0f9a96ad517c62afe',true,'PUBLISHED','v12.0.5 Trading Rules + connection authorization hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1205_05_bot_configuration','BOT_CONFIGURATION','v12.0.5','Persetujuan Perubahan Konfigurasi Bot','Setiap perubahan material pada konfigurasi bot dapat mengubah perilaku, risiko, eksposur, biaya, atau hasil trading. Sebelum menyimpan perubahan material, pengguna wajib memeriksa kembali modal, market, pair, chain, koneksi, AI provider/model, guardrail, risiko per trade, drawdown, stop loss/take profit, daily loss, max positions, dan parameter relevan lainnya.

Pengguna memahami bahwa perubahan konfigurasi merupakan keputusan pengguna dan tidak menjamin keuntungan atau mencegah kerugian. Perubahan material harus melewati server-side safety gate dan dicatat bersama versi persetujuan yang relevan.

Persetujuan ini merupakan pernyataan bahwa pengguna telah membaca, memahami, dan secara sadar menyetujui isi dokumen pada versi yang tercantum pada saat persetujuan. Persetujuan tidak merupakan pelepasan hak hukum yang tidak dapat dikesampingkan dan tidak mengubah kewajiban pihak mana pun berdasarkan peraturan perundang-undangan.','bde8334cab50f33e84c0f404f9fbcbd5dcfd5ebf0032a0dae053abf218351c23',true,'PUBLISHED','v12.0.5 Trading Rules + connection authorization hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1205_06_setup_step','SETUP_STEP','v12.0.5','Persetujuan Setup Bot','Pengguna menyatakan telah meninjau konfigurasi awal bot sebelum bot dibuat atau diluncurkan, termasuk mode, modal virtual/nyata, market, pair, chain, AI provider/model, guardrail, batas posisi, stop loss/take profit, daily loss, drawdown, dan parameter lain yang ditampilkan.

DEMO/PAPER menggunakan modal virtual. Tidak ada jaminan keuntungan. Setiap penggunaan REAL tetap tunduk pada gate produksi dan persetujuan REAL yang terpisah.

Persetujuan ini merupakan pernyataan bahwa pengguna telah membaca, memahami, dan secara sadar menyetujui isi dokumen pada versi yang tercantum pada saat persetujuan. Persetujuan tidak merupakan pelepasan hak hukum yang tidak dapat dikesampingkan dan tidak mengubah kewajiban pihak mana pun berdasarkan peraturan perundang-undangan.','c47fa4aa8ebe029c469cc9c713c8a0590cfb39ee37e5700c32d0f5d9504e799c',true,'PUBLISHED','v12.0.5 Trading Rules + connection authorization hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1205_07_real_execution','REAL_EXECUTION','v12.0.5','Persetujuan Eksekusi REAL','Dengan mengaktifkan atau memberikan instruksi eksekusi REAL, pengguna menyatakan telah memahami bahwa transaksi dapat menghasilkan keuntungan maupun kerugian nyata, termasuk kemungkinan kehilangan sebagian atau seluruh dana yang digunakan. Pengguna wajib memastikan akun pihak ketiga, izin trade, simbol, arah transaksi, ukuran posisi, leverage jika berlaku, dan parameter order sudah benar.

Pengguna memahami bahwa BLACKBOX tidak menjamin hasil, tidak menjamin order selalu berhasil, dan tidak menjamin kerugian dapat dicegah. Eksekusi hanya boleh berlangsung apabila seluruh persyaratan keamanan, otorisasi, kepatuhan, sertifikasi, dan kesiapan produksi terpenuhi. Kerugian yang timbul semata-mata dari risiko pasar atau keputusan pengguna bukan merupakan jaminan tanggung jawab penggantian oleh BLACKBOX; ketentuan ini tidak menghapus tanggung jawab yang tidak dapat dikesampingkan menurut hukum.

Persetujuan ini merupakan pernyataan bahwa pengguna telah membaca, memahami, dan secara sadar menyetujui isi dokumen pada versi yang tercantum pada saat persetujuan. Persetujuan tidak merupakan pelepasan hak hukum yang tidak dapat dikesampingkan dan tidak mengubah kewajiban pihak mana pun berdasarkan peraturan perundang-undangan.','d781dfb6a0275c3746dbec0446a2739f51f3b89056c78a327a1da6f7ee412d6c',true,'PUBLISHED','v12.0.5 Trading Rules + connection authorization hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1205_08_registration','REGISTRATION','v12.0.5','Persetujuan Registrasi BLACKBOX','Pengguna menyatakan data registrasi yang diberikan benar, akurat, lengkap, dan diberikan dengan kewenangan yang sah. Pengguna memahami BLACKBOX adalah platform teknologi pendukung dan bukan dengan sendirinya merupakan Penasihat Berjangka, Pedagang Aset Keuangan Digital, kustodian, pengelola dana, atau pihak berizin lain.

Pengguna menyatakan telah membaca Syarat Penggunaan, Kebijakan Privasi, Pemberitahuan Risiko, dan memahami bahwa trading dapat menyebabkan kerugian nyata. Pendaftaran akun BLACKBOX tidak berarti dana pengguna diserahkan kepada BLACKBOX.

Jika fitur yang dipilih membutuhkan hubungan dengan PT Alma Indonesia Raya, pengguna wajib menyelesaikan proses registrasi, verifikasi, dan penerimaan perjanjian pada PT Alma Indonesia Raya melalui kanal resmi sebelum fitur tersebut dapat digunakan.

Persetujuan ini merupakan pernyataan bahwa pengguna telah membaca, memahami, dan secara sadar menyetujui isi dokumen pada versi yang tercantum pada saat persetujuan. Persetujuan tidak merupakan pelepasan hak hukum yang tidak dapat dikesampingkan dan tidak mengubah kewajiban pihak mana pun berdasarkan peraturan perundang-undangan.','c700778b8c9e453c4937bded81cb71a9240066f95cb97d046058e2ec62fbfe0f',true,'PUBLISHED','v12.0.5 Trading Rules + connection authorization hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1205_09_alma_advisor_registration','ALMA_ADVISOR_REGISTRATION','v12.0.5','Kewajiban Pendaftaran PT Alma Indonesia Raya untuk Layanan Penasihat Berjangka','PT Alma Indonesia Raya adalah perusahaan Penasihat Berjangka yang tercantum pada daftar resmi Bappebti dengan Izin Usaha Nomor 02/BAPPEBTI/SI-PNB/02/2024. Sejak proses registrasi BLACKBOX, pengguna menerima pemberitahuan dan diwajibkan, untuk menggunakan layanan trading BLACKBOX yang berada dalam ruang lingkup hubungan Penasihat Berjangka, untuk melakukan pendaftaran/registrasi, verifikasi identitas, dan penerimaan perjanjian layanan PT Alma Indonesia Raya melalui kanal resminya.

Pendaftaran BLACKBOX tidak menggantikan perjanjian atau hubungan hukum pengguna dengan PT Alma Indonesia Raya. Pengguna wajib membaca dokumen resmi PT Alma Indonesia Raya, memahami risiko dan biaya layanan, serta menyelesaikan proses pada sistem resmi PT Alma Indonesia Raya sebelum menggunakan fitur yang mensyaratkan hubungan tersebut. BLACKBOX tidak boleh menyatakan pengguna telah menjadi klien PT Alma Indonesia Raya hanya berdasarkan checkbox atau akun BLACKBOX; apabila status hubungan eksternal belum dapat diverifikasi, fitur yang mensyaratkannya harus tetap terkunci.

Persetujuan ini merupakan pernyataan bahwa pengguna telah membaca, memahami, dan secara sadar menyetujui isi dokumen pada versi yang tercantum pada saat persetujuan. Persetujuan tidak merupakan pelepasan hak hukum yang tidak dapat dikesampingkan dan tidak mengubah kewajiban pihak mana pun berdasarkan peraturan perundang-undangan.','06b853405a0cf9412e1fd6519a0795082ad4a177c861365827729c19f249af24',true,'PUBLISHED','v12.0.5 Trading Rules + connection authorization hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1205_10_trading_rules','TRADING_RULES','v12.0.5','TRADING RULES & USER CONTROL AGREEMENT — BLACKBOX Crypto','TRADING RULES ini merupakan agreement operasional yang wajib dibaca, dipahami, dan disetujui pengguna sebelum menggunakan fitur trading, menghubungkan akun trading/wallet untuk aktivitas trading, membuat konfigurasi live, atau menjalankan bot.

A. PRINSIP UTAMA — KENDALI TRADING DI TANGAN PENGGUNA
1. Pengguna adalah pihak yang memilih apakah akan menggunakan DEMO/PAPER atau REAL, memilih market (SPOT/FUTURES/DEX bila tersedia), memilih koneksi, memilih modal/eksposur, memilih pair/simbol, dan menetapkan atau menyetujui parameter risiko.
2. BLACKBOX adalah platform teknologi pendukung. BLACKBOX bukan pihak yang mengambil alih kepemilikan akun, modal, atau keputusan investasi/trading pengguna.
3. AI, scanner, signal, router, automation, risk engine, bot, dan komponen sistem hanya boleh bekerja di dalam mandat teknis yang telah dipilih, dikonfigurasi, dan disetujui pengguna serta dibatasi oleh safety/risk gate BLACKBOX. AI tidak diberi kewenangan untuk memperluas mandat pengguna secara diam-diam.
4. Apabila konfigurasi, izin, data, koneksi, atau safety gate tidak memenuhi persyaratan, sistem wajib menolak, menahan, menghentikan, atau masuk safe-mode/fail-closed; sistem tidak boleh menganggap diamnya pengguna sebagai persetujuan tambahan.
5. Persetujuan agreement ini tidak menghapus hak atau tanggung jawab yang menurut hukum wajib tetap berlaku.

B. ALUR KERJA BLACKBOX
1. USER REGISTRATION → verifikasi identitas/kontak → pembacaan agreement → pemberitahuan/pendaftaran PT Alma Indonesia Raya sesuai ruang layanan → aktivasi layanan sesuai entitlement.
2. CONNECTION → pengguna secara sadar memilih exchange/wallet → pengguna memberikan credential/otorisasi melalui mekanisme resmi → BLACKBOX melakukan verifikasi koneksi/ownership sesuai jenis koneksi → status koneksi tercatat.
3. CONFIGURATION → pengguna memilih market, pair, modal/ukuran posisi, leverage bila berlaku, stop loss/take profit, daily loss, drawdown, max positions, liquidity/risk guardrail, dan parameter lain.
4. INTELLIGENCE → market data, scanner, AI, signal, risk engine, dan opportunity intelligence memproses data untuk membantu keputusan/otomasi sesuai konfigurasi. Kualitas data dan safety gate menjadi syarat sebelum tindakan yang lebih lanjut.
5. EXECUTION GATE → untuk REAL, sistem melakukan pemeriksaan entitlement, koneksi, izin, sertifikasi, market universe, tradability, data health, risk gate, idempotency, reconciliation, dan seluruh control yang diwajibkan.
6. EXECUTION → transaksi, bila secara teknis dan hukum diizinkan, hanya berlangsung dalam batas otorisasi dan konfigurasi yang telah disetujui. Untuk DEX/wallet, mekanisme signer/transaction authorization tetap tunduk pada persetujuan pengguna dan kemampuan wallet/provider.
7. MONITORING & RECONCILIATION → status order/fill/balance/position dipantau dan direkonsiliasi. Gangguan, mismatch, data stale, atau kondisi tidak aman dapat menyebabkan execution ditahan atau dihentikan.
8. STOP/DISCONNECT → pengguna dapat menghentikan bot, mengubah konfigurasi saat memenuhi syarat, atau memutus koneksi. Sistem tetap menyimpan audit trail agar histori tidak hilang.

C. BATASAN AI DAN SISTEM
1. AI tidak menjamin profit, win rate, keberhasilan, atau hasil trading.
2. AI tidak boleh dianggap sebagai pengganti penilaian pengguna, dokumen exchange/broker/wallet, atau perjanjian dengan PT Alma Indonesia Raya.
3. AI tidak boleh menggunakan parameter atau modal yang tidak disetujui pengguna.
4. AI tidak boleh mengubah risk limit material secara diam-diam.
5. Jika AI/signal/data gagal, stale, konflik, tidak lengkap, atau melewati threshold kualitas, sistem dapat menolak tindakan dan tidak boleh mengarang data.
6. Fitur intelligence yang berstatus read-only atau execution-prohibited tetap tidak boleh menghasilkan order.

D. RISIKO TRADING
Pengguna memahami bahwa trading dapat menyebabkan kerugian nyata, termasuk kehilangan sebagian atau seluruh modal yang digunakan. Risiko mencakup volatilitas, leverage, likuidasi, slippage, spread, partial fill, rejection, latency, biaya, likuiditas, market gap, perubahan aturan, downtime, kesalahan konfigurasi, kesalahan data, blockchain congestion/reorg, smart-contract risk, bridge/router risk, exchange/provider failure, cyber incident, dan kondisi pasar ekstrem.

E. REAL VS DEMO/PAPER
DEMO/PAPER menggunakan modal/saldo virtual dan tidak sama dengan hasil REAL. REAL dapat memengaruhi aset/dana pada akun pihak ketiga yang dipilih pengguna. Status REAL tidak boleh dianggap aktif hanya karena user telah menyetujui agreement; seluruh production certification, risk, security, compliance, connection, and infrastructure gate tetap wajib PASS.

F. USER RESPONSIBILITY
Pengguna bertanggung jawab untuk memeriksa identitas akun, tujuan penggunaan, koneksi, izin, pair, market, size, leverage, risk limit, biaya, dan konfigurasi sebelum menyetujui atau menjalankan aktivitas trading. Pengguna wajib menjaga password, MFA, API secret, private key, seed phrase, dan perangkat. BLACKBOX tidak meminta seed phrase/private key dan tidak boleh menerima rahasia tersebut melalui chat/support.

G. EXCHANGE/BROKER/WALLET PIHAK KETIGA
Akun dan aset tetap berada pada pihak ketiga yang dipilih pengguna. Availability, pricing, execution, settlement, custody, withdrawal, downtime, policy, API behavior, chain state, dan layanan pihak ketiga berada di luar kendali BLACKBOX. BLACKBOX tidak menjadi kustodian hanya karena pengguna menghubungkan akun pihak ketiga.

H. PT ALMA INDONESIA RAYA
Sejak registrasi, pengguna menerima pemberitahuan bahwa layanan BLACKBOX yang berada dalam ruang lingkup hubungan Penasihat Berjangka mensyaratkan pengguna melakukan pendaftaran/registrasi, verifikasi, dan menerima dokumen layanan PT Alma Indonesia Raya melalui kanal resmi. BLACKBOX tidak menggantikan perjanjian pengguna dengan PT Alma Indonesia Raya dan tidak dapat menyatakan hubungan hukum dengan PT Alma Indonesia Raya hanya berdasarkan akun BLACKBOX. Fitur yang mensyaratkan hubungan tersebut harus mengikuti status/verifikasi yang berlaku.

I. PERSETUJUAN, VERSI, DAN BUKTI
Dengan mencentang/menyetujui agreement ini, pengguna menyatakan telah membaca, memahami, dan secara sadar menerima TRADING RULES pada versi yang tercantum. Sistem menyimpan snapshot dokumen, hash, identitas profil yang relevan, waktu UTC dan waktu lokal/timezone, metode persetujuan, acknowledgement, konteks, dan evidence hash. Versi baru tidak menimpa snapshot agreement lama. Pengguna dapat mengunduh bukti agreement dari Legal & Agreement Center.

J. HAK DAN KEWAJIBAN HUKUM
Agreement ini dimaksudkan untuk menjelaskan pembagian kendali, mandat, risiko, dan alur operasional. Tidak ada bagian agreement yang dimaksudkan sebagai penghapusan hak konsumen, hak pengaduan, kewajiban perlindungan data, tanggung jawab yang bersifat wajib, atau ketentuan lain yang tidak dapat dikesampingkan menurut hukum yang berlaku.

Persetujuan ini merupakan pernyataan bahwa pengguna telah membaca, memahami, dan secara sadar menyetujui isi dokumen pada versi yang tercantum pada saat persetujuan. Persetujuan tidak merupakan pelepasan hak hukum yang tidak dapat dikesampingkan dan tidak mengubah kewajiban pihak mana pun berdasarkan peraturan perundang-undangan.','ebd63ebc9fc7902063ae17503c3b090f9569cdec1eeac56f15dcb1e69d6b6a80',true,'PUBLISHED','v12.0.5 Trading Rules + connection authorization hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1205_11_connection_authorization','CONNECTION_AUTHORIZATION','v12.0.5','PERSYARATAN KONEKSI EXCHANGE & WALLET — USER AUTHORIZATION AGREEMENT','Dokumen ini mengatur persetujuan sadar pengguna ketika menghubungkan akun exchange atau wallet ke BLACKBOX. Koneksi merupakan pilihan pengguna sendiri dan tidak terjadi tanpa tindakan/otorisasi pengguna.

A. EXCHANGE / CEX
1. Pengguna sendiri memilih exchange, memberi label koneksi, memilih Spot/Futures yang tersedia, dan memasukkan API credential melalui form BLACKBOX.
2. BLACKBOX hanya menerima credential yang diperlukan untuk koneksi sesuai adapter yang tersedia. Credential disimpan dalam bentuk terenkripsi/reference aman; password akun BLACKBOX, OTP, seed phrase, dan private key tidak boleh dimasukkan ke form exchange.
3. Permission withdrawal/penarikan wajib nonaktif pada koneksi BLACKBOX. Pengguna memahami bahwa izin trade yang diberikan kepada API tetap merupakan kewenangan yang diberikan oleh pengguna kepada credential tersebut.
4. BLACKBOX melakukan connection test/health check sebelum menyatakan koneksi CONNECTED. Status CONNECTED bukan jaminan order selalu berhasil.
5. Setiap bot memiliki binding koneksi sendiri. Koneksi A tidak otomatis memberi mandat kepada bot B. Market universe, symbol, tradability, risk, dan execution gate harus cocok dengan koneksi yang dipilih.
6. Pengguna dapat disconnect. Disconnect tidak menghapus histori audit/order/reconciliation yang secara hukum/operasional perlu dipertahankan.

B. WALLET / DEX
1. Pengguna memilih wallet/provider dan chain sendiri melalui wallet connector yang tersedia.
2. Verifikasi wallet menggunakan challenge/message signing untuk membuktikan kontrol atas alamat. Signature ownership tidak dengan sendirinya merupakan persetujuan transaksi atau transfer.
3. BLACKBOX tidak meminta dan tidak menyimpan seed phrase/private key. Wallet tetap non-custodial.
4. Aktivitas transaksi DEX, apabila fitur tersebut tersedia dan seluruh gate mengizinkan, tetap bergantung pada kemampuan wallet/provider dan mekanisme signer/transaction authorization. Pengguna harus memeriksa detail transaksi sebelum memberikan persetujuan/signature pada wallet.
5. Koneksi wallet tidak berarti BLACKBOX memiliki kepemilikan atau hak atas aset wallet.

C. KEPUTUSAN PENGGUNA
Pengguna menyatakan bahwa tindakan CONNECT, VERIFY, SIGN, DISCONNECT, pemilihan permission, dan pengaitan koneksi ke bot dilakukan atas kehendak dan kesadaran pengguna sendiri. Pengguna memahami bahwa menghubungkan akun pihak ketiga dapat memungkinkan sistem membaca data yang diizinkan dan, jika permission serta seluruh gate memungkinkan, mengirim instruksi trading dalam batas yang disetujui. Pengguna tetap memegang kendali atas akun pihak ketiga dan wajib mencabut permission melalui exchange/wallet apabila diperlukan.

D. RISIKO KONEKSI
Risiko dapat berasal dari credential yang salah/terkompromi, API permission, phishing, perangkat, jaringan, exchange outage, rate limit, latency, chain congestion, smart contract, router, provider, data mismatch, atau konfigurasi pengguna. BLACKBOX tidak menjamin keamanan/availability pihak ketiga di luar kontrolnya dan tidak menjamin hasil transaksi.

E. BATAS OTORISASI
BLACKBOX tidak boleh menggunakan koneksi untuk tujuan di luar scope fitur dan permission yang tercatat. Withdrawal permission pada koneksi exchange BLACKBOX dinonaktifkan. Jika safety gate, certification, market-data health, reconciliation, atau legal/compliance gate tidak terpenuhi, sistem wajib fail-closed.

F. ALMA & TRADING RULES
Koneksi trading hanya boleh digunakan setelah pengguna menerima TRADING RULES dan pemberitahuan/ketentuan pendaftaran PT Alma Indonesia Raya yang berlaku untuk layanan yang bersangkutan. Persetujuan koneksi ini tidak menggantikan dokumen exchange, wallet provider, atau PT Alma Indonesia Raya.

Persetujuan ini merupakan pernyataan bahwa pengguna telah membaca, memahami, dan secara sadar menyetujui isi dokumen pada versi yang tercantum pada saat persetujuan. Persetujuan tidak merupakan pelepasan hak hukum yang tidak dapat dikesampingkan dan tidak mengubah kewajiban pihak mana pun berdasarkan peraturan perundang-undangan.','cdce32373d715692ae433d35c03f83fef92f30f98212ab1ab6accb80825dbd2f',true,'PUBLISHED','v12.0.5 Trading Rules + connection authorization hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1205_12_regulatory_disclosure','REGULATORY_DISCLOSURE','v12.0.5','Disclosure Regulasi Indonesia — BLACKBOX Technology','KERANGKA REGULASI INDONESIA YANG RELEVAN

1. Perdagangan Berjangka Komoditi dan Penasihat Berjangka berada dalam rezim perizinan dan pengawasan yang relevan dengan Bappebti. PT Alma Indonesia Raya tercantum pada daftar resmi Bappebti sebagai Penasihat Berjangka dengan Izin Usaha Nomor 02/BAPPEBTI/SI-PNB/02/2024. Untuk layanan Expert Advisor, Bappebti juga mencantumkan PT Alma Indonesia Raya dengan Persetujuan Nomor 01/BAPPEBTI/SP-PBEA/06/2024.
2. Pengaturan dan pengawasan Aset Keuangan Digital termasuk Aset Kripto telah beralih dari Bappebti kepada OJK. POJK 27 Tahun 2024 berlaku sejak 10 Januari 2025 dan telah diubah dengan POJK 23 Tahun 2025. PADK OJK Nomor 3 Tahun 2026 berlaku sejak 1 September 2026 untuk ketentuan pelaksanaan tertentu. Penerapan suatu ketentuan kepada BLACKBOX, PT Alma Indonesia Raya, exchange, broker, atau pihak lain bergantung pada kegiatan dan status perizinan masing-masing.
3. Bank Indonesia memiliki kewenangan di bidang sistem pembayaran dan ketentuan terkait aset/derivatif yang berada dalam ruang lingkupnya. BLACKBOX tidak memosisikan aset kripto sebagai alat pembayaran dan tidak mengubah ketentuan bahwa pembayaran di Indonesia harus mengikuti ketentuan Bank Indonesia yang berlaku.
4. Penyelenggaraan sistem dan transaksi elektronik juga memperhatikan ketentuan mengenai kontrak elektronik, transparansi, akuntabilitas, privasi, dan pelindungan data pribadi, termasuk UU 27 Tahun 2022 tentang Pelindungan Data Pribadi dan PP 71 Tahun 2019 tentang Penyelenggaraan Sistem dan Transaksi Elektronik.
5. Dokumen ini adalah disclosure produk dan kepatuhan, bukan pendapat hukum. Regulasi dapat berubah. Legal & Compliance Center BLACKBOX wajib memperbarui dokumen yang relevan dan menyimpan histori versi yang telah disetujui.

Tanggal verifikasi referensi regulator: 18 Oktober 2026. Dokumen ini bukan pendapat hukum dan tidak menyatakan BLACKBOX sebagai pemegang izin yang bukan miliknya.','29c3e98a84f6a39d2cbc7c74f614fd6cb7dd20d2e8683eae02c87f5ae500c035',true,'PUBLISHED','v12.0.5 Trading Rules + connection authorization hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

UPDATE "LegalDocument" SET "active"=false, "workflowState"='SUPERSEDED' WHERE "type" IN ('TERMS','PRIVACY','RISK','BOT_START','BOT_CONFIGURATION','SETUP_STEP','REAL_EXECUTION','REGISTRATION','ALMA_ADVISOR_REGISTRATION','TRADING_RULES','CONNECTION_AUTHORIZATION','REGULATORY_DISCLOSURE') AND "version" <> 'v12.0.5' AND "active"=true;
