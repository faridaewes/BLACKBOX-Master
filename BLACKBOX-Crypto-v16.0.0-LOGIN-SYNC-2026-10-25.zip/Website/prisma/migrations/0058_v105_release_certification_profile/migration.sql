-- BLACKBOX v10.5 release certification profile
CREATE TABLE "CertificationReleaseProfile" (
    "id" TEXT NOT NULL,
    "release" TEXT NOT NULL,
    "canonicalOrder" JSONB NOT NULL,
    "productionTradingAuthorization" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "CertificationReleaseProfile_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "CertificationReleaseProfile_release_key" ON "CertificationReleaseProfile"("release");
