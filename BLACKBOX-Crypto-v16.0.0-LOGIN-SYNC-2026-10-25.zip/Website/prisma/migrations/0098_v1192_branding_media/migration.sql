ALTER TABLE "AccessPlan" ADD COLUMN "imageBytes" BYTEA;
ALTER TABLE "AccessPlan" ADD COLUMN "imageMimeType" TEXT;
ALTER TABLE "AccessPlan" ADD COLUMN "imageWidth" INTEGER;
ALTER TABLE "AccessPlan" ADD COLUMN "imageHeight" INTEGER;
ALTER TABLE "AccessPlan" ADD COLUMN "imageSize" INTEGER;
