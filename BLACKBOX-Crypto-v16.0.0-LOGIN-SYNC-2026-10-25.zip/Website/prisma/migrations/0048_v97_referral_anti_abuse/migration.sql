-- BLACKBOX Crypto v9.7.0 — Referral Anti-Abuse / Fraud Intelligence
CREATE TABLE "ReferralAbuseRisk" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "score" INTEGER NOT NULL DEFAULT 0,
  "status" TEXT NOT NULL DEFAULT 'CLEAR',
  "flags" JSONB NOT NULL,
  "metrics" JSONB NOT NULL,
  "reviewedAt" TIMESTAMP(3),
  "reviewedById" TEXT,
  "reviewNote" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ReferralAbuseRisk_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "ReferralAbuseRisk_userId_key" ON "ReferralAbuseRisk"("userId");
CREATE INDEX "ReferralAbuseRisk_status_score_updatedAt_idx" ON "ReferralAbuseRisk"("status", "score", "updatedAt");
CREATE INDEX "ReferralAbuseRisk_reviewedById_reviewedAt_idx" ON "ReferralAbuseRisk"("reviewedById", "reviewedAt");
ALTER TABLE "ReferralAbuseRisk" ADD CONSTRAINT "ReferralAbuseRisk_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ReferralAbuseRisk" ADD CONSTRAINT "ReferralAbuseRisk_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

CREATE TABLE "ReferralAbuseEvent" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "eventKey" TEXT NOT NULL,
  "riskId" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "score" INTEGER NOT NULL,
  "signals" JSONB NOT NULL,
  "metadata" JSONB NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ReferralAbuseEvent_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "ReferralAbuseEvent_eventKey_key" ON "ReferralAbuseEvent"("eventKey");
CREATE INDEX "ReferralAbuseEvent_userId_createdAt_idx" ON "ReferralAbuseEvent"("userId", "createdAt");
CREATE INDEX "ReferralAbuseEvent_status_createdAt_idx" ON "ReferralAbuseEvent"("status", "createdAt");
CREATE INDEX "ReferralAbuseEvent_score_createdAt_idx" ON "ReferralAbuseEvent"("score", "createdAt");
ALTER TABLE "ReferralAbuseEvent" ADD CONSTRAINT "ReferralAbuseEvent_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ReferralAbuseEvent" ADD CONSTRAINT "ReferralAbuseEvent_riskId_fkey" FOREIGN KEY ("riskId") REFERENCES "ReferralAbuseRisk"("id") ON DELETE CASCADE ON UPDATE CASCADE;
CREATE INDEX "ReferralAbuseEvent_riskId_createdAt_idx" ON "ReferralAbuseEvent"("riskId", "createdAt");
