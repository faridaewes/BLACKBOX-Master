ALTER TABLE "Position" ADD COLUMN "trailingStop" DOUBLE PRECISION;
ALTER TABLE "Position" ADD COLUMN "highestPrice" DOUBLE PRECISION;
ALTER TABLE "Execution" ADD COLUMN "marketType" TEXT NOT NULL DEFAULT 'SPOT';
ALTER TABLE "Execution" ADD COLUMN "leverage" INTEGER NOT NULL DEFAULT 1;
ALTER TABLE "Execution" ADD COLUMN "lastAttemptAt" TIMESTAMP(3);
ALTER TABLE "Execution" ADD COLUMN "nextAttemptAt" TIMESTAMP(3);
ALTER TABLE "Execution" ADD COLUMN "cancelRequestedAt" TIMESTAMP(3);
CREATE INDEX "Execution_nextAttemptAt_status_idx" ON "Execution"("nextAttemptAt", "status");
