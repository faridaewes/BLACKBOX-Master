-- v9.8 Referral Tree Reparenting + Case-Insensitive Identity/Referral Link Uniqueness
-- Migration intentionally fails if legacy data contains case-insensitive duplicates.

CREATE UNIQUE INDEX IF NOT EXISTS "User_username_lower_key"
  ON "User" (LOWER("username"));

CREATE UNIQUE INDEX IF NOT EXISTS "User_referralCode_upper_key"
  ON "User" (UPPER("referralCode"))
  WHERE "referralCode" IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS "ReferralProfile_customCode_upper_key"
  ON "ReferralProfile" (UPPER("customCode"))
  WHERE "customCode" IS NOT NULL;

CREATE TABLE "ReferralTreeMove" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "fromSponsorId" TEXT,
  "toSponsorId" TEXT NOT NULL,
  "subtreeSize" INTEGER NOT NULL,
  "subtreeDepth" INTEGER NOT NULL,
  "previousSponsorDepth" INTEGER,
  "newSponsorDepth" INTEGER NOT NULL,
  "reason" TEXT,
  "actorId" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ReferralTreeMove_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "ReferralTreeMove_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "ReferralTreeMove_fromSponsorId_fkey" FOREIGN KEY ("fromSponsorId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT "ReferralTreeMove_toSponsorId_fkey" FOREIGN KEY ("toSponsorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "ReferralTreeMove_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

CREATE INDEX "ReferralTreeMove_userId_createdAt_idx" ON "ReferralTreeMove"("userId", "createdAt");
CREATE INDEX "ReferralTreeMove_fromSponsorId_createdAt_idx" ON "ReferralTreeMove"("fromSponsorId", "createdAt");
CREATE INDEX "ReferralTreeMove_toSponsorId_createdAt_idx" ON "ReferralTreeMove"("toSponsorId", "createdAt");
CREATE INDEX "ReferralTreeMove_actorId_createdAt_idx" ON "ReferralTreeMove"("actorId", "createdAt");


-- Cross-namespace uniqueness: a referral identifier may not collide with any username,
-- and a username may not collide with any referral identifier, case-insensitively.
CREATE OR REPLACE FUNCTION blackbox_referral_identity_guard() RETURNS trigger AS $$
DECLARE
  v text;
BEGIN
  -- Serialize every normalized referral identifier so cross-table uniqueness is
  -- safe under concurrent registrations/updates, not only at application level.
  IF TG_TABLE_NAME = 'User' THEN
    FOR v IN SELECT x FROM unnest(ARRAY[NULLIF(LOWER(NEW."username"), ''), NULLIF(LOWER(NEW."referralCode"), '')]) x WHERE x IS NOT NULL ORDER BY x LOOP
      PERFORM pg_advisory_xact_lock(hashtext('blackbox:referral:identity:' || v));
    END LOOP;
    IF NEW."referralCode" IS NOT NULL AND EXISTS (
      SELECT 1 FROM "User" u WHERE u."id" <> NEW."id" AND LOWER(u."username") = LOWER(NEW."referralCode")
    ) THEN RAISE EXCEPTION 'REFERRAL_IDENTIFIER_COLLIDES_WITH_USERNAME'; END IF;
    IF NEW."referralCode" IS NOT NULL AND EXISTS (
      SELECT 1 FROM "ReferralProfile" rp JOIN "User" u ON u."id"=rp."userId"
      WHERE u."id" <> NEW."id" AND rp."customCode" IS NOT NULL AND LOWER(rp."customCode") = LOWER(NEW."referralCode")
    ) THEN RAISE EXCEPTION 'REFERRAL_IDENTIFIER_COLLIDES_WITH_CUSTOM_CODE'; END IF;
    IF EXISTS (
      SELECT 1 FROM "User" u WHERE u."id" <> NEW."id" AND u."referralCode" IS NOT NULL AND LOWER(u."referralCode") = LOWER(NEW."username")
    ) THEN RAISE EXCEPTION 'USERNAME_COLLIDES_WITH_REFERRAL_IDENTIFIER'; END IF;
    IF EXISTS (
      SELECT 1 FROM "ReferralProfile" rp WHERE rp."userId" <> NEW."id" AND rp."customCode" IS NOT NULL AND LOWER(rp."customCode") = LOWER(NEW."username")
    ) THEN RAISE EXCEPTION 'USERNAME_COLLIDES_WITH_CUSTOM_CODE'; END IF;
    IF NEW."referralCode" IS NOT NULL AND LOWER(NEW."referralCode") = LOWER(NEW."username") THEN
      RAISE EXCEPTION 'USERNAME_AND_REFERRAL_IDENTIFIER_MUST_DIFFER';
    END IF;
  ELSE
    IF NEW."customCode" IS NOT NULL THEN
      FOR v IN SELECT x FROM unnest(ARRAY[NULLIF(LOWER(NEW."customCode"), '')]) x WHERE x IS NOT NULL ORDER BY x LOOP
        PERFORM pg_advisory_xact_lock(hashtext('blackbox:referral:identity:' || v));
      END LOOP;
      IF EXISTS (SELECT 1 FROM "User" u WHERE LOWER(u."username") = LOWER(NEW."customCode")) THEN
        RAISE EXCEPTION 'REFERRAL_IDENTIFIER_COLLIDES_WITH_USERNAME';
      END IF;
      IF EXISTS (SELECT 1 FROM "User" u WHERE u."referralCode" IS NOT NULL AND LOWER(u."referralCode") = LOWER(NEW."customCode")) THEN
        RAISE EXCEPTION 'REFERRAL_IDENTIFIER_COLLIDES_WITH_REFERRAL_CODE';
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER "User_referral_identity_guard"
BEFORE INSERT OR UPDATE OF "username", "referralCode" ON "User"
FOR EACH ROW EXECUTE FUNCTION blackbox_referral_identity_guard();

CREATE TRIGGER "ReferralProfile_referral_identity_guard"
BEFORE INSERT OR UPDATE OF "customCode" ON "ReferralProfile"
FOR EACH ROW EXECUTE FUNCTION blackbox_referral_identity_guard();
