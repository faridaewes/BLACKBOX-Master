-- BLACKBOX v11.9.2 — payment readiness / manual proof / approval
ALTER TABLE "AccessPlan" ADD COLUMN "priceMinor" INTEGER;
ALTER TABLE "AccessPlan" ADD COLUMN "currency" TEXT NOT NULL DEFAULT 'IDR';
ALTER TABLE "AccessPlan" ADD COLUMN "paymentEnabled" BOOLEAN NOT NULL DEFAULT false;

CREATE TABLE "PaymentOrder" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "planId" TEXT NOT NULL,
  "subscriptionId" TEXT,
  "amountMinor" INTEGER NOT NULL,
  "currency" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'AWAITING_PAYMENT',
  "paymentMethod" TEXT,
  "provider" TEXT NOT NULL DEFAULT 'MANUAL',
  "providerReference" TEXT,
  "proofStorageRef" TEXT,
  "proofMimeType" TEXT,
  "proofSize" INTEGER,
  "proofSha256" TEXT,
  "payerName" TEXT,
  "payerReference" TEXT,
  "note" TEXT,
  "rejectionReason" TEXT,
  "reviewedById" TEXT,
  "reviewedAt" TIMESTAMP(3),
  "supportTicketId" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "PaymentOrder_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "PaymentOrder_subscriptionId_key" ON "PaymentOrder"("subscriptionId");
CREATE UNIQUE INDEX "PaymentOrder_supportTicketId_key" ON "PaymentOrder"("supportTicketId");
CREATE INDEX "PaymentOrder_userId_status_createdAt_idx" ON "PaymentOrder"("userId","status","createdAt");
CREATE INDEX "PaymentOrder_status_createdAt_idx" ON "PaymentOrder"("status","createdAt");
CREATE INDEX "PaymentOrder_planId_createdAt_idx" ON "PaymentOrder"("planId","createdAt");
ALTER TABLE "PaymentOrder" ADD CONSTRAINT "PaymentOrder_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "PaymentOrder" ADD CONSTRAINT "PaymentOrder_planId_fkey" FOREIGN KEY ("planId") REFERENCES "AccessPlan"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "PaymentOrder" ADD CONSTRAINT "PaymentOrder_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES "Subscription"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "PaymentOrder" ADD CONSTRAINT "PaymentOrder_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "PaymentOrder" ADD CONSTRAINT "PaymentOrder_supportTicketId_fkey" FOREIGN KEY ("supportTicketId") REFERENCES "SupportTicket"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Payment reviewer/config permissions are stored in AccessTeam grants; no default principal bypass is needed.
