ALTER TABLE "Signal" ADD COLUMN "canonicalSymbol" TEXT;
ALTER TABLE "Signal" ADD COLUMN "marketType" TEXT NOT NULL DEFAULT 'SPOT';
ALTER TABLE "Signal" ADD COLUMN "connectionKey" TEXT;
ALTER TABLE "Signal" ADD COLUMN "exchangeAccountId" TEXT;
ALTER TABLE "Signal" ADD COLUMN "walletId" TEXT;
CREATE INDEX "Signal_exchangeAccountId_marketType_canonicalSymbol_createdAt_idx" ON "Signal"("exchangeAccountId","marketType","canonicalSymbol","createdAt");
CREATE INDEX "Signal_walletId_marketType_canonicalSymbol_createdAt_idx" ON "Signal"("walletId","marketType","canonicalSymbol","createdAt");
ALTER TABLE "Signal" ADD CONSTRAINT "Signal_exchangeAccountId_fkey" FOREIGN KEY ("exchangeAccountId") REFERENCES "ExchangeAccount"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "Signal" ADD CONSTRAINT "Signal_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES "Wallet"("id") ON DELETE SET NULL ON UPDATE CASCADE;
