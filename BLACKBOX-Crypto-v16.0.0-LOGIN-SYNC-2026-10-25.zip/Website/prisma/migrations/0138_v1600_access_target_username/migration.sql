-- BLACKBOX v16.0.0
ALTER TABLE "AccessCode" ADD COLUMN IF NOT EXISTS "targetUsername" TEXT;
CREATE INDEX IF NOT EXISTS "AccessCode_targetUsername_idx" ON "AccessCode"("targetUsername");
