-- BLACKBOX v12.0.0 WPA final hardening
-- Specialization, event-driven public cache, network audience is derived from User.referredById.
ALTER TABLE "PublicAdvisor" ADD COLUMN "specialization" TEXT;

-- Service pricing is intentionally outside BLACKBOX; service CTA only opens private communication.
ALTER TABLE "WpaService" DROP COLUMN "priceMinor";
ALTER TABLE "WpaService" DROP COLUMN "currency";
