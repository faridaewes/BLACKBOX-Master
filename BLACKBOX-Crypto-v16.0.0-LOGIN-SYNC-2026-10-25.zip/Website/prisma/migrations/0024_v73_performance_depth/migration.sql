ALTER TABLE "TradingPerformanceSnapshot" ADD COLUMN IF NOT EXISTS "sidePerformance" JSONB;
ALTER TABLE "TradingPerformanceSnapshot" ADD COLUMN IF NOT EXISTS "timeframePerformance" JSONB;
ALTER TABLE "TradingPerformanceSnapshot" ADD COLUMN IF NOT EXISTS "strategyPerformance" JSONB;
ALTER TABLE "TradingPerformanceSnapshot" ADD COLUMN IF NOT EXISTS "entryQuality" DOUBLE PRECISION;
ALTER TABLE "TradingPerformanceSnapshot" ADD COLUMN IF NOT EXISTS "exitQuality" DOUBLE PRECISION;
ALTER TABLE "TradingPerformanceSnapshot" ADD COLUMN IF NOT EXISTS "aiConfirmationQuality" DOUBLE PRECISION;
ALTER TABLE "TradingPerformanceSnapshot" ADD COLUMN IF NOT EXISTS "consecutiveLosses" INTEGER NOT NULL DEFAULT 0;
ALTER TABLE "TradingPerformanceSnapshot" ADD COLUMN IF NOT EXISTS "recoveryPeriodDays" DOUBLE PRECISION;
