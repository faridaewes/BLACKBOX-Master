CREATE TABLE IF NOT EXISTS "DisasterRecoveryDrill" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "backupId" TEXT,
  "scope" TEXT NOT NULL,
  "state" TEXT NOT NULL,
  "phase" TEXT NOT NULL,
  "progressPct" INTEGER NOT NULL DEFAULT 0,
  "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "completedAt" TIMESTAMP(3),
  "durationMs" INTEGER,
  "failures" JSONB,
  "warnings" JSONB,
  "checks" JSONB,
  "createdById" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "DisasterRecoveryDrill_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS "DisasterRecoveryDrill_state_createdAt_idx" ON "DisasterRecoveryDrill"("state","createdAt");
CREATE INDEX IF NOT EXISTS "DisasterRecoveryDrill_backupId_idx" ON "DisasterRecoveryDrill"("backupId");
