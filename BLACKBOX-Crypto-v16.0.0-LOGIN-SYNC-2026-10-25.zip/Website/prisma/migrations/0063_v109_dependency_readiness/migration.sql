-- BLACKBOX v10.9.0 dependency/build readiness evidence; no production authorization.
CREATE TABLE "ReleaseDependencyReadinessSnapshot" (
  "id" TEXT NOT NULL,
  "release" TEXT NOT NULL,
  "environment" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "lockState" TEXT NOT NULL,
  "registryState" TEXT NOT NULL,
  "installState" TEXT NOT NULL,
  "buildState" TEXT NOT NULL,
  "testState" TEXT NOT NULL,
  "productionCertification" TEXT NOT NULL,
  "tradingAuthorization" TEXT NOT NULL,
  "blockers" JSONB NOT NULL,
  "checks" JSONB NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ReleaseDependencyReadinessSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ReleaseDependencyReadinessSnapshot_release_createdAt_idx" ON "ReleaseDependencyReadinessSnapshot"("release", "createdAt");
CREATE INDEX "ReleaseDependencyReadinessSnapshot_status_createdAt_idx" ON "ReleaseDependencyReadinessSnapshot"("status", "createdAt");
