-- Canonical six-team workforce structure. Idempotent and preserves existing memberships/grants.
UPDATE "AccessTeam" SET "code"='PUBLIC_WPA', "name"='Public Experience, WPA, Content & Events', "description"='Kelola public/PWA/WPA content, event dan publishing workflow' WHERE "code"='PUBLIC_CONTENT';
UPDATE "AccessTeam" SET "code"='CS_TECHNICAL', "name"='Customer Support & Technical Operations', "description"='CS, technical support, user assistance and operational support' WHERE "code"='CUSTOMER_SUPPORT';
UPDATE "AccessTeam" SET "code"='AUDIT_COMPLIANCE', "name"='Audit, Compliance & Review', "description"='Read-only audit, review, evidence and export' WHERE "code"='AUDIT';
UPDATE "AccessTeam" SET "code"='PRODUCT_SERVICES_TIER', "name"='Product, Services, Tier & Access Management', "description"='Product catalog, services, tier and access-code entitlement management' WHERE "code"='PRODUCT_SERVICES';
-- Merge legacy Tier Administration into the canonical Product team before removal.
INSERT INTO "TeamAccessGrant" ("id","teamId","permissionCode","scope","expiresAt","revokedAt","reason","grantedById","createdAt")
SELECT md5(random()::text || clock_timestamp()::text), p."id", g."permissionCode", g."scope", g."expiresAt", g."revokedAt", g."reason", g."grantedById", g."createdAt"
FROM "TeamAccessGrant" g JOIN "AccessTeam" t ON t."id"=g."teamId" JOIN "AccessTeam" p ON p."code"='PRODUCT_SERVICES_TIER'
WHERE t."code"='TIER_ADMIN' AND NOT EXISTS (SELECT 1 FROM "TeamAccessGrant" x WHERE x."teamId"=p."id" AND x."permissionCode"=g."permissionCode" AND x."scope"=g."scope");
INSERT INTO "AccessTeamMember" ("id","teamId","userId","assignedById","createdAt")
SELECT md5(random()::text || clock_timestamp()::text), p."id", m."userId", m."assignedById", m."createdAt"
FROM "AccessTeamMember" m JOIN "AccessTeam" t ON t."id"=m."teamId" JOIN "AccessTeam" p ON p."code"='PRODUCT_SERVICES_TIER'
WHERE t."code"='TIER_ADMIN' AND NOT EXISTS (SELECT 1 FROM "AccessTeamMember" x WHERE x."teamId"=p."id" AND x."userId"=m."userId");
DELETE FROM "AccessTeamMember" WHERE "teamId" IN (SELECT "id" FROM "AccessTeam" WHERE "code"='TIER_ADMIN');
DELETE FROM "TeamAccessGrant" WHERE "teamId" IN (SELECT "id" FROM "AccessTeam" WHERE "code"='TIER_ADMIN');
DELETE FROM "AccessTeam" WHERE "code"='TIER_ADMIN';
INSERT INTO "AccessTeam" ("id","code","name","description","createdById","createdAt","updatedAt")
SELECT md5(random()::text || clock_timestamp()::text),'ACCOUNT_USER','Account & User Management','Account lifecycle, user administration and account access support',u."id",CURRENT_TIMESTAMP,CURRENT_TIMESTAMP FROM "User" u WHERE u."role"='DEVELOPER' ORDER BY u."createdAt" ASC LIMIT 1
ON CONFLICT ("code") DO NOTHING;
INSERT INTO "AccessTeam" ("id","code","name","description","createdById","createdAt","updatedAt")
SELECT md5(random()::text || clock_timestamp()::text),'CUSTOM_SPECIAL','Custom / Specialized Teams','Developer-defined specialized operational teams',u."id",CURRENT_TIMESTAMP,CURRENT_TIMESTAMP FROM "User" u WHERE u."role"='DEVELOPER' ORDER BY u."createdAt" ASC LIMIT 1
ON CONFLICT ("code") DO NOTHING;
CREATE TABLE IF NOT EXISTS "TeamTask" (
  "id" TEXT NOT NULL, "teamId" TEXT NOT NULL, "title" TEXT NOT NULL, "description" TEXT,
  "status" TEXT NOT NULL DEFAULT 'TODO', "priority" TEXT NOT NULL DEFAULT 'NORMAL', "assigneeId" TEXT,
  "createdById" TEXT NOT NULL, "dueAt" TIMESTAMP(3), "completedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "TeamTask_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "TeamTaskComment" (
  "id" TEXT NOT NULL, "taskId" TEXT NOT NULL, "authorId" TEXT NOT NULL, "body" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, CONSTRAINT "TeamTaskComment_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "TeamTask_teamId_status_priority_idx" ON "TeamTask"("teamId","status","priority");
CREATE INDEX IF NOT EXISTS "TeamTask_assigneeId_status_idx" ON "TeamTask"("assigneeId","status");
CREATE INDEX IF NOT EXISTS "TeamTask_dueAt_status_idx" ON "TeamTask"("dueAt","status");
CREATE INDEX IF NOT EXISTS "TeamTaskComment_taskId_createdAt_idx" ON "TeamTaskComment"("taskId","createdAt");
ALTER TABLE "TeamTask" ADD CONSTRAINT "TeamTask_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES "AccessTeam"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "TeamTask" ADD CONSTRAINT "TeamTask_assigneeId_fkey" FOREIGN KEY ("assigneeId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "TeamTask" ADD CONSTRAINT "TeamTask_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "TeamTaskComment" ADD CONSTRAINT "TeamTaskComment_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES "TeamTask"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "TeamTaskComment" ADD CONSTRAINT "TeamTaskComment_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
-- Seed canonical permission grants idempotently.
WITH perms(team_code, permission_code) AS (
 VALUES
 ('ACCOUNT_USER','USER_READ'),('ACCOUNT_USER','USER_SUSPEND'),('ACCOUNT_USER','USER_PASSWORD_RESET'),('ACCOUNT_USER','USER_EMAIL_RESET'),('ACCOUNT_USER','USER_MFA_RESET'),('ACCOUNT_USER','TEAM_LEAD_ADMIN'),
 ('CS_TECHNICAL','USER_READ'),('CS_TECHNICAL','TEAM_LEAD_ADMIN'),('CS_TECHNICAL','SUPPORT_CHAT'),('CS_TECHNICAL','USER_SUSPEND'),('CS_TECHNICAL','USER_PASSWORD_RESET'),('CS_TECHNICAL','USER_EMAIL_RESET'),('CS_TECHNICAL','USER_MFA_RESET'),('CS_TECHNICAL','BOT_SUPPORT'),('CS_TECHNICAL','BOT_OPERATIONS'),
 ('PRODUCT_SERVICES_TIER','PRODUCT_CATALOG_READ'),('PRODUCT_SERVICES_TIER','PRODUCT_CATALOG_WRITE'),('PRODUCT_SERVICES_TIER','PRODUCT_CATALOG_PUBLISH'),('PRODUCT_SERVICES_TIER','TIER_ACCESS_CODE'),('PRODUCT_SERVICES_TIER','TEAM_LEAD_ADMIN'),('PRODUCT_SERVICES_TIER','BOT_OPERATIONS'),
 ('PUBLIC_WPA','PUBLIC_CONTENT_READ'),('PUBLIC_WPA','PUBLIC_CONTENT_WRITE'),('PUBLIC_WPA','PUBLIC_CONTENT_PUBLISH'),('PUBLIC_WPA','TEAM_LEAD_ADMIN'),
 ('AUDIT_COMPLIANCE','USER_READ'),('AUDIT_COMPLIANCE','TEAM_LEAD_ADMIN'),('AUDIT_COMPLIANCE','AUDIT_READ'),('AUDIT_COMPLIANCE','AUDIT_EXPORT'),('AUDIT_COMPLIANCE','BOT_AUDIT'),
 ('CUSTOM_SPECIAL','TEAM_LEAD_ADMIN')
)
INSERT INTO "TeamAccessGrant" ("id","teamId","permissionCode","scope","grantedById","createdAt")
SELECT md5(random()::text || clock_timestamp()::text),t."id",p.permission_code,'GLOBAL',u."id",CURRENT_TIMESTAMP
FROM perms p JOIN "AccessTeam" t ON t."code"=p.team_code CROSS JOIN LATERAL (SELECT "id" FROM "User" WHERE "role"='DEVELOPER' ORDER BY "createdAt" ASC LIMIT 1) u
WHERE NOT EXISTS (SELECT 1 FROM "TeamAccessGrant" g WHERE g."teamId"=t."id" AND g."permissionCode"=p.permission_code AND g."scope"='GLOBAL' AND g."revokedAt" IS NULL);
