CREATE TABLE IF NOT EXISTS "SystemHealthSnapshot" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "version" TEXT NOT NULL,
  "overallScore" INTEGER NOT NULL,
  "state" TEXT NOT NULL,
  "checks" JSONB NOT NULL,
  "failures" JSONB,
  "warnings" JSONB,
  "latencyMs" INTEGER,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS "SystemHealthSnapshot_createdAt_idx" ON "SystemHealthSnapshot"("createdAt");
CREATE INDEX IF NOT EXISTS "SystemHealthSnapshot_state_createdAt_idx" ON "SystemHealthSnapshot"("state","createdAt");
