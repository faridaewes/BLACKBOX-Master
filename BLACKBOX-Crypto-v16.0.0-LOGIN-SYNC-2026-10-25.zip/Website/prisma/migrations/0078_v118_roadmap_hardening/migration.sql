CREATE TABLE "BacktestReplayRun" (
  "id" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "decisionCount" INTEGER NOT NULL,
  "verifiedCount" INTEGER NOT NULL,
  "blockedCount" INTEGER NOT NULL,
  "insufficientCount" INTEGER NOT NULL,
  "datasetHash" TEXT,
  "lookaheadBlocked" BOOLEAN NOT NULL DEFAULT false,
  "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "completedAt" TIMESTAMP(3),
  CONSTRAINT "BacktestReplayRun_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "BacktestReplayRun_status_startedAt_idx" ON "BacktestReplayRun"("status","startedAt");
CREATE TABLE "RiskGateSnapshot" (
  "id" TEXT NOT NULL,"version" TEXT NOT NULL,"scope" TEXT NOT NULL,"status" TEXT NOT NULL,"score" DOUBLE PRECISION NOT NULL,"reasons" JSONB NOT NULL,"maxExposurePct" DOUBLE PRECISION NOT NULL,"maxDailyLossPct" DOUBLE PRECISION NOT NULL,"maxPositions" INTEGER NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "RiskGateSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "RiskGateSnapshot_scope_status_createdAt_idx" ON "RiskGateSnapshot"("scope","status","createdAt");
CREATE TABLE "ExecutionReadinessSnapshot" (
  "id" TEXT NOT NULL,"version" TEXT NOT NULL,"decisionId" TEXT NOT NULL,"status" TEXT NOT NULL,"executionAllowed" BOOLEAN NOT NULL DEFAULT false,"noOrderSigning" BOOLEAN NOT NULL DEFAULT true,"noOrderSubmission" BOOLEAN NOT NULL DEFAULT true,"noRouterAuthorization" BOOLEAN NOT NULL DEFAULT true,"reasons" JSONB NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ExecutionReadinessSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ExecutionReadinessSnapshot_decisionId_createdAt_idx" ON "ExecutionReadinessSnapshot"("decisionId","createdAt");
CREATE TABLE "ShadowExecutionSnapshot" (
  "id" TEXT NOT NULL,"version" TEXT NOT NULL,"orderId" TEXT NOT NULL,"symbol" TEXT NOT NULL,"side" TEXT NOT NULL,"quantity" DOUBLE PRECISION NOT NULL,"referencePrice" DOUBLE PRECISION NOT NULL,"simulatedPrice" DOUBLE PRECISION NOT NULL,"slippageBps" DOUBLE PRECISION NOT NULL,"feeUsd" DOUBLE PRECISION NOT NULL,"realOrderSubmitted" BOOLEAN NOT NULL DEFAULT false,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ShadowExecutionSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ShadowExecutionSnapshot_symbol_createdAt_idx" ON "ShadowExecutionSnapshot"("symbol","createdAt");
CREATE TABLE "ExchangeCertificationRun" (
  "id" TEXT NOT NULL,"version" TEXT NOT NULL,"exchange" TEXT NOT NULL,"status" TEXT NOT NULL,"sandboxRequired" BOOLEAN NOT NULL DEFAULT true,"realTradingEnabled" BOOLEAN NOT NULL DEFAULT false,"checks" JSONB NOT NULL,"blockers" JSONB NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ExchangeCertificationRun_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ExchangeCertificationRun_exchange_status_createdAt_idx" ON "ExchangeCertificationRun"("exchange","status","createdAt");
CREATE TABLE "OperationsRecoveryRun" (
  "id" TEXT NOT NULL,"version" TEXT NOT NULL,"status" TEXT NOT NULL,"safeMode" BOOLEAN NOT NULL DEFAULT true,"reasons" JSONB NOT NULL,"recoveryActions" JSONB NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "OperationsRecoveryRun_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "OperationsRecoveryRun_status_createdAt_idx" ON "OperationsRecoveryRun"("status","createdAt");
CREATE TABLE "ReleaseCertificationRun" (
  "id" TEXT NOT NULL,"version" TEXT NOT NULL,"status" TEXT NOT NULL,"productionEnabled" BOOLEAN NOT NULL DEFAULT false,"tradingEnabled" BOOLEAN NOT NULL DEFAULT false,"gates" JSONB NOT NULL,"blockers" JSONB NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ReleaseCertificationRun_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ReleaseCertificationRun_status_createdAt_idx" ON "ReleaseCertificationRun"("status","createdAt");
