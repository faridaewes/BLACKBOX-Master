-- BLACKBOX v14.11.0 — code-quality, syntax and historical-assertion certification
CREATE TABLE IF NOT EXISTS "CertificationRunV1411" ("id" TEXT NOT NULL,"release" TEXT NOT NULL,"runType" TEXT NOT NULL,"status" TEXT NOT NULL,"environment" TEXT NOT NULL,"startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,"completedAt" TIMESTAMP(3),"summary" JSONB NOT NULL,"evidenceHash" TEXT NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,CONSTRAINT "CertificationRunV1411_pkey" PRIMARY KEY ("id"));
CREATE INDEX IF NOT EXISTS "CertificationRunV1411_release_status_idx" ON "CertificationRunV1411"("release","status");
CREATE INDEX IF NOT EXISTS "CertificationRunV1411_runType_createdAt_idx" ON "CertificationRunV1411"("runType","createdAt");
CREATE TABLE IF NOT EXISTS "SyntaxGateV1411" ("id" TEXT NOT NULL,"release" TEXT NOT NULL,"fileCount" INTEGER NOT NULL,"errorCount" INTEGER NOT NULL,"status" TEXT NOT NULL,"evidenceHash" TEXT NOT NULL,"details" JSONB NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,CONSTRAINT "SyntaxGateV1411_pkey" PRIMARY KEY ("id"));
CREATE INDEX IF NOT EXISTS "SyntaxGateV1411_release_status_idx" ON "SyntaxGateV1411"("release","status");
CREATE INDEX IF NOT EXISTS "SyntaxGateV1411_createdAt_idx" ON "SyntaxGateV1411"("createdAt");
CREATE TABLE IF NOT EXISTS "HistoricalAssertionAuditV1411" ("id" TEXT NOT NULL,"release" TEXT NOT NULL,"file" TEXT NOT NULL,"classification" TEXT NOT NULL,"status" TEXT NOT NULL,"detail" TEXT NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,CONSTRAINT "HistoricalAssertionAuditV1411_pkey" PRIMARY KEY ("id"));
CREATE INDEX IF NOT EXISTS "HistoricalAssertionAuditV1411_release_classification_idx" ON "HistoricalAssertionAuditV1411"("release","classification");
CREATE INDEX IF NOT EXISTS "HistoricalAssertionAuditV1411_status_createdAt_idx" ON "HistoricalAssertionAuditV1411"("status","createdAt");

CREATE TABLE IF NOT EXISTS "CertificationGateEvidenceV1411" ("id" TEXT NOT NULL,"runId" TEXT NOT NULL,"gateKey" TEXT NOT NULL,"priority" TEXT NOT NULL,"status" TEXT NOT NULL,"evidence" JSONB NOT NULL,"observedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,"evidenceHash" TEXT NOT NULL,CONSTRAINT "CertificationGateEvidenceV1411_pkey" PRIMARY KEY ("id"));
CREATE INDEX IF NOT EXISTS "CertificationGateEvidenceV1411_runId_gateKey_idx" ON "CertificationGateEvidenceV1411"("runId","gateKey");
CREATE INDEX IF NOT EXISTS "CertificationGateEvidenceV1411_gateKey_status_observedAt_idx" ON "CertificationGateEvidenceV1411"("gateKey","status","observedAt");
CREATE TABLE IF NOT EXISTS "FailureInjectionRunV1411" ("id" TEXT NOT NULL,"scenario" TEXT NOT NULL,"expectedState" TEXT NOT NULL,"observedState" TEXT NOT NULL,"recovered" BOOLEAN NOT NULL,"failClosed" BOOLEAN NOT NULL DEFAULT true,"executionAllowed" BOOLEAN NOT NULL DEFAULT false,"evidence" JSONB NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,CONSTRAINT "FailureInjectionRunV1411_pkey" PRIMARY KEY ("id"));
CREATE INDEX IF NOT EXISTS "FailureInjectionRunV1411_scenario_createdAt_idx" ON "FailureInjectionRunV1411"("scenario","createdAt");
CREATE INDEX IF NOT EXISTS "FailureInjectionRunV1411_recovered_createdAt_idx" ON "FailureInjectionRunV1411"("recovered","createdAt");
CREATE TABLE IF NOT EXISTS "SecurityRedTeamFindingV1411" ("id" TEXT NOT NULL,"scenario" TEXT NOT NULL,"severity" TEXT NOT NULL,"status" TEXT NOT NULL,"blocked" BOOLEAN NOT NULL,"evidence" JSONB NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,CONSTRAINT "SecurityRedTeamFindingV1411_pkey" PRIMARY KEY ("id"));
CREATE INDEX IF NOT EXISTS "SecurityRedTeamFindingV1411_severity_status_idx" ON "SecurityRedTeamFindingV1411"("severity","status");
CREATE INDEX IF NOT EXISTS "SecurityRedTeamFindingV1411_scenario_createdAt_idx" ON "SecurityRedTeamFindingV1411"("scenario","createdAt");
CREATE TABLE IF NOT EXISTS "OperationalMetricSnapshotV1411" ("id" TEXT NOT NULL,"environment" TEXT NOT NULL,"overallState" TEXT NOT NULL,"metrics" JSONB NOT NULL,"incidents" JSONB NOT NULL,"generatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,CONSTRAINT "OperationalMetricSnapshotV1411_pkey" PRIMARY KEY ("id"));
CREATE INDEX IF NOT EXISTS "OperationalMetricSnapshotV1411_environment_generatedAt_idx" ON "OperationalMetricSnapshotV1411"("environment","generatedAt");
CREATE INDEX IF NOT EXISTS "OperationalMetricSnapshotV1411_overallState_generatedAt_idx" ON "OperationalMetricSnapshotV1411"("overallState","generatedAt");
