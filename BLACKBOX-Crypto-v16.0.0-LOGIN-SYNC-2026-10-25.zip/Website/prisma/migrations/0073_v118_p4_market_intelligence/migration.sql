CREATE TABLE "MarketIntelligenceDeepSnapshot" (
  "id" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "timeframeCoverage" INTEGER NOT NULL,
  "p4Score" INTEGER NOT NULL,
  "regime" TEXT NOT NULL,
  "regimeScore" INTEGER NOT NULL,
  "breakout" BOOLEAN NOT NULL,
  "doji" BOOLEAN NOT NULL,
  "liquidityUsd" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "volume24h" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "spreadBps" DOUBLE PRECISION,
  "orderBookScore" INTEGER,
  "derivatives" JSONB,
  "dexPool" JSONB,
  "timeframes" JSONB NOT NULL,
  "blockers" JSONB NOT NULL,
  "warnings" JSONB NOT NULL,
  "evidenceComplete" BOOLEAN NOT NULL,
  "observedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "MarketIntelligenceDeepSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "MarketIntelligenceDeepSnapshot_marketKey_createdAt_idx" ON "MarketIntelligenceDeepSnapshot"("marketKey","createdAt");
CREATE INDEX "MarketIntelligenceDeepSnapshot_status_createdAt_idx" ON "MarketIntelligenceDeepSnapshot"("status","createdAt");
CREATE INDEX "MarketIntelligenceDeepSnapshot_marketType_createdAt_idx" ON "MarketIntelligenceDeepSnapshot"("marketType","createdAt");
CREATE INDEX "MarketIntelligenceDeepSnapshot_evidenceComplete_createdAt_idx" ON "MarketIntelligenceDeepSnapshot"("evidenceComplete","createdAt");
