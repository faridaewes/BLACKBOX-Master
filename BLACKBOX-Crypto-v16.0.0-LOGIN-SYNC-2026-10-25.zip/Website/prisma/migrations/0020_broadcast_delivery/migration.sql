CREATE TABLE IF NOT EXISTS "BroadcastDelivery" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "broadcastId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "channel" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'PENDING',
  "error" TEXT,
  "sentAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "BroadcastDelivery_broadcastId_fkey" FOREIGN KEY ("broadcastId") REFERENCES "Broadcast"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "BroadcastDelivery_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS "BroadcastDelivery_broadcastId_userId_channel_key" ON "BroadcastDelivery"("broadcastId","userId","channel");
CREATE INDEX IF NOT EXISTS "BroadcastDelivery_userId_createdAt_idx" ON "BroadcastDelivery"("userId","createdAt");
CREATE INDEX IF NOT EXISTS "BroadcastDelivery_broadcastId_channel_status_idx" ON "BroadcastDelivery"("broadcastId","channel","status");
