-- v9.9 Referral Registration Integrity
-- Immutable attribution proves which referral code/sponsor was applied at registration.
CREATE TABLE "ReferralRegistrationAttribution" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "sponsorId" TEXT NOT NULL,
  "referralCode" TEXT NOT NULL,
  "source" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ReferralRegistrationAttribution_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "ReferralRegistrationAttribution_userId_key" UNIQUE ("userId"),
  CONSTRAINT "ReferralRegistrationAttribution_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "ReferralRegistrationAttribution_sponsorId_fkey" FOREIGN KEY ("sponsorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
CREATE INDEX "ReferralRegistrationAttribution_sponsorId_createdAt_idx" ON "ReferralRegistrationAttribution"("sponsorId", "createdAt");
CREATE INDEX "ReferralRegistrationAttribution_referralCode_createdAt_idx" ON "ReferralRegistrationAttribution"("referralCode", "createdAt");
