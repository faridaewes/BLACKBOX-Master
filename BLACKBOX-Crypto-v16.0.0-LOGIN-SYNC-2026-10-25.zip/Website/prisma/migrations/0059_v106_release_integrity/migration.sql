-- BLACKBOX v10.6 release integrity and runtime convergence evidence
CREATE TABLE "ReleaseIntegritySnapshot" (
    "id" TEXT NOT NULL,
    "release" TEXT NOT NULL,
    "environment" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "commit" TEXT,
    "manifestHash" TEXT NOT NULL,
    "checks" JSONB NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "ReleaseIntegritySnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ReleaseIntegritySnapshot_release_createdAt_idx" ON "ReleaseIntegritySnapshot"("release", "createdAt");
CREATE INDEX "ReleaseIntegritySnapshot_status_createdAt_idx" ON "ReleaseIntegritySnapshot"("status", "createdAt");
