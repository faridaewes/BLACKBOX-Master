-- BLACKBOX v12.0.8

-- Master Agreement, Trading Rules & User Statements + material-change re-consent hardening

BEGIN;

UPDATE "LegalDocument" SET "active"=false WHERE "active"=true;

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1208_01_terms','TERMS','v12.0.8','Syarat Penggunaan BLACKBOX Technology',$LEGAL_1$BLACKBOX Technology / BLACKBOX Crypto adalah platform teknologi pendukung aktivitas trader. Platform ini membantu pengguna memperoleh informasi pasar, analisis, edukasi, simulasi, pengaturan dan pemantauan bot, pencatatan aktivitas, serta integrasi dengan layanan pihak ketiga yang dipilih pengguna. BLACKBOX bukan tempat penyimpanan dana nasabah, bukan kustodian, dan tidak menghimpun, menerima, menyimpan, menguasai, atau mengelola dana maupun aset pengguna untuk kepentingan transaksi. BLACKBOX juga tidak menjamin keuntungan, win rate, tingkat keberhasilan, pendapatan, atau hasil trading tertentu.

Seluruh kendali atas akun, koneksi pihak ketiga, parameter trading, modal, batas risiko, persetujuan order, dan keputusan transaksi tetap berada pada pengguna. BLACKBOX dan komponen AI tidak boleh memperluas mandat, menaikkan risiko, mengganti parameter material, atau mengambil keputusan di luar ruang lingkup yang secara aktif dipilih dan disetujui pengguna melalui konfigurasi, agreement, dan control yang tersedia. Pengguna wajib memahami setiap instruksi yang diberikan, memeriksa konfigurasi sebelum menjalankan bot, dan menggunakan hanya dana yang secara finansial mampu ditanggung risikonya. Trading aset kripto, derivatif, valuta asing, dan instrumen berisiko lainnya dapat menyebabkan kerugian nyata, termasuk kehilangan sebagian atau seluruh dana yang digunakan.

Untuk fitur atau layanan BLACKBOX yang secara eksplisit terhubung dengan layanan Penasihat Berjangka PT Alma Indonesia Raya, pengguna wajib menyelesaikan pendaftaran/registrasi, verifikasi, dan penerimaan dokumen layanan PT Alma Indonesia Raya melalui kanal resminya sebelum menggunakan fitur yang mensyaratkan hubungan tersebut. Akun BLACKBOX tidak dengan sendirinya menjadikan seseorang sebagai klien Penasihat Berjangka PT Alma Indonesia Raya dan tidak menggantikan perjanjian, kewajiban, atau persetujuan yang harus dibuat dengan PT Alma Indonesia Raya.

Kerugian trading yang timbul dari keputusan pengguna, kondisi pasar, leverage, slippage, partial fill, rejection, latency, biaya, likuiditas, gangguan jaringan, blockchain, exchange/provider, atau kegagalan teknologi tidak merupakan jaminan atau kewajiban penggantian oleh BLACKBOX. Namun, tidak ada klausul dalam disclaimer ini yang dimaksudkan untuk menghapus, membatasi, atau mengesampingkan hak pengguna atau tanggung jawab pihak mana pun yang menurut hukum wajib tetap berlaku. Pengguna tetap memiliki hak untuk menyampaikan pengaduan dan menggunakan mekanisme penyelesaian sengketa yang tersedia berdasarkan hukum yang berlaku.

Gunakan BLACKBOX dan layanan terkait hanya melalui kanal resmi. Jangan memberikan password, OTP, seed phrase, private key, atau secret credential kepada siapa pun.

BLACKBOX berfungsi sebagai perangkat lunak/platform teknologi pendukung. Pengguna tetap menjadi pihak yang menentukan apakah, kapan, dan dengan parameter apa akun digunakan. TRADING RULES & USER CONTROL AGREEMENT serta CONNECTION AUTHORIZATION AGREEMENT merupakan bagian dari kerangka persetujuan operasional BLACKBOX untuk aktivitas trading dan koneksi pihak ketiga. Integrasi exchange, broker, wallet, AI provider, data provider, atau layanan pihak ketiga tunduk pada syarat dan ketentuan pihak tersebut. BLACKBOX tidak menggantikan perjanjian dengan pihak ketiga dan tidak menjanjikan ketersediaan atau hasil transaksi.

Untuk layanan yang memerlukan hubungan dengan Penasihat Berjangka PT Alma Indonesia Raya, pengguna wajib mengikuti proses resmi PT Alma Indonesia Raya. Jika suatu fitur memerlukan status klien/registrasi pada PT Alma Indonesia Raya, BLACKBOX wajib menahan akses sampai persyaratan tersebut terverifikasi.

PERNYATAAN KEHENDAK, PENERIMAAN RISIKO, PELEPASAN DAN PEMBEBASAN TUNTUTAN

Saya, pengguna yang identitas dan profilnya tercantum dalam bukti persetujuan ini, menyatakan bahwa saya telah membaca, memahami, memperoleh kesempatan yang memadai untuk meninjau dan menyimpan dokumen, serta menyetujui seluruh ketentuan dokumen ini secara sadar, sukarela, dan tanpa paksaan, tekanan, ancaman, penipuan, manipulasi, atau pengaruh tidak semestinya dari pihak mana pun.

Saya memahami bahwa persetujuan ini aktif dan bukan persetujuan diam-diam. Saya dapat memilih untuk tidak menggunakan layanan, tidak menghubungkan exchange/wallet, tidak mengaktifkan bot, tidak mengizinkan transaksi REAL, menghentikan layanan, atau tidak melanjutkan apabila saya tidak menyetujui ketentuan yang diwajibkan.

Saya menyatakan bahwa saya telah membaca, memahami, dan menyetujui pernyataan pelepasan dan pembebasan tuntutan ini secara sadar, sukarela, dengan kesempatan yang memadai untuk membaca dan menyimpan dokumen, serta tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan trading saya dan, sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan yang timbul sehubungan dengan penggunaan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.

Tidak ada bagian pernyataan ini yang dimaksudkan untuk menghapus atau mengesampingkan hak, perlindungan, kewajiban, tanggung jawab, mekanisme pengaduan, atau ketentuan lain yang menurut hukum yang berlaku bersifat wajib dan tidak dapat dikesampingkan. Jika suatu bagian pelepasan tidak dapat diberlakukan, bagian lain tetap berlaku sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku.

Saya memahami bahwa untuk perubahan material pada agreement, konfigurasi, permission, authorization, atau parameter risiko, BLACKBOX dapat meminta saya membaca kembali dan memberikan persetujuan ulang. Persetujuan lama tidak digunakan sebagai persetujuan diam-diam terhadap perubahan material.

Sebelum final acceptance, sistem dapat menampilkan identitas saya, tanggal, waktu, timezone, metode consent, document version, document hash, evidence hash, user-agent, dan konteks persetujuan. Password, OTP, MFA secret, API secret, private key, dan seed phrase tidak menjadi bagian dari bukti agreement.$LEGAL_1$,'6f521f28757c535fe02a340f5dc8999271ded4c4ca3ef50ffb26077571526ba3',true,'PUBLISHED','v12.0.8 Master Agreement, Trading Rules, User Statements and Material Re-consent Hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

-- TERMS: 6f521f28757c535fe02a340f5dc8999271ded4c4ca3ef50ffb26077571526ba3

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1208_02_privacy','PRIVACY','v12.0.8','Kebijakan Privasi dan Bukti Persetujuan BLACKBOX',$LEGAL_2$BLACKBOX memproses data pribadi untuk pembuatan dan pengamanan akun, verifikasi, penyediaan fitur, pencatatan persetujuan, audit, dukungan, pencegahan penyalahgunaan, keamanan sistem, kepatuhan, dan kewajiban hukum. Pemrosesan dilakukan secara terbatas, relevan, transparan, dan sesuai tujuan yang diberitahukan.

Untuk menjaga bukti persetujuan, sistem dapat menyimpan snapshot identitas yang relevan, versi dan hash dokumen, snapshot isi dokumen saat disetujui, waktu UTC, waktu lokal berdasarkan zona waktu yang dikirim perangkat, locale, sumber persetujuan, user-agent, hash alamat IP, konteks fitur, metode persetujuan, teks acknowledgement, dan metadata teknis yang diperlukan. Password, OTP, seed phrase, private key, dan API secret tidak dicatat sebagai isi persetujuan.

Bukti persetujuan bersifat audit evidence dan tidak boleh diubah secara diam-diam. Jika dokumen diperbarui, sistem menerbitkan versi baru; persetujuan lama tetap disimpan sebagai histori sesuai kewajiban retensi. Akses staf dibatasi berdasarkan role/permission dan setiap pencarian maupun ekspor agreement dicatat dalam audit log. Pengguna dapat mengunduh bukti persetujuannya sendiri melalui Legal & Agreement Center, dengan tetap memperhatikan kewajiban penyimpanan berdasarkan hukum yang berlaku.

PERNYATAAN KEHENDAK, PENERIMAAN RISIKO, PELEPASAN DAN PEMBEBASAN TUNTUTAN

Saya, pengguna yang identitas dan profilnya tercantum dalam bukti persetujuan ini, menyatakan bahwa saya telah membaca, memahami, memperoleh kesempatan yang memadai untuk meninjau dan menyimpan dokumen, serta menyetujui seluruh ketentuan dokumen ini secara sadar, sukarela, dan tanpa paksaan, tekanan, ancaman, penipuan, manipulasi, atau pengaruh tidak semestinya dari pihak mana pun.

Saya memahami bahwa persetujuan ini aktif dan bukan persetujuan diam-diam. Saya dapat memilih untuk tidak menggunakan layanan, tidak menghubungkan exchange/wallet, tidak mengaktifkan bot, tidak mengizinkan transaksi REAL, menghentikan layanan, atau tidak melanjutkan apabila saya tidak menyetujui ketentuan yang diwajibkan.

Saya menyatakan bahwa saya telah membaca, memahami, dan menyetujui pernyataan pelepasan dan pembebasan tuntutan ini secara sadar, sukarela, dengan kesempatan yang memadai untuk membaca dan menyimpan dokumen, serta tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan trading saya dan, sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan yang timbul sehubungan dengan penggunaan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.

Tidak ada bagian pernyataan ini yang dimaksudkan untuk menghapus atau mengesampingkan hak, perlindungan, kewajiban, tanggung jawab, mekanisme pengaduan, atau ketentuan lain yang menurut hukum yang berlaku bersifat wajib dan tidak dapat dikesampingkan. Jika suatu bagian pelepasan tidak dapat diberlakukan, bagian lain tetap berlaku sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku.

Saya memahami bahwa untuk perubahan material pada agreement, konfigurasi, permission, authorization, atau parameter risiko, BLACKBOX dapat meminta saya membaca kembali dan memberikan persetujuan ulang. Persetujuan lama tidak digunakan sebagai persetujuan diam-diam terhadap perubahan material.

Sebelum final acceptance, sistem dapat menampilkan identitas saya, tanggal, waktu, timezone, metode consent, document version, document hash, evidence hash, user-agent, dan konteks persetujuan. Password, OTP, MFA secret, API secret, private key, dan seed phrase tidak menjadi bagian dari bukti agreement.$LEGAL_2$,'2e9bb8a1b29f8150e1f8fb71160e2086315e521013c3f075e232e5d82b927ca9',true,'PUBLISHED','v12.0.8 Master Agreement, Trading Rules, User Statements and Material Re-consent Hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

-- PRIVACY: 2e9bb8a1b29f8150e1f8fb71160e2086315e521013c3f075e232e5d82b927ca9

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1208_03_risk','RISK','v12.0.8','Pemberitahuan Risiko Perdagangan dan Penggunaan BLACKBOX',$LEGAL_3$Trading aset kripto, derivatif, valuta asing, dan/atau instrumen berisiko lainnya memiliki risiko tinggi. Harga dapat bergerak cepat dan pengguna dapat kehilangan sebagian atau seluruh modal yang digunakan. Tidak ada jaminan keuntungan, win rate, pendapatan, tingkat keberhasilan, atau hasil tertentu.

Bot, AI, automation, router, signal, backtest, dan teknologi pendukung tidak menghilangkan risiko. Kesalahan konfigurasi, data yang tidak akurat, keterlambatan, slippage, partial fill, rejection, biaya, likuiditas, leverage, gangguan koneksi, blockchain, exchange/provider, perubahan kebijakan, maupun kondisi pasar ekstrem dapat menyebabkan kerugian nyata.

Pengguna wajib memeriksa modal, market, pair, leverage bila berlaku, ukuran posisi, stop loss/take profit, daily loss, drawdown, max positions, biaya, koneksi, dan parameter lain sebelum memberikan instruksi. Pengguna memahami bahwa hasil aktual dapat berbeda dari simulasi, backtest, sinyal, AI, atau ekspektasi sebelumnya. Risiko finansial dari keputusan trading berada pada pengguna sesuai penggunaan dan instruksi akunnya, tanpa menghapus tanggung jawab hukum pihak mana pun yang memang wajib menurut hukum.

PERNYATAAN KEHENDAK, PENERIMAAN RISIKO, PELEPASAN DAN PEMBEBASAN TUNTUTAN

Saya, pengguna yang identitas dan profilnya tercantum dalam bukti persetujuan ini, menyatakan bahwa saya telah membaca, memahami, memperoleh kesempatan yang memadai untuk meninjau dan menyimpan dokumen, serta menyetujui seluruh ketentuan dokumen ini secara sadar, sukarela, dan tanpa paksaan, tekanan, ancaman, penipuan, manipulasi, atau pengaruh tidak semestinya dari pihak mana pun.

Saya memahami bahwa persetujuan ini aktif dan bukan persetujuan diam-diam. Saya dapat memilih untuk tidak menggunakan layanan, tidak menghubungkan exchange/wallet, tidak mengaktifkan bot, tidak mengizinkan transaksi REAL, menghentikan layanan, atau tidak melanjutkan apabila saya tidak menyetujui ketentuan yang diwajibkan.

Saya menyatakan bahwa saya telah membaca, memahami, dan menyetujui pernyataan pelepasan dan pembebasan tuntutan ini secara sadar, sukarela, dengan kesempatan yang memadai untuk membaca dan menyimpan dokumen, serta tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan trading saya dan, sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan yang timbul sehubungan dengan penggunaan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.

Tidak ada bagian pernyataan ini yang dimaksudkan untuk menghapus atau mengesampingkan hak, perlindungan, kewajiban, tanggung jawab, mekanisme pengaduan, atau ketentuan lain yang menurut hukum yang berlaku bersifat wajib dan tidak dapat dikesampingkan. Jika suatu bagian pelepasan tidak dapat diberlakukan, bagian lain tetap berlaku sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku.

Saya memahami bahwa untuk perubahan material pada agreement, konfigurasi, permission, authorization, atau parameter risiko, BLACKBOX dapat meminta saya membaca kembali dan memberikan persetujuan ulang. Persetujuan lama tidak digunakan sebagai persetujuan diam-diam terhadap perubahan material.

Sebelum final acceptance, sistem dapat menampilkan identitas saya, tanggal, waktu, timezone, metode consent, document version, document hash, evidence hash, user-agent, dan konteks persetujuan. Password, OTP, MFA secret, API secret, private key, dan seed phrase tidak menjadi bagian dari bukti agreement.$LEGAL_3$,'2b30e3369317fe9d534f0894f0d2f9d2a217e774531ea19cd3ac620ace2caa6f',true,'PUBLISHED','v12.0.8 Master Agreement, Trading Rules, User Statements and Material Re-consent Hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

-- RISK: 2b30e3369317fe9d534f0894f0d2f9d2a217e774531ea19cd3ac620ace2caa6f

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1208_04_bot_start','BOT_START','v12.0.8','Persetujuan Pengaturan dan Menjalankan Bot',$LEGAL_4$Sebelum menekan START, pengguna wajib membaca dan memahami Syarat Penggunaan, Kebijakan Privasi, Pemberitahuan Risiko, dan ketentuan bot. Pengguna wajib memeriksa mode, market, pair, koneksi, modal, ukuran posisi, stop loss/take profit, daily loss, drawdown, max positions, biaya, dan parameter lain yang ditampilkan.

DEMO/PAPER menggunakan modal virtual. REAL, apabila seluruh gate produksi terpenuhi, dapat berdampak pada dana nyata pada akun pihak ketiga. Tidak ada jaminan bot akan menghasilkan profit, mencapai win rate tertentu, atau mencegah kerugian.

START hanya boleh diterima jika persetujuan eksplisit telah diberikan. Server mencatat versi dokumen, hash dokumen, identitas pengguna, waktu persetujuan, konteks, dan bukti teknis. Untuk REAL, persetujuan ini tidak menggantikan gate verifikasi, otorisasi, sertifikasi, keamanan, risk control, dan kesiapan produksi.

PERNYATAAN KEHENDAK, PENERIMAAN RISIKO, PELEPASAN DAN PEMBEBASAN TUNTUTAN

Saya, pengguna yang identitas dan profilnya tercantum dalam bukti persetujuan ini, menyatakan bahwa saya telah membaca, memahami, memperoleh kesempatan yang memadai untuk meninjau dan menyimpan dokumen, serta menyetujui seluruh ketentuan dokumen ini secara sadar, sukarela, dan tanpa paksaan, tekanan, ancaman, penipuan, manipulasi, atau pengaruh tidak semestinya dari pihak mana pun.

Saya memahami bahwa persetujuan ini aktif dan bukan persetujuan diam-diam. Saya dapat memilih untuk tidak menggunakan layanan, tidak menghubungkan exchange/wallet, tidak mengaktifkan bot, tidak mengizinkan transaksi REAL, menghentikan layanan, atau tidak melanjutkan apabila saya tidak menyetujui ketentuan yang diwajibkan.

Saya menyatakan bahwa saya telah membaca, memahami, dan menyetujui pernyataan pelepasan dan pembebasan tuntutan ini secara sadar, sukarela, dengan kesempatan yang memadai untuk membaca dan menyimpan dokumen, serta tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan trading saya dan, sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan yang timbul sehubungan dengan penggunaan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.

Tidak ada bagian pernyataan ini yang dimaksudkan untuk menghapus atau mengesampingkan hak, perlindungan, kewajiban, tanggung jawab, mekanisme pengaduan, atau ketentuan lain yang menurut hukum yang berlaku bersifat wajib dan tidak dapat dikesampingkan. Jika suatu bagian pelepasan tidak dapat diberlakukan, bagian lain tetap berlaku sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku.

Saya memahami bahwa untuk perubahan material pada agreement, konfigurasi, permission, authorization, atau parameter risiko, BLACKBOX dapat meminta saya membaca kembali dan memberikan persetujuan ulang. Persetujuan lama tidak digunakan sebagai persetujuan diam-diam terhadap perubahan material.

Sebelum final acceptance, sistem dapat menampilkan identitas saya, tanggal, waktu, timezone, metode consent, document version, document hash, evidence hash, user-agent, dan konteks persetujuan. Password, OTP, MFA secret, API secret, private key, dan seed phrase tidak menjadi bagian dari bukti agreement.$LEGAL_4$,'09b6c90ce790f8778e2883ba134125565a6eea1c0d80fe08646c5d5c0c0ba5e3',true,'PUBLISHED','v12.0.8 Master Agreement, Trading Rules, User Statements and Material Re-consent Hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

-- BOT_START: 09b6c90ce790f8778e2883ba134125565a6eea1c0d80fe08646c5d5c0c0ba5e3

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1208_05_bot_configuration','BOT_CONFIGURATION','v12.0.8','Persetujuan Perubahan Konfigurasi Bot',$LEGAL_5$Setiap perubahan material pada konfigurasi bot dapat mengubah perilaku, risiko, eksposur, biaya, atau hasil trading. Sebelum menyimpan perubahan material, pengguna wajib memeriksa kembali modal, market, pair, chain, koneksi, AI provider/model, guardrail, risiko per trade, drawdown, stop loss/take profit, daily loss, max positions, dan parameter relevan lainnya.

Pengguna memahami bahwa perubahan konfigurasi merupakan keputusan pengguna dan tidak menjamin keuntungan atau mencegah kerugian. Perubahan material harus melewati server-side safety gate dan dicatat bersama versi persetujuan yang relevan.

PERNYATAAN KEHENDAK, PENERIMAAN RISIKO, PELEPASAN DAN PEMBEBASAN TUNTUTAN

Saya, pengguna yang identitas dan profilnya tercantum dalam bukti persetujuan ini, menyatakan bahwa saya telah membaca, memahami, memperoleh kesempatan yang memadai untuk meninjau dan menyimpan dokumen, serta menyetujui seluruh ketentuan dokumen ini secara sadar, sukarela, dan tanpa paksaan, tekanan, ancaman, penipuan, manipulasi, atau pengaruh tidak semestinya dari pihak mana pun.

Saya memahami bahwa persetujuan ini aktif dan bukan persetujuan diam-diam. Saya dapat memilih untuk tidak menggunakan layanan, tidak menghubungkan exchange/wallet, tidak mengaktifkan bot, tidak mengizinkan transaksi REAL, menghentikan layanan, atau tidak melanjutkan apabila saya tidak menyetujui ketentuan yang diwajibkan.

Saya menyatakan bahwa saya telah membaca, memahami, dan menyetujui pernyataan pelepasan dan pembebasan tuntutan ini secara sadar, sukarela, dengan kesempatan yang memadai untuk membaca dan menyimpan dokumen, serta tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan trading saya dan, sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan yang timbul sehubungan dengan penggunaan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.

Tidak ada bagian pernyataan ini yang dimaksudkan untuk menghapus atau mengesampingkan hak, perlindungan, kewajiban, tanggung jawab, mekanisme pengaduan, atau ketentuan lain yang menurut hukum yang berlaku bersifat wajib dan tidak dapat dikesampingkan. Jika suatu bagian pelepasan tidak dapat diberlakukan, bagian lain tetap berlaku sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku.

Saya memahami bahwa untuk perubahan material pada agreement, konfigurasi, permission, authorization, atau parameter risiko, BLACKBOX dapat meminta saya membaca kembali dan memberikan persetujuan ulang. Persetujuan lama tidak digunakan sebagai persetujuan diam-diam terhadap perubahan material.

Sebelum final acceptance, sistem dapat menampilkan identitas saya, tanggal, waktu, timezone, metode consent, document version, document hash, evidence hash, user-agent, dan konteks persetujuan. Password, OTP, MFA secret, API secret, private key, dan seed phrase tidak menjadi bagian dari bukti agreement.$LEGAL_5$,'c154d12b3e80823bd386f5dffdb9982fa9d769b6168523d168d4c8530d8b760d',true,'PUBLISHED','v12.0.8 Master Agreement, Trading Rules, User Statements and Material Re-consent Hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

-- BOT_CONFIGURATION: c154d12b3e80823bd386f5dffdb9982fa9d769b6168523d168d4c8530d8b760d

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1208_06_setup_step','SETUP_STEP','v12.0.8','Persetujuan Setup Bot',$LEGAL_6$Pengguna menyatakan telah meninjau konfigurasi awal bot sebelum bot dibuat atau diluncurkan, termasuk mode, modal virtual/nyata, market, pair, chain, AI provider/model, guardrail, batas posisi, stop loss/take profit, daily loss, drawdown, dan parameter lain yang ditampilkan.

DEMO/PAPER menggunakan modal virtual. Tidak ada jaminan keuntungan. Setiap penggunaan REAL tetap tunduk pada gate produksi dan persetujuan REAL yang terpisah.

PERNYATAAN KEHENDAK, PENERIMAAN RISIKO, PELEPASAN DAN PEMBEBASAN TUNTUTAN

Saya, pengguna yang identitas dan profilnya tercantum dalam bukti persetujuan ini, menyatakan bahwa saya telah membaca, memahami, memperoleh kesempatan yang memadai untuk meninjau dan menyimpan dokumen, serta menyetujui seluruh ketentuan dokumen ini secara sadar, sukarela, dan tanpa paksaan, tekanan, ancaman, penipuan, manipulasi, atau pengaruh tidak semestinya dari pihak mana pun.

Saya memahami bahwa persetujuan ini aktif dan bukan persetujuan diam-diam. Saya dapat memilih untuk tidak menggunakan layanan, tidak menghubungkan exchange/wallet, tidak mengaktifkan bot, tidak mengizinkan transaksi REAL, menghentikan layanan, atau tidak melanjutkan apabila saya tidak menyetujui ketentuan yang diwajibkan.

Saya menyatakan bahwa saya telah membaca, memahami, dan menyetujui pernyataan pelepasan dan pembebasan tuntutan ini secara sadar, sukarela, dengan kesempatan yang memadai untuk membaca dan menyimpan dokumen, serta tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan trading saya dan, sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan yang timbul sehubungan dengan penggunaan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.

Tidak ada bagian pernyataan ini yang dimaksudkan untuk menghapus atau mengesampingkan hak, perlindungan, kewajiban, tanggung jawab, mekanisme pengaduan, atau ketentuan lain yang menurut hukum yang berlaku bersifat wajib dan tidak dapat dikesampingkan. Jika suatu bagian pelepasan tidak dapat diberlakukan, bagian lain tetap berlaku sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku.

Saya memahami bahwa untuk perubahan material pada agreement, konfigurasi, permission, authorization, atau parameter risiko, BLACKBOX dapat meminta saya membaca kembali dan memberikan persetujuan ulang. Persetujuan lama tidak digunakan sebagai persetujuan diam-diam terhadap perubahan material.

Sebelum final acceptance, sistem dapat menampilkan identitas saya, tanggal, waktu, timezone, metode consent, document version, document hash, evidence hash, user-agent, dan konteks persetujuan. Password, OTP, MFA secret, API secret, private key, dan seed phrase tidak menjadi bagian dari bukti agreement.$LEGAL_6$,'b19ab639be6778166a3a221b7856d64bb453fc344eea048685c4facbc0b0ed35',true,'PUBLISHED','v12.0.8 Master Agreement, Trading Rules, User Statements and Material Re-consent Hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

-- SETUP_STEP: b19ab639be6778166a3a221b7856d64bb453fc344eea048685c4facbc0b0ed35

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1208_07_real_execution','REAL_EXECUTION','v12.0.8','Persetujuan Eksekusi REAL',$LEGAL_7$Dengan mengaktifkan atau memberikan instruksi eksekusi REAL, pengguna menyatakan telah memahami bahwa transaksi dapat menghasilkan keuntungan maupun kerugian nyata, termasuk kemungkinan kehilangan sebagian atau seluruh dana yang digunakan. Pengguna wajib memastikan akun pihak ketiga, izin trade, simbol, arah transaksi, ukuran posisi, leverage jika berlaku, dan parameter order sudah benar.

Pengguna memahami bahwa BLACKBOX tidak menjamin hasil, tidak menjamin order selalu berhasil, dan tidak menjamin kerugian dapat dicegah. Eksekusi hanya boleh berlangsung apabila seluruh persyaratan keamanan, otorisasi, kepatuhan, sertifikasi, dan kesiapan produksi terpenuhi. Kerugian yang timbul semata-mata dari risiko pasar atau keputusan pengguna bukan merupakan jaminan tanggung jawab penggantian oleh BLACKBOX; ketentuan ini tidak menghapus tanggung jawab yang tidak dapat dikesampingkan menurut hukum.

PERNYATAAN KEHENDAK, PENERIMAAN RISIKO, PELEPASAN DAN PEMBEBASAN TUNTUTAN

Saya, pengguna yang identitas dan profilnya tercantum dalam bukti persetujuan ini, menyatakan bahwa saya telah membaca, memahami, memperoleh kesempatan yang memadai untuk meninjau dan menyimpan dokumen, serta menyetujui seluruh ketentuan dokumen ini secara sadar, sukarela, dan tanpa paksaan, tekanan, ancaman, penipuan, manipulasi, atau pengaruh tidak semestinya dari pihak mana pun.

Saya memahami bahwa persetujuan ini aktif dan bukan persetujuan diam-diam. Saya dapat memilih untuk tidak menggunakan layanan, tidak menghubungkan exchange/wallet, tidak mengaktifkan bot, tidak mengizinkan transaksi REAL, menghentikan layanan, atau tidak melanjutkan apabila saya tidak menyetujui ketentuan yang diwajibkan.

Saya menyatakan bahwa saya telah membaca, memahami, dan menyetujui pernyataan pelepasan dan pembebasan tuntutan ini secara sadar, sukarela, dengan kesempatan yang memadai untuk membaca dan menyimpan dokumen, serta tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan trading saya dan, sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan yang timbul sehubungan dengan penggunaan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.

Tidak ada bagian pernyataan ini yang dimaksudkan untuk menghapus atau mengesampingkan hak, perlindungan, kewajiban, tanggung jawab, mekanisme pengaduan, atau ketentuan lain yang menurut hukum yang berlaku bersifat wajib dan tidak dapat dikesampingkan. Jika suatu bagian pelepasan tidak dapat diberlakukan, bagian lain tetap berlaku sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku.

Saya memahami bahwa untuk perubahan material pada agreement, konfigurasi, permission, authorization, atau parameter risiko, BLACKBOX dapat meminta saya membaca kembali dan memberikan persetujuan ulang. Persetujuan lama tidak digunakan sebagai persetujuan diam-diam terhadap perubahan material.

Sebelum final acceptance, sistem dapat menampilkan identitas saya, tanggal, waktu, timezone, metode consent, document version, document hash, evidence hash, user-agent, dan konteks persetujuan. Password, OTP, MFA secret, API secret, private key, dan seed phrase tidak menjadi bagian dari bukti agreement.$LEGAL_7$,'c00044d56e08e74073e4522dcdafee3a4b63ccdc5a7f6d8487b5007f8236fec4',true,'PUBLISHED','v12.0.8 Master Agreement, Trading Rules, User Statements and Material Re-consent Hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

-- REAL_EXECUTION: c00044d56e08e74073e4522dcdafee3a4b63ccdc5a7f6d8487b5007f8236fec4

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1208_08_registration','REGISTRATION','v12.0.8','Persetujuan Registrasi BLACKBOX',$LEGAL_8$Pengguna menyatakan data registrasi yang diberikan benar, akurat, lengkap, dan diberikan dengan kewenangan yang sah. Pengguna memahami BLACKBOX adalah platform teknologi pendukung dan bukan dengan sendirinya merupakan Penasihat Berjangka, Pedagang Aset Keuangan Digital, kustodian, pengelola dana, atau pihak berizin lain.

Pengguna menyatakan telah membaca Syarat Penggunaan, Kebijakan Privasi, Pemberitahuan Risiko, dan memahami bahwa trading dapat menyebabkan kerugian nyata. Pendaftaran akun BLACKBOX tidak berarti dana pengguna diserahkan kepada BLACKBOX.

Jika fitur yang dipilih membutuhkan hubungan dengan PT Alma Indonesia Raya, pengguna wajib menyelesaikan proses registrasi, verifikasi, dan penerimaan perjanjian pada PT Alma Indonesia Raya melalui kanal resmi sebelum fitur tersebut dapat digunakan.

PERNYATAAN KEHENDAK, PENERIMAAN RISIKO, PELEPASAN DAN PEMBEBASAN TUNTUTAN

Saya, pengguna yang identitas dan profilnya tercantum dalam bukti persetujuan ini, menyatakan bahwa saya telah membaca, memahami, memperoleh kesempatan yang memadai untuk meninjau dan menyimpan dokumen, serta menyetujui seluruh ketentuan dokumen ini secara sadar, sukarela, dan tanpa paksaan, tekanan, ancaman, penipuan, manipulasi, atau pengaruh tidak semestinya dari pihak mana pun.

Saya memahami bahwa persetujuan ini aktif dan bukan persetujuan diam-diam. Saya dapat memilih untuk tidak menggunakan layanan, tidak menghubungkan exchange/wallet, tidak mengaktifkan bot, tidak mengizinkan transaksi REAL, menghentikan layanan, atau tidak melanjutkan apabila saya tidak menyetujui ketentuan yang diwajibkan.

Saya menyatakan bahwa saya telah membaca, memahami, dan menyetujui pernyataan pelepasan dan pembebasan tuntutan ini secara sadar, sukarela, dengan kesempatan yang memadai untuk membaca dan menyimpan dokumen, serta tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan trading saya dan, sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan yang timbul sehubungan dengan penggunaan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.

Tidak ada bagian pernyataan ini yang dimaksudkan untuk menghapus atau mengesampingkan hak, perlindungan, kewajiban, tanggung jawab, mekanisme pengaduan, atau ketentuan lain yang menurut hukum yang berlaku bersifat wajib dan tidak dapat dikesampingkan. Jika suatu bagian pelepasan tidak dapat diberlakukan, bagian lain tetap berlaku sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku.

Saya memahami bahwa untuk perubahan material pada agreement, konfigurasi, permission, authorization, atau parameter risiko, BLACKBOX dapat meminta saya membaca kembali dan memberikan persetujuan ulang. Persetujuan lama tidak digunakan sebagai persetujuan diam-diam terhadap perubahan material.

Sebelum final acceptance, sistem dapat menampilkan identitas saya, tanggal, waktu, timezone, metode consent, document version, document hash, evidence hash, user-agent, dan konteks persetujuan. Password, OTP, MFA secret, API secret, private key, dan seed phrase tidak menjadi bagian dari bukti agreement.$LEGAL_8$,'9c6a8ec303a3bca84346cf4a0aa80d996a3db2325931c50efbd275972f73ddf1',true,'PUBLISHED','v12.0.8 Master Agreement, Trading Rules, User Statements and Material Re-consent Hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

-- REGISTRATION: 9c6a8ec303a3bca84346cf4a0aa80d996a3db2325931c50efbd275972f73ddf1

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1208_09_alma_advisor_registration','ALMA_ADVISOR_REGISTRATION','v12.0.8','Kewajiban Pendaftaran PT Alma Indonesia Raya untuk Layanan Penasihat Berjangka',$LEGAL_9$PT Alma Indonesia Raya adalah perusahaan Penasihat Berjangka yang tercantum pada daftar resmi Bappebti dengan Izin Usaha Nomor 02/BAPPEBTI/SI-PNB/02/2024. Sejak proses registrasi BLACKBOX, pengguna menerima pemberitahuan dan diwajibkan, untuk menggunakan layanan trading BLACKBOX yang berada dalam ruang lingkup hubungan Penasihat Berjangka, untuk melakukan pendaftaran/registrasi, verifikasi identitas, dan penerimaan perjanjian layanan PT Alma Indonesia Raya melalui kanal resminya.

Pendaftaran BLACKBOX tidak menggantikan perjanjian atau hubungan hukum pengguna dengan PT Alma Indonesia Raya. Pengguna wajib membaca dokumen resmi PT Alma Indonesia Raya, memahami risiko dan biaya layanan, serta menyelesaikan proses pada sistem resmi PT Alma Indonesia Raya sebelum menggunakan fitur yang mensyaratkan hubungan tersebut. BLACKBOX tidak boleh menyatakan pengguna telah menjadi klien PT Alma Indonesia Raya hanya berdasarkan checkbox atau akun BLACKBOX; apabila status hubungan eksternal belum dapat diverifikasi, fitur yang mensyaratkannya harus tetap terkunci.

PERNYATAAN KEHENDAK, PENERIMAAN RISIKO, PELEPASAN DAN PEMBEBASAN TUNTUTAN

Saya, pengguna yang identitas dan profilnya tercantum dalam bukti persetujuan ini, menyatakan bahwa saya telah membaca, memahami, memperoleh kesempatan yang memadai untuk meninjau dan menyimpan dokumen, serta menyetujui seluruh ketentuan dokumen ini secara sadar, sukarela, dan tanpa paksaan, tekanan, ancaman, penipuan, manipulasi, atau pengaruh tidak semestinya dari pihak mana pun.

Saya memahami bahwa persetujuan ini aktif dan bukan persetujuan diam-diam. Saya dapat memilih untuk tidak menggunakan layanan, tidak menghubungkan exchange/wallet, tidak mengaktifkan bot, tidak mengizinkan transaksi REAL, menghentikan layanan, atau tidak melanjutkan apabila saya tidak menyetujui ketentuan yang diwajibkan.

Saya menyatakan bahwa saya telah membaca, memahami, dan menyetujui pernyataan pelepasan dan pembebasan tuntutan ini secara sadar, sukarela, dengan kesempatan yang memadai untuk membaca dan menyimpan dokumen, serta tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan trading saya dan, sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan yang timbul sehubungan dengan penggunaan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.

Tidak ada bagian pernyataan ini yang dimaksudkan untuk menghapus atau mengesampingkan hak, perlindungan, kewajiban, tanggung jawab, mekanisme pengaduan, atau ketentuan lain yang menurut hukum yang berlaku bersifat wajib dan tidak dapat dikesampingkan. Jika suatu bagian pelepasan tidak dapat diberlakukan, bagian lain tetap berlaku sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku.

Saya memahami bahwa untuk perubahan material pada agreement, konfigurasi, permission, authorization, atau parameter risiko, BLACKBOX dapat meminta saya membaca kembali dan memberikan persetujuan ulang. Persetujuan lama tidak digunakan sebagai persetujuan diam-diam terhadap perubahan material.

Sebelum final acceptance, sistem dapat menampilkan identitas saya, tanggal, waktu, timezone, metode consent, document version, document hash, evidence hash, user-agent, dan konteks persetujuan. Password, OTP, MFA secret, API secret, private key, dan seed phrase tidak menjadi bagian dari bukti agreement.$LEGAL_9$,'72efb7e0bf21b85780a1ebcbfdf27bf8474ba55e568517a24580b82c32c3a55c',true,'PUBLISHED','v12.0.8 Master Agreement, Trading Rules, User Statements and Material Re-consent Hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

-- ALMA_ADVISOR_REGISTRATION: 72efb7e0bf21b85780a1ebcbfdf27bf8474ba55e568517a24580b82c32c3a55c

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1208_10_trading_rules','TRADING_RULES','v12.0.8','TRADING RULES & USER CONTROL AGREEMENT — BLACKBOX Crypto',$LEGAL_10$BLACKBOX TECHNOLOGY
MASTER AGREEMENT, TRADING RULES & USER STATEMENTS
Draft Review — v12.0.8

BAGIAN 1 — IDENTITAS USER
DATA DIRI USER
Nama Lengkap: [AUTO-FILL]
Username: [AUTO-FILL]
User ID: [AUTO-FILL]
Email: [AUTO-FILL]
Nomor Telepon/WhatsApp: [AUTO-FILL]
Tanggal Lahir: [AUTO-FILL]
Alamat: [AUTO-FILL]
Negara: [AUTO-FILL]
Status Verifikasi/KYC: [AUTO-FILL]
Role: [AUTO-FILL]
Tier/Layanan: [AUTO-FILL]
Tanggal Registrasi: [AUTO-FILL]

DATA PERSETUJUAN
Tanggal Persetujuan: [AUTO]
Waktu Persetujuan: [AUTO]
Timezone: [AUTO]
Metode Persetujuan: [AUTO]
IP Evidence Hash: [AUTO]
User Agent: [AUTO]
Document Version: [AUTO]
Document Hash: [AUTO]
Evidence Hash: [AUTO]

BAGIAN 2 — PERNYATAAN IDENTITAS DAN KEHENDAK USER
Saya menyatakan bahwa identitas yang tercantum otomatis dalam dokumen ini adalah identitas saya dan bahwa saya adalah orang yang melakukan registrasi, penggunaan akun, konfigurasi layanan, pemberian persetujuan, koneksi exchange/wallet, aktivasi layanan, dan/atau aktivitas trading melalui akun BLACKBOX Technology saya.

Saya menyatakan seluruh data identitas dan informasi yang saya berikan adalah benar, lengkap, dan dapat dipertanggungjawabkan sesuai keadaan saya pada saat persetujuan. Tindakan melalui akun saya merupakan tindakan saya sendiri atau tindakan yang dilakukan berdasarkan authorization yang saya berikan melalui mekanisme resmi BLACKBOX Technology. Akun saya bersifat pribadi dan saya bertanggung jawab menjaga keamanan aksesnya.

BAGIAN 3 — PERNYATAAN SADAR DAN TANPA PAKSAAN
Saya telah diberi kesempatan yang memadai untuk membaca Agreement, Trading Rules, Risk Disclosure, Privacy Policy, Connection Authorization, Bot Agreement, Real Execution Authorization, dan dokumen lain yang berlaku. Saya menyatakan telah membaca dan memahami dokumen tersebut serta memberikan persetujuan secara sadar, sukarela, tanpa paksaan, tekanan, ancaman, penipuan, manipulasi, atau pengaruh yang tidak semestinya. Saya memahami bahwa saya dapat memilih untuk tidak menggunakan layanan, tidak menghubungkan exchange/wallet, tidak mengaktifkan bot, tidak melakukan transaksi, atau menghentikan penggunaan layanan.

BAGIAN 4 — APA ITU BLACKBOX TECHNOLOGY
BLACKBOX Technology adalah platform teknologi pendukung yang dapat menyediakan informasi pasar, market monitoring, market scanner, market intelligence, artificial intelligence, trading intelligence, risk intelligence, decision support, portfolio information, trading tools, bot configuration, bot monitoring, exchange connectivity, wallet connectivity, activity records, analytics, reporting, simulation, dan integrasi teknologi pihak ketiga.

Penggunaan BLACKBOX tidak dengan sendirinya mengalihkan kepemilikan atau kendali dana/aset, akun pihak ketiga, atau kewenangan finansial pengguna kepada BLACKBOX. Setiap fitur bekerja berdasarkan fungsi, konfigurasi, authorization, permission, safety gate, dan persetujuan yang diberikan atau ditentukan pengguna. BLACKBOX tidak boleh memperluas mandat secara diam-diam.

BAGIAN 5 — KENDALI TRADING SEPENUHNYA PADA USER
KENDALI TRADING DI TANGAN PENGGUNA
Saya sendiri yang menentukan atau menyetujui: trading atau tidak; exchange; wallet; account; jenis market; Spot/Futures/DEX bila tersedia; modal; ukuran transaksi; leverage; risk limit; stop loss; take profit; strategi; parameter bot; batas exposure; permission API; authorization; waktu mulai; waktu berhenti; izin transaksi nyata; start/stop trading; disconnect exchange; disconnect wallet; dan penghapusan akun permanen sesuai kemampuan sistem.

AI tidak diberi kewenangan untuk memperluas mandat pengguna secara diam-diam. BLACKBOX dan AI tidak boleh dianggap mengambil alih keputusan trading saya. Signal, recommendation, intelligence, analysis, prediction, opportunity detection, scanner result, dan AI output adalah teknologi pendukung dan bukan jaminan. Untuk layanan yang mensyaratkan hubungan Penasihat Berjangka, pengguna terlebih dahulu harus menyelesaikan pendaftaran/verifikasi pada PT Alma Indonesia Raya melalui kanal resmi, memahami layanan yang berlaku, menentukan manajemen trading dan risiko, lalu memberikan persetujuan pribadi untuk aktivitas yang akan dilakukan.

BAGIAN 6 — TRADING RULES
TRADING RULES ini merupakan agreement operasional yang wajib dibaca, dipahami, dan disetujui pengguna sebelum menggunakan fitur trading, menghubungkan akun trading/wallet untuk aktivitas trading, membuat konfigurasi live, atau menjalankan bot.

6.1 Prinsip Dasar
USER DECISION → USER CONFIGURATION → USER AUTHORIZATION → SYSTEM EXECUTION
BLACKBOX tidak boleh memperluas mandat secara diam-diam, mengubah parameter material tanpa authorization yang diperlukan, menggunakan exchange/wallet yang tidak diotorisasi, atau menggunakan permission melebihi scope yang diberikan.

6.2 Trading Intelligence
Trading Intelligence merupakan teknologi pendukung/penunjang untuk membaca market, scanning, analisis, identifikasi opportunity, risk analysis, informasi, signal, rekomendasi berbasis data, dan insight. Hasilnya bukan jaminan keuntungan. Kondisi market dapat berubah dan hasil aktual dapat berbeda dari analisis, prediksi, simulasi, intelligence, atau hasil masa lalu.

BAGIAN 7 — AI TRADING RULES
AI BLACKBOX bukan jaminan profit, win rate, return, income, keberhasilan, atau kebenaran output. AI tidak mengetahui masa depan market dan dapat menghasilkan output berdasarkan data/model yang tersedia yang tidak sesuai dengan kondisi aktual. AI tidak boleh melakukan tindakan di luar perintah, authorization, konfigurasi, dan safety gate yang berlaku. Keputusan menggunakan output AI tetap berada pada pengguna.

BAGIAN 8 — EXCHANGE CONNECTION AGREEMENT
Saya sendiri memilih exchange dan account yang dihubungkan. Koneksi dapat memungkinkan pembacaan informasi dan/atau tindakan tertentu sesuai permission yang saya berikan. Saya memahami permission API adalah kewenangan yang saya berikan secara sadar. Kesalahan exchange, account, permission, API configuration, atau parameter dapat menyebabkan kerugian nyata. BLACKBOX tidak meminta atau menyimpan password exchange. Withdrawal permission wajib nonaktif pada koneksi BLACKBOX; hanya permission Read/Trade yang diperlukan oleh fungsi yang diizinkan.

BAGIAN 9 — WALLET CONNECTION AGREEMENT
Saya sendiri memilih wallet dengan sadar dan tanpa paksaan. Saya memahami tujuan dan risikonya. Cryptographic ownership signature hanya membuktikan kontrol atas alamat dan tidak otomatis berarti saya memberi kewenangan kepada BLACKBOX untuk mengambil, memindahkan, atau menguasai aset. Saya tidak memberikan seed phrase atau private key; BLACKBOX tidak meminta data tersebut. Keamanan wallet tetap tanggung jawab saya.

BAGIAN 10 — BOT TRADING AGREEMENT
Sebelum mengaktifkan bot saya menyatakan telah membaca Trading Rules dan Risk Disclosure serta memahami konfigurasi, strategi, parameter, modal, risk limit, leverage, exchange/wallet connection, kemungkinan kehilangan uang nyata, dan tidak adanya jaminan profit, refund, atau kompensasi atas kerugian, sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku. Saya mengizinkan bot bekerja hanya sesuai konfigurasi yang saya pilih dan setujui. Hasil bot dapat mengalami keuntungan maupun kerugian dan tidak memiliki batas keuntungan/kerugian yang dapat dijamin sebelumnya.

BAGIAN 11 — REAL EXECUTION AUTHORIZATION
REAL EXECUTION berarti transaksi nyata dengan uang/modal nyata dapat terjadi. Risiko mencakup kehilangan uang/aset, kehilangan sebagian/seluruh modal, liquidation, slippage, partial fill, failed order, market movement, latency, exchange downtime, API failure, network failure, dan risiko lainnya. Saya telah membaca dan memahami risiko tersebut sebelum authorization. REAL execution hanya boleh berjalan sesuai konfigurasi, batasan, permission, risk gate, legal/compliance gate, security gate, dan certification gate yang benar-benar terpenuhi.

BAGIAN 12 — PENASIHAT BERJANGKA PT ALMA INDONESIA RAYA
Saya memahami bahwa sejak proses pendaftaran BLACKBOX dan sebelum fitur tertentu digunakan, saya dapat diwajibkan menyelesaikan registrasi, verifikasi, dan penerimaan dokumen layanan PT Alma Indonesia Raya melalui kanal resmi. Pendaftaran BLACKBOX tidak menggantikan registrasi, verifikasi, agreement, kontrak, hubungan hukum, atau kewajiban lain dengan PT Alma Indonesia Raya. BLACKBOX tidak menyatakan seseorang telah menjadi klien Alma hanya karena memiliki akun atau mencentang checkbox; status hubungan eksternal harus mengikuti proses dan verifikasi resmi.

BAGIAN 13 — RISIKO KEHILANGAN UANG NYATA
Trading adalah aktivitas berisiko tinggi. Saya memahami saya dapat kehilangan sebagian atau seluruh uang/modal/aset nyata yang saya gunakan atau hubungkan. TIDAK ADA JAMINAN PROFIT. TIDAK ADA JAMINAN WIN RATE. TIDAK ADA JAMINAN RETURN. TIDAK ADA JAMINAN TIDAK AKAN TERJADI KERUGIAN. TIDAK ADA JAMINAN BOT SELALU BERHASIL. TIDAK ADA JAMINAN AI SELALU BENAR.

BAGIAN 14 — PERNYATAAN TANGGUNG JAWAB USER
Keputusan menggunakan BLACKBOX, menggunakan DEMO sebelum REAL, menghubungkan exchange/wallet, memberikan permission, mengaktifkan bot, menentukan modal/strategi/leverage/parameter, menyetujui execution, dan melakukan transaksi merupakan keputusan saya sendiri. Saya bertanggung jawab membaca, memahami, dan menyetujui konfigurasi sebelum mengaktifkan layanan.

BAGIAN 15 — PERNYATAAN PELEPASAN / PEMBEBASAN TUNTUTAN
Dengan kesadaran penuh, secara sukarela, tanpa paksaan, tekanan, ancaman, penipuan, manipulasi, atau pengaruh yang tidak semestinya, dan sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku, saya secara sadar menyatakan MELEPASKAN, MEMBEBASKAN, dan TIDAK MENGAJUKAN TUNTUTAN, KLAIM, PERMINTAAN GANTI RUGI, ATAU PERMINTAAN PEMBAYARAN terhadap BLACKBOX Technology, penyedia teknologi, pengelola, operator, pengembang, afiliasi, pihak referral, dan pihak terkait yang tercakup dalam layanan BLACKBOX, atas kerugian atau kehilangan yang saya alami sehubungan dengan penggunaan layanan, koneksi pihak ketiga, permission, konfigurasi, authorization, instruksi, keputusan trading, modal, strategi, parameter risiko, aktivitas bot, AI, trading intelligence, atau transaksi yang saya pilih, setujui, konfirmasi, izinkan, atau terima.

Pernyataan ini tidak dimaksudkan sebagai jaminan bahwa semua klaim atau tanggung jawab dapat dikesampingkan secara kontraktual. Hak, perlindungan, kewajiban, tanggung jawab, mekanisme pengaduan, dan ketentuan yang menurut hukum bersifat wajib tetap berlaku. Jika suatu bagian release/waiver tidak dapat diberlakukan, bagian lainnya tetap berlaku sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku.

BAGIAN 16 — PERNYATAAN TIDAK ADA JAMINAN
BLACKBOX Technology tidak memberikan jaminan profit, return, income, win rate, successful execution, successful strategy, uninterrupted service, uninterrupted exchange, uninterrupted network, market prediction, atau hasil trading tertentu.

BAGIAN 17 — USER DAPAT MENGHENTIKAN LAYANAN
Saya dapat, sesuai kemampuan sistem dan kondisi teknis, menghentikan bot, mengubah konfigurasi, menonaktifkan layanan, disconnect exchange, disconnect wallet, menghentikan trading, dan menghapus akun secara permanen. Untuk tindakan yang sedang diproses atau yang dibatasi oleh kondisi teknis/keamanan, sistem dapat menerapkan safe-mode, fail-closed, atau prosedur penghentian yang diperlukan.

BAGIAN 18 — ALUR PERSETUJUAN
Registration → Legal Agreement → Risk Disclosure → Trading Rules → Alma Registration/Verification jika diwajibkan → Exchange/Wallet Connection → Configuration → User Authorization → Bot Start → Real Execution Authorization jika diperlukan → Execution → Monitoring → Reconciliation → Stop/Disconnect.

BAGIAN 19 — BUKTI PERSETUJUAN
Evidence dapat mencakup identity/profile snapshot, agreement, document version, document hash, document snapshot, acknowledgement text, consent method, tanggal, waktu UTC, waktu lokal, timezone, locale, user-agent, IP hash, consent context, dan evidence hash. Historical agreement yang telah disetujui dipertahankan sebagai bukti versi yang berlaku saat persetujuan. Rahasia seperti password, OTP, MFA secret, API secret, seed phrase, dan private key tidak dimasukkan ke evidence.

BAGIAN 20 — HAK USER MENDAPATKAN SALINAN
Saya dapat memperoleh dan mengunduh salinan agreement yang telah saya setujui melalui Legal Center BLACKBOX. Format dapat mencakup PDF, DOC/DOCX, dan XLSX. Salinan dapat mencantumkan identitas, waktu persetujuan, versi, hash, acknowledgement, dan evidence yang relevan.

BAGIAN 21 — CHECKBOX PERSETUJUAN
☐ Saya telah membaca Agreement, Trading Rules, dan Risk Disclosure.
☐ Saya memahami trading dapat menyebabkan kehilangan uang nyata.
☐ Saya memahami tidak ada jaminan profit, win rate, return, atau keberhasilan.
☐ Saya memahami AI bukan jaminan keberhasilan trading.
☐ Saya sendiri memilih exchange dan wallet yang saya hubungkan.
☐ Saya memahami permission yang saya berikan dan withdrawal permission wajib nonaktif.
☐ Saya menyetujui konfigurasi trading saya.
☐ Saya memahami risiko bot dan REAL execution.
☐ Saya memahami kewajiban registrasi/verifikasi/layanan edukasi PT Alma Indonesia Raya jika diwajibkan oleh layanan terkait.
☐ Saya menyatakan persetujuan diberikan secara sadar dan sukarela tanpa paksaan.
☐ Saya memperoleh kesempatan membaca dokumen secara lengkap.
☐ Saya menyetujui pencatatan evidence persetujuan.
☐ Saya menyetujui Pernyataan Pelepasan dan Pembebasan sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku.
☐ Saya menyatakan data identitas saya benar.

BAGIAN 22 — FINAL USER DECLARATION
“SAYA TELAH MEMBACA, MEMAHAMI, MENYETUJUI, DAN MENERIMA SELURUH AGREEMENT, TRADING RULES, RISIKO, PERNYATAAN, AUTHORIZATION, DAN KETENTUAN YANG BERLAKU SECARA SADAR, SUKARELA, DAN TANPA PAKSAAN DARI PIHAK MANA PUN.”

Nama User: [AUTO-FILL]
User ID: [AUTO-FILL]
Tanggal: [AUTO]
Waktu: [AUTO]
Timezone: [AUTO]
Metode Consent: [AUTO]
Document Version: [AUTO]
Document Hash: [AUTO]
Evidence Hash: [AUTO]
STATUS: AGREED / ACCEPTED

BAGIAN 23 — REKONFIRMASI SEBELUM REAL
Sebelum REAL execution, pengguna wajib meninjau dan mengonfirmasi kembali exchange/account, wallet, market, symbol/pair, modal, size, leverage, risk limit, stop loss/take profit, strategy, bot parameters, exposure, API permission, dan authorization. Persetujuan umum tidak dianggap sebagai persetujuan diam-diam untuk perubahan material.

BAGIAN 24 — PERUBAHAN MATERIAL DAN RE-CONSENT
Jika terdapat perubahan material pada agreement, risk disclosure, trading rules, exchange/wallet permission, authorization, strategy, leverage, risk limit, atau konfigurasi yang secara material mengubah risiko/mandat, sistem dapat mewajibkan pembacaan dan persetujuan ulang sebelum fitur terkait dapat digunakan. Snapshot persetujuan sebelumnya tetap disimpan sebagai histori dan tidak ditimpa.

PERNYATAAN KEHENDAK, PENERIMAAN RISIKO, PELEPASAN DAN PEMBEBASAN TUNTUTAN

Saya, pengguna yang identitas dan profilnya tercantum dalam bukti persetujuan ini, menyatakan bahwa saya telah membaca, memahami, memperoleh kesempatan yang memadai untuk meninjau dan menyimpan dokumen, serta menyetujui seluruh ketentuan dokumen ini secara sadar, sukarela, dan tanpa paksaan, tekanan, ancaman, penipuan, manipulasi, atau pengaruh tidak semestinya dari pihak mana pun.

Saya memahami bahwa persetujuan ini aktif dan bukan persetujuan diam-diam. Saya dapat memilih untuk tidak menggunakan layanan, tidak menghubungkan exchange/wallet, tidak mengaktifkan bot, tidak mengizinkan transaksi REAL, menghentikan layanan, atau tidak melanjutkan apabila saya tidak menyetujui ketentuan yang diwajibkan.

Saya menyatakan bahwa saya telah membaca, memahami, dan menyetujui pernyataan pelepasan dan pembebasan tuntutan ini secara sadar, sukarela, dengan kesempatan yang memadai untuk membaca dan menyimpan dokumen, serta tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan trading saya dan, sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan yang timbul sehubungan dengan penggunaan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.

Tidak ada bagian pernyataan ini yang dimaksudkan untuk menghapus atau mengesampingkan hak, perlindungan, kewajiban, tanggung jawab, mekanisme pengaduan, atau ketentuan lain yang menurut hukum yang berlaku bersifat wajib dan tidak dapat dikesampingkan. Jika suatu bagian pelepasan tidak dapat diberlakukan, bagian lain tetap berlaku sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku.

Saya memahami bahwa untuk perubahan material pada agreement, konfigurasi, permission, authorization, atau parameter risiko, BLACKBOX dapat meminta saya membaca kembali dan memberikan persetujuan ulang. Persetujuan lama tidak digunakan sebagai persetujuan diam-diam terhadap perubahan material.

Sebelum final acceptance, sistem dapat menampilkan identitas saya, tanggal, waktu, timezone, metode consent, document version, document hash, evidence hash, user-agent, dan konteks persetujuan. Password, OTP, MFA secret, API secret, private key, dan seed phrase tidak menjadi bagian dari bukti agreement.$LEGAL_10$,'b8a8c673899f6cf6d65a3c04e342aea322d54e4340ade61ba596b9e020e5031e',true,'PUBLISHED','v12.0.8 Master Agreement, Trading Rules, User Statements and Material Re-consent Hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

-- TRADING_RULES: b8a8c673899f6cf6d65a3c04e342aea322d54e4340ade61ba596b9e020e5031e

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1208_11_connection_authorization','CONNECTION_AUTHORIZATION','v12.0.8','PERSYARATAN KONEKSI EXCHANGE & WALLET — USER AUTHORIZATION AGREEMENT',$LEGAL_11$Dokumen ini mengatur persetujuan sadar pengguna ketika menghubungkan akun exchange atau wallet ke BLACKBOX. Koneksi merupakan pilihan pengguna sendiri dan tidak terjadi tanpa tindakan/otorisasi pengguna.

A. EXCHANGE / CEX
1. Pengguna sendiri memilih exchange, account, market scope, dan label koneksi.
2. Credential/API secret hanya diproses melalui mekanisme resmi yang diperlukan untuk koneksi; password BLACKBOX, OTP, seed phrase, dan private key tidak boleh dimasukkan sebagai legal evidence.
3. Withdrawal/transfer permission wajib nonaktif pada koneksi BLACKBOX. Permission Read/Trade hanya boleh digunakan sesuai fungsi yang diizinkan.
4. Status CONNECTED adalah status teknis koneksi dan bukan jaminan order, profit, availability, atau keamanan pihak ketiga.
5. Koneksi A tidak otomatis memberi mandat kepada bot/fitur lain. Scope, market, symbol, risk, dan execution gate harus cocok dengan koneksi yang dipilih.

B. WALLET / DEX
1. Pengguna memilih wallet/provider dan chain sendiri.
2. Challenge/signature dapat digunakan untuk membuktikan kontrol atas alamat. Ownership signature tidak otomatis merupakan authorization untuk transfer/trade.
3. BLACKBOX tidak meminta atau menyimpan seed phrase/private key.
4. Untuk transaksi DEX yang tersedia, pengguna harus meninjau detail transaksi dan memberikan signature/authorization melalui mekanisme wallet/provider yang berlaku. Koneksi wallet tidak berarti BLACKBOX memiliki aset.

C. USER RECONFIRMATION
Sebelum aktivitas REAL atau perubahan material, pengguna wajib meninjau kembali exchange/account, wallet, market, symbol/pair, modal/size, leverage, risk limit, strategy, bot parameters, exposure, permission, dan authorization. Perubahan material tidak boleh dianggap disetujui hanya karena consent lama masih ada.

D. MATERIAL CHANGE / RE-CONSENT
Perubahan material pada permission, authorization, account, market scope, leverage, risk limit, atau konfigurasi yang meningkatkan/mengubah risiko dapat memicu pembacaan dan persetujuan ulang. Snapshot consent sebelumnya tetap dipertahankan.

E. RISIKO KONEKSI
Risiko dapat berasal dari credential, API permission, phishing, perangkat, jaringan, exchange outage, rate limit, latency, chain congestion, smart contract, router, provider, data mismatch, atau konfigurasi pengguna. BLACKBOX tidak menjamin keamanan/availability pihak ketiga di luar kontrolnya dan tidak menjamin hasil transaksi.

F. BATAS OTORISASI
BLACKBOX tidak boleh menggunakan koneksi di luar scope fitur dan permission yang tercatat. Jika safety gate, certification, market-data health, reconciliation, atau legal/compliance gate tidak terpenuhi, sistem wajib fail-closed.

G. ALMA & TRADING RULES
Koneksi trading hanya boleh digunakan setelah pengguna menerima TRADING RULES dan pemberitahuan/ketentuan pendaftaran PT Alma Indonesia Raya yang berlaku untuk layanan bersangkutan. Persetujuan koneksi tidak menggantikan dokumen exchange, wallet provider, atau PT Alma Indonesia Raya.

PERNYATAAN KEHENDAK, PENERIMAAN RISIKO, PELEPASAN DAN PEMBEBASAN TUNTUTAN

Saya, pengguna yang identitas dan profilnya tercantum dalam bukti persetujuan ini, menyatakan bahwa saya telah membaca, memahami, memperoleh kesempatan yang memadai untuk meninjau dan menyimpan dokumen, serta menyetujui seluruh ketentuan dokumen ini secara sadar, sukarela, dan tanpa paksaan, tekanan, ancaman, penipuan, manipulasi, atau pengaruh tidak semestinya dari pihak mana pun.

Saya memahami bahwa persetujuan ini aktif dan bukan persetujuan diam-diam. Saya dapat memilih untuk tidak menggunakan layanan, tidak menghubungkan exchange/wallet, tidak mengaktifkan bot, tidak mengizinkan transaksi REAL, menghentikan layanan, atau tidak melanjutkan apabila saya tidak menyetujui ketentuan yang diwajibkan.

Saya menyatakan bahwa saya telah membaca, memahami, dan menyetujui pernyataan pelepasan dan pembebasan tuntutan ini secara sadar, sukarela, dengan kesempatan yang memadai untuk membaca dan menyimpan dokumen, serta tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan trading saya dan, sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan yang timbul sehubungan dengan penggunaan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.

Tidak ada bagian pernyataan ini yang dimaksudkan untuk menghapus atau mengesampingkan hak, perlindungan, kewajiban, tanggung jawab, mekanisme pengaduan, atau ketentuan lain yang menurut hukum yang berlaku bersifat wajib dan tidak dapat dikesampingkan. Jika suatu bagian pelepasan tidak dapat diberlakukan, bagian lain tetap berlaku sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku.

Saya memahami bahwa untuk perubahan material pada agreement, konfigurasi, permission, authorization, atau parameter risiko, BLACKBOX dapat meminta saya membaca kembali dan memberikan persetujuan ulang. Persetujuan lama tidak digunakan sebagai persetujuan diam-diam terhadap perubahan material.

Sebelum final acceptance, sistem dapat menampilkan identitas saya, tanggal, waktu, timezone, metode consent, document version, document hash, evidence hash, user-agent, dan konteks persetujuan. Password, OTP, MFA secret, API secret, private key, dan seed phrase tidak menjadi bagian dari bukti agreement.$LEGAL_11$,'b514a29324af707474625a61407ac899a5637fc114f18c474a368b215e104928',true,'PUBLISHED','v12.0.8 Master Agreement, Trading Rules, User Statements and Material Re-consent Hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

-- CONNECTION_AUTHORIZATION: b514a29324af707474625a61407ac899a5637fc114f18c474a368b215e104928

INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","workflowState","changeNote","publishedAt","createdAt") VALUES ('legal_v1208_12_regulatory_disclosure','REGULATORY_DISCLOSURE','v12.0.8','Disclosure Regulasi Indonesia — BLACKBOX Technology',$LEGAL_12$KERANGKA REGULASI INDONESIA YANG RELEVAN

1. Perdagangan Berjangka Komoditi dan Penasihat Berjangka berada dalam rezim perizinan dan pengawasan yang relevan dengan Bappebti. PT Alma Indonesia Raya tercantum pada daftar resmi Bappebti sebagai Penasihat Berjangka dengan Izin Usaha Nomor 02/BAPPEBTI/SI-PNB/02/2024. Untuk layanan Expert Advisor, Bappebti juga mencantumkan PT Alma Indonesia Raya dengan Persetujuan Nomor 01/BAPPEBTI/SP-PBEA/06/2024.
2. Pengaturan dan pengawasan Aset Keuangan Digital termasuk Aset Kripto telah beralih dari Bappebti kepada OJK. POJK 27 Tahun 2024 berlaku sejak 10 Januari 2025 dan telah diubah dengan POJK 23 Tahun 2025. PADK OJK Nomor 3 Tahun 2026 berlaku sejak 1 September 2026 untuk ketentuan pelaksanaan tertentu. Penerapan suatu ketentuan kepada BLACKBOX, PT Alma Indonesia Raya, exchange, broker, atau pihak lain bergantung pada kegiatan dan status perizinan masing-masing.
3. Bank Indonesia memiliki kewenangan di bidang sistem pembayaran dan ketentuan terkait aset/derivatif yang berada dalam ruang lingkupnya. BLACKBOX tidak memosisikan aset kripto sebagai alat pembayaran dan tidak mengubah ketentuan bahwa pembayaran di Indonesia harus mengikuti ketentuan Bank Indonesia yang berlaku.
4. Penyelenggaraan sistem dan transaksi elektronik juga memperhatikan ketentuan mengenai kontrak elektronik, transparansi, akuntabilitas, privasi, dan pelindungan data pribadi, termasuk UU 27 Tahun 2022 tentang Pelindungan Data Pribadi dan PP 71 Tahun 2019 tentang Penyelenggaraan Sistem dan Transaksi Elektronik.
5. Dokumen ini adalah disclosure produk dan kepatuhan, bukan pendapat hukum. Regulasi dapat berubah. Legal & Compliance Center BLACKBOX wajib memperbarui dokumen yang relevan dan menyimpan histori versi yang telah disetujui.

Tanggal verifikasi referensi regulator: 18 Oktober 2026. Dokumen ini bukan pendapat hukum dan tidak menyatakan BLACKBOX sebagai pemegang izin yang bukan miliknya.

PERNYATAAN KEHENDAK, PENERIMAAN RISIKO, PELEPASAN DAN PEMBEBASAN TUNTUTAN

Saya, pengguna yang identitas dan profilnya tercantum dalam bukti persetujuan ini, menyatakan bahwa saya telah membaca, memahami, memperoleh kesempatan yang memadai untuk meninjau dan menyimpan dokumen, serta menyetujui seluruh ketentuan dokumen ini secara sadar, sukarela, dan tanpa paksaan, tekanan, ancaman, penipuan, manipulasi, atau pengaruh tidak semestinya dari pihak mana pun.

Saya memahami bahwa persetujuan ini aktif dan bukan persetujuan diam-diam. Saya dapat memilih untuk tidak menggunakan layanan, tidak menghubungkan exchange/wallet, tidak mengaktifkan bot, tidak mengizinkan transaksi REAL, menghentikan layanan, atau tidak melanjutkan apabila saya tidak menyetujui ketentuan yang diwajibkan.

Saya menyatakan bahwa saya telah membaca, memahami, dan menyetujui pernyataan pelepasan dan pembebasan tuntutan ini secara sadar, sukarela, dengan kesempatan yang memadai untuk membaca dan menyimpan dokumen, serta tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan trading saya dan, sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan yang timbul sehubungan dengan penggunaan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.

Tidak ada bagian pernyataan ini yang dimaksudkan untuk menghapus atau mengesampingkan hak, perlindungan, kewajiban, tanggung jawab, mekanisme pengaduan, atau ketentuan lain yang menurut hukum yang berlaku bersifat wajib dan tidak dapat dikesampingkan. Jika suatu bagian pelepasan tidak dapat diberlakukan, bagian lain tetap berlaku sejauh diperbolehkan dan dapat diberlakukan menurut hukum yang berlaku.

Saya memahami bahwa untuk perubahan material pada agreement, konfigurasi, permission, authorization, atau parameter risiko, BLACKBOX dapat meminta saya membaca kembali dan memberikan persetujuan ulang. Persetujuan lama tidak digunakan sebagai persetujuan diam-diam terhadap perubahan material.

Sebelum final acceptance, sistem dapat menampilkan identitas saya, tanggal, waktu, timezone, metode consent, document version, document hash, evidence hash, user-agent, dan konteks persetujuan. Password, OTP, MFA secret, API secret, private key, dan seed phrase tidak menjadi bagian dari bukti agreement.$LEGAL_12$,'9525861330daac004be0101ea49a7730b5b56b47167f252788a9e655073652f6',true,'PUBLISHED','v12.0.8 Master Agreement, Trading Rules, User Statements and Material Re-consent Hardening',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING;

-- REGULATORY_DISCLOSURE: 9525861330daac004be0101ea49a7730b5b56b47167f252788a9e655073652f6

COMMIT;
