CREATE TABLE IF NOT EXISTS "AutonomousDecisionCycle" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "signalId" TEXT,
  "version" TEXT NOT NULL,
  "marketState" JSONB NOT NULL,
  "analysisState" JSONB NOT NULL,
  "aiState" JSONB NOT NULL,
  "riskState" JSONB NOT NULL,
  "precisionGate" JSONB NOT NULL,
  "executionState" JSONB NOT NULL,
  "reconciliationState" JSONB NOT NULL,
  "learningState" JSONB NOT NULL,
  "outcome" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AutonomousDecisionCycle_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "AutonomousDecisionCycle_signalId_fkey" FOREIGN KEY ("signalId") REFERENCES "Signal"("id") ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS "AutonomousDecisionCycle_signalId_key" ON "AutonomousDecisionCycle"("signalId") WHERE "signalId" IS NOT NULL;
CREATE INDEX IF NOT EXISTS "AutonomousDecisionCycle_userId_createdAt_idx" ON "AutonomousDecisionCycle"("userId","createdAt");
CREATE INDEX IF NOT EXISTS "AutonomousDecisionCycle_outcome_createdAt_idx" ON "AutonomousDecisionCycle"("outcome","createdAt");

CREATE OR REPLACE FUNCTION bbx_sync_autonomous_cycle() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO "AutonomousDecisionCycle" ("id","userId","signalId","version","marketState","analysisState","aiState","riskState","precisionGate","executionState","reconciliationState","learningState","outcome")
  VALUES (md5(clock_timestamp()::text || random()::text || NEW."id"), NEW."userId", NEW."id", '8.0.0',
    jsonb_build_object('symbol',NEW."symbol",'regime',NEW."regime",'timeframe',NEW."timeframe"),
    jsonb_build_object('score',NEW."score",'qualityScore',NEW."qualityScore",'action',NEW."action",'reasons',NEW."reasons"),
    jsonb_build_object('score',NEW."aiScore",'confidence',NEW."confidence"),
    jsonb_build_object('riskFlags',NEW."riskFlags"),
    jsonb_build_object('passed',COALESCE(NEW."qualityScore",NEW."score") >= 90,'qualityScore',COALESCE(NEW."qualityScore",NEW."score")),
    jsonb_build_object('lifecycle',NEW."lifecycle"),
    jsonb_build_object('status','PENDING_UNTIL_EXECUTION'),
    jsonb_build_object('result',NEW."result",'resultPnl',NEW."resultPnl"),
    COALESCE(NEW."result",NEW."lifecycle",'DECISION_RECORDED'))
  ON CONFLICT ("signalId") DO UPDATE SET
    "analysisState"=EXCLUDED."analysisState", "aiState"=EXCLUDED."aiState", "riskState"=EXCLUDED."riskState", "precisionGate"=EXCLUDED."precisionGate", "executionState"=EXCLUDED."executionState", "learningState"=EXCLUDED."learningState", "outcome"=EXCLUDED."outcome";
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS bbx_signal_autonomous_cycle ON "Signal";
CREATE TRIGGER bbx_signal_autonomous_cycle AFTER INSERT OR UPDATE OF "score","qualityScore","aiScore","riskFlags","lifecycle","result","resultPnl" ON "Signal" FOR EACH ROW EXECUTE FUNCTION bbx_sync_autonomous_cycle();
