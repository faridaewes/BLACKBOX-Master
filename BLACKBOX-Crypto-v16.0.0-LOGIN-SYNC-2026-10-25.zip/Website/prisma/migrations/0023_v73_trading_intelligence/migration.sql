CREATE TABLE IF NOT EXISTS "TradingDecisionJournal" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "signalId" TEXT NOT NULL UNIQUE,
  "symbol" TEXT NOT NULL,
  "action" TEXT NOT NULL,
  "decisionScore" INTEGER NOT NULL,
  "confidence" INTEGER NOT NULL,
  "qualityScore" INTEGER,
  "confirmations" INTEGER,
  "aiScore" INTEGER,
  "aiConfidence" INTEGER,
  "regime" TEXT,
  "timeframe" TEXT,
  "reasons" JSONB,
  "riskFlags" JSONB,
  "result" TEXT,
  "resultPnl" DOUBLE PRECISION,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "resolvedAt" TIMESTAMP(3),
  CONSTRAINT "TradingDecisionJournal_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "TradingDecisionJournal_signalId_fkey" FOREIGN KEY ("signalId") REFERENCES "Signal"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS "TradingDecisionJournal_userId_createdAt_idx" ON "TradingDecisionJournal"("userId","createdAt");
CREATE INDEX IF NOT EXISTS "TradingDecisionJournal_userId_action_createdAt_idx" ON "TradingDecisionJournal"("userId","action","createdAt");
CREATE INDEX IF NOT EXISTS "TradingDecisionJournal_symbol_createdAt_idx" ON "TradingDecisionJournal"("symbol","createdAt");

CREATE TABLE IF NOT EXISTS "TradingPerformanceSnapshot" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "period" TEXT NOT NULL,
  "fromDate" TIMESTAMP(3) NOT NULL,
  "toDate" TIMESTAMP(3) NOT NULL,
  "completedTrades" INTEGER NOT NULL,
  "wins" INTEGER NOT NULL,
  "losses" INTEGER NOT NULL,
  "winRatePct" DOUBLE PRECISION NOT NULL,
  "grossProfit" DOUBLE PRECISION NOT NULL,
  "grossLoss" DOUBLE PRECISION NOT NULL,
  "profitFactor" DOUBLE PRECISION,
  "netPnl" DOUBLE PRECISION NOT NULL,
  "fees" DOUBLE PRECISION NOT NULL,
  "maxDrawdownPct" DOUBLE PRECISION NOT NULL,
  "avgExecutionLatencyMs" DOUBLE PRECISION,
  "avgSignalQuality" DOUBLE PRECISION,
  "avgAiScore" DOUBLE PRECISION,
  "avgSlippageBps" DOUBLE PRECISION,
  "topSymbols" JSONB,
  "regimePerformance" JSONB,
  "recommendations" JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "TradingPerformanceSnapshot_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS "TradingPerformanceSnapshot_userId_createdAt_idx" ON "TradingPerformanceSnapshot"("userId","createdAt");
CREATE INDEX IF NOT EXISTS "TradingPerformanceSnapshot_userId_period_fromDate_toDate_idx" ON "TradingPerformanceSnapshot"("userId","period","fromDate","toDate");

CREATE OR REPLACE FUNCTION bbx_sync_decision_journal() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO "TradingDecisionJournal" ("id","userId","signalId","symbol","action","decisionScore","confidence","qualityScore","confirmations","aiScore","aiConfidence","regime","timeframe","reasons","riskFlags","result","resultPnl","createdAt","resolvedAt")
    VALUES (md5(clock_timestamp()::text || random()::text || NEW."id"), NEW."userId", NEW."id", NEW."symbol", NEW."action", NEW."score", NEW."confidence", NEW."qualityScore", NEW."confirmationCount", NEW."aiScore", NULL, NEW."regime", NEW."timeframe", NEW."reasons", NEW."riskFlags", NEW."result", NEW."resultPnl", NEW."createdAt", NEW."resolvedAt")
    ON CONFLICT ("signalId") DO NOTHING;
  ELSE
    UPDATE "TradingDecisionJournal" SET "result"=NEW."result", "resultPnl"=NEW."resultPnl", "resolvedAt"=NEW."resolvedAt", "qualityScore"=NEW."qualityScore", "aiScore"=NEW."aiScore", "riskFlags"=NEW."riskFlags" WHERE "signalId"=NEW."id";
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS bbx_signal_decision_journal ON "Signal";
CREATE TRIGGER bbx_signal_decision_journal AFTER INSERT OR UPDATE OF "result","resultPnl","resolvedAt","qualityScore","aiScore","riskFlags" ON "Signal" FOR EACH ROW EXECUTE FUNCTION bbx_sync_decision_journal();

INSERT INTO "TradingDecisionJournal" ("id","userId","signalId","symbol","action","decisionScore","confidence","qualityScore","confirmations","aiScore","regime","timeframe","reasons","riskFlags","result","resultPnl","createdAt","resolvedAt")
SELECT md5(clock_timestamp()::text || random()::text || s."id"), s."userId", s."id", s."symbol", s."action", s."score", s."confidence", s."qualityScore", s."confirmationCount", s."aiScore", s."regime", s."timeframe", s."reasons", s."riskFlags", s."result", s."resultPnl", s."createdAt", s."resolvedAt"
FROM "Signal" s
ON CONFLICT ("signalId") DO NOTHING;
