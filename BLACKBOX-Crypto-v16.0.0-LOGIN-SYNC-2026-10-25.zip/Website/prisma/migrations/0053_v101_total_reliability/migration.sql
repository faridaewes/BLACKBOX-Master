-- v10.1 total reliability/certification contracts
ALTER TABLE "TradingDecisionJournal" ADD COLUMN "eventVersion" TEXT NOT NULL DEFAULT '2.0';
ALTER TABLE "TradingDecisionJournal" ADD COLUMN "evidenceHash" TEXT;
ALTER TABLE "TradingDecisionJournal" ADD COLUMN "outcomeConfidence" INTEGER;
ALTER TABLE "TradingDecisionJournal" ADD COLUMN "counterfactual" JSONB;

CREATE TABLE "DeadLetterJob" ("id" TEXT NOT NULL, "queue" TEXT NOT NULL, "jobType" TEXT NOT NULL, "payload" JSONB NOT NULL, "error" TEXT NOT NULL, "attempts" INTEGER NOT NULL DEFAULT 0, "status" TEXT NOT NULL DEFAULT 'PENDING', "nextRetryAt" TIMESTAMP(3), "firstFailedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "lastFailedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "resolvedAt" TIMESTAMP(3), "traceId" TEXT, "idempotencyKey" TEXT, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL, CONSTRAINT "DeadLetterJob_pkey" PRIMARY KEY ("id"));
CREATE INDEX "DeadLetterJob_queue_status_nextRetryAt_idx" ON "DeadLetterJob"("queue","status","nextRetryAt");
CREATE INDEX "DeadLetterJob_status_lastFailedAt_idx" ON "DeadLetterJob"("status","lastFailedAt");
CREATE INDEX "DeadLetterJob_traceId_idx" ON "DeadLetterJob"("traceId");

CREATE TABLE "ObservabilityEvent" ("id" TEXT NOT NULL, "traceId" TEXT NOT NULL, "spanId" TEXT, "service" TEXT NOT NULL, "eventType" TEXT NOT NULL, "severity" TEXT NOT NULL DEFAULT 'INFO', "route" TEXT, "operation" TEXT, "statusCode" INTEGER, "durationMs" INTEGER, "userId" TEXT, "metadata" JSONB, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, CONSTRAINT "ObservabilityEvent_pkey" PRIMARY KEY ("id"));
CREATE INDEX "ObservabilityEvent_traceId_idx" ON "ObservabilityEvent"("traceId");
CREATE INDEX "ObservabilityEvent_service_createdAt_idx" ON "ObservabilityEvent"("service","createdAt");
CREATE INDEX "ObservabilityEvent_eventType_createdAt_idx" ON "ObservabilityEvent"("eventType","createdAt");
CREATE INDEX "ObservabilityEvent_severity_createdAt_idx" ON "ObservabilityEvent"("severity","createdAt");

CREATE TABLE "FinancialLedgerEntry" ("id" TEXT NOT NULL, "userId" TEXT NOT NULL, "accountType" TEXT NOT NULL, "entryType" TEXT NOT NULL, "amount" DOUBLE PRECISION NOT NULL, "currency" TEXT NOT NULL, "referenceType" TEXT NOT NULL, "referenceId" TEXT NOT NULL, "idempotencyKey" TEXT NOT NULL, "balanceAfter" DOUBLE PRECISION, "metadata" JSONB, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, CONSTRAINT "FinancialLedgerEntry_pkey" PRIMARY KEY ("id"));
CREATE UNIQUE INDEX "FinancialLedgerEntry_idempotencyKey_key" ON "FinancialLedgerEntry"("idempotencyKey");
CREATE INDEX "FinancialLedgerEntry_userId_accountType_createdAt_idx" ON "FinancialLedgerEntry"("userId","accountType","createdAt");
CREATE INDEX "FinancialLedgerEntry_referenceType_referenceId_idx" ON "FinancialLedgerEntry"("referenceType","referenceId");

CREATE TABLE "ThreatModelAssessment" ("id" TEXT NOT NULL, "release" TEXT NOT NULL, "status" TEXT NOT NULL, "score" INTEGER NOT NULL, "findings" JSONB NOT NULL, "mitigations" JSONB NOT NULL, "evidenceHash" TEXT NOT NULL, "assessedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, CONSTRAINT "ThreatModelAssessment_pkey" PRIMARY KEY ("id"));
CREATE INDEX "ThreatModelAssessment_release_assessedAt_idx" ON "ThreatModelAssessment"("release","assessedAt");
CREATE INDEX "ThreatModelAssessment_status_assessedAt_idx" ON "ThreatModelAssessment"("status","assessedAt");
