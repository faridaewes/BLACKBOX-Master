CREATE TABLE IF NOT EXISTS "MarketRegistry" (
  "id" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "venue" TEXT NOT NULL,
  "symbol" TEXT NOT NULL,
  "baseAsset" TEXT NOT NULL,
  "quoteAsset" TEXT NOT NULL,
  "chain" TEXT NOT NULL,
  "contractAddress" TEXT,
  "status" TEXT NOT NULL DEFAULT 'ACTIVE',
  "active" BOOLEAN NOT NULL DEFAULT true,
  "tickSize" DOUBLE PRECISION,
  "stepSize" DOUBLE PRECISION,
  "minOrder" DOUBLE PRECISION,
  "discoveredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "lastSeenAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "dataQuality" INTEGER NOT NULL DEFAULT 0,
  "source" TEXT NOT NULL,
  "metadata" JSONB NOT NULL DEFAULT '{}',
  CONSTRAINT "MarketRegistry_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "MarketRegistry_marketKey_key" ON "MarketRegistry"("marketKey");
CREATE INDEX IF NOT EXISTS "MarketRegistry_provider_marketType_active_idx" ON "MarketRegistry"("provider","marketType","active");
CREATE INDEX IF NOT EXISTS "MarketRegistry_chain_active_idx" ON "MarketRegistry"("chain","active");
CREATE INDEX IF NOT EXISTS "MarketRegistry_lastSeenAt_idx" ON "MarketRegistry"("lastSeenAt");
CREATE INDEX IF NOT EXISTS "MarketRegistry_symbol_idx" ON "MarketRegistry"("symbol");
