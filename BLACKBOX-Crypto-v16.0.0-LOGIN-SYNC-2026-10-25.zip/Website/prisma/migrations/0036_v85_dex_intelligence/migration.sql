CREATE TABLE "DexPoolSnapshot" (
  "id" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "chain" TEXT NOT NULL,
  "dex" TEXT NOT NULL,
  "pairAddress" TEXT NOT NULL,
  "symbol" TEXT NOT NULL,
  "priceUsd" DOUBLE PRECISION,
  "liquidityUsd" DOUBLE PRECISION,
  "volume24h" DOUBLE PRECISION,
  "priceImpactPct" DOUBLE PRECISION,
  "poolAgeHours" DOUBLE PRECISION,
  "liquidityChange24hPct" DOUBLE PRECISION,
  "volumeChange24hPct" DOUBLE PRECISION,
  "observedAt" TIMESTAMP(3) NOT NULL,
  "capturedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "source" TEXT NOT NULL,
  "metadata" JSONB NOT NULL,
  CONSTRAINT "DexPoolSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "DexPoolSnapshot_marketKey_observedAt_idx" ON "DexPoolSnapshot"("marketKey", "observedAt");
CREATE INDEX "DexPoolSnapshot_chain_dex_observedAt_idx" ON "DexPoolSnapshot"("chain", "dex", "observedAt");
CREATE INDEX "DexPoolSnapshot_liquidityUsd_volume24h_idx" ON "DexPoolSnapshot"("liquidityUsd", "volume24h");

CREATE TABLE "DexTokenRiskSnapshot" (
  "id" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "chain" TEXT NOT NULL,
  "tokenAddress" TEXT NOT NULL,
  "symbol" TEXT NOT NULL,
  "honeypot" BOOLEAN,
  "buyTaxPct" DOUBLE PRECISION,
  "sellTaxPct" DOUBLE PRECISION,
  "transferRestricted" BOOLEAN,
  "blacklist" BOOLEAN,
  "mintAuthority" BOOLEAN,
  "freezeAuthority" BOOLEAN,
  "proxy" BOOLEAN,
  "ownerRenounced" BOOLEAN,
  "liquidityLocked" BOOLEAN,
  "holderConcentrationPct" DOUBLE PRECISION,
  "verifiedContract" BOOLEAN,
  "deployerRisk" BOOLEAN,
  "riskScore" INTEGER NOT NULL,
  "status" TEXT NOT NULL,
  "blockers" JSONB NOT NULL,
  "warnings" JSONB NOT NULL,
  "observedAt" TIMESTAMP(3) NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "DexTokenRiskSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "DexTokenRiskSnapshot_marketKey_observedAt_idx" ON "DexTokenRiskSnapshot"("marketKey", "observedAt");
CREATE INDEX "DexTokenRiskSnapshot_chain_tokenAddress_observedAt_idx" ON "DexTokenRiskSnapshot"("chain", "tokenAddress", "observedAt");
CREATE INDEX "DexTokenRiskSnapshot_status_observedAt_idx" ON "DexTokenRiskSnapshot"("status", "observedAt");

CREATE TABLE "DexIntelligenceSnapshot" (
  "id" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "chain" TEXT NOT NULL,
  "dex" TEXT NOT NULL,
  "symbol" TEXT NOT NULL,
  "trustScore" INTEGER NOT NULL,
  "tokenRiskScore" INTEGER NOT NULL,
  "poolHealthScore" INTEGER NOT NULL,
  "executionQualityScore" INTEGER NOT NULL,
  "status" TEXT NOT NULL,
  "blockers" JSONB NOT NULL,
  "warnings" JSONB NOT NULL,
  "evidence" JSONB NOT NULL,
  "observedAt" TIMESTAMP(3) NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "DexIntelligenceSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "DexIntelligenceSnapshot_marketKey_observedAt_idx" ON "DexIntelligenceSnapshot"("marketKey", "observedAt");
CREATE INDEX "DexIntelligenceSnapshot_status_observedAt_idx" ON "DexIntelligenceSnapshot"("status", "observedAt");
CREATE INDEX "DexIntelligenceSnapshot_chain_dex_observedAt_idx" ON "DexIntelligenceSnapshot"("chain", "dex", "observedAt");
