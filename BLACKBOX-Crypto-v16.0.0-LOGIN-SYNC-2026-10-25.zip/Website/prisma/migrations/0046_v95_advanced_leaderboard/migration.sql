-- v9.5 Advanced Leaderboard: indexes for public network ranking aggregation.
CREATE INDEX IF NOT EXISTS "User_status_createdAt_referredById_idx" ON "User"("status", "createdAt", "referredById");
CREATE INDEX IF NOT EXISTS "User_kycStatus_hasEverActivated_referredById_idx" ON "User"("kycStatus", "hasEverActivated", "referredById");
CREATE INDEX IF NOT EXISTS "Subscription_status_expiresAt_userId_idx" ON "Subscription"("status", "expiresAt", "userId");
