ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "mustChangePassword" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Bot" ADD COLUMN IF NOT EXISTS "archivedAt" TIMESTAMP(3);
CREATE TABLE IF NOT EXISTS "Session" ("id" TEXT NOT NULL,"userId" TEXT NOT NULL,"deviceLabel" TEXT,"userAgent" TEXT,"ipHash" TEXT,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,"lastSeenAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,"expiresAt" TIMESTAMP(3) NOT NULL,"revokedAt" TIMESTAMP(3),CONSTRAINT "Session_pkey" PRIMARY KEY ("id"));
CREATE INDEX IF NOT EXISTS "Session_userId_revokedAt_idx" ON "Session"("userId","revokedAt");
CREATE INDEX IF NOT EXISTS "Session_expiresAt_idx" ON "Session"("expiresAt");
DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='Session_userId_fkey') THEN ALTER TABLE "Session" ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE; END IF; END $$;
CREATE INDEX IF NOT EXISTS "Bot_archivedAt_idx" ON "Bot"("archivedAt");
