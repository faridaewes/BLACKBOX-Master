CREATE TABLE IF NOT EXISTS "BackupArtifact" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "backupId" TEXT NOT NULL UNIQUE,
  "scope" TEXT NOT NULL,
  "filename" TEXT NOT NULL,
  "sizeBytes" BIGINT NOT NULL,
  "sha256" TEXT NOT NULL,
  "destinationEmail" TEXT,
  "objectStorageUploaded" BOOLEAN NOT NULL DEFAULT FALSE,
  "createdById" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "validatedAt" TIMESTAMP(3),
  "validationState" TEXT NOT NULL DEFAULT 'PENDING',
  CONSTRAINT "BackupArtifact_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS "BackupArtifact_createdAt_idx" ON "BackupArtifact"("createdAt");
CREATE INDEX IF NOT EXISTS "BackupArtifact_validationState_createdAt_idx" ON "BackupArtifact"("validationState","createdAt");
