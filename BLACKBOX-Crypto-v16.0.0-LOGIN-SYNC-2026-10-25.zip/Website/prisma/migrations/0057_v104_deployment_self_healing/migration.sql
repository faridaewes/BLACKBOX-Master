-- BLACKBOX v10.4 Deployment Intelligence + Self-Healing + Recovery Gate
CREATE TABLE "DeploymentRuntimeState" (
  "id" TEXT NOT NULL,
  "release" TEXT NOT NULL,
  "environment" TEXT NOT NULL,
  "deploymentMode" TEXT NOT NULL,
  "hostname" TEXT,
  "publicUrl" TEXT,
  "status" TEXT NOT NULL,
  "tradingAuthorization" TEXT NOT NULL,
  "schemaState" TEXT NOT NULL,
  "workerState" TEXT NOT NULL,
  "reconciliationState" TEXT NOT NULL,
  "marketDataState" TEXT NOT NULL,
  "lastRecoveryAt" TIMESTAMP(3),
  "lastHeartbeatAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "metadata" JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "DeploymentRuntimeState_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "DeploymentRuntimeState_status_updatedAt_idx" ON "DeploymentRuntimeState"("status", "updatedAt");
CREATE INDEX "DeploymentRuntimeState_environment_updatedAt_idx" ON "DeploymentRuntimeState"("environment", "updatedAt");

CREATE TABLE "RecoveryGateEvent" (
  "id" TEXT NOT NULL,
  "release" TEXT NOT NULL,
  "eventType" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "reason" TEXT,
  "websiteOnlineAllowed" BOOLEAN NOT NULL DEFAULT false,
  "tradingAuthorization" TEXT NOT NULL,
  "evidence" JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "RecoveryGateEvent_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "RecoveryGateEvent_release_createdAt_idx" ON "RecoveryGateEvent"("release", "createdAt");
CREATE INDEX "RecoveryGateEvent_status_createdAt_idx" ON "RecoveryGateEvent"("status", "createdAt");
