CREATE TABLE "ReferralLeaderboardSnapshot" ("id" TEXT NOT NULL,"category" TEXT NOT NULL,"depth" INTEGER NOT NULL,"payload" JSONB NOT NULL,"generatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,"expiresAt" TIMESTAMP(3) NOT NULL,CONSTRAINT "ReferralLeaderboardSnapshot_pkey" PRIMARY KEY ("id"));
CREATE UNIQUE INDEX "ReferralLeaderboardSnapshot_category_depth_key" ON "ReferralLeaderboardSnapshot"("category","depth");
CREATE INDEX "ReferralLeaderboardSnapshot_expiresAt_idx" ON "ReferralLeaderboardSnapshot"("expiresAt");
