-- BLACKBOX v12.0.0 — WPA Community integrity constraints / idempotency hardening
DO $$ BEGIN ALTER TABLE "WpaCommunity" ADD CONSTRAINT "WpaCommunity_publicationState_chk" CHECK ("publicationState" IN ('DRAFT','REVIEW','APPROVED','PUBLISHED','SUSPENDED','ARCHIVED')); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "WpaCommunity" ADD CONSTRAINT "WpaCommunity_verificationState_chk" CHECK ("verificationState" IN ('UNSUBMITTED','SUBMITTED','APPROVED','REJECTED','VERIFIED')); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "WpaCommunityAnnouncement" ADD CONSTRAINT "WpaCommunityAnnouncement_contentState_chk" CHECK ("contentState" IN ('DRAFT','REVIEW','SCHEDULED','PUBLISHED','ARCHIVED')); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "WpaCommunityRole" ADD CONSTRAINT "WpaCommunityRole_role_chk" CHECK ("role" IN ('MANAGER','MODERATOR','EDITOR')); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "WpaCommunityEventRsvp" ADD CONSTRAINT "WpaCommunityEventRsvp_status_chk" CHECK ("status" IN ('INTERESTED','REGISTERED','ATTENDED','CANCELLED')); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "WpaCommunityModerationCase" ADD CONSTRAINT "WpaCommunityModerationCase_status_chk" CHECK ("status" IN ('OPEN','RESOLVED','DISMISSED')); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "WpaCommunityModerationCase" ADD CONSTRAINT "WpaCommunityModerationCase_severity_chk" CHECK ("severity" IN ('LOW','MEDIUM','HIGH','CRITICAL')); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
CREATE UNIQUE INDEX IF NOT EXISTS "ReferralPointLedger_userId_idempotencyKey_key" ON "ReferralPointLedger"("userId","idempotencyKey");
CREATE INDEX IF NOT EXISTS "WpaCommunityEventRsvp_communityId_registeredAt_idx" ON "WpaCommunityEventRsvp"("communityId","registeredAt");
CREATE INDEX IF NOT EXISTS "WpaCommunityAnnouncement_due_idx" ON "WpaCommunityAnnouncement"("contentState","scheduledAt","active");
