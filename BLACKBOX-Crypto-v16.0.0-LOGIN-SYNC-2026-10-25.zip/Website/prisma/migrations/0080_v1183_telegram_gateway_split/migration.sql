-- v11.8.3: split Telegram credentials so Official and Transaction gateways are independently editable/testable.
ALTER TABLE "TelegramGatewayConfig" ADD COLUMN "officialBotTokenEnc" TEXT;
ALTER TABLE "TelegramGatewayConfig" ADD COLUMN "transactionBotTokenEnc" TEXT;

-- Preserve the existing v11.8.2 credential for both channels during upgrade.
UPDATE "TelegramGatewayConfig"
SET "officialBotTokenEnc" = "botTokenEnc",
    "transactionBotTokenEnc" = "botTokenEnc"
WHERE "botTokenEnc" IS NOT NULL;

-- Remove the legacy single-token value so deleting either new gateway credential remains effective.
UPDATE "TelegramGatewayConfig" SET "botTokenEnc" = NULL WHERE "botTokenEnc" IS NOT NULL;
