-- BLACKBOX v12.0.0 WPA tier activation reward + enrollment hardening
ALTER TABLE "WpaService" ADD COLUMN "rewardPoints" INTEGER NOT NULL DEFAULT 0;
CREATE TABLE "WpaServiceEnrollment" (
  "id" TEXT NOT NULL,
  "advisorId" TEXT NOT NULL,
  "serviceId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "planId" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'PENDING',
  "requestedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "approvedAt" TIMESTAMP(3),
  "approvedById" TEXT,
  "rejectedAt" TIMESTAMP(3),
  "rejectionReason" TEXT,
  "subscriptionId" TEXT,
  "rewardPointsAwarded" INTEGER NOT NULL DEFAULT 0,
  "rewardAwardedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WpaServiceEnrollment_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "WpaServiceEnrollment_advisorId_status_createdAt_idx" ON "WpaServiceEnrollment"("advisorId","status","createdAt");
CREATE INDEX "WpaServiceEnrollment_serviceId_status_createdAt_idx" ON "WpaServiceEnrollment"("serviceId","status","createdAt");
CREATE INDEX "WpaServiceEnrollment_userId_status_createdAt_idx" ON "WpaServiceEnrollment"("userId","status","createdAt");
CREATE INDEX "WpaServiceEnrollment_planId_status_createdAt_idx" ON "WpaServiceEnrollment"("planId","status","createdAt");
CREATE INDEX "WpaServiceEnrollment_subscriptionId_idx" ON "WpaServiceEnrollment"("subscriptionId");
ALTER TABLE "WpaServiceEnrollment" ADD CONSTRAINT "WpaServiceEnrollment_advisorId_fkey" FOREIGN KEY ("advisorId") REFERENCES "PublicAdvisor"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "WpaServiceEnrollment" ADD CONSTRAINT "WpaServiceEnrollment_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "WpaService"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "WpaServiceEnrollment" ADD CONSTRAINT "WpaServiceEnrollment_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "WpaServiceEnrollment" ADD CONSTRAINT "WpaServiceEnrollment_planId_fkey" FOREIGN KEY ("planId") REFERENCES "AccessPlan"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "WpaServiceEnrollment" ADD CONSTRAINT "WpaServiceEnrollment_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES "Subscription"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "WpaServiceEnrollment" ADD CONSTRAINT "WpaServiceEnrollment_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
