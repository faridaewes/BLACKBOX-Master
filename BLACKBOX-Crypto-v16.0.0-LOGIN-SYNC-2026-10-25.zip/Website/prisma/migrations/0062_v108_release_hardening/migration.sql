-- BLACKBOX v10.8.0 development/hardening release baseline
CREATE TABLE "ReleaseHardeningSnapshotV108" (
  "id" TEXT NOT NULL,
  "release" TEXT NOT NULL,
  "environment" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "manifestHash" TEXT NOT NULL,
  "dependencyState" TEXT NOT NULL,
  "buildState" TEXT NOT NULL,
  "testState" TEXT NOT NULL,
  "externalState" TEXT NOT NULL,
  "tradingAuthorization" TEXT NOT NULL,
  "blockers" JSONB NOT NULL,
  "checks" JSONB NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ReleaseHardeningSnapshotV108_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ReleaseHardeningSnapshotV108_release_createdAt_idx" ON "ReleaseHardeningSnapshotV108"("release", "createdAt");
CREATE INDEX "ReleaseHardeningSnapshotV108_status_createdAt_idx" ON "ReleaseHardeningSnapshotV108"("status", "createdAt");
