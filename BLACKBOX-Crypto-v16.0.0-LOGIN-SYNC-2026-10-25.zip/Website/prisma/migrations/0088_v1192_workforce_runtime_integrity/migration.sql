-- Runtime integrity: at most one active work session per user.
CREATE UNIQUE INDEX IF NOT EXISTS "WorkSession_one_active_per_user_idx"
ON "WorkSession" ("userId") WHERE "endedAt" IS NULL;

-- Fast activity reporting by task and type.
CREATE INDEX IF NOT EXISTS "WorkActivityEvent_task_createdAt_idx"
ON "WorkActivityEvent" ("taskId", "createdAt");
