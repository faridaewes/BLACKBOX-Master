ALTER TABLE "Bot" ADD COLUMN "walletId" TEXT;
CREATE INDEX "Bot_exchangeId_idx" ON "Bot"("exchangeId");
CREATE INDEX "Bot_walletId_idx" ON "Bot"("walletId");
ALTER TABLE "Bot" ADD CONSTRAINT "Bot_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES "Wallet"("id") ON DELETE SET NULL ON UPDATE CASCADE;
CREATE TABLE "ConnectionMarketUniverse" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "exchangeAccountId" TEXT,
  "walletId" TEXT,
  "connectionKey" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "venue" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "symbol" TEXT NOT NULL,
  "canonicalSymbol" TEXT NOT NULL,
  "baseAsset" TEXT NOT NULL,
  "quoteAsset" TEXT NOT NULL,
  "chain" TEXT NOT NULL,
  "contractAddress" TEXT,
  "marketAvailable" BOOLEAN NOT NULL DEFAULT false,
  "marketActive" BOOLEAN NOT NULL DEFAULT false,
  "buyTradable" BOOLEAN NOT NULL DEFAULT false,
  "sellTradable" BOOLEAN NOT NULL DEFAULT false,
  "tradabilityStatus" TEXT NOT NULL DEFAULT 'BLOCKED',
  "blockers" JSONB NOT NULL,
  "warnings" JSONB NOT NULL,
  "precision" JSONB NOT NULL,
  "limits" JSONB NOT NULL,
  "fees" JSONB NOT NULL,
  "liquidity" JSONB NOT NULL,
  "balance" JSONB NOT NULL,
  "metadata" JSONB NOT NULL,
  "observedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "expiresAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ConnectionMarketUniverse_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "ConnectionMarketUniverse_connectionKey_marketType_canonicalSymbol_key" ON "ConnectionMarketUniverse"("connectionKey","marketType","canonicalSymbol");
CREATE INDEX "ConnectionMarketUniverse_userId_marketType_tradabilityStatus_idx" ON "ConnectionMarketUniverse"("userId","marketType","tradabilityStatus");
CREATE INDEX "ConnectionMarketUniverse_exchangeAccountId_marketType_symbol_idx" ON "ConnectionMarketUniverse"("exchangeAccountId","marketType","symbol");
CREATE INDEX "ConnectionMarketUniverse_walletId_marketType_symbol_idx" ON "ConnectionMarketUniverse"("walletId","marketType","symbol");
CREATE INDEX "ConnectionMarketUniverse_observedAt_idx" ON "ConnectionMarketUniverse"("observedAt");
ALTER TABLE "ConnectionMarketUniverse" ADD CONSTRAINT "ConnectionMarketUniverse_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ConnectionMarketUniverse" ADD CONSTRAINT "ConnectionMarketUniverse_exchangeAccountId_fkey" FOREIGN KEY ("exchangeAccountId") REFERENCES "ExchangeAccount"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ConnectionMarketUniverse" ADD CONSTRAINT "ConnectionMarketUniverse_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES "Wallet"("id") ON DELETE CASCADE ON UPDATE CASCADE;
