CREATE TABLE "OpportunityRadarSnapshot" (
 "id" TEXT NOT NULL,
 "marketKey" TEXT NOT NULL,
 "marketType" TEXT NOT NULL,
 "provider" TEXT NOT NULL,
 "symbol" TEXT NOT NULL,
 "venue" TEXT NOT NULL,
 "chain" TEXT NOT NULL,
 "version" TEXT NOT NULL,
 "opportunityScore" INTEGER NOT NULL,
 "confidence" INTEGER NOT NULL,
 "dataTrustScore" INTEGER NOT NULL,
 "status" TEXT NOT NULL,
 "direction" TEXT NOT NULL,
 "regime" TEXT NOT NULL,
 "breakout" BOOLEAN NOT NULL,
 "doji" BOOLEAN NOT NULL,
 "timeframeCoverage" INTEGER NOT NULL,
 "lastCertifiedAt" TIMESTAMP(3),
 "thesis" JSONB NOT NULL,
 "riskFlags" JSONB NOT NULL,
 "invalidation" JSONB NOT NULL,
 "breakdown" JSONB NOT NULL,
 "executionAllowed" BOOLEAN NOT NULL DEFAULT false,
 "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT "OpportunityRadarSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "OpportunityRadarSnapshot_marketKey_createdAt_idx" ON "OpportunityRadarSnapshot"("marketKey","createdAt");
CREATE INDEX "OpportunityRadarSnapshot_status_opportunityScore_createdAt_idx" ON "OpportunityRadarSnapshot"("status","opportunityScore","createdAt");
CREATE INDEX "OpportunityRadarSnapshot_marketType_createdAt_idx" ON "OpportunityRadarSnapshot"("marketType","createdAt");
CREATE INDEX "OpportunityRadarSnapshot_provider_createdAt_idx" ON "OpportunityRadarSnapshot"("provider","createdAt");
CREATE TABLE "OpportunityRadarRun" (
 "id" TEXT NOT NULL,
 "version" TEXT NOT NULL,
 "workerId" TEXT NOT NULL,
 "inventoryCount" INTEGER NOT NULL,
 "certifiedFreshCount" INTEGER NOT NULL,
 "rankedCount" INTEGER NOT NULL,
 "status" TEXT NOT NULL,
 "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
 "completedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT "OpportunityRadarRun_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "OpportunityRadarRun_status_startedAt_idx" ON "OpportunityRadarRun"("status","startedAt");
