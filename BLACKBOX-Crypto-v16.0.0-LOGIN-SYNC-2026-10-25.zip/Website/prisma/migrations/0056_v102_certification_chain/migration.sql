CREATE TABLE IF NOT EXISTS "CertificationRun" (
  "id" TEXT NOT NULL,
  "release" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "completedAt" TIMESTAMP(3),
  "environment" TEXT NOT NULL,
  "commit" TEXT,
  "summary" JSONB NOT NULL,
  CONSTRAINT "CertificationRun_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "CertificationRun_release_startedAt_idx" ON "CertificationRun"("release","startedAt");
CREATE INDEX IF NOT EXISTS "CertificationRun_status_startedAt_idx" ON "CertificationRun"("status","startedAt");

CREATE TABLE IF NOT EXISTS "CertificationGateEvidence" (
  "id" TEXT NOT NULL,
  "runId" TEXT NOT NULL,
  "gate" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "completedAt" TIMESTAMP(3),
  "exitCode" INTEGER,
  "detail" TEXT,
  "evidence" JSONB NOT NULL,
  CONSTRAINT "CertificationGateEvidence_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "CertificationGateEvidence_runId_fkey" FOREIGN KEY ("runId") REFERENCES "CertificationRun"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS "CertificationGateEvidence_runId_startedAt_idx" ON "CertificationGateEvidence"("runId","startedAt");
CREATE INDEX IF NOT EXISTS "CertificationGateEvidence_gate_status_idx" ON "CertificationGateEvidence"("gate","status");
