-- BLACKBOX v6.9 AI Intelligence audit metadata.
ALTER TABLE "AiCall" ADD COLUMN IF NOT EXISTS "intelligenceVersion" TEXT;
ALTER TABLE "AiCall" ADD COLUMN IF NOT EXISTS "inputHash" TEXT;
ALTER TABLE "AiCall" ADD COLUMN IF NOT EXISTS "agreement" TEXT;
ALTER TABLE "AiCall" ADD COLUMN IF NOT EXISTS "safetyScore" INTEGER;
ALTER TABLE "AiCall" ADD COLUMN IF NOT EXISTS "calibratedScore" INTEGER;
ALTER TABLE "AiCall" ADD COLUMN IF NOT EXISTS "calibratedConfidence" INTEGER;
ALTER TABLE "AiCall" ADD COLUMN IF NOT EXISTS "conflictFlags" JSONB;
CREATE INDEX IF NOT EXISTS "AiCall_intelligenceVersion_createdAt_idx" ON "AiCall"("intelligenceVersion", "createdAt");
CREATE INDEX IF NOT EXISTS "AiCall_inputHash_idx" ON "AiCall"("inputHash");
