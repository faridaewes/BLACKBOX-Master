CREATE TABLE "TelegramAlertDelivery" (
  "id" TEXT NOT NULL,
  "broadcastId" TEXT NOT NULL,
  "chatId" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'PENDING',
  "error" TEXT,
  "sentAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "TelegramAlertDelivery_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "TelegramAlertDelivery_broadcastId_chatId_key" ON "TelegramAlertDelivery"("broadcastId","chatId");
CREATE INDEX "TelegramAlertDelivery_chatId_createdAt_idx" ON "TelegramAlertDelivery"("chatId","createdAt");
CREATE INDEX "TelegramAlertDelivery_broadcastId_status_idx" ON "TelegramAlertDelivery"("broadcastId","status");
ALTER TABLE "TelegramAlertDelivery" ADD CONSTRAINT "TelegramAlertDelivery_broadcastId_fkey" FOREIGN KEY ("broadcastId") REFERENCES "Broadcast"("id") ON DELETE CASCADE ON UPDATE CASCADE;
