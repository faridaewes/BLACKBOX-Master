-- BLACKBOX v10.6.1 release convergence evidence
CREATE TABLE "ReleaseConvergenceSnapshot" (
    "id" TEXT NOT NULL,
    "release" TEXT NOT NULL,
    "environment" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "manifestHash" TEXT NOT NULL,
    "runtimeHash" TEXT NOT NULL,
    "configurationHash" TEXT NOT NULL,
    "migrationState" TEXT NOT NULL,
    "workflowState" TEXT NOT NULL,
    "checks" JSONB NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "ReleaseConvergenceSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ReleaseConvergenceSnapshot_release_createdAt_idx" ON "ReleaseConvergenceSnapshot"("release", "createdAt");
CREATE INDEX "ReleaseConvergenceSnapshot_status_createdAt_idx" ON "ReleaseConvergenceSnapshot"("status", "createdAt");
