-- BLACKBOX v11.8 P8 — Decision Quality, Outcome Attribution & Leakage-safe validation
ALTER TABLE "OpportunityRadarSnapshot" ADD COLUMN "referencePrice" DOUBLE PRECISION;
ALTER TABLE "AiConfirmationSnapshot" ADD COLUMN "referencePrice" DOUBLE PRECISION;
CREATE TABLE "DecisionOutcomeObservation" (
  "id" TEXT NOT NULL,"decisionSnapshotId" TEXT NOT NULL,"marketKey" TEXT NOT NULL,"marketType" TEXT NOT NULL,"provider" TEXT NOT NULL,"horizon" TEXT NOT NULL,"dueAt" TIMESTAMP(3) NOT NULL,"observedAt" TIMESTAMP(3) NOT NULL,"referencePrice" DOUBLE PRECISION NOT NULL,"observedPrice" DOUBLE PRECISION NOT NULL,"highPrice" DOUBLE PRECISION,"lowPrice" DOUBLE PRECISION,"sourceVersion" TEXT NOT NULL,"sourceObservedAt" TIMESTAMP(3),"observationStatus" TEXT NOT NULL,"provenance" JSONB NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "DecisionOutcomeObservation_pkey" PRIMARY KEY ("id"));
CREATE UNIQUE INDEX "DecisionOutcomeObservation_decisionSnapshotId_horizon_key" ON "DecisionOutcomeObservation"("decisionSnapshotId","horizon");
CREATE INDEX "DecisionOutcomeObservation_marketKey_horizon_observedAt_idx" ON "DecisionOutcomeObservation"("marketKey","horizon","observedAt");
CREATE INDEX "DecisionOutcomeObservation_observationStatus_observedAt_idx" ON "DecisionOutcomeObservation"("observationStatus","observedAt");
CREATE TABLE "DecisionQualitySnapshot" (
  "id" TEXT NOT NULL,"decisionSnapshotId" TEXT NOT NULL,"marketKey" TEXT NOT NULL,"marketType" TEXT NOT NULL,"provider" TEXT NOT NULL,"horizon" TEXT NOT NULL,"version" TEXT NOT NULL,"decisionStatus" TEXT NOT NULL,"outcomeStatus" TEXT NOT NULL,"direction" TEXT NOT NULL,"referencePrice" DOUBLE PRECISION NOT NULL,"observedPrice" DOUBLE PRECISION,"returnPct" DOUBLE PRECISION,"mfePct" DOUBLE PRECISION,"maePct" DOUBLE PRECISION,"directionCorrect" BOOLEAN,"invalidationHit" BOOLEAN,"elapsedMs" BIGINT,"observationId" TEXT,"leakageGuard" TEXT NOT NULL,"attribution" JSONB NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "DecisionQualitySnapshot_pkey" PRIMARY KEY ("id"));
CREATE UNIQUE INDEX "DecisionQualitySnapshot_decisionSnapshotId_horizon_key" ON "DecisionQualitySnapshot"("decisionSnapshotId","horizon");
CREATE INDEX "DecisionQualitySnapshot_marketKey_horizon_outcomeStatus_idx" ON "DecisionQualitySnapshot"("marketKey","horizon","outcomeStatus");
CREATE INDEX "DecisionQualitySnapshot_outcomeStatus_createdAt_idx" ON "DecisionQualitySnapshot"("outcomeStatus","createdAt");
CREATE TABLE "DecisionQualityRun" (
  "id" TEXT NOT NULL,"version" TEXT NOT NULL,"workerId" TEXT NOT NULL,"inventoryCount" INTEGER NOT NULL,"dueCount" INTEGER NOT NULL,"observedCount" INTEGER NOT NULL,"correctCount" INTEGER NOT NULL,"failedCount" INTEGER NOT NULL,"invalidatedCount" INTEGER NOT NULL,"insufficientCount" INTEGER NOT NULL,"blockedCount" INTEGER NOT NULL,"status" TEXT NOT NULL,"startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,"completedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "DecisionQualityRun_pkey" PRIMARY KEY ("id"));
CREATE INDEX "DecisionQualityRun_status_startedAt_idx" ON "DecisionQualityRun"("status","startedAt");
