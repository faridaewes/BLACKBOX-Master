CREATE TABLE "ExecutionIntelligenceSnapshot" (
  "id" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "venue" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "route" TEXT NOT NULL,
  "expectedOutput" DOUBLE PRECISION NOT NULL,
  "netExpectedOutput" DOUBLE PRECISION NOT NULL,
  "priceImpactPct" DOUBLE PRECISION NOT NULL,
  "slippageBps" DOUBLE PRECISION NOT NULL,
  "feeBps" DOUBLE PRECISION NOT NULL,
  "gasCostQuote" DOUBLE PRECISION NOT NULL,
  "latencyMs" DOUBLE PRECISION NOT NULL,
  "liquidityUsd" DOUBLE PRECISION NOT NULL,
  "trustScore" INTEGER NOT NULL,
  "score" DOUBLE PRECISION NOT NULL,
  "status" TEXT NOT NULL,
  "blockers" JSONB NOT NULL,
  "warnings" JSONB NOT NULL,
  "evidence" JSONB NOT NULL,
  "observedAt" TIMESTAMP(3) NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ExecutionIntelligenceSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ExecutionIntelligenceSnapshot_marketKey_observedAt_idx" ON "ExecutionIntelligenceSnapshot"("marketKey","observedAt");
CREATE INDEX "ExecutionIntelligenceSnapshot_status_observedAt_idx" ON "ExecutionIntelligenceSnapshot"("status","observedAt");
CREATE INDEX "ExecutionIntelligenceSnapshot_provider_marketType_observedAt_idx" ON "ExecutionIntelligenceSnapshot"("provider","marketType","observedAt");
