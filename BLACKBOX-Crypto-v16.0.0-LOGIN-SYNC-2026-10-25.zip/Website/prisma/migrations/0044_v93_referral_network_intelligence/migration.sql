-- v9.3 Referral Network Intelligence: query-path indexes and no balance-state duplication.
CREATE INDEX IF NOT EXISTS "User_referredById_idx" ON "User"("referredById");
CREATE INDEX IF NOT EXISTS "Subscription_userId_status_expiresAt_idx" ON "Subscription"("userId", "status", "expiresAt");
CREATE INDEX IF NOT EXISTS "ReferralRedemption_userId_createdAt_idx" ON "ReferralRedemption"("userId", "createdAt");
CREATE INDEX IF NOT EXISTS "ReferralPointLedger_userId_status_createdAt_idx" ON "ReferralPointLedger"("userId", "status", "createdAt");
