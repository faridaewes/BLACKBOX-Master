-- BLACKBOX v16.0.0 — Canonical runtime execution integration for Position Truth, Correlation Context, Idempotency Ledger, and Trade Passport.
-- v16.0.0 canonical runtime execution integration
ALTER TABLE "Execution" ADD COLUMN "correlationId" TEXT;
ALTER TABLE "Execution" ADD COLUMN "passportId" TEXT;
CREATE INDEX "Execution_correlationId_createdAt_idx" ON "Execution"("correlationId", "createdAt");
CREATE INDEX "Execution_passportId_createdAt_idx" ON "Execution"("passportId", "createdAt");
