ALTER TABLE "SupportTicket" ADD COLUMN "assignedTeamId" TEXT;
ALTER TABLE "SupportTicket" ADD COLUMN "assignedAgentId" TEXT;
ALTER TABLE "SupportTicket" ADD COLUMN "routedAt" TIMESTAMP(3);

CREATE TABLE "WorkSession" (
 "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "teamId" TEXT NOT NULL, "startedAt" TIMESTAMP(3) NOT NULL,
 "endedAt" TIMESTAMP(3), "lastHeartbeatAt" TIMESTAMP(3), "source" TEXT NOT NULL DEFAULT 'WEB', "note" TEXT,
 "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
 "approvedById" TEXT,
 CONSTRAINT "WorkSession_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "WorkActivityEvent" (
 "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "teamId" TEXT NOT NULL, "sessionId" TEXT, "taskId" TEXT, "type" TEXT NOT NULL,
 "metadata" JSONB, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT "WorkActivityEvent_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "SupportTicketTransfer" (
 "id" TEXT NOT NULL, "ticketId" TEXT NOT NULL, "fromTeamId" TEXT, "toTeamId" TEXT NOT NULL, "fromAgentId" TEXT, "toAgentId" TEXT,
 "reason" TEXT NOT NULL, "createdById" TEXT NOT NULL, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT "SupportTicketTransfer_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "SupportTicket_assignedTeamId_updatedAt_idx" ON "SupportTicket"("assignedTeamId","updatedAt");
CREATE INDEX "SupportTicket_assignedAgentId_updatedAt_idx" ON "SupportTicket"("assignedAgentId","updatedAt");
CREATE INDEX "WorkSession_userId_startedAt_idx" ON "WorkSession"("userId","startedAt");
CREATE INDEX "WorkSession_teamId_startedAt_idx" ON "WorkSession"("teamId","startedAt");
CREATE INDEX "WorkSession_userId_endedAt_idx" ON "WorkSession"("userId","endedAt");
CREATE INDEX "WorkActivityEvent_userId_createdAt_idx" ON "WorkActivityEvent"("userId","createdAt");
CREATE INDEX "WorkActivityEvent_teamId_createdAt_idx" ON "WorkActivityEvent"("teamId","createdAt");
CREATE INDEX "WorkActivityEvent_sessionId_createdAt_idx" ON "WorkActivityEvent"("sessionId","createdAt");
CREATE INDEX "SupportTicketTransfer_ticketId_createdAt_idx" ON "SupportTicketTransfer"("ticketId","createdAt");
CREATE INDEX "SupportTicketTransfer_toTeamId_createdAt_idx" ON "SupportTicketTransfer"("toTeamId","createdAt");
ALTER TABLE "SupportTicket" ADD CONSTRAINT "SupportTicket_assignedTeamId_fkey" FOREIGN KEY ("assignedTeamId") REFERENCES "AccessTeam"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "SupportTicket" ADD CONSTRAINT "SupportTicket_assignedAgentId_fkey" FOREIGN KEY ("assignedAgentId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "WorkSession" ADD CONSTRAINT "WorkSession_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "WorkSession" ADD CONSTRAINT "WorkSession_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES "AccessTeam"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "WorkSession" ADD CONSTRAINT "WorkSession_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "WorkActivityEvent" ADD CONSTRAINT "WorkActivityEvent_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "WorkActivityEvent" ADD CONSTRAINT "WorkActivityEvent_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES "AccessTeam"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "WorkActivityEvent" ADD CONSTRAINT "WorkActivityEvent_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "WorkSession"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "WorkActivityEvent" ADD CONSTRAINT "WorkActivityEvent_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES "TeamTask"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "SupportTicketTransfer" ADD CONSTRAINT "SupportTicketTransfer_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES "SupportTicket"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "SupportTicketTransfer" ADD CONSTRAINT "SupportTicketTransfer_fromTeamId_fkey" FOREIGN KEY ("fromTeamId") REFERENCES "AccessTeam"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "SupportTicketTransfer" ADD CONSTRAINT "SupportTicketTransfer_toTeamId_fkey" FOREIGN KEY ("toTeamId") REFERENCES "AccessTeam"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "SupportTicketTransfer" ADD CONSTRAINT "SupportTicketTransfer_fromAgentId_fkey" FOREIGN KEY ("fromAgentId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "SupportTicketTransfer" ADD CONSTRAINT "SupportTicketTransfer_toAgentId_fkey" FOREIGN KEY ("toAgentId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "SupportTicketTransfer" ADD CONSTRAINT "SupportTicketTransfer_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
