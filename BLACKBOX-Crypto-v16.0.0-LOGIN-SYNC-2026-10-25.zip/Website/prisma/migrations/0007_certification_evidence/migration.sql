ALTER TABLE "ExchangeAccount" ADD COLUMN IF NOT EXISTS "certificationStatus" TEXT NOT NULL DEFAULT 'NOT_CERTIFIED';
ALTER TABLE "ExchangeAccount" ADD COLUMN IF NOT EXISTS "certificationTests" JSONB;
ALTER TABLE "ExchangeAccount" ADD COLUMN IF NOT EXISTS "certificationCompletedAt" TIMESTAMP(3);
UPDATE "ExchangeAccount" SET "certificationStatus"='NOT_CERTIFIED' WHERE "certificationStatus" IS NULL;
