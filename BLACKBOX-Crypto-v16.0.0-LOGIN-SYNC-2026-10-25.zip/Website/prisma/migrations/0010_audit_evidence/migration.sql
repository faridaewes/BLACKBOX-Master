ALTER TABLE "LegalDocument" ADD COLUMN IF NOT EXISTS "contentHash" TEXT;
ALTER TABLE "Consent" ADD COLUMN IF NOT EXISTS "documentHash" TEXT;
ALTER TABLE "Consent" ADD COLUMN IF NOT EXISTS "documentVersion" TEXT;
ALTER TABLE "Consent" ADD COLUMN IF NOT EXISTS "documentTitle" TEXT;
CREATE INDEX IF NOT EXISTS "Consent_userId_acceptedAt_idx" ON "Consent" ("userId","acceptedAt");
CREATE INDEX IF NOT EXISTS "Consent_documentId_acceptedAt_idx" ON "Consent" ("documentId","acceptedAt");
ALTER TABLE "AuditLog" ADD COLUMN IF NOT EXISTS "actorNameSnapshot" TEXT;
ALTER TABLE "AuditLog" ADD COLUMN IF NOT EXISTS "actorEmailSnapshot" TEXT;
ALTER TABLE "AuditLog" ADD COLUMN IF NOT EXISTS "actorRoleSnapshot" TEXT;
ALTER TABLE "AuditLog" ADD COLUMN IF NOT EXISTS "targetNameSnapshot" TEXT;
ALTER TABLE "AuditLog" ADD COLUMN IF NOT EXISTS "targetEmailSnapshot" TEXT;
ALTER TABLE "AuditLog" ADD COLUMN IF NOT EXISTS "targetRoleSnapshot" TEXT;
CREATE INDEX IF NOT EXISTS "AuditLog_createdAt_idx" ON "AuditLog" ("createdAt");
CREATE INDEX IF NOT EXISTS "AuditLog_actorId_createdAt_idx" ON "AuditLog" ("actorId","createdAt");
CREATE INDEX IF NOT EXISTS "AuditLog_targetType_targetId_createdAt_idx" ON "AuditLog" ("targetType","targetId","createdAt");
CREATE INDEX IF NOT EXISTS "AuditLog_action_createdAt_idx" ON "AuditLog" ("action","createdAt");

CREATE OR REPLACE FUNCTION blackbox_audit_snapshot_user()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  actor_user "User"%ROWTYPE;
  target_user "User"%ROWTYPE;
BEGIN
  IF NEW.actorId IS NOT NULL THEN
    SELECT * INTO actor_user FROM "User" WHERE id = NEW.actorId;
    IF FOUND THEN
      NEW.actorNameSnapshot := COALESCE(NEW.actorNameSnapshot, actor_user.name);
      NEW.actorEmailSnapshot := COALESCE(NEW.actorEmailSnapshot, actor_user.email);
      NEW.actorRoleSnapshot := COALESCE(NEW.actorRoleSnapshot, actor_user.role::text);
    END IF;
  END IF;
  IF upper(COALESCE(NEW.targetType,'')) = 'USER' AND NEW.targetId IS NOT NULL THEN
    SELECT * INTO target_user FROM "User" WHERE id = NEW.targetId;
    IF FOUND THEN
      NEW.targetNameSnapshot := COALESCE(NEW.targetNameSnapshot, target_user.name);
      NEW.targetEmailSnapshot := COALESCE(NEW.targetEmailSnapshot, target_user.email);
      NEW.targetRoleSnapshot := COALESCE(NEW.targetRoleSnapshot, target_user.role::text);
    END IF;
  END IF;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS blackbox_audit_snapshot_user_trigger ON "AuditLog";
CREATE TRIGGER blackbox_audit_snapshot_user_trigger
BEFORE INSERT ON "AuditLog"
FOR EACH ROW EXECUTE FUNCTION blackbox_audit_snapshot_user();

UPDATE "AuditLog" a
SET "actorNameSnapshot" = u.name,
    "actorEmailSnapshot" = u.email,
    "actorRoleSnapshot" = u.role::text
FROM "User" u
WHERE a."actorId" = u.id
  AND (a."actorNameSnapshot" IS NULL OR a."actorEmailSnapshot" IS NULL OR a."actorRoleSnapshot" IS NULL);

UPDATE "AuditLog" a
SET "targetNameSnapshot" = u.name,
    "targetEmailSnapshot" = u.email,
    "targetRoleSnapshot" = u.role::text
FROM "User" u
WHERE upper(COALESCE(a."targetType",'')) = 'USER'
  AND a."targetId" = u.id
  AND (a."targetNameSnapshot" IS NULL OR a."targetEmailSnapshot" IS NULL OR a."targetRoleSnapshot" IS NULL);
