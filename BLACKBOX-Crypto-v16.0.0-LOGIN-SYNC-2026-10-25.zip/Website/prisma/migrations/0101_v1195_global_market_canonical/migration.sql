ALTER TABLE "MarketRegistry" ADD COLUMN "canonicalSymbol" TEXT;
ALTER TABLE "MarketRegistry" ADD COLUMN "settlementAsset" TEXT;
ALTER TABLE "MarketRegistry" ADD COLUMN "instrumentType" TEXT;
ALTER TABLE "MarketRegistry" ADD COLUMN "contractKind" TEXT;
CREATE INDEX "MarketRegistry_canonicalSymbol_idx" ON "MarketRegistry"("canonicalSymbol");
CREATE INDEX "MarketRegistry_marketType_canonicalSymbol_idx" ON "MarketRegistry"("marketType","canonicalSymbol");
