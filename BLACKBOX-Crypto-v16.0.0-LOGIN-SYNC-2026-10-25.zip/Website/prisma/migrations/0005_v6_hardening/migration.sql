-- BLACKBOX v6 hardening: session invalidation, real-order metadata, reconciliation relations.
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "sessionVersion" INTEGER NOT NULL DEFAULT 0;

DO $$ BEGIN
  ALTER TYPE "OrderStatus" ADD VALUE IF NOT EXISTS 'PARTIALLY_FILLED';
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

ALTER TABLE "Order" ADD COLUMN IF NOT EXISTS "filledQuantity" DOUBLE PRECISION NOT NULL DEFAULT 0;
ALTER TABLE "Order" ADD COLUMN IF NOT EXISTS "averagePrice" DOUBLE PRECISION;
ALTER TABLE "Order" ADD COLUMN IF NOT EXISTS "clientOrderId" TEXT;
ALTER TABLE "Order" ADD COLUMN IF NOT EXISTS "fee" DOUBLE PRECISION NOT NULL DEFAULT 0;
ALTER TABLE "Order" ADD COLUMN IF NOT EXISTS "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

CREATE INDEX IF NOT EXISTS "Order_botId_createdAt_idx" ON "Order"("botId","createdAt");
CREATE INDEX IF NOT EXISTS "Order_externalId_idx" ON "Order"("externalId");
CREATE UNIQUE INDEX IF NOT EXISTS "Order_botId_clientOrderId_key" ON "Order"("botId","clientOrderId");

DO $$ BEGIN
  ALTER TABLE "Reconciliation" ADD CONSTRAINT "Reconciliation_exchangeAccountId_fkey"
    FOREIGN KEY ("exchangeAccountId") REFERENCES "ExchangeAccount"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE "Reconciliation" ADD CONSTRAINT "Reconciliation_executionId_fkey"
    FOREIGN KEY ("executionId") REFERENCES "Execution"("id") ON DELETE SET NULL ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

CREATE INDEX IF NOT EXISTS "Reconciliation_exchangeAccountId_checkedAt_idx" ON "Reconciliation"("exchangeAccountId","checkedAt");
CREATE INDEX IF NOT EXISTS "Reconciliation_executionId_checkedAt_idx" ON "Reconciliation"("executionId","checkedAt");
