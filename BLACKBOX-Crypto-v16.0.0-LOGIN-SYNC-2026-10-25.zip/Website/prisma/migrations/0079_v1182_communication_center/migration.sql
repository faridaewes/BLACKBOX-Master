ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "telegramChatId" TEXT;
CREATE TABLE IF NOT EXISTS "TelegramGatewayConfig" (
  "id" TEXT NOT NULL,
  "enabled" BOOLEAN NOT NULL DEFAULT true,
  "botTokenEnc" TEXT,
  "officialChatId" TEXT NOT NULL,
  "transactionChatId" TEXT NOT NULL,
  "updatedById" TEXT,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "TelegramGatewayConfig_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "TelegramOutboundEvent" (
  "id" TEXT NOT NULL,
  "eventKey" TEXT NOT NULL,
  "chatId" TEXT NOT NULL,
  "kind" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'PENDING',
  "attempts" INTEGER NOT NULL DEFAULT 0,
  "telegramMessageId" INTEGER,
  "error" TEXT,
  "sentAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "TelegramOutboundEvent_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "TelegramOutboundEvent_eventKey_key" ON "TelegramOutboundEvent"("eventKey");
CREATE INDEX IF NOT EXISTS "TelegramOutboundEvent_chatId_createdAt_idx" ON "TelegramOutboundEvent"("chatId","createdAt");
CREATE INDEX IF NOT EXISTS "TelegramOutboundEvent_kind_createdAt_idx" ON "TelegramOutboundEvent"("kind","createdAt");
CREATE INDEX IF NOT EXISTS "TelegramOutboundEvent_status_createdAt_idx" ON "TelegramOutboundEvent"("status","createdAt");
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='TelegramGatewayConfig_updatedById_fkey') THEN
    ALTER TABLE "TelegramGatewayConfig" ADD CONSTRAINT "TelegramGatewayConfig_updatedById_fkey" FOREIGN KEY ("updatedById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
END $$;
CREATE INDEX IF NOT EXISTS "User_telegramChatId_idx" ON "User"("telegramChatId");
