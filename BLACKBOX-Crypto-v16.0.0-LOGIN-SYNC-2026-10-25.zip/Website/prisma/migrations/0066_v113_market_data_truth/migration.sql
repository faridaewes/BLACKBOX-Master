CREATE TABLE "MarketDataTruthSnapshot" (
  "id" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "symbol" TEXT NOT NULL,
  "chain" TEXT NOT NULL,
  "priceUsd" DOUBLE PRECISION,
  "bidUsd" DOUBLE PRECISION,
  "askUsd" DOUBLE PRECISION,
  "spreadBps" DOUBLE PRECISION,
  "liquidityUsd" DOUBLE PRECISION,
  "volume24h" DOUBLE PRECISION,
  "observedAt" TIMESTAMP(3) NOT NULL,
  "fetchedAt" TIMESTAMP(3),
  "sourceUpdatedAt" TIMESTAMP(3),
  "freshnessMs" INTEGER,
  "sourceAgeMs" INTEGER,
  "clockSkewMs" INTEGER,
  "qualityScore" INTEGER NOT NULL,
  "status" TEXT NOT NULL,
  "blockers" JSONB NOT NULL,
  "warnings" JSONB NOT NULL,
  "ohlcvCount" INTEGER NOT NULL DEFAULT 0,
  "capturedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "MarketDataTruthSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "MarketDataTruthSnapshot_marketKey_capturedAt_idx" ON "MarketDataTruthSnapshot"("marketKey", "capturedAt");
CREATE INDEX "MarketDataTruthSnapshot_status_capturedAt_idx" ON "MarketDataTruthSnapshot"("status", "capturedAt");
CREATE INDEX "MarketDataTruthSnapshot_provider_marketType_capturedAt_idx" ON "MarketDataTruthSnapshot"("provider", "marketType", "capturedAt");
