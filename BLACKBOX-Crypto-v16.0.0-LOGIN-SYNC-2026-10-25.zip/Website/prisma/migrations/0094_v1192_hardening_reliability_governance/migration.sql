ALTER TABLE "TierActivationDelivery" ADD COLUMN IF NOT EXISTS "emailAttempts" INTEGER NOT NULL DEFAULT 0;
ALTER TABLE "TierActivationDelivery" ADD COLUMN IF NOT EXISTS "emailNextAttemptAt" TIMESTAMP(3);
CREATE INDEX IF NOT EXISTS "TierActivationDelivery_emailRetry_idx" ON "TierActivationDelivery"("emailStatus","emailNextAttemptAt");
ALTER TABLE "PublicAdvisor" ALTER COLUMN "workflowStatus" SET DEFAULT 'DRAFT';
ALTER TABLE "DashboardAnnouncement" ALTER COLUMN "workflowStatus" SET DEFAULT 'DRAFT';
