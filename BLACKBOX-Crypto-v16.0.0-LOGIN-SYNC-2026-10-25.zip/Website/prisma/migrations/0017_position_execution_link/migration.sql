ALTER TABLE "Position" ADD COLUMN "executionId" TEXT;
CREATE UNIQUE INDEX "Position_executionId_key" ON "Position"("executionId");
ALTER TABLE "Position" ADD CONSTRAINT "Position_executionId_fkey" FOREIGN KEY ("executionId") REFERENCES "Execution"("id") ON DELETE SET NULL ON UPDATE CASCADE;
