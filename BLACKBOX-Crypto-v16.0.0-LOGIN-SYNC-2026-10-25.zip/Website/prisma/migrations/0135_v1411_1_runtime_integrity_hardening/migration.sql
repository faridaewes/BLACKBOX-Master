-- BLACKBOX v14.11.3 runtime integrity hardening (migration directory retained for canonical schema identity).
-- Additive certification/evidence tables; no trading authority is granted.
CREATE TABLE "CertificationRunV1411_1" (
  "id" TEXT NOT NULL, "release" TEXT NOT NULL, "overallState" TEXT NOT NULL,
  "environment" TEXT NOT NULL, "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "completedAt" TIMESTAMP(3), "evidence" JSONB NOT NULL,
  CONSTRAINT "CertificationRunV1411_1_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "CertificationRunV1411_1_release_startedAt_idx" ON "CertificationRunV1411_1"("release","startedAt");
CREATE INDEX "CertificationRunV1411_1_overallState_startedAt_idx" ON "CertificationRunV1411_1"("overallState","startedAt");

CREATE TABLE "RuntimeIntegrityCheckV1411_1" (
  "id" TEXT NOT NULL, "runId" TEXT NOT NULL, "gate" TEXT NOT NULL,
  "status" TEXT NOT NULL, "detail" TEXT NOT NULL, "evidence" JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "RuntimeIntegrityCheckV1411_1_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "RuntimeIntegrityCheckV1411_1_runId_fkey" FOREIGN KEY ("runId") REFERENCES "CertificationRunV1411_1"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX "RuntimeIntegrityCheckV1411_1_runId_status_idx" ON "RuntimeIntegrityCheckV1411_1"("runId","status");
CREATE INDEX "RuntimeIntegrityCheckV1411_1_gate_createdAt_idx" ON "RuntimeIntegrityCheckV1411_1"("gate","createdAt");
