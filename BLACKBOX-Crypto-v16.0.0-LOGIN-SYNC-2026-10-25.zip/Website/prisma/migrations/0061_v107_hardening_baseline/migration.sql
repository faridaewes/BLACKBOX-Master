-- BLACKBOX v10.7.0 development/hardening baseline evidence
CREATE TABLE "ReleaseHardeningSnapshot" (
    "id" TEXT NOT NULL,
    "release" TEXT NOT NULL,
    "environment" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "manifestHash" TEXT NOT NULL,
    "lockState" TEXT NOT NULL,
    "buildState" TEXT NOT NULL,
    "testState" TEXT NOT NULL,
    "externalState" TEXT NOT NULL,
    "tradingAuthorization" TEXT NOT NULL,
    "blockers" JSONB NOT NULL,
    "checks" JSONB NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "ReleaseHardeningSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ReleaseHardeningSnapshot_release_createdAt_idx" ON "ReleaseHardeningSnapshot"("release", "createdAt");
CREATE INDEX "ReleaseHardeningSnapshot_status_createdAt_idx" ON "ReleaseHardeningSnapshot"("status", "createdAt");
