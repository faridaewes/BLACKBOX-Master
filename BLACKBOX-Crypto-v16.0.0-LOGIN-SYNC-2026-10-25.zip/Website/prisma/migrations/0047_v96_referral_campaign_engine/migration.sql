-- v9.6 Referral Campaign Engine
CREATE TABLE IF NOT EXISTS "ReferralCampaign" (
  "id" TEXT NOT NULL, "code" TEXT NOT NULL, "name" TEXT NOT NULL, "description" TEXT,
  "status" TEXT NOT NULL DEFAULT 'DRAFT', "trigger" TEXT NOT NULL, "threshold" INTEGER,
  "rewardPoints" INTEGER NOT NULL, "maxRewardsPerUser" INTEGER NOT NULL DEFAULT 1,
  "maxTotalRewards" INTEGER, "startsAt" TIMESTAMP(3) NOT NULL, "endsAt" TIMESTAMP(3),
  "createdById" TEXT NOT NULL, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ReferralCampaign_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "ReferralCampaign_code_key" UNIQUE ("code")
);
CREATE TABLE IF NOT EXISTS "ReferralCampaignReward" (
  "id" TEXT NOT NULL, "campaignId" TEXT NOT NULL, "userId" TEXT NOT NULL,
  "points" INTEGER NOT NULL, "eventKey" TEXT NOT NULL, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ReferralCampaignReward_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "ReferralCampaignReward_campaignId_userId_eventKey_key" UNIQUE ("campaignId","userId","eventKey"),
  CONSTRAINT "ReferralCampaignReward_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES "ReferralCampaign"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "ReferralCampaignReward_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS "ReferralCampaign_status_startsAt_endsAt_idx" ON "ReferralCampaign"("status","startsAt","endsAt");
CREATE INDEX IF NOT EXISTS "ReferralCampaign_trigger_status_startsAt_idx" ON "ReferralCampaign"("trigger","status","startsAt");
CREATE INDEX IF NOT EXISTS "ReferralCampaignReward_userId_createdAt_idx" ON "ReferralCampaignReward"("userId","createdAt");
CREATE INDEX IF NOT EXISTS "ReferralCampaignReward_campaignId_createdAt_idx" ON "ReferralCampaignReward"("campaignId","createdAt");

CREATE INDEX IF NOT EXISTS "ReferralCampaign_createdById_createdAt_idx" ON "ReferralCampaign"("createdById","createdAt");
