-- BLACKBOX Crypto v10.0.0 — Referral & Reward OS
CREATE TABLE "ReferralOSEvent" (
  "id" TEXT NOT NULL,
  "eventKey" TEXT NOT NULL,
  "eventType" TEXT NOT NULL,
  "userId" TEXT,
  "sponsorId" TEXT,
  "referralCode" TEXT,
  "source" TEXT NOT NULL DEFAULT 'SYSTEM',
  "status" TEXT NOT NULL DEFAULT 'RECORDED',
  "points" INTEGER NOT NULL DEFAULT 0,
  "metadata" JSONB NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ReferralOSEvent_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "ReferralOSEvent_eventKey_key" ON "ReferralOSEvent"("eventKey");
CREATE INDEX "ReferralOSEvent_eventType_createdAt_idx" ON "ReferralOSEvent"("eventType", "createdAt");
CREATE INDEX "ReferralOSEvent_userId_createdAt_idx" ON "ReferralOSEvent"("userId", "createdAt");
CREATE INDEX "ReferralOSEvent_sponsorId_createdAt_idx" ON "ReferralOSEvent"("sponsorId", "createdAt");
CREATE INDEX "ReferralOSEvent_source_createdAt_idx" ON "ReferralOSEvent"("source", "createdAt");
CREATE INDEX "ReferralOSEvent_status_createdAt_idx" ON "ReferralOSEvent"("status", "createdAt");
ALTER TABLE "ReferralOSEvent" ADD CONSTRAINT "ReferralOSEvent_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
