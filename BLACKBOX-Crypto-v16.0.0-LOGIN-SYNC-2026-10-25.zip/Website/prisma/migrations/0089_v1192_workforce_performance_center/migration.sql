-- Workforce Performance Center indexes and active-session race protection.
-- PostgreSQL partial uniqueness prevents concurrent START requests from opening
-- multiple active payroll sessions for the same worker.
CREATE UNIQUE INDEX IF NOT EXISTS "WorkSession_one_active_per_user_idx"
ON "WorkSession"("userId") WHERE "endedAt" IS NULL;

CREATE INDEX IF NOT EXISTS "WorkSession_team_end_start_idx"
ON "WorkSession"("teamId", "endedAt", "startedAt");

CREATE INDEX IF NOT EXISTS "WorkActivityEvent_task_time_idx"
ON "WorkActivityEvent"("taskId", "createdAt");

CREATE INDEX IF NOT EXISTS "TeamTask_team_completed_created_idx"
ON "TeamTask"("teamId", "completedAt", "createdAt");

CREATE INDEX IF NOT EXISTS "TeamTask_assignee_completed_idx"
ON "TeamTask"("assigneeId", "completedAt");

CREATE INDEX IF NOT EXISTS "SupportTicket_team_agent_status_idx"
ON "SupportTicket"("assignedTeamId", "assignedAgentId", "status", "updatedAt");

CREATE INDEX IF NOT EXISTS "SupportTicket_agent_created_idx"
ON "SupportTicket"("assignedAgentId", "createdAt");
