-- BLACKBOX v12.0.0 — WPA Community Hardening / Roles / Lifecycle / RSVP / Moderation / Points Traceability
ALTER TABLE "WpaCommunity" ADD COLUMN IF NOT EXISTS "publicationState" TEXT NOT NULL DEFAULT 'DRAFT';
ALTER TABLE "WpaCommunity" ADD COLUMN IF NOT EXISTS "verified" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "WpaCommunity" ADD COLUMN IF NOT EXISTS "verifiedAt" TIMESTAMP(3);
ALTER TABLE "WpaCommunity" ADD COLUMN IF NOT EXISTS "verifiedById" TEXT;
ALTER TABLE "WpaCommunity" ADD COLUMN IF NOT EXISTS "publishedAt" TIMESTAMP(3);
UPDATE "WpaCommunity" SET "publicationState"='PUBLISHED' WHERE "published"=true AND "status"='ACTIVE';
UPDATE "WpaCommunity" SET "publicationState"='SUSPENDED' WHERE "status"='SUSPENDED';
UPDATE "WpaCommunity" SET "publicationState"='ARCHIVED' WHERE "status"='ARCHIVED';
CREATE INDEX IF NOT EXISTS "WpaCommunity_published_status_publicationState_updatedAt_idx" ON "WpaCommunity"("published","status","publicationState","updatedAt");

ALTER TABLE "WpaCommunityAnnouncement" ADD COLUMN IF NOT EXISTS "contentState" TEXT NOT NULL DEFAULT 'DRAFT';
ALTER TABLE "WpaCommunityAnnouncement" ADD COLUMN IF NOT EXISTS "scheduledAt" TIMESTAMP(3);
ALTER TABLE "WpaCommunityAnnouncement" ADD COLUMN IF NOT EXISTS "version" INTEGER NOT NULL DEFAULT 1;
UPDATE "WpaCommunityAnnouncement" SET "contentState"='PUBLISHED' WHERE "active"=true AND "publishedAt" IS NOT NULL;
CREATE INDEX IF NOT EXISTS "WpaCommunityAnnouncement_communityId_active_pinned_contentState_scheduledAt_publishedAt_idx" ON "WpaCommunityAnnouncement"("communityId","active","pinned","contentState","scheduledAt","publishedAt");

CREATE TABLE IF NOT EXISTS "WpaCommunityAnnouncementVersion" (
  "id" TEXT NOT NULL,
  "announcementId" TEXT NOT NULL,
  "version" INTEGER NOT NULL,
  "title" TEXT NOT NULL,
  "body" TEXT NOT NULL,
  "imageUrl" TEXT,
  "createdById" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "WpaCommunityAnnouncementVersion_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "WpaCommunityAnnouncementVersion_announcementId_version_key" ON "WpaCommunityAnnouncementVersion"("announcementId","version");
CREATE INDEX IF NOT EXISTS "WpaCommunityAnnouncementVersion_announcementId_createdAt_idx" ON "WpaCommunityAnnouncementVersion"("announcementId","createdAt");
DO $$ BEGIN ALTER TABLE "WpaCommunityAnnouncementVersion" ADD CONSTRAINT "WpaCommunityAnnouncementVersion_announcementId_fkey" FOREIGN KEY ("announcementId") REFERENCES "WpaCommunityAnnouncement"("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "WpaCommunityAnnouncementVersion" ADD CONSTRAINT "WpaCommunityAnnouncementVersion_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
INSERT INTO "WpaCommunityAnnouncementVersion" ("id","announcementId","version","title","body","imageUrl","createdById")
SELECT 'wpa-ann-v1-'||a."id",a."id",1,a."title",a."body",a."imageUrl",pa."userId"
FROM "WpaCommunityAnnouncement" a JOIN "WpaCommunity" c ON c."id"=a."communityId" JOIN "PublicAdvisor" pa ON pa."id"=c."advisorId"
WHERE pa."userId" IS NOT NULL AND NOT EXISTS (SELECT 1 FROM "WpaCommunityAnnouncementVersion" v WHERE v."announcementId"=a."id");

CREATE TABLE IF NOT EXISTS "WpaCommunityRole" (
  "id" TEXT NOT NULL,
  "communityId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "role" TEXT NOT NULL,
  "assignedById" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WpaCommunityRole_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "WpaCommunityRole_communityId_userId_key" ON "WpaCommunityRole"("communityId","userId");
CREATE INDEX IF NOT EXISTS "WpaCommunityRole_communityId_role_idx" ON "WpaCommunityRole"("communityId","role");
DO $$ BEGIN ALTER TABLE "WpaCommunityRole" ADD CONSTRAINT "WpaCommunityRole_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES "WpaCommunity"("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "WpaCommunityRole" ADD CONSTRAINT "WpaCommunityRole_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "WpaCommunityRole" ADD CONSTRAINT "WpaCommunityRole_assignedById_fkey" FOREIGN KEY ("assignedById") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS "WpaCommunityEventRsvp" (
  "id" TEXT NOT NULL,
  "eventId" TEXT NOT NULL,
  "communityId" TEXT NOT NULL,
  "memberId" TEXT,
  "userId" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'INTERESTED',
  "registeredAt" TIMESTAMP(3),
  "attendedAt" TIMESTAMP(3),
  "cancelledAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WpaCommunityEventRsvp_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "WpaCommunityEventRsvp_eventId_userId_key" ON "WpaCommunityEventRsvp"("eventId","userId");
CREATE INDEX IF NOT EXISTS "WpaCommunityEventRsvp_eventId_status_updatedAt_idx" ON "WpaCommunityEventRsvp"("eventId","status","updatedAt");
CREATE INDEX IF NOT EXISTS "WpaCommunityEventRsvp_communityId_status_updatedAt_idx" ON "WpaCommunityEventRsvp"("communityId","status","updatedAt");
DO $$ BEGIN ALTER TABLE "WpaCommunityEventRsvp" ADD CONSTRAINT "WpaCommunityEventRsvp_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "WpaCommunityEvent"("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "WpaCommunityEventRsvp" ADD CONSTRAINT "WpaCommunityEventRsvp_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES "WpaCommunity"("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "WpaCommunityEventRsvp" ADD CONSTRAINT "WpaCommunityEventRsvp_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "WpaCommunityMember"("id") ON DELETE SET NULL ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "WpaCommunityEventRsvp" ADD CONSTRAINT "WpaCommunityEventRsvp_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS "WpaCommunityModerationCase" (
  "id" TEXT NOT NULL,
  "communityId" TEXT NOT NULL,
  "actorId" TEXT NOT NULL,
  "targetType" TEXT NOT NULL,
  "targetId" TEXT,
  "severity" TEXT NOT NULL DEFAULT 'MEDIUM',
  "reason" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'OPEN',
  "resolution" TEXT,
  "resolvedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WpaCommunityModerationCase_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "WpaCommunityModerationCase_communityId_status_createdAt_idx" ON "WpaCommunityModerationCase"("communityId","status","createdAt");
CREATE INDEX IF NOT EXISTS "WpaCommunityModerationCase_targetType_targetId_idx" ON "WpaCommunityModerationCase"("targetType","targetId");
DO $$ BEGIN ALTER TABLE "WpaCommunityModerationCase" ADD CONSTRAINT "WpaCommunityModerationCase_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES "WpaCommunity"("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "WpaCommunityModerationCase" ADD CONSTRAINT "WpaCommunityModerationCase_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE "ReferralPointLedger" ADD COLUMN IF NOT EXISTS "idempotencyKey" TEXT;
CREATE INDEX IF NOT EXISTS "ReferralPointLedger_userId_idempotencyKey_idx" ON "ReferralPointLedger"("userId","idempotencyKey");
ALTER TABLE "WpaCommunity" ADD COLUMN IF NOT EXISTS "verificationState" TEXT NOT NULL DEFAULT 'UNSUBMITTED';
ALTER TABLE "WpaCommunity" ADD COLUMN IF NOT EXISTS "verificationReason" TEXT;
ALTER TABLE "WpaCommunity" ADD COLUMN IF NOT EXISTS "verificationReviewedAt" TIMESTAMP(3);
