-- BLACKBOX v12.0.0 WPA parity + Daily Trading Signals
-- Adds configurable WPA marketplace/profile ecosystem and gated daily signal snapshots.

CREATE TABLE "WpaService" (
  "id" TEXT NOT NULL, "advisorId" TEXT NOT NULL, "name" TEXT NOT NULL, "description" TEXT,
  "category" TEXT, "priceMinor" INTEGER, "currency" TEXT NOT NULL DEFAULT 'IDR',
  "durationMinutes" INTEGER, "active" BOOLEAN NOT NULL DEFAULT true, "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WpaService_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "WpaService_advisorId_active_sortOrder_idx" ON "WpaService"("advisorId","active","sortOrder");
ALTER TABLE "WpaService" ADD CONSTRAINT "WpaService_advisorId_fkey" FOREIGN KEY ("advisorId") REFERENCES "PublicAdvisor"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "WpaCertification" (
  "id" TEXT NOT NULL, "advisorId" TEXT NOT NULL, "authority" TEXT NOT NULL, "credential" TEXT NOT NULL,
  "credentialNumber" TEXT, "issuedAt" TIMESTAMP(3), "expiresAt" TIMESTAMP(3), "verificationUrl" TEXT,
  "status" TEXT NOT NULL DEFAULT 'VERIFIED', "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WpaCertification_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "WpaCertification_advisorId_status_sortOrder_idx" ON "WpaCertification"("advisorId","status","sortOrder");
ALTER TABLE "WpaCertification" ADD CONSTRAINT "WpaCertification_advisorId_fkey" FOREIGN KEY ("advisorId") REFERENCES "PublicAdvisor"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "WpaFollower" (
  "id" TEXT NOT NULL, "advisorId" TEXT NOT NULL, "userId" TEXT NOT NULL, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "WpaFollower_pkey" PRIMARY KEY ("id"), CONSTRAINT "WpaFollower_advisorId_userId_key" UNIQUE ("advisorId","userId")
);
CREATE INDEX "WpaFollower_advisorId_createdAt_idx" ON "WpaFollower"("advisorId","createdAt");
ALTER TABLE "WpaFollower" ADD CONSTRAINT "WpaFollower_advisorId_fkey" FOREIGN KEY ("advisorId") REFERENCES "PublicAdvisor"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "WpaFollower" ADD CONSTRAINT "WpaFollower_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "WpaInquiry" (
  "id" TEXT NOT NULL, "advisorId" TEXT NOT NULL, "userId" TEXT, "name" TEXT NOT NULL, "phone" TEXT NOT NULL,
  "purpose" TEXT, "message" TEXT, "status" TEXT NOT NULL DEFAULT 'NEW',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WpaInquiry_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "WpaInquiry_advisorId_status_createdAt_idx" ON "WpaInquiry"("advisorId","status","createdAt");
ALTER TABLE "WpaInquiry" ADD CONSTRAINT "WpaInquiry_advisorId_fkey" FOREIGN KEY ("advisorId") REFERENCES "PublicAdvisor"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "WpaInquiry" ADD CONSTRAINT "WpaInquiry_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

CREATE TABLE "WpaApplication" (
  "id" TEXT NOT NULL, "userId" TEXT, "fullName" TEXT NOT NULL, "email" TEXT NOT NULL, "phone" TEXT,
  "referralCode" TEXT, "type" TEXT NOT NULL DEFAULT 'INDIVIDUAL', "legalNumber" TEXT, "legalDocumentUrl" TEXT,
  "status" TEXT NOT NULL DEFAULT 'SUBMITTED', "notes" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WpaApplication_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "WpaApplication_email_status_createdAt_idx" ON "WpaApplication"("email","status","createdAt");
ALTER TABLE "WpaApplication" ADD CONSTRAINT "WpaApplication_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

CREATE TABLE "DailyTradingSignal" (
  "id" TEXT NOT NULL, "signalDate" TIMESTAMP(3) NOT NULL, "marketKey" TEXT NOT NULL, "marketType" TEXT NOT NULL,
  "provider" TEXT NOT NULL, "symbol" TEXT NOT NULL, "venue" TEXT, "chain" TEXT, "direction" TEXT NOT NULL, "action" TEXT NOT NULL,
  "score" INTEGER NOT NULL, "confidence" INTEGER NOT NULL, "dataTrustScore" INTEGER NOT NULL, "qualityScore" INTEGER, "regime" TEXT,
  "referencePrice" DOUBLE PRECISION, "entry" DOUBLE PRECISION, "stopLoss" DOUBLE PRECISION, "takeProfit1" DOUBLE PRECISION, "takeProfit2" DOUBLE PRECISION, "riskReward" DOUBLE PRECISION,
  "thesis" JSONB NOT NULL, "riskFlags" JSONB NOT NULL, "invalidation" JSONB NOT NULL, "evidence" JSONB NOT NULL, "sourceSnapshotId" TEXT,
  "strategyVersion" TEXT NOT NULL, "executionAllowed" BOOLEAN NOT NULL DEFAULT false, "generatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "expiresAt" TIMESTAMP(3), "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "DailyTradingSignal_pkey" PRIMARY KEY ("id"), CONSTRAINT "DailyTradingSignal_signalDate_marketKey_key" UNIQUE ("signalDate","marketKey")
);
CREATE INDEX "DailyTradingSignal_signalDate_marketType_score_idx" ON "DailyTradingSignal"("signalDate","marketType","score");
CREATE INDEX "DailyTradingSignal_symbol_signalDate_idx" ON "DailyTradingSignal"("symbol","signalDate");
CREATE INDEX "DailyTradingSignal_marketType_generatedAt_idx" ON "DailyTradingSignal"("marketType","generatedAt");

ALTER TABLE "PublicAdvisor" ADD COLUMN "instagram" TEXT;
ALTER TABLE "PublicAdvisor" ADD COLUMN "experienceYears" INTEGER;
