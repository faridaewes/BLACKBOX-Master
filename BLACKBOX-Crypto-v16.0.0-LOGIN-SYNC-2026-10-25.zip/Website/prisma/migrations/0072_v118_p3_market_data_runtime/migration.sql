-- BLACKBOX P3: provider/runtime reliability evidence. Read-only observability; no execution capability.
CREATE TABLE "MarketDataProviderHealthSnapshot" (
  "id" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "source" TEXT NOT NULL,
  "state" TEXT NOT NULL,
  "ok" BOOLEAN NOT NULL,
  "latencyMs" INTEGER NOT NULL,
  "itemCount" INTEGER NOT NULL DEFAULT 0,
  "freshnessMs" INTEGER NOT NULL DEFAULT 0,
  "error" TEXT,
  "capturedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "MarketDataProviderHealthSnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "MarketDataProviderHealthSnapshot_provider_marketType_capturedAt_idx" ON "MarketDataProviderHealthSnapshot"("provider","marketType","capturedAt");
CREATE INDEX "MarketDataProviderHealthSnapshot_state_capturedAt_idx" ON "MarketDataProviderHealthSnapshot"("state","capturedAt");

CREATE TABLE "MarketDataIntegritySnapshot" (
  "id" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "instrumentKey" TEXT NOT NULL,
  "candleScore" INTEGER NOT NULL DEFAULT 0,
  "orderBookScore" INTEGER NOT NULL DEFAULT 0,
  "reconciliationStatus" TEXT NOT NULL,
  "sourceCount" INTEGER NOT NULL DEFAULT 1,
  "duplicateCount" INTEGER NOT NULL DEFAULT 0,
  "blockers" JSONB NOT NULL,
  "warnings" JSONB NOT NULL,
  "capturedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "MarketDataIntegritySnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "MarketDataIntegritySnapshot_marketKey_capturedAt_idx" ON "MarketDataIntegritySnapshot"("marketKey","capturedAt");
CREATE INDEX "MarketDataIntegritySnapshot_instrumentKey_capturedAt_idx" ON "MarketDataIntegritySnapshot"("instrumentKey","capturedAt");
CREATE INDEX "MarketDataIntegritySnapshot_reconciliationStatus_capturedAt_idx" ON "MarketDataIntegritySnapshot"("reconciliationStatus","capturedAt");
