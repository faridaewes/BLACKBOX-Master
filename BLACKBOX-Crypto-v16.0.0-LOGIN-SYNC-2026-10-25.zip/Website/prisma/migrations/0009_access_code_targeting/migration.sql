ALTER TABLE "AccessCode" ADD COLUMN IF NOT EXISTS "targetUserId" TEXT;
ALTER TABLE "AccessCode" ADD COLUMN IF NOT EXISTS "targetEmail" TEXT;
CREATE INDEX IF NOT EXISTS "AccessCode_targetUserId_idx" ON "AccessCode"("targetUserId");
CREATE INDEX IF NOT EXISTS "AccessCode_targetEmail_idx" ON "AccessCode"("targetEmail");
DO $$ BEGIN
  ALTER TABLE "AccessCode" ADD CONSTRAINT "AccessCode_targetUserId_fkey" FOREIGN KEY ("targetUserId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
