-- Developer-only demo trading and Telegram audit hardening
ALTER TABLE "Bot" ADD COLUMN IF NOT EXISTS "developerDemo" BOOLEAN NOT NULL DEFAULT false;

CREATE INDEX IF NOT EXISTS "Bot_developerDemo_status_idx" ON "Bot"("developerDemo", "status");
CREATE INDEX IF NOT EXISTS "TelegramOutboundEvent_event_kind_status_idx" ON "TelegramOutboundEvent"("eventKey", "kind", "status");
