CREATE TABLE IF NOT EXISTS "RiskIntelligenceSnapshot" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "marketRisk" TEXT NOT NULL,
  "portfolioRisk" TEXT NOT NULL,
  "liquidityRisk" TEXT NOT NULL,
  "executionRisk" TEXT NOT NULL,
  "drawdownRisk" TEXT NOT NULL,
  "riskMode" TEXT NOT NULL,
  "positionSizeMultiplier" DOUBLE PRECISION NOT NULL,
  "maxExposurePct" DOUBLE PRECISION NOT NULL,
  "maxPositions" INTEGER NOT NULL,
  "minSignalQuality" INTEGER NOT NULL,
  "maxDailyLossPct" DOUBLE PRECISION NOT NULL,
  "volatilityTolerancePct" DOUBLE PRECISION NOT NULL,
  "reasons" JSONB NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "RiskIntelligenceSnapshot_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS "RiskIntelligenceSnapshot_userId_createdAt_idx" ON "RiskIntelligenceSnapshot"("userId","createdAt");
CREATE INDEX IF NOT EXISTS "RiskIntelligenceSnapshot_riskMode_createdAt_idx" ON "RiskIntelligenceSnapshot"("riskMode","createdAt");
