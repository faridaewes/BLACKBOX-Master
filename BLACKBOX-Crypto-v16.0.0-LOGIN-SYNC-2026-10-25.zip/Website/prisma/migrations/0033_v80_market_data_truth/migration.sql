CREATE TABLE IF NOT EXISTS "MarketDataHeartbeat" (
  "id" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "marketType" TEXT NOT NULL DEFAULT 'SPOT',
  "source" TEXT NOT NULL,
  "observedAt" TIMESTAMP(3) NOT NULL,
  "fetchedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "latencyMs" INTEGER,
  "itemCount" INTEGER NOT NULL DEFAULT 0,
  "ok" BOOLEAN NOT NULL DEFAULT true,
  "error" TEXT,
  CONSTRAINT "MarketDataHeartbeat_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "MarketDataHeartbeat_provider_marketType_source_key" ON "MarketDataHeartbeat"("provider","marketType","source");
CREATE INDEX IF NOT EXISTS "MarketDataHeartbeat_observedAt_idx" ON "MarketDataHeartbeat"("observedAt");
CREATE INDEX IF NOT EXISTS "MarketDataHeartbeat_ok_observedAt_idx" ON "MarketDataHeartbeat"("ok","observedAt");
