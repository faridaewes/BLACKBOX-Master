ALTER TABLE "AccessTeam" ADD COLUMN IF NOT EXISTS "leadUserId" TEXT;
ALTER TABLE "AccessTeam" ADD CONSTRAINT "AccessTeam_leadUserId_fkey" FOREIGN KEY ("leadUserId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

CREATE TABLE IF NOT EXISTS "AccessApproval" (
  "id" TEXT NOT NULL, "action" TEXT NOT NULL, "targetType" TEXT, "targetId" TEXT,
  "requestedById" TEXT NOT NULL, "approvedById" TEXT, "status" TEXT NOT NULL DEFAULT 'PENDING',
  "reason" TEXT NOT NULL, "expiresAt" TIMESTAMP(3) NOT NULL, "approvedAt" TIMESTAMP(3), "usedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AccessApproval_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "AccessApproval_requestedById_status_expiresAt_idx" ON "AccessApproval"("requestedById","status","expiresAt");
CREATE INDEX IF NOT EXISTS "AccessApproval_action_targetType_targetId_status_idx" ON "AccessApproval"("action","targetType","targetId","status");
ALTER TABLE "AccessApproval" ADD CONSTRAINT "AccessApproval_requestedById_fkey" FOREIGN KEY ("requestedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "AccessApproval" ADD CONSTRAINT "AccessApproval_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

INSERT INTO "AccessTeam" ("id","code","name","description","createdById","updatedAt")
SELECT 'team-public-content','PUBLIC_CONTENT','Public / PWA Content','Kelola konten publik, WPA, media, draft/review/publish',id,CURRENT_TIMESTAMP FROM "User" WHERE "role"='DEVELOPER' ORDER BY "createdAt" ASC LIMIT 1
ON CONFLICT ("code") DO NOTHING;
INSERT INTO "AccessTeam" ("id","code","name","description","createdById","updatedAt")
SELECT 'team-product-services','PRODUCT_SERVICES','Product & Services','Kelola product layanan dan katalog tier',id,CURRENT_TIMESTAMP FROM "User" WHERE "role"='DEVELOPER' ORDER BY "createdAt" ASC LIMIT 1
ON CONFLICT ("code") DO NOTHING;
