-- BLACKBOX v11.11.0 — Priority 1-3 Trading Intelligence aggregate evidence snapshot.
CREATE TABLE "TradingIntelligencePriority123Snapshot" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "scope" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "priority" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "executionAllowed" BOOLEAN NOT NULL DEFAULT false,
  "failClosed" BOOLEAN NOT NULL DEFAULT true,
  "payload" JSONB NOT NULL,
  "evidence" JSONB NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX "TradingIntelligencePriority123Snapshot_scope_createdAt_idx" ON "TradingIntelligencePriority123Snapshot"("scope","createdAt");
CREATE INDEX "TradingIntelligencePriority123Snapshot_priority_status_createdAt_idx" ON "TradingIntelligencePriority123Snapshot"("priority","status","createdAt");
CREATE INDEX "TradingIntelligencePriority123Snapshot_executionAllowed_createdAt_idx" ON "TradingIntelligencePriority123Snapshot"("executionAllowed","createdAt");
