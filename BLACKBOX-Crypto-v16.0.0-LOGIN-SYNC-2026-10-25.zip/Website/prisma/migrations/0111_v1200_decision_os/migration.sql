-- BLACKBOX v12.0.0 — Decision OS persistence contract.
CREATE TABLE IF NOT EXISTS "DecisionOsRun" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "marketKey" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "action" TEXT NOT NULL,
  "score" INTEGER NOT NULL,
  "confidence" INTEGER NOT NULL,
  "executionAllowed" BOOLEAN NOT NULL DEFAULT false,
  "noOrderSigning" BOOLEAN NOT NULL DEFAULT true,
  "noOrderSubmission" BOOLEAN NOT NULL DEFAULT true,
  "noRouterAuthorization" BOOLEAN NOT NULL DEFAULT true,
  "evidenceHash" TEXT NOT NULL,
  "contract" JSONB NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "DecisionOsRun_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "DecisionOsNode" (
  "id" TEXT NOT NULL, "runId" TEXT NOT NULL, "nodeType" TEXT NOT NULL, "status" TEXT NOT NULL,
  "score" INTEGER, "blockers" JSONB NOT NULL, "warnings" JSONB NOT NULL, "evidence" JSONB NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, CONSTRAINT "DecisionOsNode_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "DecisionOsGuardEvent" (
  "id" TEXT NOT NULL, "runId" TEXT NOT NULL, "guard" TEXT NOT NULL, "state" TEXT NOT NULL, "reason" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, CONSTRAINT "DecisionOsGuardEvent_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "DecisionOsRun_userId_createdAt_idx" ON "DecisionOsRun"("userId","createdAt");
CREATE INDEX IF NOT EXISTS "DecisionOsRun_marketKey_createdAt_idx" ON "DecisionOsRun"("marketKey","createdAt");
CREATE INDEX IF NOT EXISTS "DecisionOsRun_status_createdAt_idx" ON "DecisionOsRun"("status","createdAt");
CREATE INDEX IF NOT EXISTS "DecisionOsNode_runId_createdAt_idx" ON "DecisionOsNode"("runId","createdAt");
CREATE INDEX IF NOT EXISTS "DecisionOsNode_nodeType_status_createdAt_idx" ON "DecisionOsNode"("nodeType","status","createdAt");
CREATE INDEX IF NOT EXISTS "DecisionOsGuardEvent_runId_createdAt_idx" ON "DecisionOsGuardEvent"("runId","createdAt");
CREATE INDEX IF NOT EXISTS "DecisionOsGuardEvent_guard_state_createdAt_idx" ON "DecisionOsGuardEvent"("guard","state","createdAt");
DO $$ BEGIN ALTER TABLE "DecisionOsNode" ADD CONSTRAINT "DecisionOsNode_runId_fkey" FOREIGN KEY ("runId") REFERENCES "DecisionOsRun"("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE "DecisionOsGuardEvent" ADD CONSTRAINT "DecisionOsGuardEvent_runId_fkey" FOREIGN KEY ("runId") REFERENCES "DecisionOsRun"("id") ON DELETE CASCADE ON UPDATE CASCADE; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
