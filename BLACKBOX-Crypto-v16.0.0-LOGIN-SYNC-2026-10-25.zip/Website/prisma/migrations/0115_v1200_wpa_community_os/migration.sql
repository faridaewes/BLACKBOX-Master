-- BLACKBOX v12.0.0
-- WPA Community OS foundation: independent community identity, public sections, socials, members, announcements, events and audit trail.
CREATE TABLE "WpaCommunity" (
  "id" TEXT NOT NULL, "advisorId" TEXT NOT NULL, "slug" TEXT NOT NULL, "name" TEXT NOT NULL,
  "tagline" TEXT, "description" TEXT, "logoUrl" TEXT, "bannerUrl" TEXT, "foundedAt" TIMESTAMP(3),
  "language" TEXT, "country" TEXT, "timezone" TEXT NOT NULL DEFAULT 'Asia/Jakarta', "status" TEXT NOT NULL DEFAULT 'ACTIVE',
  "published" BOOLEAN NOT NULL DEFAULT true, "theme" JSONB, "sections" JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WpaCommunity_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "WpaCommunity_advisorId_key" ON "WpaCommunity"("advisorId");
CREATE UNIQUE INDEX "WpaCommunity_slug_key" ON "WpaCommunity"("slug");
CREATE INDEX "WpaCommunity_published_status_updatedAt_idx" ON "WpaCommunity"("published","status","updatedAt");
ALTER TABLE "WpaCommunity" ADD CONSTRAINT "WpaCommunity_advisorId_fkey" FOREIGN KEY ("advisorId") REFERENCES "PublicAdvisor"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "WpaCommunitySocial" (
  "id" TEXT NOT NULL, "communityId" TEXT NOT NULL, "platform" TEXT NOT NULL, "label" TEXT, "url" TEXT NOT NULL,
  "visible" BOOLEAN NOT NULL DEFAULT true, "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WpaCommunitySocial_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "WpaCommunitySocial_communityId_platform_key" ON "WpaCommunitySocial"("communityId","platform");
CREATE INDEX "WpaCommunitySocial_communityId_visible_sortOrder_idx" ON "WpaCommunitySocial"("communityId","visible","sortOrder");
ALTER TABLE "WpaCommunitySocial" ADD CONSTRAINT "WpaCommunitySocial_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES "WpaCommunity"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "WpaCommunityMember" (
  "id" TEXT NOT NULL, "communityId" TEXT NOT NULL, "userId" TEXT NOT NULL, "status" TEXT NOT NULL DEFAULT 'ACTIVE',
  "joinedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WpaCommunityMember_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "WpaCommunityMember_communityId_userId_key" ON "WpaCommunityMember"("communityId","userId");
CREATE INDEX "WpaCommunityMember_communityId_status_joinedAt_idx" ON "WpaCommunityMember"("communityId","status","joinedAt");
CREATE INDEX "WpaCommunityMember_userId_status_idx" ON "WpaCommunityMember"("userId","status");
ALTER TABLE "WpaCommunityMember" ADD CONSTRAINT "WpaCommunityMember_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES "WpaCommunity"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "WpaCommunityMember" ADD CONSTRAINT "WpaCommunityMember_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "WpaCommunityAnnouncement" (
  "id" TEXT NOT NULL, "communityId" TEXT NOT NULL, "title" TEXT NOT NULL, "body" TEXT NOT NULL, "imageUrl" TEXT,
  "active" BOOLEAN NOT NULL DEFAULT true, "pinned" BOOLEAN NOT NULL DEFAULT false, "publishedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WpaCommunityAnnouncement_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "WpaCommunityAnnouncement_communityId_active_pinned_publishedAt_idx" ON "WpaCommunityAnnouncement"("communityId","active","pinned","publishedAt");
ALTER TABLE "WpaCommunityAnnouncement" ADD CONSTRAINT "WpaCommunityAnnouncement_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES "WpaCommunity"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "WpaCommunityEvent" (
  "id" TEXT NOT NULL, "communityId" TEXT NOT NULL, "title" TEXT NOT NULL, "description" TEXT, "bannerUrl" TEXT,
  "startsAt" TIMESTAMP(3) NOT NULL, "endsAt" TIMESTAMP(3), "timezone" TEXT NOT NULL DEFAULT 'Asia/Jakarta', "mode" TEXT NOT NULL DEFAULT 'ONLINE',
  "location" TEXT, "externalUrl" TEXT, "capacity" INTEGER, "active" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WpaCommunityEvent_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "WpaCommunityEvent_communityId_active_startsAt_idx" ON "WpaCommunityEvent"("communityId","active","startsAt");
ALTER TABLE "WpaCommunityEvent" ADD CONSTRAINT "WpaCommunityEvent_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES "WpaCommunity"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "WpaCommunityAudit" (
  "id" TEXT NOT NULL, "communityId" TEXT NOT NULL, "actorId" TEXT NOT NULL, "action" TEXT NOT NULL, "targetType" TEXT NOT NULL,
  "targetId" TEXT, "metadata" JSONB, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "WpaCommunityAudit_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "WpaCommunityAudit_communityId_createdAt_idx" ON "WpaCommunityAudit"("communityId","createdAt");
CREATE INDEX "WpaCommunityAudit_actorId_createdAt_idx" ON "WpaCommunityAudit"("actorId","createdAt");
ALTER TABLE "WpaCommunityAudit" ADD CONSTRAINT "WpaCommunityAudit_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES "WpaCommunity"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "WpaCommunityAudit" ADD CONSTRAINT "WpaCommunityAudit_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
