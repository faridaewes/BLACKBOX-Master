-- Granular broadcast capabilities are string-based permissions, so no schema columns are required.
-- Seed safe defaults onto the canonical workforce teams when those teams already exist.
DO $$
DECLARE
  t_id text;
  p text;
BEGIN
  SELECT id INTO t_id FROM "AccessTeam" WHERE code='ACCOUNT_USER' LIMIT 1;
  IF t_id IS NOT NULL THEN
    FOREACH p IN ARRAY ARRAY['USER_BROADCAST_SEND','BROADCAST_HISTORY_READ'] LOOP
      INSERT INTO "TeamAccessGrant" (id,"teamId","permissionCode",scope,"grantedById","createdAt")
      SELECT md5(random()::text || clock_timestamp()::text),t_id,p,'GLOBAL',"createdById",NOW() FROM "AccessTeam" WHERE id=t_id
      AND NOT EXISTS (SELECT 1 FROM "TeamAccessGrant" g WHERE g."teamId"=t_id AND g."permissionCode"=p AND g."revokedAt" IS NULL);
    END LOOP;
  END IF;
  SELECT id INTO t_id FROM "AccessTeam" WHERE code='CS_TECHNICAL' LIMIT 1;
  IF t_id IS NOT NULL THEN
    FOREACH p IN ARRAY ARRAY['USER_BROADCAST_SEND','BROADCAST_HISTORY_READ'] LOOP
      INSERT INTO "TeamAccessGrant" (id,"teamId","permissionCode",scope,"grantedById","createdAt")
      SELECT md5(random()::text || clock_timestamp()::text),t_id,p,'GLOBAL',"createdById",NOW() FROM "AccessTeam" WHERE id=t_id
      AND NOT EXISTS (SELECT 1 FROM "TeamAccessGrant" g WHERE g."teamId"=t_id AND g."permissionCode"=p AND g."revokedAt" IS NULL);
    END LOOP;
  END IF;
  SELECT id INTO t_id FROM "AccessTeam" WHERE code='PRODUCT_SERVICES_TIER' LIMIT 1;
  IF t_id IS NOT NULL THEN
    FOREACH p IN ARRAY ARRAY['USER_BROADCAST_SEND','BROADCAST_HISTORY_READ'] LOOP
      INSERT INTO "TeamAccessGrant" (id,"teamId","permissionCode",scope,"grantedById","createdAt")
      SELECT md5(random()::text || clock_timestamp()::text),t_id,p,'GLOBAL',"createdById",NOW() FROM "AccessTeam" WHERE id=t_id
      AND NOT EXISTS (SELECT 1 FROM "TeamAccessGrant" g WHERE g."teamId"=t_id AND g."permissionCode"=p AND g."revokedAt" IS NULL);
    END LOOP;
  END IF;
  SELECT id INTO t_id FROM "AccessTeam" WHERE code='PUBLIC_WPA' LIMIT 1;
  IF t_id IS NOT NULL THEN
    FOREACH p IN ARRAY ARRAY['OFFICIAL_BROADCAST_SEND','OFFICIAL_BROADCAST_ATTACH','BROADCAST_HISTORY_READ'] LOOP
      INSERT INTO "TeamAccessGrant" (id,"teamId","permissionCode",scope,"grantedById","createdAt")
      SELECT md5(random()::text || clock_timestamp()::text),t_id,p,'GLOBAL',"createdById",NOW() FROM "AccessTeam" WHERE id=t_id
      AND NOT EXISTS (SELECT 1 FROM "TeamAccessGrant" g WHERE g."teamId"=t_id AND g."permissionCode"=p AND g."revokedAt" IS NULL);
    END LOOP;
  END IF;
  SELECT id INTO t_id FROM "AccessTeam" WHERE code='AUDIT_COMPLIANCE' LIMIT 1;
  IF t_id IS NOT NULL THEN
    FOREACH p IN ARRAY ARRAY['BROADCAST_HISTORY_READ','BROADCAST_HISTORY_EXPORT'] LOOP
      INSERT INTO "TeamAccessGrant" (id,"teamId","permissionCode",scope,"grantedById","createdAt")
      SELECT md5(random()::text || clock_timestamp()::text),t_id,p,'GLOBAL',"createdById",NOW() FROM "AccessTeam" WHERE id=t_id
      AND NOT EXISTS (SELECT 1 FROM "TeamAccessGrant" g WHERE g."teamId"=t_id AND g."permissionCode"=p AND g."revokedAt" IS NULL);
    END LOOP;
  END IF;
END $$;

-- v12 compatibility: legacy team aliases remain recognized during org-team migration.
-- PUBLIC_WPA -> OFFICIAL_BROADCAST_SEND/OFFICIAL_BROADCAST_ATTACH
-- CS_TECHNICAL -> USER_BROADCAST_SEND
-- PRODUCT_SERVICES_TIER -> TIER_NOTIFICATION_TEMPLATE_MANAGE
