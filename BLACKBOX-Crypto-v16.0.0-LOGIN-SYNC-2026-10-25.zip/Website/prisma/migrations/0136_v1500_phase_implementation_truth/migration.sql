-- BLACKBOX v15.0.0
-- Phase implementation truth ledger. Applied migrations are immutable; future schema changes require a new migration.
CREATE TABLE "PhaseImplementationTruthV1500" (
  "id" TEXT NOT NULL,
  "phase" INTEGER NOT NULL,
  "phaseKey" TEXT NOT NULL,
  "dimension" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "evidence" JSONB NOT NULL,
  "observedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "PhaseImplementationTruthV1500_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "PhaseImplementationTruthV1500_phase_dimension_key" ON "PhaseImplementationTruthV1500"("phase", "dimension");
CREATE INDEX "PhaseImplementationTruthV1500_phase_status_idx" ON "PhaseImplementationTruthV1500"("phase", "status");
CREATE INDEX "PhaseImplementationTruthV1500_phaseKey_dimension_idx" ON "PhaseImplementationTruthV1500"("phaseKey", "dimension");
CREATE INDEX "PhaseImplementationTruthV1500_status_observedAt_idx" ON "PhaseImplementationTruthV1500"("status", "observedAt");
