# Historical migration 0136

This migration is part of the immutable Prisma migration chain and MUST NOT be deleted or renamed. It is historical (v15-era) and is superseded by canonical release migration `0137_v1600_mobile_push`. It is not the active release contract.
