-- BLACKBOX v12.0.1 — legal consent evidence, regulatory disclosure and global footer hardening.
ALTER TABLE "Consent" ADD COLUMN IF NOT EXISTS "consentTimezone" TEXT;
ALTER TABLE "Consent" ADD COLUMN IF NOT EXISTS "consentLocale" TEXT;
ALTER TABLE "Consent" ADD COLUMN IF NOT EXISTS "consentSource" TEXT;
ALTER TABLE "Consent" ADD COLUMN IF NOT EXISTS "subjectSnapshot" JSONB;
CREATE INDEX IF NOT EXISTS "Consent_documentVersion_acceptedAt_idx" ON "Consent"("documentVersion","acceptedAt");
INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","createdAt")
VALUES ('legal_v1201_886a095a17ed7876666a2562','TERMS','v12.0.1','Syarat Penggunaan BLACKBOX Technology','BLACKBOX Technology adalah platform teknologi yang membantu pengguna mengelola informasi pasar, analisis, pencatatan, simulasi, pengaturan bot, koneksi akun pihak ketiga, dan fitur pendukung aktivitas trading. BLACKBOX bukan bank, kustodian, pengelola dana, penerima titipan dana, atau jaminan keuntungan. BLACKBOX tidak meminta pengguna menyerahkan dana untuk dikelola oleh BLACKBOX.

Untuk layanan atau fitur yang terkait dengan kegiatan Penasihat Berjangka, pengguna wajib mengikuti proses pendaftaran, verifikasi, perjanjian layanan, dan ketentuan yang ditetapkan oleh PT Alma Indonesia Raya melalui kanal resminya. Pendaftaran pada BLACKBOX tidak menggantikan perjanjian atau persyaratan layanan PT Alma Indonesia Raya.

Pengguna bertanggung jawab atas akun, kredensial, koneksi exchange/wallet, parameter bot, modal, batas risiko, serta setiap keputusan transaksi yang dibuat atau dikonfirmasi melalui akunnya. Pengguna memahami bahwa sistem, AI, data pasar, koneksi pihak ketiga, likuiditas, blockchain, exchange, dan jaringan dapat mengalami keterlambatan, kesalahan, gangguan, perubahan kebijakan, partial fill, slippage, atau kegagalan.

Tidak ada ketentuan dalam dokumen ini yang menghapus hak pengguna berdasarkan peraturan perundang-undangan atau membebaskan pihak penyedia dari tanggung jawab yang menurut hukum tidak dapat dikecualikan. Ketentuan yang bertentangan dengan hukum dianggap tidak berlaku sejauh yang diperlukan, tanpa mempengaruhi ketentuan lainnya.','886a095a17ed7876666a2562979105888f5dc7a1e3d505197fb5eb9f869e7570',true,CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;
INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","createdAt")
VALUES ('legal_v1201_8006818371b66720a14a985a','PRIVACY','v12.0.1','Kebijakan Privasi BLACKBOX Technology','BLACKBOX memproses data pribadi untuk pembuatan dan pengamanan akun, verifikasi, penyediaan fitur, pencatatan persetujuan, audit, dukungan, pencegahan penyalahgunaan, kepatuhan, keamanan sistem, dan kewajiban hukum yang berlaku. Data dikumpulkan secara terbatas dan relevan dengan tujuan pemrosesan.

BLACKBOX mencatat bukti persetujuan, termasuk dokumen yang disetujui, versi, hash dokumen, waktu persetujuan, identitas akun, user-agent, dan hash alamat IP. Snapshot identitas pada saat persetujuan dapat disimpan sebagai bukti transaksi persetujuan. Data tersebut dilindungi dengan kontrol akses dan keamanan yang sesuai.

Pengguna memiliki hak sesuai Undang-Undang Pelindungan Data Pribadi, termasuk hak untuk memperoleh akses, memperbaiki data, meminta pembatasan atau pengakhiran pemrosesan dalam kondisi yang diperbolehkan, dan menarik persetujuan apabila dasar pemrosesannya adalah persetujuan. Hak tersebut tetap tunduk pada kewajiban penyimpanan berdasarkan hukum yang berlaku.','8006818371b66720a14a985a5786bd37304c72d2cb52075bbbecf2b59ce75629',true,CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;
INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","createdAt")
VALUES ('legal_v1201_27944c8cf6492b299e7accfe','RISK','v12.0.1','Pemberitahuan Risiko Perdagangan dan Penggunaan BLACKBOX','Perdagangan aset kripto, derivatif, valuta asing, dan/atau instrumen lain yang terhubung dengan layanan pihak ketiga memiliki risiko tinggi. Nilai aset dapat naik atau turun secara cepat dan pengguna dapat kehilangan sebagian atau seluruh modal yang digunakan. Tidak ada jaminan keuntungan, tingkat keberhasilan, win rate, pendapatan, atau hasil tertentu.

Penggunaan bot atau AI tidak menghilangkan risiko. Sistem dapat menghasilkan keputusan yang salah atau terlambat, data dapat tidak akurat, koneksi dapat terputus, order dapat mengalami slippage, partial fill, rejection, latency, biaya, likuiditas rendah, atau kondisi pasar ekstrem. Kerugian nyata menjadi risiko pengguna sesuai keputusan dan profil risikonya.

Pengguna wajib menggunakan dana yang secara finansial mampu ditanggung risikonya, memahami parameter bot, batas kerugian, leverage jika berlaku, biaya, dan kondisi pasar sebelum mengaktifkan fitur trading. BLACKBOX tidak menjamin bahwa proteksi sistem dapat mencegah seluruh kerugian.','27944c8cf6492b299e7accfe9a065361000f0d4fc1ffa7088f089c3f03ffca09',true,CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;
INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","createdAt")
VALUES ('legal_v1201_2bcfd3c015ac50ea5e7b3b83','BOT_START','v12.0.1','Persetujuan Pengaturan dan Menjalankan Bot','Sebelum menjalankan bot, pengguna menyatakan telah membaca dan memahami Syarat Penggunaan, Kebijakan Privasi, Pemberitahuan Risiko, serta ketentuan khusus bot. Pengguna telah memeriksa mode bot, market, koneksi, modal, ukuran posisi, batas risiko, stop loss/take profit, daily loss, drawdown, dan parameter lain yang tersedia.

Pengguna memahami bahwa tombol START merupakan instruksi untuk menjalankan workflow yang telah dikonfigurasi pengguna. Untuk mode DEMO/PAPER, seluruh modal dan hasil bersifat virtual. Untuk mode REAL, apabila dan ketika seluruh gate produksi terpenuhi, transaksi dapat berdampak pada dana nyata pada akun pihak ketiga yang terhubung.','2bcfd3c015ac50ea5e7b3b83712e6b5f955d34767e12dbf058cfd954a3a568f6',true,CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;
INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","createdAt")
VALUES ('legal_v1201_28e2a85ae5cec4b13a262016','REAL_EXECUTION','v12.0.1','Persetujuan Eksekusi REAL','Dengan mengaktifkan atau memberikan instruksi eksekusi REAL, pengguna menyatakan telah memahami bahwa transaksi dapat menghasilkan keuntungan maupun kerugian nyata, termasuk kemungkinan kehilangan sebagian atau seluruh dana yang digunakan. Pengguna bertanggung jawab memastikan koneksi, izin trade, simbol, arah transaksi, ukuran posisi, leverage, batas risiko, dan parameter order sudah benar.

Persetujuan ini tidak mengubah status regulasi pihak mana pun dan tidak merupakan pengesampingan hak pengguna yang tidak dapat dikesampingkan menurut hukum. Eksekusi hanya boleh berlangsung apabila seluruh persyaratan keamanan, otorisasi, kepatuhan, dan kesiapan produksi BLACKBOX terpenuhi.','28e2a85ae5cec4b13a26201667c38647dd611fe0b23aa2334b76dfbcf6d290ac',true,CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;
INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","createdAt")
VALUES ('legal_v1201_8c027c1a0cb444c58453de25','REGISTRATION','v12.0.1','Persetujuan Registrasi BLACKBOX','Pengguna menyatakan bahwa data yang diberikan saat registrasi adalah benar, akurat, dan milik pengguna atau diberikan dengan kewenangan yang sah. Pengguna memahami bahwa akun BLACKBOX digunakan untuk mengakses platform teknologi dan fitur pendukung trading.

Pengguna menyatakan telah membaca dan menyetujui Syarat Penggunaan, Kebijakan Privasi, dan Pemberitahuan Risiko yang berlaku. Pengguna memahami bahwa pendaftaran BLACKBOX tidak dengan sendirinya menjadikan BLACKBOX sebagai Penasihat Berjangka, Pedagang Aset Keuangan Digital, kustodian, pengelola dana, atau pihak berizin lainnya.','8c027c1a0cb444c58453de25c9e2d7545a9492ff33b8753139f9720025c6b201',true,CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;
INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","createdAt")
VALUES ('legal_v1201_46b20504de394304c704da3a','ALMA_ADVISOR_REGISTRATION','v12.0.1','Kewajiban Pendaftaran pada PT Alma Indonesia Raya untuk Layanan Penasihat Berjangka','Untuk menggunakan layanan atau fitur BLACKBOX yang secara eksplisit terhubung dengan layanan Penasihat Berjangka, pengguna wajib menyelesaikan pendaftaran/registrasi dan proses penerimaan layanan pada PT Alma Indonesia Raya melalui kanal resmi yang ditentukan oleh PT Alma Indonesia Raya. Proses tersebut dapat mencakup verifikasi identitas, dokumen, persetujuan perjanjian layanan, dan persyaratan kepatuhan yang berlaku.

BLACKBOX hanya menjadi platform teknologi pendukung dan tidak menggantikan dokumen, perjanjian, kewajiban, atau hubungan hukum antara pengguna dan PT Alma Indonesia Raya. Pengguna harus membaca dokumen resmi PT Alma Indonesia Raya sebelum menggunakan layanan Penasihat Berjangka.','46b20504de394304c704da3aab897251b7f955adc7e58060f2761a032a19f3ff',true,CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;
