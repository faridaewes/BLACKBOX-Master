DROP INDEX IF EXISTS "PositionFill_externalTradeId_key";
CREATE UNIQUE INDEX IF NOT EXISTS "PositionFill_executionId_externalTradeId_key" ON "PositionFill"("executionId","externalTradeId") WHERE "executionId" IS NOT NULL AND "externalTradeId" IS NOT NULL;
