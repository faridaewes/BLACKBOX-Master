-- BLACKBOX v12.0.2 — legal consent registry, immutable document snapshot and evidence hash hardening.
ALTER TABLE "Consent" ADD COLUMN IF NOT EXISTS "documentBodySnapshot" TEXT;
ALTER TABLE "Consent" ADD COLUMN IF NOT EXISTS "evidenceHash" TEXT;
CREATE INDEX IF NOT EXISTS "Consent_userId_documentVersion_acceptedAt_idx" ON "Consent"("userId","documentVersion","acceptedAt");
INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","createdAt")
VALUES ('legal_v1202_55c80329facf5665327a9f8e','TERMS','v12.0.2','Syarat Penggunaan BLACKBOX Technology','BLACKBOX Technology / BLACKBOX Crypto adalah platform teknologi pendukung yang membantu pengguna memperoleh informasi pasar, analisis, edukasi, simulasi, pengaturan dan pemantauan bot, koneksi akun pihak ketiga, pencatatan, serta kebutuhan operasional trader. BLACKBOX tidak menghimpun, menerima, menyimpan, menguasai, atau mengelola dana atau aset nasabah/klien untuk kepentingan transaksi, dan tidak menjamin keuntungan, tingkat keberhasilan, win rate, pendapatan, atau hasil tertentu. Akun, dana, kredensial, parameter trading, dan keputusan transaksi tetap berada dalam kendali pengguna.

Penggunaan fitur trading dapat menimbulkan risiko nyata, termasuk kehilangan sebagian atau seluruh dana yang digunakan, slippage, partial fill, rejection, latency, gangguan jaringan, kesalahan data, likuiditas rendah, perubahan kondisi pasar, kegagalan pihak ketiga, serta risiko teknologi. Pengguna wajib memahami risiko dan menggunakan dana yang sanggup ditanggung apabila terjadi kerugian.

Untuk layanan atau fitur BLACKBOX yang secara eksplisit terhubung dengan layanan Penasihat Berjangka PT Alma Indonesia Raya, pengguna wajib menyelesaikan proses pendaftaran, verifikasi, dan perjanjian layanan pada PT Alma Indonesia Raya melalui kanal resmi yang ditentukan. Pendaftaran BLACKBOX tidak menggantikan hubungan hukum, dokumen, atau kewajiban layanan PT Alma Indonesia Raya.

Disclaimer ini tidak dimaksudkan untuk menghapus, membatasi, atau mengesampingkan hak pengguna maupun tanggung jawab pihak mana pun yang menurut hukum tidak dapat dikesampingkan. Pengguna tetap dapat menggunakan haknya sesuai peraturan perundang-undangan yang berlaku.

Pengguna bertanggung jawab menjaga keamanan akun, kredensial, koneksi exchange/wallet, konfigurasi bot, modal, batas risiko, serta setiap instruksi atau keputusan transaksi yang dilakukan melalui akunnya. BLACKBOX berfungsi sebagai sarana teknologi pendukung dan tidak menggantikan perjanjian layanan dengan pihak ketiga maupun dokumen resmi regulator.','96c375f3a1b89fd3876ddb3cda2d2d3f3c0f7c7730505433891692abfd8bfaab',true,CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;
INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","createdAt")
VALUES ('legal_v1202_39d98d5b9cd58b92d8900eab','PRIVACY','v12.0.2','Kebijakan Privasi BLACKBOX Technology','BLACKBOX memproses data pribadi untuk pembuatan dan pengamanan akun, verifikasi, penyediaan fitur, pencatatan persetujuan, audit, dukungan, pencegahan penyalahgunaan, kepatuhan, keamanan sistem, dan kewajiban hukum yang berlaku. Data diproses secara terbatas, relevan, dan sesuai tujuan yang diberitahukan.

Bukti persetujuan dapat mencakup dokumen yang disetujui, versi, hash dokumen, isi dokumen pada saat persetujuan, waktu persetujuan, identitas akun, konteks perangkat/browser, user-agent, hash alamat IP, zona waktu, sumber persetujuan, dan snapshot identitas yang relevan. Bukti tersebut disimpan dengan kontrol akses dan keamanan yang sesuai.

Pengguna memiliki hak sesuai peraturan pelindungan data pribadi yang berlaku, termasuk hak akses, perbaikan, dan hak lain sesuai dasar pemrosesan serta kewajiban penyimpanan yang diwajibkan hukum.','827a39f35b8be2d598e89081e4568fc023388fcfb9d91c1f7e9d20d276acc29b',true,CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;
INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","createdAt")
VALUES ('legal_v1202_0021ec158a497012ff8389a0','RISK','v12.0.2','Pemberitahuan Risiko Perdagangan dan Penggunaan BLACKBOX','Perdagangan aset kripto, derivatif, valuta asing, dan/atau instrumen lain melalui pihak ketiga memiliki risiko tinggi. Harga dapat bergerak cepat dan pengguna dapat kehilangan sebagian atau seluruh modal. Tidak ada jaminan keuntungan, win rate, pendapatan, atau hasil tertentu.

Bot, AI, automation, router, dan teknologi pendukung tidak menghilangkan risiko. Kesalahan konfigurasi, data tidak akurat, keterlambatan, slippage, partial fill, rejection, biaya, likuiditas, gangguan koneksi, blockchain, exchange, dan kondisi pasar ekstrem dapat menyebabkan kerugian nyata.

Pengguna wajib memeriksa modal, market, pair, leverage jika berlaku, ukuran posisi, stop loss/take profit, daily loss, drawdown, biaya, koneksi, dan parameter lainnya sebelum memberikan instruksi. Kerugian akibat keputusan dan transaksi pengguna menjadi risiko pengguna, tanpa mengurangi tanggung jawab pihak mana pun yang menurut hukum tetap berlaku.','091fd54ea3b540577cae824829bc5e064742b4a4992b8eb9936a27e05603a393',true,CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;
INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","createdAt")
VALUES ('legal_v1202_f7ec7403a6df330816c7bb08','BOT_START','v12.0.2','Persetujuan Pengaturan dan Menjalankan Bot','Sebelum menjalankan bot, pengguna menyatakan telah membaca dan memahami Syarat Penggunaan, Kebijakan Privasi, Pemberitahuan Risiko, dan ketentuan bot. Pengguna telah memeriksa mode, market, pair, koneksi, modal, ukuran posisi, stop loss/take profit, daily loss, drawdown, dan parameter lain yang tersedia.

Pengguna memahami bahwa START merupakan instruksi untuk menjalankan workflow yang dikonfigurasi pengguna. DEMO/PAPER menggunakan modal virtual. REAL, apabila dan ketika seluruh gate produksi terpenuhi, dapat berdampak pada dana nyata pada akun pihak ketiga.','17a3d6bba8c2769a8ef2fca12059dc3f0a03f46fb29daf586b74aa5adad650df',true,CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;
INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","createdAt")
VALUES ('legal_v1202_86d433265b137b63896fe8a8','BOT_CONFIGURATION','v12.0.2','Persetujuan Perubahan Konfigurasi Bot','Setiap perubahan material pada konfigurasi bot dapat mengubah perilaku, risiko, eksposur, biaya, atau hasil trading. Sebelum menyimpan perubahan, pengguna menyatakan telah memeriksa kembali modal, market, pair, koneksi, chain, guardrail, risiko per trade, drawdown, stop loss/take profit, daily loss, max positions, dan parameter relevan lainnya.

Pengguna memahami bahwa perubahan konfigurasi merupakan keputusan pengguna dan tidak menjamin keuntungan atau mencegah kerugian. Perubahan hanya diterapkan apabila seluruh server-side safety gate terpenuhi.','33ae0f01eff2bb893b1d8cc10a01e1afe9723a60f21e2d14e59c2d64a38489c7',true,CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;
INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","createdAt")
VALUES ('legal_v1202_915ea0b2aca23e9fc835b8db','REAL_EXECUTION','v12.0.2','Persetujuan Eksekusi REAL','Dengan mengaktifkan atau memberikan instruksi eksekusi REAL, pengguna menyatakan telah memahami bahwa transaksi dapat menghasilkan keuntungan maupun kerugian nyata, termasuk kemungkinan kehilangan sebagian atau seluruh dana yang digunakan. Pengguna wajib memastikan akun pihak ketiga, izin trade, simbol, arah transaksi, ukuran posisi, leverage jika berlaku, dan parameter order sudah benar.

Persetujuan ini bukan pengesampingan hak pengguna yang tidak dapat dikesampingkan menurut hukum. Eksekusi hanya boleh berlangsung apabila seluruh persyaratan keamanan, otorisasi, kepatuhan, sertifikasi, dan kesiapan produksi BLACKBOX terpenuhi.','565fd59e988376172cdccd1dc16ae1c2351f2db3a9bc52e6f9b5956acb9bde09',true,CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;
INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","createdAt")
VALUES ('legal_v1202_6b88b7c6bffe0bbda72dbb75','REGISTRATION','v12.0.2','Persetujuan Registrasi BLACKBOX','Pengguna menyatakan data registrasi yang diberikan adalah benar, akurat, dan diberikan dengan kewenangan yang sah. Pengguna memahami BLACKBOX adalah platform teknologi pendukung dan bukan dengan sendirinya merupakan Penasihat Berjangka, Pedagang Aset Keuangan Digital, kustodian, pengelola dana, atau pihak berizin lain.

Pengguna telah membaca Syarat Penggunaan, Kebijakan Privasi, dan Pemberitahuan Risiko serta memahami bahwa trading dapat menyebabkan kerugian nyata.','32593102e130223a710ec51b61a1ee25dc1b3be4847f169eb226f5b014c92f5c',true,CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;
INSERT INTO "LegalDocument" ("id","type","version","title","body","contentHash","active","createdAt")
VALUES ('legal_v1202_34ec069f11816ac85343316d','ALMA_ADVISOR_REGISTRATION','v12.0.2','Kewajiban Pendaftaran pada PT Alma Indonesia Raya untuk Layanan Penasihat Berjangka','Untuk menggunakan layanan atau fitur BLACKBOX yang secara eksplisit terhubung dengan layanan Penasihat Berjangka PT Alma Indonesia Raya, pengguna wajib menyelesaikan pendaftaran/registrasi, verifikasi, dan penerimaan perjanjian layanan pada PT Alma Indonesia Raya melalui kanal resminya. Proses dapat mencakup verifikasi identitas, dokumen, persetujuan perjanjian, dan persyaratan kepatuhan yang berlaku.

BLACKBOX tidak menggantikan perjanjian atau hubungan hukum antara pengguna dan PT Alma Indonesia Raya. Pengguna wajib membaca dokumen resmi PT Alma Indonesia Raya dan menggunakan kanal resminya sebelum memperoleh layanan Penasihat Berjangka.','a8232a0005d4e51349c21c1bfe2a4db640627647202998032ffe3985f54a661e',true,CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;
UPDATE "LegalDocument" SET "active"=false WHERE "type"='TERMS' AND "version" <> 'v12.0.2' AND "active"=true;
UPDATE "LegalDocument" SET "active"=false WHERE "type"='PRIVACY' AND "version" <> 'v12.0.2' AND "active"=true;
UPDATE "LegalDocument" SET "active"=false WHERE "type"='RISK' AND "version" <> 'v12.0.2' AND "active"=true;
UPDATE "LegalDocument" SET "active"=false WHERE "type"='BOT_START' AND "version" <> 'v12.0.2' AND "active"=true;
UPDATE "LegalDocument" SET "active"=false WHERE "type"='BOT_CONFIGURATION' AND "version" <> 'v12.0.2' AND "active"=true;
UPDATE "LegalDocument" SET "active"=false WHERE "type"='REAL_EXECUTION' AND "version" <> 'v12.0.2' AND "active"=true;
UPDATE "LegalDocument" SET "active"=false WHERE "type"='REGISTRATION' AND "version" <> 'v12.0.2' AND "active"=true;
UPDATE "LegalDocument" SET "active"=false WHERE "type"='ALMA_ADVISOR_REGISTRATION' AND "version" <> 'v12.0.2' AND "active"=true;
