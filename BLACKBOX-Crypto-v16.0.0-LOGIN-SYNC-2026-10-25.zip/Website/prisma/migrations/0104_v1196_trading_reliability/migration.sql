CREATE TABLE "TradingReliabilitySnapshot" (
  "id" TEXT NOT NULL,
  "scope" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "provider" TEXT,
  "connectionKey" TEXT,
  "marketKey" TEXT,
  "version" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "opportunityScore" INTEGER,
  "dataTrustScore" INTEGER,
  "connectionHealthScore" INTEGER,
  "executionQualityScore" INTEGER,
  "noTrade" BOOLEAN NOT NULL DEFAULT false,
  "reasons" JSONB NOT NULL,
  "evidence" JSONB NOT NULL,
  "observedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "TradingReliabilitySnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "TradingReliabilitySnapshot_scope_createdAt_idx" ON "TradingReliabilitySnapshot"("scope","createdAt");
CREATE INDEX "TradingReliabilitySnapshot_marketType_provider_createdAt_idx" ON "TradingReliabilitySnapshot"("marketType","provider","createdAt");
CREATE INDEX "TradingReliabilitySnapshot_connectionKey_createdAt_idx" ON "TradingReliabilitySnapshot"("connectionKey","createdAt");
CREATE INDEX "TradingReliabilitySnapshot_marketKey_createdAt_idx" ON "TradingReliabilitySnapshot"("marketKey","createdAt");
CREATE INDEX "TradingReliabilitySnapshot_status_createdAt_idx" ON "TradingReliabilitySnapshot"("status","createdAt");

CREATE TABLE "ExchangeReliabilitySnapshot" (
  "id" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "connectionKey" TEXT NOT NULL,
  "marketType" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "score" INTEGER NOT NULL,
  "status" TEXT NOT NULL,
  "apiHealthy" BOOLEAN NOT NULL DEFAULT false,
  "marketDataHealthy" BOOLEAN NOT NULL DEFAULT false,
  "orderChannelHealthy" BOOLEAN NOT NULL DEFAULT false,
  "reconciliationHealthy" BOOLEAN NOT NULL DEFAULT false,
  "latencyMs" INTEGER,
  "errorRatePct" DOUBLE PRECISION,
  "rateLimitPct" DOUBLE PRECISION,
  "blockers" JSONB NOT NULL,
  "warnings" JSONB NOT NULL,
  "observedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ExchangeReliabilitySnapshot_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ExchangeReliabilitySnapshot_provider_marketType_createdAt_idx" ON "ExchangeReliabilitySnapshot"("provider","marketType","createdAt");
CREATE INDEX "ExchangeReliabilitySnapshot_connectionKey_createdAt_idx" ON "ExchangeReliabilitySnapshot"("connectionKey","createdAt");
CREATE INDEX "ExchangeReliabilitySnapshot_status_createdAt_idx" ON "ExchangeReliabilitySnapshot"("status","createdAt");
