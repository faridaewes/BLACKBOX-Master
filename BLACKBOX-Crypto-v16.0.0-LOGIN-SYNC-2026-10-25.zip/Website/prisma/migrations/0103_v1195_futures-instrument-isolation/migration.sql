ALTER TABLE "ConnectionMarketUniverse" ADD COLUMN "instrumentType" TEXT NOT NULL DEFAULT 'SPOT';
DROP INDEX IF EXISTS "ConnectionMarketUniverse_connectionKey_marketType_canonicalSymbol_key";
CREATE UNIQUE INDEX "ConnectionMarketUniverse_connectionKey_marketType_canonicalSymbol_instrumentType_key" ON "ConnectionMarketUniverse"("connectionKey","marketType","canonicalSymbol","instrumentType");
CREATE INDEX "ConnectionMarketUniverse_connection_market_instrument_idx" ON "ConnectionMarketUniverse"("exchangeAccountId","marketType","instrumentType","canonicalSymbol");
ALTER TABLE "Signal" ADD COLUMN "instrumentType" TEXT;
ALTER TABLE "Position" ADD COLUMN "instrumentType" TEXT;
ALTER TABLE "Order" ADD COLUMN "instrumentType" TEXT;
ALTER TABLE "Execution" ADD COLUMN "instrumentType" TEXT;
