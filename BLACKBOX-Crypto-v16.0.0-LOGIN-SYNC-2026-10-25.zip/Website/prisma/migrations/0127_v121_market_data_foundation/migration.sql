-- BLACKBOX v12.1.0
CREATE TABLE IF NOT EXISTS "MarketDataV121Snapshot" ("id" TEXT NOT NULL,"marketKey" TEXT NOT NULL,"marketType" TEXT NOT NULL,"provider" TEXT NOT NULL,"qualityScore" INTEGER NOT NULL,"state" TEXT NOT NULL,"blockers" JSONB NOT NULL,"warnings" JSONB NOT NULL,"evidence" JSONB NOT NULL,"observedAt" TIMESTAMP(3),"capturedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,CONSTRAINT "MarketDataV121Snapshot_pkey" PRIMARY KEY ("id"));
CREATE INDEX IF NOT EXISTS "MarketDataV121Snapshot_marketKey_capturedAt_idx" ON "MarketDataV121Snapshot"("marketKey","capturedAt");
CREATE INDEX IF NOT EXISTS "MarketDataV121Snapshot_marketType_state_capturedAt_idx" ON "MarketDataV121Snapshot"("marketType","state","capturedAt");
