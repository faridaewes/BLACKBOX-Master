-- v9.2 Referral depth/reward rules
-- L1..L10 registration rewards; only L1 receives the separate +50 qualified bonus.

-- Neutralize the legacy v9.1 +10 activation-only referral reward so it cannot survive the rule change.
INSERT INTO "ReferralPointLedger" ("id","userId","amount","kind","status","referenceType","referenceId","counterpartyUserId","description")
SELECT 'v92_reverse_' || l."id", l."userId", -l."amount", 'REWARD_REVERSAL', 'AVAILABLE', 'LEGACY_REFERRAL_REWARD', l."id", l."counterpartyUserId", 'Reverse legacy v9.1 activation-only referral reward'
FROM "ReferralPointLedger" l
WHERE l."kind" = 'QUALIFIED_REFERRAL' AND l."amount" = 10
AND NOT EXISTS (SELECT 1 FROM "ReferralPointLedger" x WHERE x."kind"='REWARD_REVERSAL' AND x."referenceId"=l."id");

-- Registration reward for every existing referred user, maximum 10 uplines.
WITH RECURSIVE chain AS (
  SELECT child."id" AS "childId", parent."id" AS "ancestorId", 1 AS depth, ARRAY[child."id", parent."id"] AS path
  FROM "User" child JOIN "User" parent ON parent."id" = child."referredById"
  WHERE child."referredById" IS NOT NULL
  UNION ALL
  SELECT c."childId", parent."id", c.depth + 1, c.path || parent."id"
  FROM chain c JOIN "User" current ON current."id" = c."ancestorId"
  JOIN "User" parent ON parent."id" = current."referredById"
  WHERE c.depth < 10 AND NOT parent."id" = ANY(c.path)
), rewards AS (
  SELECT *, CASE depth
    WHEN 1 THEN 50 WHEN 2 THEN 25 WHEN 3 THEN 15 WHEN 4 THEN 10 WHEN 5 THEN 8
    WHEN 6 THEN 6 WHEN 7 THEN 4 WHEN 8 THEN 3 WHEN 9 THEN 2 WHEN 10 THEN 1
  END AS amount
  FROM chain
)
INSERT INTO "ReferralPointLedger" ("id","userId","amount","kind","status","referenceType","referenceId","counterpartyUserId","description")
SELECT 'v92_reg_' || "ancestorId" || '_' || "childId", "ancestorId", amount, 'REFERRAL_REGISTRATION', 'AVAILABLE', 'USER_REGISTRATION', "childId", "childId", 'Referral registration L' || depth || ' (backfill v9.2)'
FROM rewards r
WHERE NOT EXISTS (
  SELECT 1 FROM "ReferralPointLedger" l
  WHERE l."userId"=r."ancestorId" AND l."kind"='REFERRAL_REGISTRATION' AND l."referenceId"=r."childId"
);

-- Direct +50 qualification bonus only when the downline has BOTH activation and KYC approval.
INSERT INTO "ReferralPointLedger" ("id","userId","amount","kind","status","referenceType","referenceId","counterpartyUserId","description")
SELECT 'v92_qualified_' || u."referredById" || '_' || u."id", u."referredById", 50, 'QUALIFIED_DIRECT_REFERRAL', 'AVAILABLE', 'USER_QUALIFICATION', u."id", u."id", 'Direct referral qualification bonus (backfill v9.2)'
FROM "User" u
WHERE u."referredById" IS NOT NULL
AND u."hasEverActivated" = true
AND u."kycStatus" = 'APPROVED'
AND NOT EXISTS (
  SELECT 1 FROM "ReferralPointLedger" l
  WHERE l."userId"=u."referredById" AND l."kind"='QUALIFIED_DIRECT_REFERRAL' AND l."referenceId"=u."id"
);
