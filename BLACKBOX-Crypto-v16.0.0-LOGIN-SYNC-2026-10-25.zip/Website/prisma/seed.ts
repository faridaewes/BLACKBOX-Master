import crypto from "node:crypto";
import "../src/lib/load-env";
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

type SeedRole = "DEVELOPER" | "ADMIN" | "USER";

const DEFAULTS: Record<SeedRole, { email: string; phone: string; name: string; role: SeedRole; envKey: string }> = {
  DEVELOPER: { email: "developer@blackbox.com", phone: "+620000000001", name: "BLACKBOX Developer", role: "DEVELOPER", envKey: "DEVELOPER_SEED_PASSWORD" },
  ADMIN: { email: "admin@blackbox.com", phone: "+620000000002", name: "BLACKBOX Admin", role: "ADMIN", envKey: "ADMIN_SEED_PASSWORD" },
  USER: { email: process.env.USER_SEED_EMAIL || "user1@blackbox.com", phone: process.env.USER_SEED_PHONE || "+620000000003", name: "BLACKBOX User 1", role: "USER", envKey: "USER_SEED_PASSWORD" },
};

async function ensureAccount(account: (typeof DEFAULTS)[SeedRole]) {
  const existing = await db.user.findUnique({ where: { email: account.email } });
  const configured = process.env[account.envKey];
  const validStagingPassword = !!configured && configured.length >= 1 && !/\s/.test(configured);
  if (!validStagingPassword) {
    throw new Error(`${account.envKey} must be provided without whitespace. This relaxed validation is only reachable in the explicitly gated staging/demo bootstrap path; never use these test passwords in production.`);
  }
  if (existing) {
    // Sinkronisasi otomatis: jika password di .env berubah, akun bootstrap ikut diperbarui.
    // Hanya berjalan pada jalur staging/demo yang sudah digerbang (sandboxAllowed).
    if (!(await bcrypt.compare(configured, existing.passwordHash))) {
      await db.user.update({ where: { id: existing.id }, data: { passwordHash: await bcrypt.hash(configured, 12), mustChangePassword: true, status: "ACTIVE" } });
      console.log(`[seed] password ${account.role} disinkronkan dari ${account.envKey}`);
    }
    return existing;
  }

  const passwordHash = await bcrypt.hash(configured, 12);
  const username = account.role === "DEVELOPER" ? "developer" : account.role === "ADMIN" ? "admin" : "user1";
  return db.user.create({
    data: {
      username,
      email: account.email,
      phone: account.phone,
      passwordHash,
      name: account.name,
      role: account.role,
      developerLevel: account.role === "DEVELOPER" ? "PRINCIPAL" : undefined,
      status: "ACTIVE",
      emailVerifiedAt: new Date(),
      phoneVerifiedAt: new Date(),
      // Bootstrap credentials are one-time staging credentials.
      // Every seeded account must rotate its password on first login.
      mustChangePassword: true,
      kycStatus: account.role === "USER" ? "NOT_STARTED" : "APPROVED",
    },
  });
}

async function main() {
  const sandboxAllowed = process.env.STAGING_BOOTSTRAP === "true"
    && ["staging", "demo"].includes(String(process.env.DEPLOYMENT_MODE || "").toLowerCase())
    && process.env.NODE_ENV !== "production"
    && process.env.REAL_TRADING_ENABLED !== "true"
    && process.env.REAL_TRADING_PRODUCTION_READY !== "true";

  let developer: Awaited<ReturnType<typeof ensureAccount>> | null = null;
  let admin: Awaited<ReturnType<typeof ensureAccount>> | null = null;
  let user: Awaited<ReturnType<typeof ensureAccount>> | null = null;
  if (sandboxAllowed) {
    developer = await ensureAccount(DEFAULTS.DEVELOPER);
    admin = await ensureAccount(DEFAULTS.ADMIN);
    user = await ensureAccount(DEFAULTS.USER);
  } else {
    console.log("Sandbox accounts skipped: only staging/demo with STAGING_BOOTSTRAP=true may create test accounts.");
  }

  const plans = [
    ["Silver", { activeBots: 1, concurrentPositions: 5, exchanges: 1, scanSeconds: 60, ai: "basic", marketPairs: 10, marketTypes: ["SPOT"], durationDays: 30, features: { dailySignals: true, signals: true } }],
    ["Gold", { activeBots: 3, concurrentPositions: 15, exchanges: 3, scanSeconds: 15, ai: "advanced", marketPairs: 50, marketTypes: ["SPOT", "FUTURES"], durationDays: 30, features: { dailySignals: true, signals: true } }],
    ["Platinum", { activeBots: 10, concurrentPositions: 50, exchanges: 10, scanSeconds: 5, ai: "full", marketPairs: 100, marketTypes: ["SPOT", "FUTURES", "DEX"], durationDays: 90, features: { dailySignals: true, signals: true } }],
    ["PRO", { activeBots: 50, concurrentPositions: 150, exchanges: 25, scanSeconds: 2, ai: "full", marketPairs: 250, marketTypes: ["SPOT", "FUTURES", "DEX"], durationDays: 365, features: { dailySignals: true, signals: true } }],
    ["Enterprise", { activeBots: 100, concurrentPositions: 250, exchanges: 50, scanSeconds: 1, ai: "custom", marketPairs: 500, marketTypes: ["SPOT", "FUTURES", "DEX"], durationDays: 365, features: { dailySignals: true, signals: true } }],
  ] as const;

  const planRows = new Map<string, any>();
  for (const [name, entitlements] of plans) {
    const priceMinor = ({Silver:100000,Gold:200000,Platinum:500000,PRO:1000000,Enterprise:0} as Record<string,number>)[name] ?? 0;
    const row = await db.accessPlan.upsert({ where: { name }, update: { entitlements, priceMinor, currency: "IDR" }, create: { name, entitlements, priceMinor, currency: "IDR" } });
    planRows.set(name, row);
  }

  await db.platformSetting.upsert({ where: { key: "REFERRAL_REDEMPTION_TIERS" }, update: { value: JSON.stringify([
    { code: "SILVER", label: "SILVER", points: 100, durationDays: 30, active: true, planName: "Silver" },
    { code: "GOLD", label: "GOLD", points: 200, durationDays: 30, active: true, planName: "Gold" },
    { code: "PLATINUM", label: "PLATINUM", points: 500, durationDays: 90, active: true, planName: "Platinum" },
    { code: "PRO", label: "PRO", points: 1000, durationDays: 365, active: true, planName: "PRO" }
  ]), updatedById: developer?.id ?? null }, create: { key: "REFERRAL_REDEMPTION_TIERS", value: JSON.stringify([
    { code: "SILVER", label: "SILVER", points: 100, durationDays: 30, active: true, planName: "Silver" },
    { code: "GOLD", label: "GOLD", points: 200, durationDays: 30, active: true, planName: "Gold" },
    { code: "PLATINUM", label: "PLATINUM", points: 500, durationDays: 90, active: true, planName: "Platinum" },
    { code: "PRO", label: "PRO", points: 1000, durationDays: 365, active: true, planName: "PRO" }
  ]), updatedById: developer?.id ?? null } });

  const silver = planRows.get("Silver");
  if (!silver) throw new Error("Silver plan seed failed");
  const now = new Date();
  if (developer && user) {
    const existingSubscription = await db.subscription.findFirst({
    where: { userId: user.id, status: "ACTIVE", expiresAt: { gt: now } },
    orderBy: { expiresAt: "desc" },
  });
    if (!existingSubscription) {
      await db.subscription.create({
        data: {
          userId: user.id,
          planId: silver.id,
          status: "ACTIVE",
          startsAt: now,
          expiresAt: new Date(now.getTime() + 30 * 86400000),
          grantedById: developer.id,
          complimentary: true,
        },
      });
    }
  }

  const { LEGAL_DOCUMENTS, LEGAL_DOCUMENT_VERSION } = await import("../src/lib/legal-content");
  for (const doc of Object.values(LEGAL_DOCUMENTS)) {
    const found = await db.legalDocument.findFirst({ where: { type: doc.type, version: LEGAL_DOCUMENT_VERSION } });
    if (!found) await db.legalDocument.create({ data: { type: doc.type, version: LEGAL_DOCUMENT_VERSION, title: doc.title, body: doc.body, workflowState: "PUBLISHED", publishedAt: new Date(), contentHash: crypto.createHash("sha256").update(`${doc.type}\n${LEGAL_DOCUMENT_VERSION}\n${doc.title}\n${doc.body}`, "utf8").digest("hex") } });
  }

  if (developer) {
    for (const [key, value] of [["GLOBAL_TRADING_HALT", false], ["GLOBAL_API_REVOKED", false], ["MAINTENANCE_MODE", false]] as const) {
      await db.systemControl.upsert({ where: { key }, update: {}, create: { key, value, updatedBy: developer.id } });
    }
  }

  console.log("Seed complete:");
  if (developer && admin && user) {
    console.log(`  Developer: ${developer.email}`);
    console.log(`  Admin:     ${admin.email}`);
    console.log(`  User:      ${user.email}`);
    console.log("  User receives complimentary Silver access for 30 days in staging.");
  } else {
    console.log("  Sandbox accounts: SKIPPED (production-safe seed mode).");
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
}).finally(async () => {
  await db.$disconnect();
});
