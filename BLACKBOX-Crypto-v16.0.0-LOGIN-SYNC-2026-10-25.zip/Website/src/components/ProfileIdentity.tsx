'use client';
import { useEffect, useState } from 'react';

type Profile = {
  id: string;
  name: string;
  role: 'DEVELOPER' | 'ADMIN' | 'USER';
  roleIndex: number | null;
  roleLabel: string;
  tier: string;
  tierExpiresAt: string | null;
  tierStatus: 'ACTIVE' | 'EXPIRED' | 'NONE';
  username: string;
  referralPro: boolean;
  avatarUrl: string | null;
};

function dateLabel(value: string | null) {
  if (!value) return null;
  return new Date(value).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function formatProfileLine(profile: Profile) {
  const identity = profile.role === 'USER' ? profile.name : `${profile.name} (${profile.roleLabel})`;
  const expiry = dateLabel(profile.tierExpiresAt);
  if (profile.tierStatus === 'EXPIRED' && expiry) return `${identity} — Tier ${profile.tier} (EXPIRED · ${expiry})`;
  if (expiry) return `${identity} — Tier ${profile.tier} (s.d. ${expiry})`;
  return `${identity} — Tier ${profile.tier}`;
}

export default function ProfileIdentity({ compact = false }: { compact?: boolean }) {
  const [profile, setProfile] = useState<Profile | null>(null);
  useEffect(() => {
    let live = true;
    fetch('/api/profile', { cache: 'no-store' }).then((r) => r.json()).then((j) => {
      if (live && j.ok) setProfile(j.profile);
    }).catch(() => {});
    return () => { live = false; };
  }, []);
  if (!profile) return null;
  return (
    <div className={`profileIdentity ${compact ? 'compact' : ''}`} aria-label="Identitas akun dan tier">{profile.avatarUrl && <img src={profile.avatarUrl} alt="" style={{width:32,height:32,borderRadius:'50%',objectFit:'cover'}} />}
      <span className="profileIdentityName">{profile.name}</span><span className="profileIdentityRole">@{profile.username}</span>{profile.referralPro && <span className="profileIdentityRole">PRO</span>}
      {profile.role !== 'USER' && <span className="profileIdentityRole">{profile.roleLabel}</span>}
      <span className="profileIdentityTier">Tier {profile.tier}</span>
      {profile.tierExpiresAt && <span className={`profileIdentityExpiry ${profile.tierStatus === 'EXPIRED' ? 'expired' : ''}`}>{profile.tierStatus === 'EXPIRED' ? 'EXPIRED' : 's.d.'} {dateLabel(profile.tierExpiresAt)}</span>}
    </div>
  );
}
