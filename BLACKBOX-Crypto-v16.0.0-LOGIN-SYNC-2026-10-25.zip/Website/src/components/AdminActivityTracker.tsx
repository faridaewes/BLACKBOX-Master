'use client';
import { useEffect } from 'react';
import { usePathname } from 'next/navigation';
export default function AdminActivityTracker(){
  const pathname=usePathname();
  useEffect(()=>{
    if(!pathname)return;
    const send=()=>fetch('/api/analytics/admin/heartbeat',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({module:pathname,action:'VIEW'}),keepalive:true}).catch(()=>{});
    send(); const t=setInterval(send,30_000); return()=>clearInterval(t);
  },[pathname]);
  return null;
}
