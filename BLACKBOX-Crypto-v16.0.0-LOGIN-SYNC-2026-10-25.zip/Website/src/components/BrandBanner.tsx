'use client';
import { useEffect, useState } from 'react';
export default function BrandBanner(){
  const [logo,setLogo]=useState('/api/public/branding/logo');
  useEffect(()=>{setLogo(`/api/public/branding/logo?v=${Date.now()}`)},[]);
  return <div className="brandBanner"><div className="brandBannerMark"><img src={logo} alt="BLACKBOX Crypto" width={240} height={240} style={{width:240,height:"auto",maxWidth:"100%",objectFit:"contain"}} loading="eager" /></div><div><b>BLACKBOX Crypto</b><div className="small">Intelligent crypto trading command center</div></div></div>;
}
