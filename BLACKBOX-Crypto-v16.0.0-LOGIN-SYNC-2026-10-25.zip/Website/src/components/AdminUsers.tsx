'use client';
import { useCallback, useEffect, useState } from 'react';
import UserEntitlementEditor from './UserEntitlementEditor';

export default function AdminUsers({ role }: { role: string }) {
  const [users, setUsers] = useState<any[]>([]);
  const [plans, setPlans] = useState<any[]>([]);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [sel, setSel] = useState<Record<string, { plan?: string; days?: number }>>({});
  const [q, setQ] = useState('');
  const [tempPassword, setTempPassword] = useState<{email:string;password:string}|null>(null);

  const load = useCallback(async () => {
    const j = await fetch('/api/admin/users', { cache: 'no-store' }).then((r) => r.json()).catch(() => null);
    if (j?.ok) { setUsers(j.users); setPlans(j.plans); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const patch = async (body: Record<string, unknown>) => {
    const j = await fetch('/api/admin/users', { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }).then((r) => r.json()).catch(() => ({ ok: false, error: 'Koneksi gagal' }));
    if (j.temporaryPassword) setTempPassword({ email: String(body.targetEmail || body.userId), password: j.temporaryPassword });
    setMsg(j.ok ? { ok: true, text: j.temporaryPassword ? 'Temporary password dibuat. Tampilkan hanya sekali.' : 'Perubahan tersimpan.' } : { ok: false, text: j.error || 'Gagal' });
    load();
  };
  const list = users.filter((u) => !q || (u.email + u.name).toLowerCase().includes(q.toLowerCase()));

  return (
    <section className="panel section">
      <div className="panelHead"><span className="panelTitle">PENGGUNA & PAKET</span><input className="input" placeholder="Cari email / nama" value={q} onChange={(e) => setQ(e.target.value)} style={{ maxWidth: 220 }} /></div>
      <div className="panelBody tableWrap">
        {msg && <div className={'banner ' + (msg.ok ? '' : 'red')}>{msg.text}</div>}
        {tempPassword && <div className="banner amber"><b>TEMPORARY PASSWORD</b><br/><span className="mono">{tempPassword.password}</span><br/><span className="small">Berikan melalui kanal aman. User wajib menggantinya saat login. Jangan simpan di chat/tiket.</span><button className="btn ghost" style={{marginLeft:10}} onClick={()=>setTempPassword(null)}>TUTUP</button></div>}
        <table className="table">
          <thead><tr><th>USER</th><th>PERAN</th><th>STATUS</th><th>PAKET</th><th>BERIKAN PAKET</th><th>AKSI</th></tr></thead>
          <tbody>
            {list.map((u) => {
              const s = sel[u.id] || {}; const manageable = u.role === 'USER' || (role === 'DEVELOPER' && u.role === 'ADMIN');
              return (
                <tr key={u.id}>
                  <td><b>{u.name}</b><div className="small">{u.email}</div></td>
                  <td>{u.role}{u.mfaRecoveryRequired&&<div><span className="pill amber">MFA RECOVERY</span></div>}</td>
                  <td><span className={'pill ' + (u.status === 'ACTIVE' ? 'green' : 'red')}>{u.status}</span></td>
                  <td>{u.plan ? <>{u.plan}{u.entitlementsOverride && <span className="pill amber" style={{marginLeft:6}}>CUSTOM</span>}<div className="small">s/d {new Date(u.planExpiresAt).toLocaleDateString('id-ID')}</div></> : <span className="small">DEMO</span>}</td>
                  <td>{manageable && u.role === 'USER' && (
                    <div className="actions">
                      <select className="input" value={s.plan || ''} onChange={(e) => setSel({ ...sel, [u.id]: { ...s, plan: e.target.value } })}><option value="">Pilih…</option>{plans.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
                      <input className="input" type="number" min={1} max={3650} placeholder="hari" style={{ maxWidth: 80 }} value={s.days ?? 30} onChange={(e) => setSel({ ...sel, [u.id]: { ...s, days: Number(e.target.value) } })} />
                      <button className="btn ghost" disabled={!s.plan} onClick={() => patch({ userId: u.id, action: 'GRANT_PLAN', planId: s.plan, days: s.days ?? 30 })}>BERIKAN</button>{u.plan && <UserEntitlementEditor user={u} plan={{id:u.planId,name:u.plan,entitlements:u.planEntitlements}} onSaved={load} />}
                    </div>)}</td>
                  <td>{manageable && (
                    <div className="actions">
                      {u.status === 'ACTIVE' ? <button className="btn danger" onClick={() => confirm(`Suspend ${u.email}? Bot miliknya akan dihentikan.`) && patch({ userId: u.id, action: 'SET_STATUS', status: 'SUSPENDED' })}>SUSPEND</button> : <button className="btn ghost" onClick={() => patch({ userId: u.id, action: 'SET_STATUS', status: 'ACTIVE' })}>AKTIFKAN</button>}
                      {u.plan && u.role === 'USER' && <>{role === 'DEVELOPER' ? <button className="btn ghost" onClick={() => patch({ userId: u.id, action: 'REVOKE_PLAN' })}>CABUT PAKET</button> : null}</>}
                      {role === 'DEVELOPER' && <button className="btn ghost" onClick={() => patch({ userId: u.id, action: 'SET_ROLE', role: u.role === 'ADMIN' ? 'USER' : 'ADMIN' })}>{u.role === 'ADMIN' ? 'JADIKAN USER' : 'JADIKAN ADMIN'}</button>}<button className="btn ghost" onClick={() => patch({userId:u.id,action:'RESET_SESSION'})}>RESET SESI</button><button className="btn ghost" onClick={() => confirm(`Reset MFA ${u.email}? Semua sesi aktif akan dicabut. MFA lama akan dinonaktifkan; MFA baru hanya dapat dibuat dan diaktifkan sendiri oleh user.`) && patch({userId:u.id,action:'RESET_MFA'})}>RESET MFA</button><button className="btn ghost" onClick={() => confirm(`Buat temporary password untuk ${u.email}? Semua sesi aktif akan dicabut.`) && patch({userId:u.id,action:'RESET_PASSWORD',targetEmail:u.email})}>TEMP PASSWORD</button><button className="btn ghost" onClick={() => confirm(`Paksa ${u.email} mengganti password pada login berikutnya?`) && patch({userId:u.id,action:'FORCE_PASSWORD_CHANGE'})}>FORCE RESET</button><button className="btn ghost" onClick={() => { const email=prompt('Email baru untuk '+u.email); if(email) patch({userId:u.id,action:'RESET_EMAIL',newEmail:email}); }}>RESET EMAIL</button><button className="btn danger" onClick={() => confirm('PERMANEN: anonymize dan nonaktifkan akun '+u.email+'?') && patch({userId:u.id,action:'DELETE_ACCOUNT',confirmation:'DELETE PERMANENTLY'})}>HAPUS AKUN</button>
                    </div>)}</td>
                </tr>
              );
            })}
            {!list.length && <tr><td colSpan={6} className="small">Belum ada pengguna.</td></tr>}
          </tbody>
        </table>
      </div>
    </section>
  );
}
