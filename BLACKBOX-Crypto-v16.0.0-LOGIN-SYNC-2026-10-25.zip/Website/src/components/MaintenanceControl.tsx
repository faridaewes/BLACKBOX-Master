'use client';
import {useEffect,useState} from 'react';
export default function MaintenanceControl(){
 const [flags,setFlags]=useState<any>(null),[confirm,setConfirm]=useState(''),[busy,setBusy]=useState(false),[msg,setMsg]=useState('');
 const [draft,setDraft]=useState({title:'',body:'',emailSubject:'',imageUrl:''});
 const load=()=>fetch('/api/emergency',{cache:'no-store'}).then(r=>r.json()).then(j=>{if(j.ok){setFlags(j);if(j.maintenanceDraft)setDraft({title:j.maintenanceDraft.title,body:j.maintenanceDraft.body,emailSubject:j.maintenanceDraft.emailSubject,imageUrl:j.maintenanceDraft.imageUrl||''})}}).catch(()=>{});
 useEffect(()=>{load()},[]);
 const run=async(on:boolean)=>{setBusy(true);setMsg('');try{const phrase=on?'START BLACKBOX MAINTENANCE':'STOP BLACKBOX MAINTENANCE';const r=await fetch('/api/emergency',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action:'SET_MAINTENANCE',on,confirm,draft})});const j=await r.json();setMsg(j.ok?(on?'Maintenance aktif. Notifikasi dashboard/email/Telegram dikirim melalui gateway.':'Maintenance selesai. Notifikasi pemulihan dikirim.'):(j.error||'Gagal'));if(j.ok){setConfirm('');await load()}}finally{setBusy(false)}};
 if(!flags)return null; const phrase=flags.maintenance?'STOP BLACKBOX MAINTENANCE':'START BLACKBOX MAINTENANCE';
 return <section className="panel maintenanceControl"><div className="panelHead"><span className="panelTitle">SYSTEM MAINTENANCE · DEVELOPER ONLY</span><span className={`pill ${flags.maintenance?'amber':'green'}`}>{flags.maintenance?'MAINTENANCE ACTIVE':'OPERATIONAL'}</span></div><div className="panelBody">
 <div className="warning">Pesan wajib disiapkan dan dapat diperiksa sebelum tombol START/STOP dijalankan. Setelah START, pesan yang disimpan menjadi sumber resmi untuk Dashboard, Email, dan Telegram user.</div>
 <div className="two"><label className="field">Judul<input className="input" value={draft.title} onChange={e=>setDraft({...draft,title:e.target.value})}/></label><label className="field">Subject Email<input className="input" value={draft.emailSubject} onChange={e=>setDraft({...draft,emailSubject:e.target.value})}/></label></div>
 <label className="field">Isi pesan<textarea className="input" rows={7} value={draft.body} onChange={e=>setDraft({...draft,body:e.target.value})}/></label>
 <label className="field">Banner URL (opsional)<input className="input" value={draft.imageUrl} onChange={e=>setDraft({...draft,imageUrl:e.target.value})} placeholder="https://..."/></label>
 <div className="card" style={{marginTop:10}}><b>PREVIEW</b><h3>{draft.title||'—'}</h3><p className="small" style={{whiteSpace:'pre-wrap'}}>{draft.body||'—'}</p></div>
 <div className="actions"><input className="input" value={confirm} onChange={e=>setConfirm(e.target.value)} placeholder={`Ketik: ${phrase}`} disabled={busy}/>{!flags.maintenance?<button className="btn danger" disabled={busy||confirm.trim()!==phrase||!draft.title.trim()||!draft.body.trim()} onClick={()=>run(true)}>START MAINTENANCE & KIRIM</button>:<button className="btn primary" disabled={busy||confirm.trim()!==phrase} onClick={()=>run(false)}>STOP MAINTENANCE & KIRIM</button>}</div>{msg&&<div className="banner" style={{marginTop:10}}>{msg}</div>}
 </div></section>
}
