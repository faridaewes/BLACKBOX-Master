"use client";
import{useEffect,useState}from"react";
import Link from 'next/link';
import BlackboxLogo from"@/components/BlackboxLogo";
import { BLACKBOX_RELEASE_VERSION } from '@/lib/release-version';
import { BLACKBOX_FOOTER_SHORT_DISCLAIMER } from '@/lib/legal-content';

export default function SocialFooter(){
 const[v,setV]=useState<any>({});
 useEffect(()=>{fetch("/api/public/social-links",{cache:'no-store'}).then(r=>r.json()).then(j=>j.ok&&setV(j)).catch(()=>{})},[]);
 return <footer className="footer bbLegalFooter" aria-label="Disclaimer dan informasi hukum BLACKBOX">
  <div className="bbLegalFooterBrand"><BlackboxLogo compact/><div><b>BLACKBOX Technology · BLACKBOX Crypto</b><div>Platform teknologi pendukung aktivitas trading · v{BLACKBOX_RELEASE_VERSION}</div></div></div>
  <div className="bbLegalFooterDisclaimer">
   <b>DISCLAIMER BLACKBOX TECHNOLOGY</b>
   <p style={{margin:'8px 0 0',lineHeight:1.7}}>{BLACKBOX_FOOTER_SHORT_DISCLAIMER}</p>
  </div>
  <div className="bbLegalFooterLinks">
   <Link href="/legal">Legal & Consent</Link><Link href="/regulations">Regulatory Center</Link><Link href="/dashboard/legal">My Agreements</Link>
   {v.telegram&&<a href={v.telegram} target="_blank" rel="noreferrer">Telegram</a>}{v.tiktok&&<a href={v.tiktok} target="_blank" rel="noreferrer">TikTok</a>}{v.instagram&&<a href={v.instagram} target="_blank" rel="noreferrer">Instagram</a>}
  </div>
  <div className="bbLegalFooterCopyright">© {new Date().getFullYear()} BLACKBOX Technology. Gunakan hanya kanal resmi, baca disclosure dan agreement, serta pahami risiko sebelum trading.</div>
 </footer>
}
