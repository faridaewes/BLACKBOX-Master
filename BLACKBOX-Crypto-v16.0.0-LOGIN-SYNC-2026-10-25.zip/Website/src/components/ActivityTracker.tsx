'use client';
import { useEffect } from 'react';
import { usePathname } from 'next/navigation';
export default function ActivityTracker(){const pathname=usePathname();useEffect(()=>{if(!pathname)return;fetch('/api/activity/track',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({type:'PAGE_VIEW',path:pathname,metadata:{visibility:document.visibilityState}}),keepalive:true}).catch(()=>{});},[pathname]);return null;}
