'use client';
import { useEffect, useState } from 'react';

export default function AutoProtectPanel() {
  const [email, setEmail] = useState('');
  const [configured, setConfigured] = useState(false);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const j = await fetch('/api/developer/auto-protect', { cache: 'no-store' }).then((r) => r.json());
    if (j.ok) {
      setEmail(j.email || '');
      setConfigured(!!j.configured);
    }
  };
  useEffect(() => {
    load();
  }, []);

  const save = async () => {
    setBusy(true);
    setMsg('');
    try {
      const r = await fetch('/api/developer/auto-protect', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ action: 'SET_EMAIL', email }),
      });
      const j = await r.json();
      setMsg(j.ok ? 'Email auto-protect disimpan.' : j.error || 'Gagal');
      await load();
    } finally {
      setBusy(false);
    }
  };

  const test = async () => {
    setBusy(true);
    setMsg('');
    try {
      const r = await fetch('/api/developer/auto-protect', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ action: 'TEST_BACKUP' }),
      });
      const j = await r.json();
      setMsg(j.ok ? 'Backup uji dipicu (cek email & audit log).' : JSON.stringify(j.result || j.error));
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel section" id="auto-protect">
      <div className="panelHead">
        <span className="panelTitle">AUTO-PROTECT · Backup darurat ke email</span>
        <span className="small">Developer Principal only</span>
      </div>
      <div className="panelBody formGrid">
        <p className="hint">
          Jika terdeteksi banjir autentikasi / pemicu proteksi, sistem dapat membuat backup{' '}
          <b>FULL_SYSTEM</b> (ZIP terenkripsi) dan mengirimkannya ke email ini. Pastikan SMTP /
          BACKUP_ENCRYPTION_KEY sudah dikonfigurasi di environment.
        </p>
        <label>
          Email tujuan backup otomatis
          <input
            className="input"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="security@perusahaan.com"
          />
        </label>
        <div className="actions">
          <button className="btn primary" disabled={busy || !email.includes('@')} onClick={save}>
            Simpan email
          </button>
          <button className="btn" disabled={busy || !configured} onClick={test}>
            Uji backup sekarang
          </button>
        </div>
        <div className="muted">Status: {configured ? 'EMAIL TERKONFIGURASI' : 'BELUM DIATUR'}</div>
        {msg && <div className="banner">{msg}</div>}
      </div>
    </section>
  );
}
