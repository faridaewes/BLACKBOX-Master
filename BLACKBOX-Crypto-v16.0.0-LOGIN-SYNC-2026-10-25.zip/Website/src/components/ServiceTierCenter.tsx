'use client';
import {useEffect,useState} from 'react';
function fmt(v:any){if(Array.isArray(v))return v.join(', ');if(typeof v==='boolean')return v?'Ya':'Tidak';return String(v??'—')}
export default function ServiceTierCenter(){
 const[data,setData]=useState<any>(null);const[open,setOpen]=useState<string|null>(null);
 useEffect(()=>{fetch('/api/public/tiers',{cache:'no-store'}).then(r=>r.json()).then(j=>{if(j.ok)setData(j)}).catch(()=>{});},[]);
 if(!data)return <section className="panel section"><div className="panelHead"><span className="panelTitle">SERVICE TIER</span></div><div className="panelBody"><div className="small">Memuat layanan tier…</div></div></section>;
 const wa=data.contact?.whatsapp?`https://wa.me/${String(data.contact.whatsapp).replace(/\D/g,'')}`:null;
 const tg=data.contact?.telegram?(String(data.contact.telegram).startsWith('http')?String(data.contact.telegram):`https://t.me/${String(data.contact.telegram).replace('@','')}`):null;
 return <section className="panel section" id="service-tier">
  <div className="panelHead"><div><span className="panelTitle">SERVICE TIER · PILIH LAYANAN</span><div className="small">Rincian dibaca langsung dari konfigurasi tier aktif. Saat Developer/Admin memperbarui tier, katalog user ikut berubah otomatis.</div></div></div>
  <div className="panelBody">
   <div className="three">
    {data.plans.map((p:any)=><article className="card" key={p.id} style={{display:'flex',flexDirection:'column',gap:10}}>
      <div>
       {p.imageUrl&&<img src={p.imageUrl} alt={p.imageAlt||`${p.name} tier`} style={{width:'100%',height:150,objectFit:'cover',borderRadius:14,marginBottom:8}}/>}
       <span className="pill green">{p.name}</span><h3 style={{margin:'10px 0 4px'}}>{p.description||'Layanan BLACKBOX'}</h3>
      </div>
      <div className="small">{p.details?.slice(0,6).map((d:any)=><div className="listItem" key={d.key}><span>{d.label}</span><b>{fmt(d.value)}</b></div>)}</div>
      <button className="btn ghost" onClick={()=>setOpen(open===p.id?null:p.id)}>{open===p.id?'SEMBUNYIKAN RINCIAN':'LIHAT RINCIAN'}</button>
      {open===p.id&&<div className="panel" style={{marginTop:4}}><div className="panelBody">{p.details?.map((d:any)=><div className="listItem" key={d.key}><span>{d.label}</span><b>{fmt(d.value)}</b></div>)}</div></div>}
      <div className="actions">
       {p.paymentEnabled&&p.priceMinor>0&&<a className="btn primary" href={`/dashboard/payments?plan=${encodeURIComponent(p.id)}`}>BAYAR & UPLOAD BUKTI</a>}
       <a className="btn primary" href={wa||'/dashboard/support'} target={wa?'_blank':undefined} rel={wa?'noreferrer':undefined}>HUBUNGI ADMIN PIC</a>
       <a className="btn ghost" href={tg||'/dashboard/support?topic=tier'} target={tg?'_blank':undefined} rel={tg?'noreferrer':undefined}>{tg?'TELEGRAM':'LIVE CHAT'}</a>
       <a className="btn ghost" href="/dashboard/support?topic=tier">LIVE CHAT</a>
      </div>
      <div className="mini">{p.paymentEnabled&&p.priceMinor>0?'Pembayaran BLACKBOX tersedia sesuai metode yang PUBLIC ON.':'Pembayaran saat ini dilakukan di luar BLACKBOX melalui Admin PIC/Live Chat karena metode pembayaran publik belum diaktifkan.'}</div>
    </article>)}
   </div>
   {!data.plans.length&&<div className="small">Belum ada layanan tier aktif.</div>}
  </div>
 </section>;
}
