'use client';
import { useEffect, useState } from 'react';

const PRESETS = [
  { id: 'gmail', label: 'Gmail', host: 'smtp.gmail.com', port: 587, secure: false },
  { id: 'outlook', label: 'Outlook / Hotmail', host: 'smtp.office365.com', port: 587, secure: false },
  { id: 'custom', label: 'Custom / VPS', host: '', port: 587, secure: false },
];

export default function SmtpConfigPanel() {
  const [form, setForm] = useState({ host: '', port: 587, secure: false, user: '', pass: '', from: '' });
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const [configured, setConfigured] = useState(false);

  useEffect(() => {
    fetch('/api/developer/smtp-config', { cache: 'no-store' })
      .then((r) => r.json())
      .then((j) => {
        if (j.ok && j.config) {
          setConfigured(true);
          setForm({
            host: j.config.host || '',
            port: j.config.port || 587,
            secure: !!j.config.secure,
            user: j.config.user || '',
            pass: '',
            from: j.config.from || '',
          });
        }
      });
  }, []);

  const applyPreset = (id: string) => {
    const p = PRESETS.find((x) => x.id === id);
    if (!p) return;
    setForm((f) => ({ ...f, host: p.host || f.host, port: p.port, secure: p.secure }));
  };

  const save = async () => {
    setBusy(true);
    setMsg('');
    try {
      const r = await fetch('/api/developer/smtp-config', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(form),
      });
      const j = await r.json();
      setMsg(j.ok ? 'SMTP tersimpan. Auto-protect & email sistem memakai ini otomatis.' : j.error || 'Gagal');
      if (j.ok) setConfigured(true);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel section" id="smtp-config">
      <div className="panelHead">
        <span className="panelTitle">SMTP DINAMIS · Email sistem & Auto-Protect</span>
        <span className="small">Isi sekali — dipakai otomatis</span>
      </div>
      <div className="panelBody formGrid">
        <p className="hint">
          Tidak perlu mengedit file .env. Pilih preset (mis. Gmail), isi email + sandi aplikasi, simpan.
          Verifikasi, reset password, dan backup Auto-Protect mengikuti pengaturan ini.
        </p>
        <div className="actions">
          {PRESETS.map((p) => (
            <button key={p.id} type="button" className="btn ghost" onClick={() => applyPreset(p.id)}>
              {p.label}
            </button>
          ))}
        </div>
        <label>
          Host SMTP
          <input className="input" value={form.host} onChange={(e) => setForm({ ...form, host: e.target.value })} placeholder="smtp.gmail.com" />
        </label>
        <label>
          Port
          <input className="input" type="number" value={form.port} onChange={(e) => setForm({ ...form, port: Number(e.target.value) })} />
        </label>
        <label>
          <input type="checkbox" checked={form.secure} onChange={(e) => setForm({ ...form, secure: e.target.checked })} /> Secure (SSL 465)
        </label>
        <label>
          User / Email login SMTP
          <input className="input" value={form.user} onChange={(e) => setForm({ ...form, user: e.target.value })} />
        </label>
        <label>
          Password / App password
          <input className="input" type="password" value={form.pass} onChange={(e) => setForm({ ...form, pass: e.target.value })} placeholder={configured ? '(tersimpan — isi untuk ganti)' : ''} />
        </label>
        <label>
          From (pengirim)
          <input className="input" value={form.from} onChange={(e) => setForm({ ...form, from: e.target.value })} placeholder="sama dengan user bila kosong" />
        </label>
        <button className="btn primary" disabled={busy || !form.host} onClick={save}>
          Simpan SMTP
        </button>
        <div className="muted">Status: {configured ? 'TERKONFIGURASI' : 'BELUM'}</div>
        {msg && <div className="banner">{msg}</div>}
      </div>
    </section>
  );
}
