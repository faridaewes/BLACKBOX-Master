'use client';
import { useEffect, useState } from 'react';

type Status = 'healthy'|'degraded'|'offline';
type Health = { status?:Status; score?:number; components?:Array<{id:string;state:string;detail:string}>; recovery?:{tradingAuthorization?:string} };

export default function RuntimeStatusBanner(){
  const [health,setHealth]=useState<Health|null>(null);
  const [open,setOpen]=useState(false);
  useEffect(()=>{
    let alive=true;
    const poll=async()=>{
      try{const r=await fetch('/api/health',{cache:'no-store'});const j=await r.json().catch(()=>({}));if(alive)setHealth({...j,status:r.ok?(j.status||'healthy'):'degraded'});}catch{if(alive)setHealth({status:'offline'});}
    };
    poll(); const id=window.setInterval(poll,30000); return()=>{alive=false;window.clearInterval(id)};
  },[]);
  if(!health || health.status==='healthy') return null;
  const degraded=health.status==='degraded';
  return <section className="banner amber bb-runtime-banner" role="status" aria-live="polite" style={{marginBottom:14}}>
    <div style={{display:'flex',gap:12,alignItems:'center',justifyContent:'space-between',flexWrap:'wrap'}}>
      <div><b>{degraded?'⚠ SISTEM TERDEGRADASI':'◌ KONEKSI STATUS TERPUTUS'}</b><div className="small">{degraded?'BLACKBOX tetap berjalan. Provider/komponen tertentu sedang dipulihkan; tidak ada order otomatis dari kondisi ini.':'Status server belum dapat dibaca. Coba lagi sebentar.'}</div></div>
      <div className="actions"><button className="btn ghost" onClick={()=>setOpen(v=>!v)}>{open?'SEMBUNYIKAN':'LIHAT STATUS'}</button><button className="btn ghost" onClick={()=>location.reload()}>MUAT ULANG</button></div>
    </div>
    {open&&<div className="list" style={{marginTop:10}}>{(health.components||[]).map(c=><div className="listItem" key={c.id}><span>{c.id}</span><b>{c.state}</b></div>)}<div className="small">Trading authorization: {health.recovery?.tradingAuthorization||'LOCKED_UNTIL_EXPLICIT_CERTIFICATION'}</div></div>}
  </section>;
}
