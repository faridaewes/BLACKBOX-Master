'use client';
import { useEffect, useState } from 'react';

export default function OtpChannelsPanel() {
  const [status, setStatus] = useState<any>(null);
  const [wa, setWa] = useState({ accessToken: '', phoneNumberId: '' });
  const [tw, setTw] = useState({ accountSid: '', authToken: '', from: '' });
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const j = await fetch('/api/developer/otp-channels', { cache: 'no-store' }).then((r) => r.json());
    if (j.ok) setStatus(j);
  };
  useEffect(() => {
    load();
  }, []);

  const save = async (channel: string, body: any) => {
    setBusy(true);
    setMsg('');
    try {
      const r = await fetch('/api/developer/otp-channels', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ channel, ...body }),
      });
      const j = await r.json();
      setMsg(j.ok ? 'Tersimpan.' : j.error || 'Gagal');
      await load();
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel section" id="otp-channels">
      <div className="panelHead">
        <span className="panelTitle">OTP HP / WhatsApp — tanpa ribet teknis</span>
        <span className="small">Developer Principal</span>
      </div>
      <div className="panelBody formGrid">
        <div className="banner">
          <b>Rekomendasi sederhana:</b>
          <ol style={{ margin: '8px 0 0 18px', lineHeight: 1.55 }}>
            <li>
              Isi dulu panel <b>SMTP</b> (email). Verifikasi email langsung jalan.
            </li>
            <li>
              Untuk nomor HP: bila WhatsApp/Twilio belum diisi, sistem <b>mengirim kode HP ke email
              user</b> (fallback) agar pendaftaran tetap bisa.
            </li>
            <li>
              Opsional nanti: aktifkan WhatsApp (Meta) atau SMS (Twilio) dengan menempel token dari
              dashboard mereka — panduan di bawah.
            </li>
          </ol>
        </div>

        <div className="muted">
          Status sekarang — Email: {status?.channels?.email?.configured ? 'SIAP' : 'BELUM'} ·
          WhatsApp: {status?.channels?.whatsapp?.configured ? 'SIAP' : 'BELUM'} · SMS/Twilio:{' '}
          {status?.channels?.sms?.configured ? 'SIAP' : 'BELUM'}
        </div>

        <h3 style={{ margin: '12px 0 4px' }}>Opsi A — WhatsApp (Meta Cloud API)</h3>
        <p className="hint">
          1) Buka developers.facebook.com → buat app tipe Business → produk WhatsApp.
          <br />
          2) Di WhatsApp → API Setup, salin <b>Temporary/Permanent Access Token</b> dan{' '}
          <b>Phone number ID</b>.
          <br />
          3) Tempel di bawah lalu Simpan. (Untuk produksi, Meta minta verifikasi bisnis.)
        </p>
        <label>
          Access Token
          <input
            className="input"
            value={wa.accessToken}
            onChange={(e) => setWa({ ...wa, accessToken: e.target.value })}
            placeholder="EAAB..."
          />
        </label>
        <label>
          Phone Number ID
          <input
            className="input"
            value={wa.phoneNumberId}
            onChange={(e) => setWa({ ...wa, phoneNumberId: e.target.value })}
            placeholder="angka ID nomor"
          />
        </label>
        <div className="actions">
          <button
            className="btn primary"
            disabled={busy}
            onClick={() => save('WHATSAPP', wa)}
          >
            Simpan WhatsApp
          </button>
          <button className="btn ghost" disabled={busy} onClick={() => save('CLEAR_WHATSAPP', {})}>
            Hapus WhatsApp
          </button>
        </div>

        <h3 style={{ margin: '16px 0 4px' }}>Opsi B — SMS Twilio (opsional)</h3>
        <p className="hint">
          1) Daftar twilio.com → Console → Account SID & Auth Token.
          <br />
          2) Beli/aktifkan nomor pengirim → salin nomor (From).
          <br />
          3) Tempel di bawah. SMS berbayar per pesan.
        </p>
        <label>
          Account SID
          <input
            className="input"
            value={tw.accountSid}
            onChange={(e) => setTw({ ...tw, accountSid: e.target.value })}
          />
        </label>
        <label>
          Auth Token
          <input
            className="input"
            type="password"
            value={tw.authToken}
            onChange={(e) => setTw({ ...tw, authToken: e.target.value })}
          />
        </label>
        <label>
          From (nomor Twilio)
          <input
            className="input"
            value={tw.from}
            onChange={(e) => setTw({ ...tw, from: e.target.value })}
            placeholder="+1..."
          />
        </label>
        <div className="actions">
          <button className="btn" disabled={busy} onClick={() => save('TWILIO', tw)}>
            Simpan Twilio
          </button>
          <button className="btn ghost" disabled={busy} onClick={() => save('CLEAR_TWILIO', {})}>
            Hapus Twilio
          </button>
        </div>

        {msg && <div className="banner">{msg}</div>}
      </div>
    </section>
  );
}
