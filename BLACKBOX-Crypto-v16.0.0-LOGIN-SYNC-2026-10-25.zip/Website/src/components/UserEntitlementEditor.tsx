'use client';
import { useEffect, useState } from 'react';

const markets = ['SPOT','FUTURES','DEX'];
const features = ['customTier','realTrading','advancedRisk','mtf','alerts','backtest','apiAccess'];

export default function UserEntitlementEditor({ user, plan, onSaved }: { user: any; plan: any; onSaved: () => void }) {
  const base = (plan?.entitlements || {}) as any;
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<any>({ activeBots: base.activeBots ?? 1, concurrentPositions: base.concurrentPositions ?? 3, exchanges: base.exchanges ?? 0, scanSeconds: base.scanSeconds ?? 30, marketPairs: base.marketPairs ?? 3, ai: base.ai ?? 'basic', marketTypes: base.marketTypes ?? ['SPOT'], features: { ...(base.features || {}) } });
  const [msg, setMsg] = useState('');
  useEffect(() => { if (open) setForm({ activeBots: base.activeBots ?? 1, concurrentPositions: base.concurrentPositions ?? 3, exchanges: base.exchanges ?? 0, scanSeconds: base.scanSeconds ?? 30, marketPairs: base.marketPairs ?? 3, ai: base.ai ?? 'basic', marketTypes: base.marketTypes ?? ['SPOT'], features: { ...(base.features || {}) } }); }, [open, plan]);
  if (!user?.plan) return null;
  const save = async () => {
    setMsg('MENYIMPAN…');
    const r = await fetch('/api/admin/users', { method: 'PATCH', headers: {'content-type':'application/json'}, body: JSON.stringify({ userId: user.id, action: 'SET_ENTITLEMENT_OVERRIDE', entitlements: form }) });
    const j = await r.json(); setMsg(j.ok ? 'CUSTOM TIER AKTIF' : (j.error || 'GAGAL')); if (j.ok) { onSaved(); setTimeout(()=>setOpen(false),500); }
  };
  return <>
    <button className="btn ghost bbTinyBtn" onClick={()=>setOpen(v=>!v)}>{open ? 'TUTUP' : 'CUSTOMIZE'}</button>
    {open && <div className="bbEntEditor">
      <div className="bbEntHeader"><b>USER ENTITLEMENT MATRIX</b><span>{user.name}</span></div>
      <div className="bbEntGrid">
        {([['activeBots','MAX BOT'],['concurrentPositions','MAX POSISI'],['exchanges','EXCHANGE'],['marketPairs','MAX PAIR'],['scanSeconds','SCAN SEC']] as const).map(([k,l])=><label key={k}>{l}<input className="input" type="number" min={k==='scanSeconds'?1:0} value={form[k]} onChange={e=>setForm({...form,[k]:Number(e.target.value)})}/></label>)}
        <label>AI<select className="input" value={form.ai} onChange={e=>setForm({...form,ai:e.target.value})}><option value="basic">BASIC</option><option value="advanced">ADVANCED</option><option value="full">FULL</option><option value="custom">CUSTOM</option></select></label>
      </div>
      <div className="bbEntChips"><span>MARKET</span>{markets.map(m=><button key={m} className={form.marketTypes.includes(m)?'on':''} onClick={()=>setForm({...form,marketTypes:form.marketTypes.includes(m)?form.marketTypes.filter((x:string)=>x!==m):[...form.marketTypes,m]})}>{m}</button>)}</div>
      <div className="bbEntChips"><span>FEATURES</span>{features.map(f=><button key={f} className={form.features?.[f]?'on':''} onClick={()=>setForm({...form,features:{...form.features,[f]:!form.features?.[f]}})}>{f}</button>)}</div>
      <div className="actions"><button className="btn primary" onClick={save}>APPLY USER TIER</button><span className="small">{msg || 'Override hanya user ini; tier master tetap utuh.'}</span></div>
    </div>}
  </>;
}
