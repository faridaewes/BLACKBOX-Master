'use client';
import { useState } from 'react';

export default function AccountRecoveryPanel() {
  const [userId, setUserId] = useState('');
  const [email, setEmail] = useState('');
  const [reason, setReason] = useState('Bantuan petugas');
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  const resolveUserId = async () => {
    if (userId.trim()) return userId.trim();
    if (!email.trim()) throw new Error('Isi userId atau email');
    const r = await fetch(`/api/developer/users`, { cache: 'no-store' });
    const j = await r.json();
    if (!j.ok) throw new Error('Gagal memuat user');
    const hit = (j.users || []).find(
      (u: any) => String(u.email || '').toLowerCase() === email.trim().toLowerCase(),
    );
    if (!hit) throw new Error('User tidak ditemukan');
    return hit.id as string;
  };

  const act = async (action: string) => {
    setBusy(true);
    setMsg('');
    try {
      const id = await resolveUserId();
      const r = await fetch('/api/developer/account-recovery', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ action, userId: id, reason }),
      });
      const j = await r.json();
      setMsg(j.ok ? j.message || 'OK' : j.error || 'Gagal');
    } catch (e) {
      setMsg(e instanceof Error ? e.message : 'Gagal');
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel section" id="account-recovery">
      <div className="panelHead">
        <span className="panelTitle">PEMULIHAN AKUN · Unfreeze trading / Buka blokir</span>
        <span className="small">Developer / petugas USER_SUSPEND</span>
      </div>
      <div className="panelBody formGrid">
        <p className="hint">
          Untuk akun yang kena proteksi login gagal (bot dibekukan) atau status SUSPENDED/DISABLED.
          NORMALIZE = unfreeze + buka blokir sekaligus.
        </p>
        <label>
          User ID (opsional jika isi email)
          <input className="input" value={userId} onChange={(e) => setUserId(e.target.value)} placeholder="cuid…" />
        </label>
        <label>
          Email user
          <input className="input" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="user@email.com" />
        </label>
        <label>
          Alasan
          <input className="input" value={reason} onChange={(e) => setReason(e.target.value)} />
        </label>
        <div className="actions">
          <button className="btn" disabled={busy} onClick={() => act('UNFREEZE_TRADING')}>
            Unfreeze trading
          </button>
          <button className="btn" disabled={busy} onClick={() => act('UNBLOCK_ACCOUNT')}>
            Buka blokir akun
          </button>
          <button className="btn primary" disabled={busy} onClick={() => act('NORMALIZE')}>
            Normalkan semua
          </button>
        </div>
        {msg && <div className="banner">{msg}</div>}
      </div>
    </section>
  );
}
