'use client';
export const GUARDRAIL_FIELDS: [string, string, string][] = [
  ['maxDrawdownPct', 'Max Drawdown (%)', '1–50'], ['riskPerTradePct', 'Risk per Trade (%)', '0.1–5'], ['sessionTargetPct', 'Target Sesi (%)', '1–100'],
  ['dailyLossLimitPct', 'Daily Loss Limit (%)', '1–30'], ['maxPositions', 'Maks Posisi', '1–50'], ['allocationPct', 'Alokasi / Posisi (%)', '1–100'],
  ['stopLossPct', 'Stop Loss (%)', '1–50'], ['takeProfitPct', 'Take Profit (%)', '1–500'], ['minAiScore', 'Min Skor AI', '0–100'],
  ['maxRugRisk', 'Maks Rug Risk', '0–100'], ['minLiquidityUsd', 'Min Likuiditas (USD)', '1000+'], ['decisionIntervalSec', 'Interval Keputusan (detik)', '5+'],
];

export default function GuardrailFields({ value, onChange }: { value: Record<string, number>; onChange: (k: string, v: number) => void }) {
  return (
    <div className="grid2">
      {GUARDRAIL_FIELDS.map(([k, label, hint]) => (
        <label key={k}>{label}
          <input className="input" type="number" step="any" value={Number.isFinite(value[k]) ? value[k] : ''} placeholder={hint}
            onChange={(e) => onChange(k, e.target.value === '' ? NaN : Number(e.target.value))} />
        </label>
      ))}
    </div>
  );
}
