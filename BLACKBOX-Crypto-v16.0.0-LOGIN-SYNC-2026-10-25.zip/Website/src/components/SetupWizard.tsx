'use client';
import { useEffect, useState } from 'react';
import { useBot } from './BotProvider';
import GuardrailFields from './GuardrailFields';
import { PRESETS } from '@/lib/paper/engine';
import { RISK_NOTICE } from '@/lib/risk';
import { usd } from '@/lib/format';

const CHAINS: [string, string][] = [['solana', 'Solana'], ['base', 'Base'], ['bsc', 'BNB Chain'], ['ethereum', 'Ethereum']];
const CAPITALS = [10, 100, 500, 1000, 10000, 50000];
const STEPS = ['Mode & Modal', 'AI Engine', 'Guardrails', 'Review & Launch'];

export default function SetupWizard({ onDone }: { onDone?: () => void }) {
  const ctx = useBot();
  const [step, setStep] = useState(0);
  const [name, setName] = useState('BLACKBOX Bot');
  const [capital, setCapital] = useState(1000);
  const [chains, setChains] = useState<string[]>(CHAINS.map((c) => c[0]));
  const [marketTypes, setMarketTypes] = useState<Array<'SPOT'|'FUTURES'|'DEX'>>(['SPOT']);
  const [symbols, setSymbols] = useState('BTC/USDT,ETH/USDT,SOL/USDT');
  const [preset, setPreset] = useState<'conservative' | 'balanced' | 'degen'>('balanced');
  const [g, setG] = useState<Record<string, number>>({ ...(PRESETS.balanced as any) });
  const [agree, setAgree] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [test, setTest] = useState<any>(null);
  const ai = ctx?.ai;
  const [availableSymbols, setAvailableSymbols] = useState<string[]>([]);
  const maxPairs = Number(ctx?.entitlements?.marketPairs || 3);
  const primaryMarketType = marketTypes[0] || 'SPOT';
  useEffect(() => { if (marketTypes.length !== 1 || marketTypes[0] === 'DEX') { setAvailableSymbols([]); return; } fetch(`/api/market/symbols?marketType=${marketTypes[0]}&mode=DEMO`).then(r=>r.json()).then(j=>{ if(j.ok) setAvailableSymbols(j.symbols||[]); }).catch(()=>{}); }, [marketTypes]);
  const selectedSymbols = symbols.split(',').map(x=>x.trim()).filter(Boolean);
  const toggleSymbol = (symbol:string) => { const has=selectedSymbols.includes(symbol); if(has) setSymbols(selectedSymbols.filter(x=>x!==symbol).join(',')); else if(selectedSymbols.length<maxPairs) setSymbols([...selectedSymbols,symbol].join(',')); };

  const pick = (p: 'conservative' | 'balanced' | 'degen') => { setPreset(p); setG({ ...(PRESETS[p] as any) }); };
  const toggleChain = (c: string) => setChains((cur) => (cur.includes(c) ? (cur.length > 1 ? cur.filter((x) => x !== c) : cur) : [...cur, c]));

  const testAi = async () => {
    setTest({ busy: true });
    const r = await fetch('/api/ai/decision', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ symbol: 'TEST/SOL', priceUsd: 1, priceChange5m: 2.5, priceChange1h: 5, liquidityUsd: 500000, volume24h: 2000000, score: 80, rug: 15 }) }).then((x) => x.json()).catch(() => ({ ok: false, error: 'Tidak bisa menghubungi server' }));
    setTest(r);
  };

  const launch = async () => {
    const cleanSymbols = symbols.split(',').map(x=>x.trim()).filter(Boolean).slice(0,maxPairs);
    if (!name.trim()) { setErr('Nama bot wajib diisi.'); return; }
    if (!Number.isFinite(capital) || capital < 10 || capital > 10000000) { setErr('Modal demo harus antara $10 dan $10.000.000.'); return; }
    if (!marketTypes.length) { setErr('Pilih minimal satu market: SPOT, FUTURES, atau DEX.'); return; }
    if (!cleanSymbols.length) { setErr('Pilih minimal satu pair untuk demo.'); return; }
    if (cleanSymbols.length > maxPairs) { setErr(`Tier ${ctx?.entitlements?.label || 'DEMO'} maksimal ${maxPairs} pair.`); return; }
    setBusy(true); setErr(null);
    try {
      const { capital: _c, ...rest } = g as any;
      const consent = await fetch('/api/consent', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ type: 'SETUP_STEP', metadata: { step: 'REVIEW_AND_LAUNCH', marketTypes, symbols: cleanSymbols, preset }, acknowledgementText: 'Saya telah membaca, memahami, dan menyetujui dokumen ini secara sadar, sukarela, dan tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan saya serta, sejauh diperbolehkan dan dapat diberlakukan menurut hukum, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan, klaim, atau permintaan ganti rugi sehubungan dengan penggunaan layanan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, konfirmasi, izinkan, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.', consentMethod: 'EXPLICIT_CHECKBOX', consentContext: { timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Jakarta', locale: navigator.language || 'id-ID', source: 'SETUP_WIZARD' } }) }).then(x=>x.json());
      if (!consent.ok) throw new Error(consent.error || 'Persetujuan setup gagal');
      const r = await fetch('/api/bots', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ name, preset, capital, chains, guardrails: rest, marketType: primaryMarketType, marketTypes, symbols: cleanSymbols }) }).then((x) => x.json());
      if (!r.ok) { setErr(r.details?.length ? `${r.error}: ${r.details.join(' · ')}` : (r.error || 'Gagal membuat bot')); setBusy(false); return; }
      const c = await fetch(`/api/bots/${r.id}/control`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action: 'START', riskAccepted: true, consentAcknowledgement: 'Saya telah membaca, memahami, dan menyetujui dokumen ini secara sadar, sukarela, dan tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan saya serta, sejauh diperbolehkan dan dapat diberlakukan menurut hukum, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan, klaim, atau permintaan ganti rugi sehubungan dengan penggunaan layanan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, konfirmasi, izinkan, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.', consentMethod: 'EXPLICIT_CHECKBOX', consentAccepted: true, consentTypes: ['TERMS','PRIVACY','RISK','BOT_START','TRADING_RULES','ALMA_ADVISOR_REGISTRATION'], consentContext: { timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Jakarta', locale: navigator.language || 'id-ID', source: 'SETUP_WIZARD' } }) }).then((x) => x.json());
      await ctx?.refresh();
      if (!c.ok) { setErr(`Bot sudah dibuat, tetapi START tertahan: ${c.error || 'START_FAILED'}. Anda dapat kembali ke dashboard dan mencoba START lagi.`); setBusy(false); onDone?.(); return; }
      onDone?.();
    } catch (e) { setErr(e instanceof Error ? e.message : 'Terjadi kesalahan jaringan.'); }
    setBusy(false);
  };

  const providerLabel = !ai ? '…' : ai.provider === 'local-fallback' ? 'Rule-based lokal (tanpa API)' : ai.provider;
  return (
    <section className="panel">
      <div className="panelHead"><span className="panelTitle">SETUP SANDBOX</span><span className="badge">DEMO</span></div>
      <div className="panelBody">
        <div className="stepper">{STEPS.map((s, i) => <span key={s} className={i === step ? 'on' : ''}>{i + 1} · {s}</span>)}</div>

        {step === 0 && (<>
          <p className="small">Keputusan AI dieksekusi pada akun virtual dengan harga, likuiditas, slippage, dan fee yang disimulasikan. Tidak ada dana nyata.</p>
          <label className="small">Nama bot<input className="input" value={name} maxLength={40} onChange={(e) => setName(e.target.value)} /></label>
          <div className="small" style={{ marginTop: 12 }}>MODE</div>
          <div className="seg"><button className="on">DEMO / PAPER TRADING</button><button disabled title="Live trading terkunci pada versi ini">LIVE · TERKUNCI 🔒</button></div>
          <div className="small">SALDO DEMO / MODAL VIRTUAL</div>
          <div className="seg">{CAPITALS.map((c) => <button key={c} className={capital === c ? 'on' : ''} onClick={() => setCapital(c)}>{usd(c, 0)}</button>)}</div>
          <label className="small">Atur nominal sendiri (USD)
            <input className="input" type="number" min={10} max={10000000} step={10} value={capital} onChange={(e) => setCapital(Math.min(10000000, Math.max(10, Number(e.target.value) || 10)))} />
          </label>
          <div className="small">MARKET TYPE · PILIH SATU ATAU SEMUA</div><div className="marketModeGrid">{(['SPOT','FUTURES','DEX'] as const).map((m) => { const enabled = true; const on = marketTypes.includes(m); return <button type="button" key={m} disabled={!enabled} className={`marketModeCard ${on?'on':''}`} onClick={()=>setMarketTypes(cur=>on ? (cur.length>1 ? cur.filter(x=>x!==m) : cur) : [...cur,m])}><b>{m}</b><span>{m==='SPOT'?'CEX spot market':m==='FUTURES'?'Perpetual / futures':'On-chain DEX market'}</span>{on&&<small>DEMO ENABLED</small>}</button>; })}</div><div className="small">{marketTypes.length===3 ? 'DEMO MULTI-MARKET: SPOT + FUTURES + DEX aktif bersamaan. Semua eksekusi tetap virtual.' : marketTypes.length===2 ? `DEMO MULTI-MARKET: ${marketTypes.join(' + ')} aktif bersamaan. Semua eksekusi tetap virtual.` : primaryMarketType==='FUTURES' ? 'DEMO Futures memakai data market futures dan tetap virtual; tidak ada leverage REAL.' : primaryMarketType==='DEX' ? 'DEMO DEX memakai feed DexScreener / simulasi fallback dan chain screening. Eksekusi REAL DEX tetap terpisah dan tidak aktif dari DEMO.' : 'DEMO Spot memakai data market spot dan simulasi eksekusi virtual.'}</div><label className="small">PAIR PILIHAN · {selectedSymbols.length}/{maxPairs}<input className="input" value={symbols} onChange={e=>setSymbols(e.target.value.split(',').map(x=>x.trim()).filter(Boolean).slice(0,maxPairs).join(','))} placeholder="BTC/USDT,ETH/USDT,SOL/USDT" /></label>{availableSymbols.length>0&&<div className="seg" style={{maxHeight:150,overflow:'auto'}}>{availableSymbols.slice(0,Math.min(1000,maxPairs*3)).map(sym=><button type="button" key={sym} className={selectedSymbols.includes(sym)?'on':''} onClick={()=>toggleSymbol(sym)}>{sym}</button>)}</div>}<div className="small">DEMO: SPOT / FUTURES / DEX tersedia tanpa mengubah entitlement LIVE. Tier {ctx?.entitlements?.label||'DEMO'} tetap membatasi fitur LIVE dan maksimum {maxPairs} pair.</div><div className="small">CHAIN YANG DI-SCREENING</div>
          <div className="seg">{CHAINS.map(([k, l]) => <button key={k} className={chains.includes(k) ? 'on' : ''} onClick={() => toggleChain(k)}>{l}</button>)}</div>
        </>)}

        {step === 1 && (<>
          <p className="small">AI tidak pernah mengeksekusi sendiri: AI mengusulkan → Risk Engine memvalidasi → Router mensimulasikan → Execution mencatat fill.</p>
          <div className="grid2">
            <div className="metric"><div className="metricLabel">PROVIDER</div><div className="kpi" style={{ fontSize: 16 }}>{providerLabel}</div></div>
            <div className="metric"><div className="metricLabel">MODEL</div><div className="kpi" style={{ fontSize: 16 }}>{ai?.model ?? '…'}</div></div>
            <div className="metric"><div className="metricLabel">API KEY</div><div className="kpi" style={{ fontSize: 16 }}>{ai?.hasKey ? 'TERISI' : 'KOSONG'}</div></div>
          </div>
          <div className="banner">AI diatur lewat file <b>.env</b> di server (<code>AI_PROVIDER</code>, <code>AI_API_KEY</code>, <code>AI_MODEL</code>). Tanpa API key, bot tetap berjalan memakai mesin aturan lokal. Panduan AI gratis ada di <b>INSTALL.md</b>.</div>
          <button className="btn ghost" onClick={testAi} disabled={test?.busy}>{test?.busy ? 'MENGUJI…' : 'TEST KONEKSI AI'}</button>
          {test && !test.busy && <div className="log" style={{ marginTop: 10 }}>{test.ok ? <><b>[OK]</b> {test.provider} · {test.model} → {test.decision?.action} (skor {test.decision?.score})</> : <><b>[ERR]</b> {test.error}</>}</div>}
        </>)}

        {step === 2 && (<>
          <div className="seg">{(['conservative', 'balanced', 'degen'] as const).map((p) => <button key={p} className={preset === p ? 'on' : ''} onClick={() => pick(p)}>{p === 'conservative' ? 'CONSERVATIVE' : p === 'balanced' ? 'SEIMBANG' : 'DEGEN'}</button>)}</div>
          <GuardrailFields value={g} onChange={(k, v) => setG((cur) => ({ ...cur, [k]: v }))} />
          <p className="small">Nilai di luar batas aman akan otomatis dikoreksi oleh server.</p>
        </>)}

        {step === 3 && (<>
          <div className="listItem"><span>Akun</span><b>Demo · {usd(capital, 0)} virtual</b></div>
          <div className="listItem"><span>Market</span><b>{marketTypes.join(' / ')}</b></div>
          <div className="listItem"><span>Chain</span><b>{chains.join(' / ').toUpperCase()}</b></div>
          <div className="listItem"><span>AI</span><b>{providerLabel}</b></div>
          <div className="listItem"><span>Guardrails</span><b>DD {g.maxDrawdownPct}% · risk {g.riskPerTradePct}% · SL -{g.stopLossPct}% · TP +{g.takeProfitPct}% · maks {g.maxPositions} posisi</b></div>
          <div className="banner amber" style={{ marginTop: 12 }}>{RISK_NOTICE}</div>
          <label className="check"><input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} /> Saya telah membaca dan memahami Syarat Penggunaan, Kebijakan Privasi, Pemberitahuan Risiko, serta Persetujuan Pengaturan Bot. Saya memahami bahwa DEMO/PAPER menggunakan modal virtual, sedangkan trading REAL (jika kelak diaktifkan setelah seluruh gate terpenuhi) dapat menyebabkan kerugian uang nyata. Tidak ada jaminan keuntungan.</label>
        </>)}

        {err && <div className="banner red">{err}</div>}
        <div className="actions" style={{ marginTop: 14 }}>
          {step > 0 && <button className="btn ghost" onClick={() => setStep(step - 1)} disabled={busy}>← KEMBALI</button>}
          {step < 3 && <button className="btn primary" onClick={() => setStep(step + 1)}>LANJUT →</button>}
          {step === 3 && <button className="btn primary" disabled={!agree || busy} onClick={launch}>{busy ? 'MENYALAKAN…' : 'LAUNCH SANDBOX'}</button>}
        </div>
      </div>
    </section>
  );
}
