'use client';
import { useEffect, useState } from 'react';

type Side = 'OFFICIAL' | 'TRANSACTION';
type Config = {
  ok: boolean;
  enabled?: boolean;
  officialChatId?: string;
  transactionChatId?: string;
  officialTokenConfigured?: boolean;
  transactionTokenConfigured?: boolean;
};

export default function TelegramCommunicationCenter() {
  const [cfg, setCfg] = useState<Config | null>(null);
  const [officialToken, setOfficialToken] = useState('');
  const [transactionToken, setTransactionToken] = useState('');
  const [official, setOfficial] = useState('');
  const [transaction, setTransaction] = useState('');
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [testing, setTesting] = useState<Side | null>(null);
  const [msg, setMsg] = useState('');

  const load = () => fetch('/api/telegram/config', { cache: 'no-store' }).then((r) => r.json()).then((j: Config) => {
    setCfg(j);
    if (j.ok) {
      setOfficial(j.officialChatId || '');
      setTransaction(j.transactionChatId || '');
    }
  });
  useEffect(load, []);

  const save = async (side: Side) => {
    setBusy(true); setMsg('');
    try {
      const payload = side === 'OFFICIAL'
        ? { enabled: true, officialBotToken: officialToken || undefined, officialChatId: official }
        : { enabled: true, transactionBotToken: transactionToken || undefined, transactionChatId: transaction };
      const r = await fetch('/api/telegram/config', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload) });
      const j = await r.json();
      setMsg(j.ok ? `${side === 'OFFICIAL' ? 'Official' : 'Transaction'} Telegram configuration saved.` : (j.error || 'Failed to save configuration.'));
      if (j.ok) { if (side === 'OFFICIAL') setOfficialToken(''); else setTransactionToken(''); await load(); }
    } finally { setBusy(false); }
  };

  const test = async (side: Side) => {
    setTesting(side); setMsg('');
    try {
      const r = await fetch('/api/telegram/config', { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ side }) });
      const j = await r.json();
      setMsg(j.ok ? `${side === 'OFFICIAL' ? 'Official' : 'Transaction'} TEST CONNECTION SUCCESS · ${j.testId}` : `${side} TEST FAILED · ${j.error || 'FAILED'}`);
    } finally { setTesting(null); }
  };

  const clear = async (side: Side) => {
    if (!window.confirm(`Hapus token dan Chat ID ${side === 'OFFICIAL' ? 'Official' : 'Transaction'}?`)) return;
    setBusy(true); setMsg('');
    try {
      const r = await fetch('/api/telegram/config', { method: 'DELETE', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ side }) });
      const j = await r.json();
      if (j.ok) {
        if (side === 'OFFICIAL') { setOfficial(''); setOfficialToken(''); } else { setTransaction(''); setTransactionToken(''); }
        await load();
      }
      setMsg(j.ok ? `${side === 'OFFICIAL' ? 'Official' : 'Transaction'} Telegram configuration deleted.` : (j.error || 'Delete failed.'));
    } finally { setBusy(false); }
  };

  const send = async () => {
    if (!title.trim() || !body.trim()) return setMsg('Judul dan pesan wajib diisi.');
    setBusy(true);
    try {
      const f = new FormData(); f.append('title', title); f.append('body', body); if (file) f.append('file', file);
      const r = await fetch('/api/telegram/official', { method: 'POST', body: f }); const j = await r.json();
      setMsg(j.ok ? `Official broadcast terkirim. ID: ${j.broadcastId}` : (j.error || 'Gagal mengirim'));
      if (j.ok) { setTitle(''); setBody(''); setFile(null); }
    } finally { setBusy(false); }
  };

  const sideCard = (side: Side) => {
    const isOfficial = side === 'OFFICIAL';
    const tokenConfigured = isOfficial ? cfg?.officialTokenConfigured : cfg?.transactionTokenConfigured;
    const chat = isOfficial ? official : transaction;
    return <div className="card" key={side}>
      <div className="badge">{isOfficial ? '1 · OFFICIAL TELEGRAM' : '2 · TRANSACTION TELEGRAM'}</div>
      <h3>{isOfficial ? 'Official Broadcast Gateway' : 'Transaction Alert Gateway'}</h3>
      <p className="muted">Developer-only. Token disimpan terenkripsi dan tidak pernah ditampilkan kembali.</p>
      <label>Bot Token<input className="input" type="password" value={isOfficial ? officialToken : transactionToken} onChange={(e) => isOfficial ? setOfficialToken(e.target.value) : setTransactionToken(e.target.value)} placeholder={tokenConfigured ? '•••••••• · isi untuk mengganti token' : 'Bot token'} autoComplete="new-password" /></label>
      <label>{isOfficial ? 'Official Chat / Channel ID' : 'Transaction Alert Chat ID'}<input className="input" value={chat} onChange={(e) => isOfficial ? setOfficial(e.target.value) : setTransaction(e.target.value)} placeholder="-100…" /></label>
      <div className="actions">
        <button className="btn primary" disabled={busy || testing !== null} onClick={() => save(side)}>SAVE CONFIGURATION</button>
        <button className="btn ghost" disabled={busy || testing !== null} onClick={() => test(side)}>{testing === side ? 'TESTING…' : 'TEST CONNECTION'}</button>
        <button className="btn ghost" disabled={busy || testing !== null} onClick={() => clear(side)}>DELETE CONFIG</button>
      </div>
      <div className="hint">Status token: {tokenConfigured ? 'CONFIGURED' : 'NOT CONFIGURED'} · Target: {chat ? 'SET' : 'NOT SET'}</div>
    </div>;
  };

  return <section className="card section">
    <div className="badge">COMMUNICATION CENTER</div>
    <h2>Telegram Gateway</h2>
    <p className="muted">Developer-only. Official dan Transaction memakai credential Telegram terpisah dan dapat diuji, diedit, atau dihapus secara independen.</p>
    <div className="bbBroadcastGrid">{sideCard('OFFICIAL')}{sideCard('TRANSACTION')}</div>
    <hr />
    <div className="badge">OFFICIAL BROADCAST</div>
    <label>Judul<input className="input" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={160} /></label>
    <label>Pesan<textarea className="input bbBroadcastText" value={body} onChange={(e) => setBody(e.target.value)} maxLength={8000} rows={6} /></label>
    <label>Foto / Dokumen / File<input className="input" type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} /></label>
    <div className="actions"><button className="btn primary" disabled={busy || testing !== null} onClick={send}>KIRIM OFFICIAL BROADCAST</button></div>
    {msg && <div className="hint">{msg}</div>}
  </section>;
}
