"use client";
import { useEffect, useState } from 'react';

type Scope = 'DATABASE' | 'FULL_SYSTEM';
type Completeness={status:string;failures:string[];checks:{id:string;label:string;status:string;detail:string;severity:string}[]};
type Validation = { ok:boolean; state:string; phase:string; progressPct:number; message:string; backupId?:string; startedAt?:string; completedAt?:string; checks:{id:string;label:string;status:string;detail:string;expected?:unknown;actual?:unknown}[]; failures:string[]; warnings:string[]; lastError?:string };

const scopes = [
  { id: 'DATABASE' as const, title: '1. DATABASE', description: 'Backup database PostgreSQL lengkap untuk restore, audit, dan migrasi data.', items: ['Akun & profile', 'MFA encrypted secret', 'Credential references', 'Portfolio, positions & balances', 'Orders, executions & reconciliation', 'Audit, support & live chat', 'Subscription & entitlement', 'Financial Intelligence', 'Schema, constraints & sequences'] },
  { id: 'FULL_SYSTEM' as const, title: '2. SELURUH DATA', description: 'Database + seluruh master-data storage + project files yang dikonfigurasi untuk migrasi server menyeluruh.', items: ['Semua isi backup DATABASE', 'private-kyc & private-users', 'Semua master-data directory yang dikonfigurasi', 'Project files', 'Manifest, fingerprint & restore instructions'] },
];

export default function DeveloperBackup(){
  const [scope,setScope]=useState<Scope>('DATABASE');
  const [email,setEmail]=useState('');
  const [busy,setBusy]=useState(false);
  const [msg,setMsg]=useState('');
  const [ok,setOk]=useState(false);
  const [validation,setValidation]=useState<Validation|null>(null);
  const [validating,setValidating]=useState(false);
  const [completeness,setCompleteness]=useState<Completeness|null>(null);
  const [loadingCompleteness,setLoadingCompleteness]=useState(true);

  const loadValidation=async()=>{
    try{ const r=await fetch('/api/developer/backup/validation',{cache:'no-store'}); const j=await r.json(); if(r.ok&&j.ok)setValidation(j.validation); }catch{}
  };
  const loadCompleteness=async()=>{ setLoadingCompleteness(true); try{ const r=await fetch('/api/developer/backup',{cache:'no-store'}); const j=await r.json(); if(r.ok&&j.ok)setCompleteness(j.completeness); }catch{} finally{setLoadingCompleteness(false)} };
  useEffect(()=>{ loadValidation(); loadCompleteness(); },[]);
  useEffect(()=>{
    if(validation?.state!=='RUNNING') return;
    const id=window.setInterval(loadValidation,3000);
    return()=>window.clearInterval(id);
  },[validation?.state]);

  const submit=async()=>{
    setMsg(''); setOk(false);
    if(!email.trim()) return setMsg('Email tujuan wajib diisi.');
    if(!window.confirm(`Anda memilih ${scope === 'FULL_SYSTEM' ? 'SELURUH DATA' : 'DATABASE'}. Backup sensitif akan dienkripsi dan dikirim sebagai ZIP ke email tujuan. Lanjutkan?`)) return;
    setBusy(true);
    try{
      const r=await fetch('/api/developer/backup',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({destinationEmail:email,scope})});
      const j=await r.json();
      if(!r.ok||!j.ok) return setMsg(j.error||'Backup gagal dibuat/dikirim.');
      setOk(true); setMsg(`Backup ${scope === 'FULL_SYSTEM' ? 'seluruh data' : scope === 'FULL_SYSTEM' ? 'seluruh data' : 'database'} berhasil dikirim ke ${j.backup.destinationEmail}. Backup ID: ${j.backup.backupId}. SHA-256: ${j.backup.sha256}`); setEmail('');
    }catch{setMsg('Backup gagal dibuat atau dikirim.')}finally{setBusy(false); loadCompleteness()}
  };

  const runValidation=async()=>{
    setValidating(true); setMsg('');
    try{
      const r=await fetch('/api/developer/backup/validation',{method:'POST'}); const j=await r.json();
      if(!r.ok){ setMsg(j.error||'Validasi tidak dapat dimulai.'); return; }
      setValidation(j.validation); setMsg('Validasi dimulai. Status akan diperbarui otomatis setiap 3 detik.');
    }catch{setMsg('Validasi tidak dapat dimulai.')}finally{setValidating(false)}
  };

  const validationTone=validation?.state==='PASS'?'hint':validation?.state==='FAIL'?'risk':'card';
  const download=async()=>{setMsg('');if(!window.confirm('Buat ZIP backup dan download langsung ke perangkat? Backup tetap tercatat sebagai ARCHIVE_READY.'))return;setBusy(true);try{const r=await fetch('/api/developer/backup/download',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({scope})});if(!r.ok){const j=await r.json().catch(()=>({}));setMsg(j.error||'Download backup gagal.');return;}const blob=await r.blob();const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=r.headers.get('Content-Disposition')?.match(/filename="?([^";]+)"?/i)?.[1]||`blackbox-${scope.toLowerCase()}-backup.zip`;a.click();URL.revokeObjectURL(url);setOk(true);setMsg('ZIP backup berhasil dibuat dan disiapkan untuk download.');}catch{setMsg('Download backup gagal.')}finally{setBusy(false)}};
  return <section className="card section" style={{marginTop:16}}>
    <div className="badge">SECURE MIGRATION BACKUP</div><h2>Backup & Migrasi Darurat</h2>
    <p className="muted">Developer dapat membuat snapshot konsisten untuk perlindungan mandiri dan migrasi server. Setelah restore di server baru, jalankan VALIDASI untuk memastikan data, file master, integritas relasi, dan sinkronisasi exchange benar-benar selesai.</p>
    <div className="grid" style={{marginTop:12}}>
      {scopes.map(x=><button type="button" key={x.id} className={`card ${scope===x.id?'primary':''}`} style={{textAlign:'left',cursor:'pointer',border:scope===x.id?'2px solid var(--accent,#C59F22)':'1px solid rgba(255,255,255,.12)'}} onClick={()=>setScope(x.id)} disabled={busy}>
        <div className="badge">{x.title}</div><h3>{x.description}</h3><ul>{x.items.map(i=><li key={i}>{i}</li>)}</ul>
      </button>)}
    </div>
    <div className={completeness?.status==='PASS'?'hint':'risk'} style={{marginTop:12,padding:12}}><div className="badge">BACKUP COMPLETENESS CONTRACT v1.0</div><b>{loadingCompleteness?'MEMERIKSA KELENGKAPAN…':completeness?.status==='PASS'?'✓ BACKUP COMPLETE ELIGIBILITY: PASS':'✕ BACKUP BLOCKED — REQUIRED COMPONENT MISSING'}</b>{completeness?.status!=='PASS'&&completeness?.failures?.length?<ul>{completeness.failures.slice(0,12).map(x=><li key={x}>{x}</li>)}</ul>:<div className="small" style={{marginTop:6}}>DB, schema/migrations, source/config inventory, release/version, required secret references, dan master-data roots sudah lolos pemeriksaan. Nilai secret tidak pernah ditampilkan.</div>}<button className="btn ghost" style={{marginTop:8}} onClick={loadCompleteness} disabled={loadingCompleteness||busy}>REFRESH COMPLETENESS</button></div>
    <div className="risk" style={{marginTop:12}}>PENTING: backup dapat berisi data sangat sensitif. ZIP dienkripsi AES-256-GCM. BACKUP_ENCRYPTION_KEY dan DATA_ENCRYPTION_KEY tidak pernah dimasukkan ke ZIP, email, UI, atau audit log.</div>
    <label style={{display:'grid',gap:6,marginTop:12}}><span className="small">EMAIL TUJUAN BACKUP</span><input className="input" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="migration@contoh.com" maxLength={320} disabled={busy}/></label>
    {msg&&<div className={ok?'hint':'risk'} style={{marginTop:10}}>{msg}</div>}
    <div className="actions"><button className="btn primary" disabled={busy||!email.trim()||scope==='FULL_SYSTEM'&&completeness?.status!=='PASS'} onClick={submit}>{busy?'MEMBUAT & MENGIRIM BACKUP…':scope==='FULL_SYSTEM'?'BACKUP SELURUH DATA & KIRIM EMAIL':'BACKUP DATABASE & KIRIM EMAIL'}</button><button className="btn ghost" disabled={busy||(scope==='FULL_SYSTEM'&&completeness?.status!=='PASS')} onClick={download}>DOWNLOAD ZIP</button></div>
    <p className="small" style={{marginTop:10}}>Backup database menggunakan PostgreSQL custom dump untuk restore schema/data/sequences. FULL_SYSTEM menambahkan master data storage yang dikonfigurasi. Jika arsip melebihi batas attachment SMTP, backup gagal dengan aman dan tidak dilaporkan sebagai terkirim.</p>

    <div className="card" style={{marginTop:18}}>
      <div className="badge">POST-RESTORE VALIDATION</div>
      <h2 style={{marginBottom:6}}>Cek Status Validasi Data</h2>
      <p className="muted">Gunakan tombol ini di server baru setelah proses restore. Validator mengecek fingerprint tabel, jumlah data, foreign-key integrity, master-file SHA-256, exchange reconciliation, account health, dan memastikan REAL trading tetap terkunci selama migrasi.</p>
      <div className="actions" style={{marginTop:10}}>
        <button className="btn primary" onClick={runValidation} disabled={validating||validation?.state==='RUNNING'}>{validating||validation?.state==='RUNNING'?'VALIDASI SEDANG BERJALAN…':'CEK STATUS & VALIDASI SEMUA DATA'}</button>
        <button className="btn ghost" onClick={loadValidation} disabled={validation?.state==='RUNNING'}>REFRESH STATUS</button>
      </div>
      {validation&&<div className={validationTone} style={{marginTop:12,padding:12}}>
        <div style={{display:'flex',justifyContent:'space-between',gap:12,flexWrap:'wrap'}}><b>{validation.state==='PASS'?'✓ VALIDATION PASS':validation.state==='FAIL'?'✕ VALIDATION FAIL':validation.state==='RUNNING'?'⟳ SINKRONISASI / VALIDASI BERJALAN':'STATUS VALIDASI'}</b><span>{validation.progressPct}% · {validation.phase}</span></div>
        <div style={{marginTop:6}}>{validation.message}</div>
        {validation.backupId&&<div className="small" style={{marginTop:6}}>Backup ID: {validation.backupId}</div>}
        {validation.startedAt&&<div className="small">Mulai: {new Date(validation.startedAt).toLocaleString('id-ID')}{validation.completedAt?` · Selesai: ${new Date(validation.completedAt).toLocaleString('id-ID')}`:''}</div>}
        {validation.failures.length>0&&<div style={{marginTop:10}}><b>KEGAGALAN / MISMATCH:</b><ul>{validation.failures.slice(0,50).map(x=><li key={x}>{x}</li>)}</ul></div>}
        {validation.warnings.length>0&&<div style={{marginTop:10}}><b>WARNING / MASIH PERLU SINKRONISASI:</b><ul>{validation.warnings.slice(0,50).map(x=><li key={x}>{x}</li>)}</ul></div>}
        {validation.checks.length>0&&<div style={{overflowX:'auto',marginTop:10}}><table><thead><tr><th>Check</th><th>Status</th><th>Detail</th></tr></thead><tbody>{validation.checks.slice(-100).map(c=><tr key={c.id}><td>{c.label}</td><td><b>{c.status}</b></td><td>{c.detail}</td></tr>)}</tbody></table></div>}
        {validation.lastError&&<div className="risk" style={{marginTop:10}}>Validator berhenti karena error runtime. Detail internal tidak boleh dipakai sebagai kredensial; periksa server log secara aman.</div>}
      </div>}
      {!validation&&<div className="small" style={{marginTop:10}}>Belum ada restore validation receipt pada server ini. Restore harus dijalankan melalui prosedur migrasi sebelum status dapat dinyatakan PASS.</div>}
    </div>
  </section>
}
