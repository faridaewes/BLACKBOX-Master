'use client';
import { useState } from 'react';

// Logo resmi BLACKBOX (full color). Varian compact memakai mark kubus agar
// tetap tajam di navigasi, footer, dan header yang sempit.
const MARK_SRC = '/brand/blackbox-mark.png';
const FULL_FALLBACK = '/brand/blackbox-logo.png';

export default function BlackboxLogo({ compact = false }: { compact?: boolean }) {
  const [logoSrc, setLogoSrc] = useState(compact ? MARK_SRC : '/api/public/branding/logo');
  const size = compact ? 34 : 56;
  return <span className={`bbLogo ${compact ? 'bbLogoCompact' : 'bbLogoFull'}`} aria-label="BLACKBOX Crypto">
    <img
      src={logoSrc}
      alt="BLACKBOX Crypto logo"
      height={size}
      width={compact ? size : undefined}
      style={{ height: size, width: compact ? size : 'auto', objectFit: 'contain' }}
      onError={() => { const fallback = compact ? MARK_SRC : FULL_FALLBACK; if (logoSrc !== fallback) setLogoSrc(fallback); }}
    />
  </span>;
}
