'use client';

import { useEffect, useState } from 'react';

type ReleaseInfo = { ok: boolean; version?: string; minVersion?: string; androidDownloadUrl?: string; error?: string };

export default function AndroidReleaseCard() {
  const [release, setRelease] = useState<ReleaseInfo | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/mobile/release', { cache: 'no-store' })
      .then(async (r) => (await r.json()) as ReleaseInfo)
      .then(setRelease)
      .catch(() => setRelease({ ok: false, error: 'RELEASE_INFO_UNAVAILABLE' }))
      .finally(() => setLoading(false));
  }, []);

  const configured = Boolean(release?.ok && release.androidDownloadUrl);
  return (
    <section className="panel">
      <div className="panelBody">
        <h2>BLACKBOX CRYPTO ANDROID</h2>
        <p className="hint">Release Android dikelola terpisah dari Website. URL APK production harus menunjuk ke APK yang sudah ditandatangani dan diverifikasi.</p>
        {loading && <p className="small">Memeriksa release Android…</p>}
        {!loading && release?.ok && <p className="small">Versi release: <b>{release.version}</b> · Minimum: <b>{release.minVersion}</b></p>}
        {!loading && !configured && <p className="small">Download belum tersedia. Administrator/developer harus mengonfigurasi <code>ANDROID_DOWNLOAD_URL</code> dengan HTTPS URL APK release.</p>}
        {configured && (
          <a className="btn gold" href="/api/mobile/android/download" rel="noreferrer">DOWNLOAD ANDROID APK</a>
        )}
      </div>
    </section>
  );
}
