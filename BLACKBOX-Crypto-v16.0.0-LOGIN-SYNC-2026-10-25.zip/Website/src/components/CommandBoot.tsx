'use client';
import { useEffect, useState } from 'react';

const BOOT_LINES = [
  ['MARKET ENGINE', 'ONLINE'],
  ['AI BRAIN', 'ONLINE'],
  ['RISK ENGINE', 'ARMED'],
  ['EXECUTION ROUTER', 'STANDBY'],
  ['SECURITY CORE', 'ARMED'],
];

export default function CommandBoot() {
  const [open, setOpen] = useState(false);
  const [ready, setReady] = useState(0);
  useEffect(() => {
    try { if (sessionStorage.getItem('bbx-v4-boot')) return; sessionStorage.setItem('bbx-v4-boot', '1'); setOpen(true); } catch { setOpen(true); }
    const t = window.setInterval(() => setReady((n) => Math.min(n + 1, BOOT_LINES.length)), 260);
    const done = window.setTimeout(() => setOpen(false), 2100);
    return () => { window.clearInterval(t); window.clearTimeout(done); };
  }, []);
  if (!open) return null;
  return <div className="bbBoot" role="status" aria-live="polite">
    <div className="bbBootGrid" />
    <div className="bbBootCore"><span className="bbBootRing r1"/><span className="bbBootRing r2"/><span className="bbBootGlyph">◉</span></div>
    <div className="bbBootCopy">
      <div className="bbBootEyebrow">BLACKBOX // AUTONOMOUS CRYPTO OPERATIONS</div>
      <h1>COMMAND CENTER <span>V4</span></h1>
      <div className="bbBootLines">{BOOT_LINES.map(([label, status], i) => <div className={i < ready ? 'ready' : ''} key={label}><span>{label}</span><b>{i < ready ? status : 'CHECKING'}</b></div>)}</div>
      <div className="bbBootProgress"><i style={{ width: `${Math.round((ready / BOOT_LINES.length) * 100)}%` }} /></div>
      <div className="bbBootFoot">SYSTEM INITIALIZATION · {Math.round((ready / BOOT_LINES.length) * 100)}%</div>
    </div>
    <button className="bbBootSkip" onClick={() => setOpen(false)}>SKIP BOOT</button>
  </div>;
}
