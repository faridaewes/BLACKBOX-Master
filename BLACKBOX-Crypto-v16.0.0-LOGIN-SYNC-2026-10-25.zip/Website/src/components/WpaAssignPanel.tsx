'use client';
import { useCallback, useEffect, useState } from 'react';

export default function WpaAssignPanel() {
  const [profiles, setProfiles] = useState<any[]>([]);
  const [candidates, setCandidates] = useState<any[]>([]);
  const [userId, setUserId] = useState('');
  const [title, setTitle] = useState('Wakil Penasihat Berjangka');
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const j = await fetch('/api/developer/wpa-assign', { cache: 'no-store' }).then((r) => r.json());
    if (j.ok) {
      setProfiles(j.profiles || []);
      setCandidates(j.candidates || []);
    }
  }, []);
  useEffect(() => {
    load();
  }, [load]);

  const act = async (action: string, id: string, extra?: any) => {
    setBusy(true);
    setMsg('');
    try {
      const r = await fetch('/api/developer/wpa-assign', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ action, userId: id, title, ...extra }),
      });
      const j = await r.json();
      setMsg(j.ok ? j.message || 'OK' : j.error || 'Gagal');
      await load();
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel section" id="wpa-assign">
      <div className="panelHead">
        <span className="panelTitle">WPA ASSIGNMENT · Angkat / cabut status WPA dari akun USER</span>
        <span className="small">Developer atau petugas berizin WPA_MANAGE</span>
      </div>
      <div className="panelBody formGrid">
        <p className="hint">
          User yang diangkat mendapat menu <b>WPA Saya</b> untuk mengatur data profil sendiri. Cabut
          status mengembalikan akun ke user biasa (profil diarsipkan).
        </p>
        <label>
          Pilih USER
          <select className="input" value={userId} onChange={(e) => setUserId(e.target.value)}>
            <option value="">— pilih user aktif —</option>
            {candidates.map((u) => (
              <option key={u.id} value={u.id}>
                {u.name} · {u.email}
              </option>
            ))}
          </select>
        </label>
        <label>
          Title awal
          <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} />
        </label>
        <div className="actions">
          <button
            className="btn primary"
            disabled={busy || !userId}
            onClick={() => act('ASSIGN', userId, { workflowStatus: 'DRAFT' })}
          >
            Jadikan WPA (Draft)
          </button>
          <button
            className="btn"
            disabled={busy || !userId}
            onClick={() => act('ASSIGN', userId, { workflowStatus: 'PUBLISHED' })}
          >
            Jadikan WPA + Publish
          </button>
        </div>
        {msg && <div className="banner">{msg}</div>}
      </div>
      <div className="panelBody">
        <div className="panelTitle" style={{ marginBottom: 8 }}>
          WPA terhubung ke akun
        </div>
        {profiles
          .filter((p) => p.userId)
          .map((p) => (
            <div key={p.id} className="eventRow" style={{ flexWrap: 'wrap', gap: 8 }}>
              <b>{p.name}</b>
              <span className="muted">{p.user?.email}</span>
              <span className="pill">{p.workflowStatus}</span>
              <span className="muted">{p.active ? 'ACTIVE' : 'OFF'}</span>
              <button
                className="btn"
                disabled={busy}
                onClick={() => act('UPDATE', p.userId, { workflowStatus: 'PUBLISHED', active: true })}
              >
                Publish
              </button>
              <button className="btn danger" disabled={busy} onClick={() => act('REVOKE', p.userId)}>
                Cabut WPA → User
              </button>
            </div>
          ))}
        {!profiles.filter((p) => p.userId).length && (
          <div className="muted">Belum ada WPA yang terhubung ke akun user.</div>
        )}
      </div>
    </section>
  );
}
