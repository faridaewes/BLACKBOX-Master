'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';

export type ActResult = { ok: boolean; error?: string };
export type BotCtx = {
  loading: boolean;
  error: string | null;
  bots: any[];
  entitlements: any;
  tierExpiresAt: string | null;
  profile: any | null;
  botId: string | null;
  view: any | null;          // hasil GET /api/bots/:id
  ai: any | null;            // hasil GET /api/ai/status
  verificationRequired: boolean;
  verification: any | null;
  refresh: () => Promise<void>;
  selectBot: (id: string) => void;
  act: (action: string, extra?: Record<string, unknown>) => Promise<ActResult>;
  deleteBot: (id: string) => Promise<ActResult>;
  resetDemo: () => Promise<ActResult>;
  call: (url: string, method?: string, body?: unknown) => Promise<any>;
};

const Ctx = createContext<BotCtx | null>(null);
export const useBot = () => useContext(Ctx);

async function api(url: string, method = 'GET', body?: unknown) {
  const r = await fetch(url, { method, headers: body ? { 'content-type': 'application/json' } : undefined, body: body ? JSON.stringify(body) : undefined, cache: 'no-store' });
  if (r.status === 401 && typeof window !== 'undefined') { window.location.href = '/login'; throw new Error('UNAUTHENTICATED'); }
  let j: any = null;
  try { j = await r.json(); } catch { /* bukan JSON */ }
  if (!j) return { ok: false, error: `HTTP ${r.status}` };
  return j;
}

export default function BotProvider({ children }: { children: React.ReactNode }) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [bots, setBots] = useState<any[]>([]);
  const [entitlements, setEnt] = useState<any>(null);
  const [tierExpiresAt, setTierExpiresAt] = useState<string | null>(null);
  const [profile, setProfile] = useState<any | null>(null);
  const [botId, setBotId] = useState<string | null>(null);
  const [view, setView] = useState<any | null>(null);
  const [ai, setAi] = useState<any | null>(null);
  const [verificationRequired, setVerificationRequired] = useState(false);
  const [verification, setVerification] = useState<any | null>(null);
  const idRef = useRef<string | null>(null);
  const busy = useRef(false);

  const refresh = useCallback(async () => {
    if (busy.current) return; busy.current = true;
    try {
      const status = await api('/api/auth/status');
      if (status.ok) { setVerification(status); setVerificationRequired(!!status.verificationRequired); }
      const list = await api('/api/bots');
      if (!list.ok) {
        if (list.error === 'EMAIL_PHONE_VERIFICATION_REQUIRED') setVerificationRequired(true);
        setError(list.error || 'Gagal memuat bot'); return;
      }
      setBots(list.bots); setEnt(list.entitlements); setTierExpiresAt(list.tierExpiresAt || null); setProfile(list.profile || null);
      let id = idRef.current;
      if (!id || !list.bots.some((b: any) => b.id === id)) id = list.bots[0]?.id ?? null;
      idRef.current = id; setBotId(id);
      if (id) {
        const v = await api(`/api/bots/${id}`);
        if (v.ok) { setView(v); setError(null); } else setError(v.error || 'Gagal memuat data bot');
      } else { setView(null); setError(null); }
    } catch (e: any) { if (e?.message !== 'UNAUTHENTICATED') setError('Koneksi ke server terputus. Mencoba lagi…'); }
    finally { busy.current = false; setLoading(false); }
  }, []);

  useEffect(() => {
    refresh();
    api('/api/ai/status').then((j) => { if (j.ok) setAi(j); }).catch(() => {});
    const t = setInterval(() => { if (typeof document === 'undefined' || document.visibilityState === 'visible') refresh(); }, 7000);
    return () => clearInterval(t);
  }, [refresh]);

  const selectBot = useCallback((id: string) => { idRef.current = id; setBotId(id); setView(null); refresh(); }, [refresh]);

  const act = useCallback(async (action: string, extra: Record<string, unknown> = {}): Promise<ActResult> => {
    if (!idRef.current) return { ok: false, error: 'Belum ada bot.' };
    const j = await api(`/api/bots/${idRef.current}/control`, 'POST', { action, ...extra });
    await refresh();
    return { ok: !!j.ok, error: j.error };
  }, [refresh]);

  const deleteBot = useCallback(async (id: string): Promise<ActResult> => {
    const j = await api(`/api/bots/${id}`, 'DELETE');
    if (j.ok) {
      if (idRef.current === id) idRef.current = null;
      await refresh();
    }
    return { ok: !!j.ok, error: j.error };
  }, [refresh]);

  const resetDemo = useCallback(async (): Promise<ActResult> => {
    if (!idRef.current) return { ok: false, error: 'Belum ada bot.' };
    const j = await api(`/api/bots/${idRef.current}/reset-demo`, 'POST', { confirm: true });
    if (j.ok) await refresh();
    return { ok: !!j.ok, error: j.error };
  }, [refresh]);

  const call = useCallback(async (url: string, method = 'GET', body?: unknown) => { const j = await api(url, method, body); await refresh(); return j; }, [refresh]);

  const value = useMemo<BotCtx>(() => ({ loading, error, bots, entitlements, tierExpiresAt, profile, botId, view, ai, verificationRequired, verification, refresh, selectBot, act, deleteBot, resetDemo, call }), [loading, error, bots, entitlements, tierExpiresAt, profile, botId, view, ai, verificationRequired, verification, refresh, selectBot, act, deleteBot, resetDemo, call]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
