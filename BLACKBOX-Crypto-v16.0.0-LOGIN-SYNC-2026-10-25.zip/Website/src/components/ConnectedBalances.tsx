'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';

type ExchangeAsset={asset:string;total:number;free:number;used:number};
type ExchangeBalance={id:string;provider?:string;label?:string;marketType?:string;status:string;checkedAt:string;assets:ExchangeAsset[];stableTotal:number;error?:string};
type WalletBalance={id:string;provider:string;address:string;status:string;checkedAt:string;network?:string;chain?:string;chainId?:number|null;assets:{asset:string;amount:number;chain:string;native:boolean}[];error?:string};

type Props={compact?:boolean};
const fmt=(n:number,max=6)=>new Intl.NumberFormat('en-US',{maximumFractionDigits:max}).format(Number.isFinite(n)?n:0);
const short=(a:string)=>a.length>18?`${a.slice(0,8)}…${a.slice(-6)}`:a;

export default function ConnectedBalances({compact=false}:Props){
 const [data,setData]=useState<{exchanges:ExchangeBalance[];wallets:WalletBalance[];serverTime:string;refreshAfterMs:number}|null>(null);
 const [loading,setLoading]=useState(true); const [refreshing,setRefreshing]=useState(false); const [error,setError]=useState('');
 const load=useCallback(async(silent=false)=>{if(silent)setRefreshing(true);else setLoading(true);try{const r=await fetch('/api/connections/balances',{cache:'no-store'});const j=await r.json();if(!j.ok)throw new Error(j.error||'BALANCE_READ_FAILED');setData(j);setError('')}catch(e:any){setError(e?.message||'BALANCE_READ_FAILED')}finally{setLoading(false);setRefreshing(false)}},[]);
 useEffect(()=>{load(false);const id=window.setInterval(()=>load(true),15000);return()=>window.clearInterval(id)},[load]);
 const connected=useMemo(()=>[...(data?.exchanges||[]),...(data?.wallets||[])].filter(x=>x.status==='CONNECTED').length,[data]);
 const totalSources=(data?.exchanges?.length||0)+(data?.wallets?.length||0);
 if(loading&&!data)return <section className="panel section"><div className="panelHead"><span className="panelTitle">CONNECTED ASSETS</span><span className="pill amber">SYNC…</span></div><div className="panelBody"><p className="small">Membaca saldo koneksi secara aman…</p></div></section>;
 return <section className="panel section connectedBalancePanel">
   <div className="panelHead"><div><span className="panelTitle">CONNECTED ASSETS</span><div className="mini">Exchange + wallet · auto refresh 15s · {connected}/{totalSources} healthy</div></div><button className="btn ghost" onClick={()=>load(true)} disabled={refreshing}>{refreshing?'SYNC…':'REFRESH'}</button></div>
   <div className="panelBody">
    {error&&<div className="banner amber">Balance sync: {error}</div>}
    {!totalSources&&<div className="hint">Belum ada exchange atau wallet yang terhubung. Hubungkan di <a href="/dashboard/connections">Connections</a>.</div>}
    {data?.exchanges?.map(x=><div className="balanceSource" key={`e-${x.id}`}>
      <div className="balanceSourceHead"><div><b>{x.label||x.provider}</b><span className="mini"> · {x.provider} · {x.marketType}</span></div><span className={`pill ${x.status==='CONNECTED'?'green':'red'}`}>{x.status==='CONNECTED'?'CONNECTED':'ERROR'}</span></div>
      {x.error?<div className="mini negative">{x.error}</div>:<div className="balanceAssets">{x.assets.slice(0,compact?5:12).map(a=><div className="balanceAsset" key={a.asset}><span>{a.asset}</span><b>{fmt(a.total)}</b><small>free {fmt(a.free)} · used {fmt(a.used)}</small></div>)}</div>}
    </div>)}
    {data?.wallets?.map(x=><div className="balanceSource" key={`w-${x.id}`}>
      <div className="balanceSourceHead"><div><b>{x.provider}</b><span className="mini"> · {x.network||x.chain} · {short(x.address)}</span></div><span className={`pill ${x.status==='CONNECTED'?'green':'red'}`}>{x.status==='CONNECTED'?'CONNECTED':'ERROR'}</span></div>
      {x.error?<div className="mini negative">{x.error}</div>:<div className="balanceAssets">{x.assets.map(a=><div className="balanceAsset" key={`${a.chain}-${a.asset}`}><span>{a.asset}</span><b>{fmt(a.amount)}</b><small>native · {a.chain}</small></div>)}</div>}
    </div>)}
    {data?.serverTime&&<div className="mini" style={{marginTop:10}}>Last server sync: {new Date(data.serverTime).toLocaleTimeString('id-ID')}</div>}
   </div>
 </section>
}
