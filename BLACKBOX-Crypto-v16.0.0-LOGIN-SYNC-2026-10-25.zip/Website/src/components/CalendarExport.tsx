"use client";
import { useRef } from 'react';

type Row={date:string;equity:number;pnl:number;pnlPercent:number;trades:number;tradesOpened:number;tradesClosed:number;activeTrades:number;activeVolumeUsd:number;volumeUsd:number;growthUsd:number;growthPercent:number;cumulativePnl:number;winRate:number};
export default function CalendarExport({month,rows}:{month:string;rows:Row[]}){
  const ref=useRef<HTMLDivElement>(null);
  const exportImage=async()=>{
    const canvas=document.createElement('canvas'); canvas.width=1600; canvas.height=1000; const ctx=canvas.getContext('2d'); if(!ctx)return;
    ctx.fillStyle='#0E0D0A';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.fillStyle='#ffffff';ctx.font='700 42px Arial';ctx.fillText('BLACKBOX CRYPTO — History Growth',60,75);
    ctx.fillStyle='#A9A38F';ctx.font='24px Arial';ctx.fillText(`${month} · Portfolio performance calendar`,60,115);
    const totalVolume=rows.reduce((n,x)=>n+x.volumeUsd,0), cumulative=rows.at(-1)?.cumulativePnl||0, win=rows.at(-1)?.winRate||0;
    ctx.fillStyle='#F1ECDE';ctx.font='700 26px Arial';ctx.fillText(`Volume $${totalVolume.toFixed(2)}   •   Cumulative PnL $${cumulative.toFixed(2)}   •   Win rate ${win.toFixed(1)}%`,60,165);
    const items=rows.slice(-18); const w=480,h=92,gap=18; items.forEach((x,i)=>{const col=i%3,row=Math.floor(i/3),xx=60+col*(w+gap),yy=205+row*(h+gap);ctx.strokeStyle='#4D4425';ctx.strokeRect(xx,yy,w,h);ctx.fillStyle='#fff';ctx.font='700 20px Arial';ctx.fillText(x.date,xx+16,yy+28);ctx.fillStyle=x.growthUsd>=0?'#F0D67F':'#ff7b86';ctx.font='700 24px Arial';ctx.fillText(`${x.growthUsd>=0?'+':''}$${x.growthUsd.toFixed(2)}`,xx+16,yy+58);ctx.fillStyle='#A9A38F';ctx.font='15px Arial';ctx.fillText(`Equity $${x.equity.toFixed(2)} · +${x.tradesOpened} / -${x.tradesClosed} · ${x.activeTrades} active`,xx+190,yy+28);ctx.fillText(`Growth $${x.growthUsd.toFixed(2)} (${x.growthPercent.toFixed(2)}%) · Volume $${x.volumeUsd.toFixed(0)}`,xx+190,yy+54);});
    ctx.fillStyle='#A9A38F';ctx.font='16px Arial';ctx.fillText('Performance history exported by BLACKBOX Crypto. Past performance does not guarantee future results.',60,960);
    canvas.toBlob(blob=>{if(!blob)return;const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`blackbox-history-growth-${month}.png`;a.click();URL.revokeObjectURL(url);},'image/png');
  };
  return <div ref={ref} style={{display:'flex',gap:10,flexWrap:'wrap',marginTop:18}}><a className="btn" href={`/api/portfolio/export?format=pdf&month=${month}`}>Export Portfolio PDF</a><a className="btn" href={`/api/portfolio/export?format=xlsx&month=${month}`}>Export Excel</a><button className="btn gold" onClick={exportImage}>Export Gambar (PNG)</button></div>;
}
