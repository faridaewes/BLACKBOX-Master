'use client';
import { useEffect, useState } from 'react';

type Profile = { id:string; name:string; role:'DEVELOPER'|'ADMIN'|'USER'; roleLabel:string; tier:string; tierExpiresAt:string|null; tierStatus:'ACTIVE'|'EXPIRED'|'NONE' };
function dateLabel(v:string|null){ return v ? new Date(v).toLocaleDateString('id-ID',{day:'2-digit',month:'short',year:'numeric'}) : null; }
export default function WelcomeTransition({children}:{children:React.ReactNode}){
  const [profile,setProfile]=useState<Profile|null>(null); const [show,setShow]=useState(false); const [done,setDone]=useState(false);
  useEffect(()=>{ let live=true; fetch('/api/profile',{cache:'no-store'}).then(r=>r.json()).then(j=>{ if(!live||!j.ok)return; const p=j.profile as Profile; setProfile(p); const key=`bbx-welcome:${p.id}`; if(sessionStorage.getItem(key)==='1'){setDone(true);return;} setShow(true); const t=window.setTimeout(()=>{sessionStorage.setItem(key,'1');setShow(false);setDone(true)},2600); return ()=>window.clearTimeout(t); }).catch(()=>setDone(true)); return ()=>{live=false}; },[]);
  if(!profile || done) return <>{children}</>;
  if(!show) return <>{children}</>;
  const identity=profile.role==='USER'?profile.name:`${profile.name} (${profile.roleLabel})`;
  const expiry=dateLabel(profile.tierExpiresAt);
  return <div className="bbWelcome" role="status" aria-live="polite"><div className="bbWelcomeGrid"/><div className="bbWelcomeOrb"><i/><i/><i/></div><div className="bbWelcomeCard"><div className="bbWelcomeEyebrow">BLACKBOX CRYPTO // SECURE SESSION</div><div className="bbWelcomeLogo">BLACK<span>BOX</span></div><div className="bbWelcomeLine"/><div className="bbWelcomeKicker">WELCOME BACK</div><h1>{profile.name}</h1><div className="bbWelcomeIdentity">{identity}</div><div className="bbWelcomeMeta"><span>ACCESS <b>{profile.role}</b></span><span>TIER <b>{profile.tier}</b></span>{expiry&&<span>{profile.tierStatus==='EXPIRED'?'EXPIRED':'VALID UNTIL'} <b>{expiry}</b></span>}</div><div className="bbWelcomeStatus"><i/> SECURE SESSION ESTABLISHED <span>•</span> LOADING COMMAND CENTER</div><div className="bbWelcomeProgress"><i/></div></div></div>;
}
