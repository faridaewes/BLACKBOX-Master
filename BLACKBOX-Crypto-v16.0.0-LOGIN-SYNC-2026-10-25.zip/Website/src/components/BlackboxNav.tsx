'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useBot } from './BotProvider';
import { usd } from '@/lib/format';
import SystemNotice from './SystemNotice';
import ProfileIdentity from './ProfileIdentity';
import BlackboxLogo from './BlackboxLogo';

type NavItem = { href:string; label:string; icon:string };
const items: NavItem[] = [
  // —— Command & trading (single sources of truth) ——
  {href:'/dashboard', icon:'command', label:'COMMAND'},
  {href:'/dashboard/superapp', icon:'command', label:'SUPERAPP'},
  {href:'/dashboard/bot-control', icon:'bot', label:'BOT CONTROL'},
  {href:'/dashboard/portfolio', icon:'portfolio', label:'PORTFOLIO'},
  {href:'/dashboard/trades', icon:'trades', label:'TRADES'},
  {href:'/dashboard/paper', icon:'paper', label:'PAPER LAB'},
  // —— Markets (one primary entry; tools linked from screener) ——
  {href:'/dashboard/screener', icon:'scan', label:'MARKETS'},
  {href:'/dashboard/market-data-trust', icon:'shield', label:'MARKET DATA TRUST'},
  {href:'/dashboard/dex-intelligence', icon:'radar', label:'DEX INTELLIGENCE'},
  {href:'/dashboard/dex-signatures', icon:'lock', label:'DEX SIGNATURES'},
  {href:'/dashboard/dex-autonomy', icon:'shield', label:'DEX AUTONOMY'},
  // —— Intelligence ——
  {href:'/dashboard/ai-brain', icon:'brain', label:'AI BRAIN'},
  {href:'/dashboard/ai-market-intelligence', icon:'brain', label:'AI MARKET INTEL'},
  {href:'/dashboard/trading-intelligence', icon:'chart', label:'TRADING INTEL'},
  {href:'/dashboard/daily-signals', icon:'chart', label:'SIGNAL DAILY'},
  {href:'/dashboard/router', icon:'route', label:'ROUTER'},
  {href:'/dashboard/risk-intelligence', icon:'shield', label:'RISK'},
  {href:'/dashboard/universal-scanner', icon:'scan', label:'UNIVERSAL SCANNER'},
  {href:'/dashboard/alert-intelligence', icon:'radar', label:'ALERT INTELLIGENCE'},
  {href:'/dashboard/decision-os', icon:'brain', label:'DECISION OS'},
  {href:'/dashboard/control-center', icon:'shield', label:'CONTROL CENTER'},
  // —— Account & growth ——
  {href:'/dashboard/referral', icon:'link', label:'REFERRAL'},
  {href:'/dashboard/partner', icon:'link', label:'PARTNER'},
  {href:'/dashboard/access', icon:'access', label:'ACCESS CODE'},
  {href:'/dashboard/payments', icon:'finance', label:'PAYMENTS'},
  {href:'/dashboard/kyc', icon:'shield', label:'KYC'},
  {href:'/dashboard/connections', icon:'link', label:'CONNECTIONS'},
  {href:'/dashboard/support', icon:'support', label:'SUPPORT'},
  {href:'/dashboard/live-chat', icon:'support', label:'LIVE CHAT'},
  {href:'/dashboard/history', icon:'history', label:'HISTORY'},
  {href:'/dashboard/calendar', icon:'calendar', label:'CALENDAR'},
  {href:'/dashboard/wpa-profile', icon:'shield', label:'WPA SAYA'},
  {href:'/dashboard/settings', icon:'settings', label:'SETTINGS'},
  {href:'/dashboard/android', icon:'download', label:'ANDROID APP'},
  {href:'/dashboard/security', icon:'lock', label:'SECURITY'},
];
const mobilePrimary = items.filter((item) => ['/dashboard','/dashboard/bot-control','/dashboard/screener','/dashboard/trades','/dashboard/support'].includes(item.href));
const mobileMore = items.filter((item) => !mobilePrimary.some((p) => p.href === item.href));
const ALMAI_REFERRAL_DEFAULT = 'https://almai.id/referral/Indonesia';

function NavIcon({name}:{name:string}) {
  const paths: Record<string, React.ReactNode> = {
    bot:<><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M5 8l2 2M17 8l2 2M5 16l2-2M17 16l2-2"/></>,
    command:<><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/></>,
    scan:<><circle cx="11" cy="11" r="6"/><path d="m16 16 4 4M8 11h6M11 8v6"/></>,
    radar:<><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="M12 2v4M22 12h-4M12 22v-4M2 12h4"/></>,
    trades:<><path d="M4 7h12M12 3l4 4-4 4M20 17H8M12 13l-4 4 4 4"/></>,
    chart:<><path d="M4 19V5M4 19h16"/><path d="m7 15 3-4 3 2 5-7"/></>,
    finance:<><path d="M4 19h16M6 16V8M10 16V5M14 16v-7M18 16v-11"/><path d="M5 8l5-3 4 2 5-4"/></>,
    brain:<><path d="M9 4a3 3 0 0 0-3 3v1a3 3 0 0 0-2 5 3 3 0 0 0 3 3h2V4ZM15 4a3 3 0 0 1 3 3v1a3 3 0 0 1 2 5 3 3 0 0 1-3 3h-2V4ZM9 8h6M9 12h6M9 16h6"/></>,
    paper:<><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 11h8M8 15h5"/></>,
    route:<><path d="M4 6h10a3 3 0 0 1 3 3v9M17 18l-3-3M17 18l3-3M20 6h-6M14 6l3-3"/></>,
    access:<><path d="M4 7h16M7 4v6M17 14v6M4 17h16"/></>,
    shield:<><path d="M12 3 19 6v5c0 4.5-2.8 7.3-7 10-4.2-2.7-7-5.5-7-10V6l7-3Z"/><path d="m9 12 2 2 4-4"/></>,
    support:<><circle cx="12" cy="12" r="9"/><path d="M8 15c1.1 1 2.3 1.5 4 1.5s2.9-.5 4-1.5M8.5 10h.01M15.5 10h.01"/></>,
    link:<><path d="M10 13a4 4 0 0 0 6 0l2-2a4 4 0 0 0-6-6l-1 1M14 11a4 4 0 0 0-6 0l-2 2a4 4 0 0 0 6 6l1-1"/></>,
    settings:<><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1l2-1.5-2-3.5-2.3 1a8 8 0 0 0-1.8-1L14.5 3h-5L9 6a8 8 0 0 0-1.8 1L5 6 3 9.5 5.1 11a7 7 0 0 0 0 2L3 14.5 5 18l2.2-1a8 8 0 0 0 1.8 1l.5 3h5l.5-3a8 8 0 0 0 1.8-1l2.2 1 2-3.5-2-1.5c0-.3.1-.7.1-1Z"/></>,
    lock:<><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/></>,
    download:<><path d="M12 3v11M8 10l4 4 4-4M5 20h14"/></>,
    portfolio:<><circle cx="12" cy="12" r="8"/><path d="M5 15l4-4 3 2 5-6M17 7h-4M17 7v4"/></>,
    history:<><path d="M4 12a8 8 0 1 0 2.3-5.6"/><path d="M4 5v5h5M12 7v5l3 2"/></>,
    calendar:<><rect x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4M16 3v4M4 9h16M8 13h.01M12 13h.01M16 13h.01M8 17h.01M12 17h.01"/></>,
    more:<><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>,
  };
  return <svg className="navIcon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>;
}

export default function BlackboxNav() {
  const path = usePathname();
  const ctx = useBot();
  const [moreOpen, setMoreOpen] = useState(false);
  const [almaiReferral,setAlmaiReferral]=useState(ALMAI_REFERRAL_DEFAULT);
  useEffect(()=>{fetch('/api/public/almai',{cache:'no-store'}).then(r=>r.json()).then(j=>{if(j.ok&&j.url)setAlmaiReferral(j.url)}).catch(()=>{});},[]);
  const v = ctx?.view;
  const mode = v?.bot?.mode === 'REAL' ? 'REAL' : 'DEMO';
  const status = v?.bot?.status;
  const ai = v?.ai?.provider || ctx?.ai?.provider;
  const role = ctx?.profile?.role as 'DEVELOPER'|'ADMIN'|'USER'|undefined;
  const canAdmin = role === 'DEVELOPER' || role === 'ADMIN';
  const canDeveloper = role === 'DEVELOPER';
  const aiLabel = !ai ? 'AI' : ai === 'local-fallback' ? 'RULE-BASED' : String(ai).toUpperCase();
  const active = (href: string) => (href === '/dashboard' ? path === href : path.startsWith(href));
  useEffect(() => { setMoreOpen(false); }, [path]);
  return (
    <>
      <SystemNotice />
      <header className="topbar commandTopbar">
        <Link href="/dashboard" className="brand"><BlackboxLogo compact /><span>BLACKBOX<span className="brandSlash">// COMMAND CENTER</span></span></Link>
        <div className="systemRail"><ProfileIdentity compact />
          <span className={`topstat statusStat ${status === 'RUNNING' ? 'live' : ''}`}><i />{status || 'STANDBY'}</span>
          <span className="topstat">{mode}</span>
          <span className="topstat aiStat"><b>AI</b> {aiLabel}</span>
          <span className="topstat equityStat">{v ? usd(v.account.equity) : '—'}</span>
        </div>
        <nav className="topnav">
          {items.map((item) => <Link className={active(item.href) ? 'active' : ''} href={item.href} key={item.href}><NavIcon name={item.icon}/><span>{item.label}</span></Link>)}
          <a className="almaiNavLink" href={almaiReferral} target="_blank" rel="noopener noreferrer"><img src="/penasihat-berjangka.png" alt="ALMAI" /><span>Penasihat Berjangka</span></a>
          {canAdmin && <Link href="/admin"><NavIcon name="shield"/><span>ADMIN</span></Link>}{canDeveloper && <Link href="/developer"><NavIcon name="command"/><span>DEVELOPER</span></Link>}
      </nav>
      </header>

      <nav className="navBottom commandBottomNav" aria-label="Dashboard navigation">
        {items.map((item) => <Link className={active(item.href) ? 'active' : ''} href={item.href} key={item.href}><NavIcon name={item.icon}/><span>{item.label}</span></Link>)}
        <a className="almaiBottomLink" href={almaiReferral} target="_blank" rel="noopener noreferrer"><img src="/penasihat-berjangka.png" alt=""/><span>PENASIHAT</span></a>
      </nav>

      <nav className="mobileBottomNav" aria-label="Mobile dashboard navigation">
        {mobilePrimary.map((item) => <Link className={active(item.href) ? 'active' : ''} href={item.href} key={item.href}><NavIcon name={item.icon}/><span>{item.label}</span></Link>)}
        <button className={moreOpen || mobileMore.some((item) => active(item.href)) ? 'active' : ''} onClick={() => setMoreOpen((v) => !v)} aria-expanded={moreOpen} aria-label="More dashboard sections"><NavIcon name="more"/><span>MORE</span></button>
      </nav>

      {moreOpen && <>
        <button className="mobileMoreBackdrop" aria-label="Close menu" onClick={() => setMoreOpen(false)} />
        <section className="mobileMoreSheet" aria-label="More sections">
          <div className="mobileMoreHandle" />
          <div className="mobileMoreHeader"><b>BLACKBOX MENU</b><button onClick={() => setMoreOpen(false)} aria-label="Close">×</button></div>
          <div className="mobileMoreGrid">
            <Link className={`redeemAccessQuick ${active('/dashboard/access') ? 'active' : ''}`} href="/dashboard/access" onClick={() => setMoreOpen(false)}>
              <NavIcon name="access"/><span>REDEEM ACCESS CODE</span><small>Aktivasi Tier</small>
            </Link>
            {mobileMore.filter((item) => item.href !== '/dashboard/access').map((item) => <Link className={active(item.href) ? 'active' : ''} href={item.href} key={item.href} onClick={() => setMoreOpen(false)}><NavIcon name={item.icon}/><span>{item.label}</span></Link>)}
            <a href={almaiReferral} target="_blank" rel="noopener noreferrer"><img src="/penasihat-berjangka.png" alt=""/><span>PENASIHAT</span></a>
            {canAdmin && <Link href="/admin"><NavIcon name="shield"/><span>ADMIN</span></Link>}
            {canDeveloper && <Link href="/developer"><NavIcon name="command"/><span>DEVELOPER</span></Link>}
          </div>
        </section>
      </>}
    </>
  );
}
