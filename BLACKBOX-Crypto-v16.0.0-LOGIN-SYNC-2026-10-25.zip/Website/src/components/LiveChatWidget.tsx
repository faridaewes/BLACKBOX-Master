'use client';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

type Msg = {
  id: string;
  body: string;
  createdAt: string;
  mine?: boolean;
  sender?: { id: string; name: string; role: string };
};
type Ticket = {
  id: string;
  subject: string;
  status: string;
  priority?: string;
  category?: string;
  updatedAt?: string;
  user?: { id: string; name: string; email?: string };
  assignedTeam?: { id: string; name: string; code?: string } | null;
  assignedAgent?: { id: string; name: string } | null;
  messages?: Msg[];
  transfers?: any[];
};
type Cat = { code: string; label: string };
type TeamOpt = { id: string; name: string; code: string; members: { id: string; name: string }[] };

export default function LiveChatWidget() {
  const [open, setOpen] = useState(false);
  const [minimized, setMinimized] = useState(false);
  const [role, setRole] = useState<string>('USER');
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [filter, setFilter] = useState<'ALL' | 'OPEN' | 'PENDING' | 'MINE'>('OPEN');
  const [msg, setMsg] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [category, setCategory] = useState('GENERAL');
  const [categories, setCategories] = useState<Cat[]>([{ code: 'GENERAL', label: 'Umum' }]);
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState<'chat' | 'new' | 'queue'>('chat');
  const [showTransfer, setShowTransfer] = useState(false);
  const [transferTeams, setTransferTeams] = useState<TeamOpt[]>([]);
  const [toTeamId, setToTeamId] = useState('');
  const [toAgentId, setToAgentId] = useState('');
  const [transferReason, setTransferReason] = useState('');
  const [transferCategory, setTransferCategory] = useState('');
  const listRef = useRef<HTMLDivElement>(null);

  const load = useCallback(async () => {
    try {
      const q = selected ? `?ticketId=${encodeURIComponent(selected)}` : '';
      const r = await fetch(`/api/support${q}`, { cache: 'no-store' });
      if (r.status === 401) return;
      const j = await r.json();
      if (!j.ok) return;
      setRole(j.role || 'USER');
      setTickets(j.tickets || []);
      if (j.categories?.length) setCategories(j.categories);
      if (!selected && j.selectedTicketId) setSelected(j.selectedTicketId);
    } catch { /* silent */ }
  }, [selected]);

  useEffect(() => {
    load();
    const id = setInterval(load, 4000);
    return () => clearInterval(id);
  }, [load]);

  useEffect(() => {
    if (listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight;
  }, [selected, tickets, open, minimized]);

  const isOps = role === 'DEVELOPER' || role === 'ADMIN';
  const active = useMemo(
    () => tickets.find((t) => t.id === selected) || tickets[0] || null,
    [tickets, selected],
  );

  const queue = useMemo(() => {
    let rows = tickets;
    if (filter === 'OPEN')
      rows = rows.filter((t) =>
        ['OPEN', 'PENDING', 'ACTIVE', 'WAITING', 'IN_PROGRESS'].includes(String(t.status).toUpperCase()),
      );
    if (filter === 'PENDING') rows = rows.filter((t) => String(t.status).toUpperCase() === 'PENDING');
    return rows;
  }, [tickets, filter]);

  const sendMessage = async () => {
    if (!active || !msg.trim() || busy) return;
    setBusy(true);
    try {
      const r = await fetch('/api/support', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ action: 'message', ticketId: active.id, body: msg.trim() }),
      });
      const j = await r.json();
      if (j.ok) {
        setMsg('');
        await load();
      }
    } finally {
      setBusy(false);
    }
  };

  const createTicket = async () => {
    if (!subject.trim() || !body.trim() || busy) return;
    setBusy(true);
    try {
      const r = await fetch('/api/support', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          category,
          priority: 'NORMAL',
          subject: subject.trim(),
          body: body.trim(),
        }),
      });
      const j = await r.json();
      if (j.ok) {
        setSubject('');
        setBody('');
        setSelected(j.ticket?.id || null);
        setTab('chat');
        await load();
      }
    } finally {
      setBusy(false);
    }
  };

  const setStatus = async (status: string) => {
    if (!active) return;
    setBusy(true);
    try {
      await fetch('/api/support', {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ ticketId: active.id, status }),
      });
      await load();
    } finally {
      setBusy(false);
    }
  };

  const claim = async () => {
    if (!active) return;
    setBusy(true);
    try {
      await fetch('/api/support', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ action: 'CLAIM', ticketId: active.id }),
      });
      await load();
    } finally {
      setBusy(false);
    }
  };

  const openTransfer = async () => {
    if (!active) return;
    setShowTransfer(true);
    setTransferCategory(active.category || 'GENERAL');
    const r = await fetch(
      `/api/support?meta=teams&category=${encodeURIComponent(active.category || 'GENERAL')}`,
      { cache: 'no-store' },
    );
    const j = await r.json();
    if (j.ok) {
      setTransferTeams(j.teams || []);
      setToTeamId(j.teams?.[0]?.id || '');
      setToAgentId('');
    }
  };

  const loadTeamsForCategory = async (cat: string) => {
    setTransferCategory(cat);
    const r = await fetch(`/api/support?meta=teams&category=${encodeURIComponent(cat)}`, {
      cache: 'no-store',
    });
    const j = await r.json();
    if (j.ok) {
      setTransferTeams(j.teams || []);
      setToTeamId(j.teams?.[0]?.id || '');
      setToAgentId('');
    }
  };

  const doTransfer = async () => {
    if (!active || !toTeamId || transferReason.trim().length < 3) return;
    setBusy(true);
    try {
      const r = await fetch('/api/support', {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          action: 'TRANSFER',
          ticketId: active.id,
          toTeamId,
          toAgentId: toAgentId || null,
          reason: transferReason.trim(),
          category: transferCategory || active.category,
        }),
      });
      const j = await r.json();
      if (j.ok) {
        setShowTransfer(false);
        setTransferReason('');
        await load();
      }
    } finally {
      setBusy(false);
    }
  };

  if (!open) {
    return (
      <button
        type="button"
        className="lcLauncher"
        onClick={() => {
          setOpen(true);
          setMinimized(false);
        }}
        aria-label="Open live chat"
      >
        <span className="lcLauncherRing" />
        <span className="lcLauncherIcon">◈</span>
        <span className="lcLauncherLabel">LIVE SUPPORT</span>
        {tickets.some((t) =>
          ['OPEN', 'PENDING', 'WAITING', 'IN_PROGRESS'].includes(String(t.status).toUpperCase()),
        ) && <span className="lcBadge">{queue.length || tickets.length}</span>}
      </button>
    );
  }

  if (minimized) {
    return (
      <button type="button" className="lcMiniBar" onClick={() => setMinimized(false)}>
        <span className="lcMiniDot" />
        LIVE SUPPORT · {active ? active.subject.slice(0, 28) : 'Ready'}
        <span className="lcMiniActions">
          <span
            onClick={(e) => {
              e.stopPropagation();
              setMinimized(false);
            }}
          >
            ▸
          </span>
          <span
            onClick={(e) => {
              e.stopPropagation();
              setOpen(false);
            }}
          >
            ✕
          </span>
        </span>
      </button>
    );
  }

  const teamMembers = transferTeams.find((t) => t.id === toTeamId)?.members || [];

  return (
    <div className="lcPanel" role="dialog" aria-label="Live support chat">
      <header className="lcHead">
        <div>
          <div className="lcHeadTitle">BLACKBOX · LIVE SUPPORT</div>
          <div className="lcHeadSub">
            {isOps ? 'Operator console' : 'Secure channel'} · auto-refresh 4s
          </div>
        </div>
        <div className="lcHeadBtns">
          <button type="button" title="Minimize" onClick={() => setMinimized(true)}>
            —
          </button>
          <button type="button" title="Close" onClick={() => setOpen(false)}>
            ✕
          </button>
        </div>
      </header>

      <div className="lcTabs">
        <button type="button" className={tab === 'chat' ? 'on' : ''} onClick={() => setTab('chat')}>
          Chat
        </button>
        {isOps && (
          <button
            type="button"
            className={tab === 'queue' ? 'on' : ''}
            onClick={() => setTab('queue')}
          >
            Queue ({queue.length})
          </button>
        )}
        <button type="button" className={tab === 'new' ? 'on' : ''} onClick={() => setTab('new')}>
          New
        </button>
      </div>

      {tab === 'queue' && isOps && (
        <div className="lcQueue">
          <div className="lcFilters">
            {(['OPEN', 'PENDING', 'ALL'] as const).map((f) => (
              <button
                key={f}
                type="button"
                className={filter === f ? 'on' : ''}
                onClick={() => setFilter(f)}
              >
                {f}
              </button>
            ))}
          </div>
          <div className="lcQueueList">
            {queue.map((t) => (
              <button
                key={t.id}
                type="button"
                className={`lcQueueItem ${selected === t.id ? 'active' : ''}`}
                onClick={() => {
                  setSelected(t.id);
                  setTab('chat');
                }}
              >
                <div className="lcQueueTop">
                  <b>{t.user?.name || 'User'}</b>
                  <span className={`lcSt lcSt-${String(t.status).toLowerCase()}`}>{t.status}</span>
                </div>
                <div className="lcQueueSub">
                  [{t.category || 'GENERAL'}] {t.subject}
                </div>
                <div className="lcQueueMeta">
                  {t.assignedTeam?.name || 'Unassigned'} ·{' '}
                  {t.updatedAt ? new Date(t.updatedAt).toLocaleString('id-ID') : ''}
                </div>
              </button>
            ))}
            {!queue.length && <div className="lcEmpty">Tidak ada ticket pada filter ini.</div>}
          </div>
        </div>
      )}

      {tab === 'new' && (
        <div className="lcNew">
          <select
            className="lcInput"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            {categories.map((c) => (
              <option key={c.code} value={c.code}>
                {c.label}
              </option>
            ))}
          </select>
          <input
            className="lcInput"
            placeholder="Subjek"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
          />
          <textarea
            className="lcInput lcTextarea"
            placeholder="Jelaskan kebutuhan atau kendala Anda…"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={5}
          />
          <button
            type="button"
            className="lcSend"
            disabled={busy || !subject.trim() || !body.trim()}
            onClick={createTicket}
          >
            BUKA TICKET
          </button>
        </div>
      )}

      {tab === 'chat' && (
        <>
          {isOps && (
            <div className="lcOpsBar">
              <select
                className="lcSelect"
                value={active?.id || ''}
                onChange={(e) => setSelected(e.target.value || null)}
              >
                <option value="">— pilih user / ticket —</option>
                {tickets.map((t) => (
                  <option key={t.id} value={t.id}>
                    {(t.user?.name || 'User')} · [{t.category || 'GENERAL'}] {t.subject.slice(0, 32)} ·{' '}
                    {t.status}
                  </option>
                ))}
              </select>
              {active && (
                <div className="lcOpsActions">
                  <button type="button" onClick={claim} disabled={busy}>
                    Ambil / Claim
                  </button>
                  <button type="button" onClick={openTransfer} disabled={busy}>
                    Transfer
                  </button>
                  <button type="button" onClick={() => setStatus('RESOLVED')} disabled={busy}>
                    Selesai
                  </button>
                  <button type="button" onClick={() => setStatus('CLOSED')} disabled={busy}>
                    Tutup obrolan
                  </button>
                </div>
              )}
            </div>
          )}

          {showTransfer && active && (
            <div className="lcTransferBox">
              <div className="lcTransferTitle">Transfer ke tim / kategori lain</div>
              <select
                className="lcInput"
                value={transferCategory}
                onChange={(e) => loadTeamsForCategory(e.target.value)}
              >
                {categories.map((c) => (
                  <option key={c.code} value={c.code}>
                    Kategori: {c.label}
                  </option>
                ))}
              </select>
              <select
                className="lcInput"
                value={toTeamId}
                onChange={(e) => {
                  setToTeamId(e.target.value);
                  setToAgentId('');
                }}
              >
                {transferTeams.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name} ({t.code})
                  </option>
                ))}
              </select>
              <select
                className="lcInput"
                value={toAgentId}
                onChange={(e) => setToAgentId(e.target.value)}
              >
                <option value="">— semua petugas di tim —</option>
                {teamMembers.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </select>
              <input
                className="lcInput"
                placeholder="Alasan transfer (wajib)"
                value={transferReason}
                onChange={(e) => setTransferReason(e.target.value)}
              />
              <div className="lcOpsActions">
                <button type="button" className="lcSend" disabled={busy} onClick={doTransfer}>
                  KIRIM TRANSFER
                </button>
                <button type="button" onClick={() => setShowTransfer(false)}>
                  Batal
                </button>
              </div>
            </div>
          )}

          <div className="lcThreadMeta">
            {active ? (
              <>
                <b>{active.subject}</b>
                <span className={`lcSt lcSt-${String(active.status).toLowerCase()}`}>
                  {active.status}
                </span>
                <span className="lcUserTag">{active.category || 'GENERAL'}</span>
                {isOps && active.user && <span className="lcUserTag">{active.user.name}</span>}
                {active.assignedTeam && (
                  <span className="lcMuted">→ {active.assignedTeam.name}</span>
                )}
              </>
            ) : (
              <span className="lcMuted">Belum ada percakapan. Buat ticket baru dari tab New.</span>
            )}
          </div>

          <div className="lcMessages" ref={listRef}>
            {(active?.messages || []).map((m) => (
              <div key={m.id} className={`lcBubble ${m.mine ? 'mine' : 'theirs'}`}>
                <div className="lcBubbleMeta">
                  {m.sender?.name || (m.mine ? 'Anda' : 'Support')} ·{' '}
                  {m.createdAt
                    ? new Date(m.createdAt).toLocaleTimeString('id-ID', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })
                    : ''}
                </div>
                <div className="lcBubbleBody">{m.body}</div>
              </div>
            ))}
            {active && !(active.messages || []).length && (
              <div className="lcEmpty">Belum ada pesan. Kirim pesan pertama di bawah.</div>
            )}
          </div>

          <div className="lcComposer">
            <input
              className="lcInput"
              placeholder={
                active?.status === 'CLOSED'
                  ? 'Obrolan ditutup'
                  : active
                    ? 'Tulis pesan…'
                    : 'Pilih atau buat ticket terlebih dahulu'
              }
              value={msg}
              disabled={!active || busy || active?.status === 'CLOSED'}
              onChange={(e) => setMsg(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage();
                }
              }}
            />
            <button
              type="button"
              className="lcSend"
              disabled={!active || busy || !msg.trim() || active?.status === 'CLOSED'}
              onClick={sendMessage}
            >
              KIRIM
            </button>
          </div>
        </>
      )}
    </div>
  );
}
