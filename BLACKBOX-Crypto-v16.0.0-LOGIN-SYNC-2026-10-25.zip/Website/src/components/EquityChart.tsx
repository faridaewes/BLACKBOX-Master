import { usd } from '@/lib/format';

type Props = { history?: [number, number][]; target?: number; peak?: number; ddLimit?: number };

export default function EquityChart({ history = [], target, peak, ddLimit }: Props) {
  const H = 230, W = 1000;
  const pts = history.slice(-300);
  const vals = pts.map((p) => p[1]);
  const extra = [target, peak, ddLimit].filter((v): v is number => typeof v === 'number' && Number.isFinite(v));
  const all = [...vals, ...extra];
  if (!all.length) return <div className="chart"><span className="chartLabel" style={{ top: '45%' }}>Menunggu data…</span></div>;
  let lo = Math.min(...all), hi = Math.max(...all);
  if (hi - lo < 1e-6) { hi += 1; lo -= 1; }
  const pad = (hi - lo) * 0.08; lo -= pad; hi += pad;
  const y = (v: number) => H - ((v - lo) / (hi - lo)) * H;
  const x = (i: number) => (pts.length <= 1 ? 0 : (i / (pts.length - 1)) * W);
  const line = pts.length > 1 ? pts.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)} ${y(p[1]).toFixed(1)}`).join(' ') : `M0 ${y(vals[0] ?? lo).toFixed(1)} L${W} ${y(vals[0] ?? lo).toFixed(1)}`;
  const top = (v: number) => `${Math.max(2, Math.min(90, (y(v) / H) * 100))}%`;
  const ref = (v: number | undefined, color: string, dash: string) => (v == null ? null : <path d={`M0 ${y(v).toFixed(1)} L${W} ${y(v).toFixed(1)}`} stroke={color} strokeDasharray={dash} strokeWidth="1" opacity=".55" vectorEffect="non-scaling-stroke" />);
  const up = vals.length < 2 || vals[vals.length - 1] >= vals[0];
  const col = up ? '#FFD342' : '#ff5968';
  return (
    <div className="chart">
      <i className="gridline g1" /><i className="gridline g2" /><i className="gridline g3" />
      {target != null && <span className="chartLabel" style={{ top: top(target) }}>TGT {usd(target, 0)}</span>}
      {peak != null && <span className="chartLabel" style={{ top: top(peak), right: 'auto', left: '40%' }}>PEAK {usd(peak, 0)}</span>}
      {ddLimit != null && <span className="chartLabel" style={{ top: top(ddLimit), color: '#ff8a94' }}>DD {usd(ddLimit, 0)}</span>}
      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
        <defs><linearGradient id="area" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor={col} stopOpacity=".24" /><stop offset="1" stopColor={col} stopOpacity="0" /></linearGradient></defs>
        <path d={`${line} L${W} ${H} L0 ${H}Z`} fill="url(#area)" />
        <path d={line} fill="none" stroke={col} strokeWidth="2" vectorEffect="non-scaling-stroke" />
        {ref(target, '#A99555', '6 8')}{ref(peak, '#d6b24d', '3 6')}{ref(ddLimit, '#ff5968', '6 8')}
      </svg>
    </div>
  );
}
