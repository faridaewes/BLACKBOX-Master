'use client';
import { useCallback, useEffect, useState } from 'react';

type Health = { ok?: boolean; status?: string; database?: string; worker?: string; latencyMs?: number; timestamp?: string; realTradingEnabled?: boolean; components?: Array<{id:string;state:string;detail?:string}> };

function Item({ label, value, good }: { label: string; value: string; good: boolean }) {
  return <div className="healthItem"><span><i className={good ? 'healthDot good' : 'healthDot warn'} />{label}</span><b className={good ? 'positive' : 'negative'}>{value}</b></div>;
}

export default function SystemHealth() {
  const [data, setData] = useState<Health | null>(null);
  const [busy, setBusy] = useState(true);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      const r = await fetch('/api/health', { cache: 'no-store' });
      const j = await r.json().catch(() => ({}));
      setData(j);
    } catch {
      setData({ ok: false, status: 'offline', database: 'error', worker: 'unknown' });
    } finally { setBusy(false); }
  }, []);

  useEffect(() => { load(); const t = window.setInterval(load, 20000); return () => window.clearInterval(t); }, [load]);

  const provider = data?.components?.find((c) => c.id === 'market-provider-failover');
  const healthy = data?.ok === true && data.database === 'ok' && data.worker === 'ok';
  const providerHealthy = provider?.state === 'HEALTHY';
  return <section className="panel systemHealth">
    <div className="panelHead"><span className="panelTitle">BLACKBOX HEALTH</span><span className={'pill ' + (healthy ? 'green' : 'amber')}>{busy ? 'CHECKING' : healthy ? 'HEALTHY' : 'DEGRADED'}</span></div>
    <div className="panelBody">
      <div className="healthGrid">
        <Item label="API" value={data?.ok ? 'ONLINE' : 'OFFLINE'} good={!!data?.ok} />
        <Item label="DATABASE" value={data?.database === 'ok' ? 'HEALTHY' : 'ERROR'} good={data?.database === 'ok'} />
        <Item label="WORKER" value={data?.worker === 'ok' ? 'HEALTHY' : data?.worker === 'stale' ? 'STALE' : 'UNKNOWN'} good={data?.worker === 'ok'} />
        <Item label="MARKET PROVIDER" value={providerHealthy ? 'HEALTHY' : provider ? 'DEGRADED' : 'UNKNOWN'} good={providerHealthy || !!provider} />
        <Item label="REAL GATE" value={data?.realTradingEnabled ? 'ENABLED' : 'GATED'} good={!data?.realTradingEnabled || healthy} />
      </div>
      <div className="healthMeta" style={{justifyContent:'space-between'}}><span>{providerHealthy ? 'Market provider sehat.' : 'Market provider dapat terdegradasi tanpa mematikan dashboard.'}</span>{data?.latencyMs != null ? `Last check ${data.latencyMs}ms` : 'Health check unavailable'} · auto-check 20s <button className="btn ghost" onClick={load} disabled={busy}>CHECK NOW</button></div>
    </div>
  </section>;
}
