'use client';
import { useCallback, useEffect, useState } from 'react';

export default function StaffRecruitmentPanel() {
  const [staff, setStaff] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [teams, setTeams] = useState<any[]>([]);
  const [userId, setUserId] = useState('');
  const [teamId, setTeamId] = useState('');
  const [reason, setReason] = useState('');
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const j = await fetch('/api/developer/staff', { cache: 'no-store' }).then((r) => r.json());
    if (j.ok) {
      setStaff(j.staff || []);
      setUsers(j.recruitableUsers || []);
      setTeams(j.teams || []);
    }
  }, []);
  useEffect(() => {
    load();
  }, [load]);

  const act = async (action: string, id: string) => {
    setBusy(true);
    setMsg('');
    try {
      const r = await fetch('/api/developer/staff', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          action,
          userId: id,
          teamId: teamId || undefined,
          reason: reason || undefined,
        }),
      });
      const j = await r.json();
      setMsg(j.ok ? j.message || 'OK' : j.error || 'Gagal');
      await load();
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel section">
      <div className="panelHead">
        <span className="panelTitle">STAFF RECRUITMENT · Promote USER yang sudah daftar (bukan buat akun baru)</span>
        <span className="small">Developer-only</span>
      </div>
      <div className="panelBody formGrid">
        <p className="hint">
          Rekrut petugas dari akun USER yang sudah mendaftar, atau kembalikan ADMIN menjadi USER.
          Suspend kerja memutus sesi dan menonaktifkan akses operasional segera.
        </p>
        <label>
          Pilih USER untuk dipromosikan
          <select className="input" value={userId} onChange={(e) => setUserId(e.target.value)}>
            <option value="">— pilih user —</option>
            {users.map((u) => (
              <option key={u.id} value={u.id}>
                {u.name} · {u.email}
              </option>
            ))}
          </select>
        </label>
        <label>
          Tim awal (opsional)
          <select className="input" value={teamId} onChange={(e) => setTeamId(e.target.value)}>
            <option value="">— tanpa tim dulu —</option>
            {teams.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name} ({t.code})
              </option>
            ))}
          </select>
        </label>
        <label>
          Alasan (opsional untuk promote, disarankan untuk suspend)
          <input className="input" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Alasan" />
        </label>
        <div className="actions">
          <button className="btn primary" disabled={busy || !userId} onClick={() => act('PROMOTE', userId)}>
            Promosikan → ADMIN
          </button>
        </div>
        {msg && <div className="banner">{msg}</div>}
      </div>
      <div className="panelBody">
        <div className="panelTitle" style={{ marginBottom: 8 }}>
          Direktori staf
        </div>
        {staff.map((s) => (
          <div key={s.id} className="eventRow" style={{ flexWrap: 'wrap', gap: 8 }}>
            <b>
              {s.name} · {s.role}
              {s.developerLevel ? `/${s.developerLevel}` : ''}
            </b>
            <span className="muted">{s.email}</span>
            <span className={`pill ${s.status === 'ACTIVE' ? 'green' : 'warn'}`}>{s.status}</span>
            <span className="muted">
              {(s.teamMemberships || []).map((m: any) => m.team?.name).filter(Boolean).join(', ') || 'No team'}
            </span>
            {s.role === 'ADMIN' && (
              <>
                <button className="btn" disabled={busy} onClick={() => act('DEMOTE', s.id)}>
                  Demote → USER
                </button>
                {s.status === 'ACTIVE' ? (
                  <button className="btn danger" disabled={busy} onClick={() => act('SUSPEND_WORK', s.id)}>
                    Urgent suspend
                  </button>
                ) : (
                  <button className="btn" disabled={busy} onClick={() => act('RESTORE_WORK', s.id)}>
                    Restore work
                  </button>
                )}
              </>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
