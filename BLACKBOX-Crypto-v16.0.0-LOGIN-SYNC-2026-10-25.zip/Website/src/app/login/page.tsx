'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import BlackboxLogo from '@/components/BlackboxLogo';

declare global {
  interface Window {
    google?: any;
  }
}

export default function Login() {
  const r = useRouter();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [mfa, setMfa] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [showMfa, setShowMfa] = useState(false);
  const googleEnabled = !!(process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID || '').trim();

  const go = async () => {
    setBusy(true);
    setErr('');
    try {
      const x = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          identifier,
          password,
          mfaCode: mfa || undefined,
        }),
      });
      const j = await x.json();
      if (j.ok) {
        try {
          Object.keys(sessionStorage)
            .filter((k) => k.startsWith('bbx-welcome:'))
            .forEach((k) => sessionStorage.removeItem(k));
        } catch { /* */ }
        r.push(j.mustChangePassword ? '/change-password' : '/dashboard');
      } else if (j.error === 'MFA_REQUIRED_OR_INVALID') {
        setShowMfa(true);
        setErr('Masukkan kode MFA dari aplikasi autentikator Anda.');
      } else if (j.suggestPasswordReset || j.code === 'SUGGEST_PASSWORD_RESET') {
        setErr(j.message || 'Terlalu banyak percobaan gagal. Silakan reset password.');
        if (
          typeof window !== 'undefined' &&
          window.confirm(
            (j.message || 'Login gagal berulang. Reset password sekarang?') +
              '\n\nOK = buka halaman reset password',
          )
        ) {
          r.push('/forgot-password');
        }
      } else {
        setErr(j.error || 'Login gagal');
      }
    } catch {
      setErr('Koneksi gagal. Coba lagi.');
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    if (!googleEnabled) return;
    const s = document.createElement('script');
    s.src = 'https://accounts.google.com/gsi/client';
    s.async = true;
    s.defer = true;
    s.onload = async () => {
      const clientId = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID || '';
      if (!window.google || !clientId) return;
      let nonce = '';
      try {
        const challengeResponse = await fetch('/api/auth/google/nonce', { method: 'GET', cache: 'no-store', credentials: 'same-origin' });
        const challenge = await challengeResponse.json().catch(() => ({}));
        if (!challengeResponse.ok || typeof challenge.nonce !== 'string' || !challenge.nonce) {
          setErr(challenge.error || 'Tidak dapat memulai verifikasi Google. Silakan muat ulang halaman.');
          return;
        }
        nonce = challenge.nonce;
      } catch {
        setErr('Tidak dapat memulai verifikasi Google. Periksa koneksi lalu muat ulang halaman.');
        return;
      }
      window.google.accounts.id.initialize({
        client_id: clientId,
        nonce,
        callback: async (res: any) => {
          setBusy(true);
          setErr('');
          try {
            const x = await fetch('/api/auth/google', {
              method: 'POST',
              headers: { 'content-type': 'application/json' },
              body: JSON.stringify({ credential: res.credential, nonce }),
            });
            const j = await x.json();
            if (j.ok) r.push('/dashboard');
            else if (j.registrationRequired) {
              r.push(
                `/register?googleEmail=${encodeURIComponent(j.email || '')}&googleName=${encodeURIComponent(j.name || '')}`,
              );
            } else if (j.error === 'GOOGLE_LOGIN_NOT_CONFIGURED') {
              setErr('Login Google belum dikonfigurasi oleh pengelola. Silakan gunakan email dan password.');
            } else setErr(j.error || 'Google login gagal');
          } catch {
            setErr('Google login gagal');
          } finally {
            setBusy(false);
          }
        },
      });
      const target = document.getElementById('google-login');
      if (target) {
        target.innerHTML = '';
        window.google.accounts.id.renderButton(target, {
          theme: 'outline',
          size: 'large',
          width: Math.max(220, Math.floor(target.clientWidth || 360)),
          text: 'signin_with',
          shape: 'rectangular',
          logo_alignment: 'left',
        });
      }
    };
    document.head.appendChild(s);
    return () => {
      s.remove();
    };
  }, [googleEnabled, r]);

  return (
    <main className="authShell">
      <div className="authCard">
        <div className="authBrand">
          <BlackboxLogo />
          <span className="badge">SECURE ACCESS</span>
        </div>
        <h1>Masuk ke BLACKBOX</h1>
        <p className="authLead">
          Login manual dengan email/username, atau satu ketukan dengan akun Google di perangkat Anda.
        </p>

        {googleEnabled && (
          <>
            <div id="google-login" className="googleBtnWrap" />
            <div className="authDivider">
              <span>atau lanjut manual</span>
            </div>
          </>
        )}
        {!googleEnabled && (
          <p className="hint">
            Login dengan Google belum tersedia saat ini. Silakan masuk menggunakan email dan password.
          </p>
        )}

        <label className="authLabel">
          Email atau username
          <input
            className="input"
            autoComplete="username"
            placeholder="nama@email.com atau username"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && go()}
          />
        </label>
        <label className="authLabel">
          Password
          <input
            className="input"
            type="password"
            autoComplete="current-password"
            placeholder="Password Anda"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && go()}
          />
        </label>
        {(showMfa || mfa) && (
          <label className="authLabel">
            Kode MFA (jika aktif)
            <input
              className="input"
              inputMode="numeric"
              placeholder="6 digit"
              value={mfa}
              onChange={(e) => setMfa(e.target.value)}
            />
          </label>
        )}

        {err && <div className="banner warnBanner">{err}</div>}

        <button className="btn primary authSubmit" disabled={busy || !identifier || !password} onClick={go}>
          {busy ? 'Memproses…' : 'Masuk'}
        </button>

        <div className="authLinks">
          <Link href="/forgot-password">Lupa password?</Link>
          <Link href="/register">Buat akun baru</Link>
        </div>
        <p className="authFoot">Akses terenkripsi · Sesi aman · BLACKBOX Command Center</p>
      </div>
    </main>
  );
}
