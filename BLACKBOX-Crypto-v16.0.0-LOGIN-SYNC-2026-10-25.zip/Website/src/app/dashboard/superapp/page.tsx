'use client';
import {useEffect,useMemo,useState} from 'react';
import Link from 'next/link';
import BlackboxNav from '@/components/BlackboxNav';

type Module={id:string;label:string;group:string;href:string;icon:string;description:string;available:boolean;state:string;reason?:string};
type Plane={ok:boolean;identity:any;entitlement:any;health:any;safety:any;modules:Module[];summary:any};
const groups=['MARKETS','INTELLIGENCE','FINANCE','ACCOUNT','COMMUNICATION','OPERATIONS'];
const icon=(x:string)=>({scan:'◌',portfolio:'◈',trades:'↗',chart:'⌁',radar:'◎',brain:'✦',shield:'◇',link:'↔',finance:'▣',access:'▤',support:'◉',lock:'⌾',command:'◉'} as Record<string,string>)[x]||'•';
export default function SuperAppHome(){
 const [p,setP]=useState<Plane|null>(null); const [err,setErr]=useState(false);
 useEffect(()=>{fetch('/api/superapp',{cache:'no-store'}).then(r=>r.json()).then(j=>j?.ok?setP(j):setErr(true)).catch(()=>setErr(true));},[]);
 const modules=useMemo(()=>p?.modules||[],[p]);
 return <><BlackboxNav/><main className="page">
  <section className="hero commandHero" style={{minHeight:220}}>
   <div><div className="eyebrow">BLACKBOX SUPERAPP · CONTROL PLANE</div><h1 style={{fontSize:'clamp(2rem,5vw,4rem)',margin:'8px 0'}}>ONE APP. ONE EXPERIENCE.</h1><p className="hint">Satu workspace untuk Markets, Intelligence, Finance, Account dan Services. Modul dikendalikan oleh entitlement, role, dan health state.</p></div>
   <div className="panel" style={{padding:18,minWidth:230}}><div className="mini">IDENTITY</div><b style={{fontSize:20}}>{p?.identity?.name||'—'}</b><div className="pill green" style={{display:'inline-block',marginTop:8}}>{p?.identity?.role||'—'} · {p?.identity?.tier||'—'}</div><div className="mini" style={{marginTop:12}}>MODULES {p?.summary?.available ?? '—'} / {p?.summary?.total ?? '—'}</div></div>
  </section>
  {err&&<div className="banner amber">SuperApp Control Plane sementara tidak tersedia. Fitur trading tetap fail-closed.</div>}
  <section className="metrics"><div className="panel"><div className="panelBody"><div className="mini">HEALTH</div><b>{p?.health?.overall||'UNKNOWN'}</b><p className="mini">Score {p?.health?.score??'—'}/100</p></div></div><div className="panel"><div className="panelBody"><div className="mini">AVAILABLE</div><b>{p?.summary?.available??'—'}</b><p className="mini">Modul siap digunakan</p></div></div><div className="panel"><div className="panelBody"><div className="mini">LOCKED</div><b>{p?.summary?.locked??'—'}</b><p className="mini">Role / tier / entitlement</p></div></div><div className="panel"><div className="panelBody"><div className="mini">SAFETY</div><b>FAIL-CLOSED</b><p className="mini">Execution remains certified-gated</p></div></div></section>
  {groups.map(group=><section className="panel section" key={group}><div className="panelHead"><span className="panelTitle">{group}</span><span className="mini">MODULE REGISTRY</span></div><div className="panelBody"><div className="three">{modules.filter(m=>m.group===group).map(m=><article className="panel" key={m.id} style={{padding:0,opacity:m.available?1:.65}}><div className="panelBody"><div style={{display:'flex',justifyContent:'space-between',gap:12}}><b>{icon(m.icon)} &nbsp;{m.label}</b><span className={'pill '+(m.state==='AVAILABLE'?'green':'amber')}>{m.state}</span></div><p className="mini">{m.description}</p>{m.available?<Link className="btn ghost" href={m.href}>OPEN</Link>:<span className="mini">{m.reason}</span>}</div></article>)}</div></div></section>)}
  <section className="panel section"><div className="panelHead"><span className="panelTitle">OPERATING PRINCIPLE</span></div><div className="panelBody"><div className="pipe commandPipe"><span className="on">01 IDENTITY</span><span>02 ENTITLEMENT</span><span>03 DATA</span><span>04 EVIDENCE</span><span>05 INTELLIGENCE</span><span>06 RISK</span><span>07 POLICY</span><span>08 AUTHORIZATION</span><span>09 EXECUTION</span><span>10 RECONCILIATION</span><span>11 AUDIT</span></div><div className="banner amber" style={{marginTop:14}}>AI, Radar, dan SuperApp UI tidak mendapatkan kewenangan eksekusi. Real trading tetap terkunci sampai certification gate eksternal terpenuhi.</div></div></section>
 </main></>;
}
