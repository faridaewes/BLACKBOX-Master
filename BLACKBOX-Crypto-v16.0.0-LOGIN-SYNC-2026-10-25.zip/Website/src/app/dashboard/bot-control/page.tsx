'use client';
import { useEffect, useState } from 'react';
import BlackboxNav from '@/components/BlackboxNav';
import { useBot } from '@/components/BotProvider';
import { usd } from '@/lib/format';
import { PRESET_CATALOG, getPresetInfo } from '@/lib/facade/presets';

export default function BotControlPage() {
  const ctx = useBot();
  const [journal, setJournal] = useState<any[]>([]);
  const [drySteps, setDrySteps] = useState<any[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const v = ctx?.view;
  const bot = v?.bot;
  const running = bot?.status === 'RUNNING';
  const engine = (v as any)?.engineHealth;
  const preset = getPresetInfo((v as any)?.preset);

  const refreshJournal = async () => {
    if (!ctx?.botId) return;
    const r = await fetch(`/api/bots/${ctx.botId}/decision-journal`, { cache: 'no-store' });
    const j = await r.json();
    if (j.ok) setJournal(j.journal || []);
  };

  useEffect(() => { refreshJournal(); const t = setInterval(refreshJournal, 15000); return () => clearInterval(t); }, [ctx?.botId]);

  const act = async (action: string, extra?: Record<string, unknown>) => {
    if (!ctx) return;
    setBusy(true); setMsg(null); setDrySteps(null);
    try {
      if (action === 'DRY_RUN') {
        const r = await ctx.call(`/api/bots/${ctx.botId}/control`, 'POST', { action: 'DRY_RUN' });
        if (r.ok) { setDrySteps(r.steps || []); setMsg(r.message || 'Dry-run selesai'); }
        else setMsg(r.error || 'Dry-run gagal');
      } else {
        const r = await ctx.act(action, extra);
        setMsg(r.ok ? `OK: ${action}` : (r.error || 'Gagal'));
        await ctx.refresh();
        await refreshJournal();
      }
    } finally { setBusy(false); }
  };

  if (!ctx) return null;
  if (ctx.loading) return <><BlackboxNav /><main className="page"><p>Memuat…</p></main></>;

  return (
    <>
      <BlackboxNav />
      <main className="page botControlPage">
        <div className="pageTitle">
          <div>
            <h1>Bot Control</h1>
            <p>Satu pusat kontrol bot: status, START/STOP, equity, posisi, journal penolakan, dan dry-run edukasi. Bukan Paper Lab (analisa candle).</p>
          </div>
          <span className={`pill ${engine?.status === 'ONLINE' ? 'green' : 'warn'}`}>
            ENGINE · {engine?.status || 'UNKNOWN'}{engine?.heartbeatAgeSec != null ? ` · ${engine.heartbeatAgeSec}s` : ''}
          </span>
        </div>

        {/* Bot cards with heartbeat */}
        <section className="panel">
          <div className="panelBody botCardGrid">
            {(ctx.bots || []).map((b: any) => {
              const active = b.id === ctx.botId;
              const st = b.status || 'STOPPED';
              const live = st === 'RUNNING';
              return (
                <button
                  key={b.id}
                  type="button"
                  className={`botCard ${active ? 'active' : ''} ${live ? 'live' : 'idle'}`}
                  onClick={() => ctx.selectBot(b.id)}
                >
                  <span className={`hbDot ${live ? 'hbOn' : 'hbOff'}`} aria-hidden />
                  <div className="botCardName">{b.name || b.id.slice(0, 8)}</div>
                  <div className="botCardMeta">{st} · {b.mode || 'DEMO'}</div>
                </button>
              );
            })}
            {!ctx.bots?.length && <div className="muted">Belum ada bot. Buat bot dari Command / Setup.</div>}
          </div>
        </section>

        {bot && (
          <>
            <section className="panel">
              <div className="panelBody botControlHero">
                <div>
                  <div className="eyebrow">{bot.name} · {bot.mode}</div>
                  <div className="equity">{usd(v?.account?.equity)}</div>
                  <div className="hint">
                    Status bot: <b>{bot.status}</b>
                    {' · '}
                    Engine: <b>{engine?.status || '—'}</b>
                    {engine?.detail ? ` — ${engine.detail}` : ''}
                  </div>
                  <div className="hint">
                    Posisi terbuka: {v?.open?.length ?? 0} · Preset: <b>{preset.labelId}</b> ({preset.expectedEntriesPerDay})
                  </div>
                </div>
                <div className="botControlActions">
                  {!running && (
                    <button className="btn primary" disabled={busy} onClick={() => act('START', { riskAccepted: true })}>START</button>
                  )}
                  {running && (
                    <>
                      <button className="btn" disabled={busy} onClick={() => act('PAUSE')}>PAUSE</button>
                      <button className="btn danger" disabled={busy} onClick={() => act('STOP')}>STOP</button>
                    </>
                  )}
                  <button className="btn" disabled={busy} onClick={() => act('DRY_RUN')}>DRY-RUN (1 siklus)</button>
                </div>
              </div>
              {msg && <div className="hint" style={{ padding: '0 16px 12px' }}>{msg}</div>}
            </section>

            {/* Preset catalog */}
            <section className="panel">
              <div className="panelHead"><b>Preset Guardrail</b></div>
              <div className="panelBody presetGrid">
                {PRESET_CATALOG.map((p) => (
                  <div key={p.id} className={`presetCard ${preset.id === p.id ? 'active' : ''}`}>
                    <div className="presetTitle">{p.labelId} <span>({p.labelEn})</span></div>
                    <p>{p.description}</p>
                    <div className="presetFreq">{p.expectedDecisionsPerHour}</div>
                    <div className="presetFreq">{p.expectedEntriesPerDay}</div>
                  </div>
                ))}
              </div>
              <div className="hint" style={{ padding: '0 16px 12px' }}>Ubah preset di Settings / konfigurasi bot. Angka frekuensi bersifat edukatif, bukan jaminan.</div>
            </section>

            {/* Open positions */}
            <section className="panel">
              <div className="panelHead"><b>Posisi Terbuka</b></div>
              <div className="panelBody">
                {(v?.open || []).length === 0 && <div className="muted">Tidak ada posisi terbuka.</div>}
                {(v?.open || []).map((p: any) => (
                  <div key={p.id} className="eventRow">
                    <b>{p.symbol}</b>
                    <span>entry {p.entry} · mark {p.price} · qty {p.qty}</span>
                  </div>
                ))}
              </div>
            </section>

            {/* Dry-run result */}
            {drySteps && (
              <section className="panel">
                <div className="panelHead"><b>Hasil Dry-Run</b></div>
                <div className="panelBody">
                  {drySteps.map((s: any, i: number) => (
                    <div key={i} className="eventRow">
                      <b>{s.stage}</b>
                      <span>{s.ok ? '✓' : '•'} {s.detail}</span>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Decision journal ID */}
            <section className="panel">
              <div className="panelHead"><b>Journal Keputusan (penolakan ENTRY)</b></div>
              <div className="panelBody">
                {!journal.length && <div className="muted">Belum ada penolakan tercatat.</div>}
                {journal.map((j) => (
                  <div key={j.id} className="eventRow journalRow">
                    <b>{j.symbol || j.type}</b>
                    <span>{j.summaryId}</span>
                    <span className="muted">{j.at ? new Date(j.at).toLocaleString('id-ID') : ''}</span>
                  </div>
                ))}
              </div>
            </section>

            {/* Recent agent logs */}
            <section className="panel">
              <div className="panelHead"><b>Log Agen (terbaru)</b></div>
              <div className="panelBody">
                {(v?.logs || []).slice(0, 12).map((l: any) => (
                  <div key={l.id} className="eventRow">
                    <b>[{l.stage}]</b>
                    <span>{l.message}</span>
                  </div>
                ))}
              </div>
            </section>
          </>
        )}
      </main>
    </>
  );
}
