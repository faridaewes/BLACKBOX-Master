'use client';
import { useState } from 'react';
import BlackboxNav from '@/components/BlackboxNav';
import { useBot } from '@/components/BotProvider';
import { chainLabel, clock, pct, price, signedUsd, usd } from '@/lib/format';

const STAGES = ['SIGNAL', 'AI', 'RISK', 'ROUTE', 'FILL', 'MONITOR'];
const MAP: Record<string, string> = { SCAN: 'SIGNAL', THINK: 'AI', HOLD: 'AI', RISK: 'RISK', BLOCK: 'RISK', ROUTE: 'ROUTE', FILL: 'FILL', MONITOR: 'MONITOR' };
const REASON: Record<string, string> = { TAKE_PROFIT: 'Take Profit', STOP_LOSS: 'Stop Loss', BREAKEVEN_STOP: 'Breakeven Stop', MANUAL: 'Manual' };

export default function Trades() {
  const ctx = useBot()!;
  const v = ctx.view;
  const [busy, setBusy] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  if (ctx.loading) return <><BlackboxNav /><main className="page"><p className="small">Memuat…</p></main></>;
  if (!v) return <><BlackboxNav /><main className="page"><div className="pageTitle"><div><h1>Trades</h1></div></div><div className="banner">Belum ada bot. Buat bot di <a href="/dashboard">Dashboard</a>.</div></main></>;

  const unreal = v.open.reduce((s: number, p: any) => s + p.pnl, 0);
  const last = v.logs[0] ? MAP[v.logs[0].stage] : '';
  const fills = v.logs.filter((l: any) => l.stage === 'FILL').slice(0, 6);

  const close = async (pid: string) => {
    setBusy(pid); setMsg(null);
    const j = await ctx.call(`/api/bots/${v.bot.id}/positions/${pid}/close`, 'POST');
    if (!j.ok) setMsg(j.error || 'Gagal menutup posisi'); setBusy(null);
  };
  const closeAll = async () => {
    if (!v.open.length || !confirm(`Tutup semua ${v.open.length} posisi pada harga terakhir?`)) return;
    setBusy('all'); setMsg(null);
    const j = await ctx.call(`/api/bots/${v.bot.id}/close-all`, 'POST');
    if (!j.ok) setMsg(j.error || 'Gagal menutup posisi'); setBusy(null);
  };

  return (
    <>
      <BlackboxNav />
      <main className="page">
        <div className="pageTitle">
          <div><h1>Trades</h1><p>Posisi terbuka, riwayat, dan kontrol manual.</p></div>
          <div className="actions"><button className="btn danger" onClick={closeAll} disabled={!v.open.length || busy === 'all'}>CLOSE ALL</button></div>
        </div>
        {msg && <div className="banner red">{msg}</div>}
        <div className="metrics">
          <div className="metric"><div className="metricLabel">POSISI TERBUKA</div><div className="kpi">{v.open.length} / {v.guardrails.maxPositions}</div></div>
          <div className="metric"><div className="metricLabel">UNREALIZED PNL</div><div className={'kpi ' + (unreal >= 0 ? 'positive' : 'negative')}>{signedUsd(unreal)}</div></div>
          <div className="metric"><div className="metricLabel">WIN RATE</div><div className="kpi">{v.stats.winRate.toFixed(0)}%</div><div className="mini">{v.stats.wins}W / {v.stats.losses}L</div></div>
          <div className="metric"><div className="metricLabel">PRECISION TARGET</div><div className="kpi">≥{v.guardrails.targetWinRatePct ?? 85}%</div><div className="mini">{v.guardrails.signalProfile ?? "PRECISION"} · WAIT is valid</div></div>
        </div>

        <section className="panel section">
          <div className="panelHead"><span className="panelTitle">EXECUTION PIPELINE</span></div>
          <div className="panelBody">
            <div className="pipe">{STAGES.map((s) => <span key={s} className={v.bot.status === 'RUNNING' && last === s ? 'on' : ''}>{s}</span>)}</div>
            <div className="log">{fills.map((l: any) => <div key={l.id}><b>[FILL]</b> {l.message}</div>)}{!fills.length && <div className="small">Belum ada fill.</div>}</div>
          </div>
        </section>

        <section className="panel section">
          <div className="panelHead"><span className="panelTitle">POSISI TERBUKA</span><span className="pill">{v.open.length} / {v.guardrails.maxPositions}</span></div>
          <div className="panelBody tableWrap">
            <table className="table tradeTable">
              <thead><tr><th>TOKEN</th><th>ENTRY → SEKARANG</th><th>SIZE</th><th>NILAI</th><th>PNL</th><th>SL · TP</th><th>AI/RUG</th><th></th></tr></thead>
              <tbody>
                {v.open.map((p: any) => {
                  const lo = p.sl ?? p.entry * 0.85, hi = p.tp ?? p.entry * 1.4;
                  const pos = Math.max(0, Math.min(100, ((p.price - lo) / (hi - lo)) * 100));
                  return (
                    <tr key={p.id}>
                      <td><b>{p.symbol}</b><div className="small">{chainLabel(p.chainId)} · {p.dex}</div></td>
                      <td className="mono">${price(p.entry)} → ${price(p.price)}</td>
                      <td>{usd(p.sizeUsd)}</td><td>{usd(p.value)}</td>
                      <td className={p.pnl >= 0 ? 'positive' : 'negative'}>{signedUsd(p.pnl)}<div className="small">{pct((p.pnl / p.sizeUsd) * 100, 1)}</div></td>
                      <td style={{ minWidth: 150 }}><div className="lvl"><i style={{ left: `${pos}%` }} /></div><div className="small">SL ${price(lo)} · TP ${price(hi)}</div></td>
                      <td className="small">{p.aiScore ?? '—'} / {p.rugRisk ?? '—'}</td>
                      <td><button className="btn ghost" disabled={busy === p.id} onClick={() => close(p.id)}>CLOSE</button></td>
                    </tr>
                  );
                })}
                {!v.open.length && <tr><td colSpan={8} className="small">Tidak ada posisi terbuka.</td></tr>}
              </tbody>
            </table>
            <div className="tradeCards">
              {v.open.map((p: any) => {
                const lo = p.sl ?? p.entry * 0.85, hi = p.tp ?? p.entry * 1.4;
                const pos = Math.max(0, Math.min(100, ((p.price - lo) / (hi - lo)) * 100));
                return <article className="tradeCard" key={p.id}>
                  <div className="tradeCardTop"><div><div className="tradeCardSymbol">{p.symbol}</div><div className="small">{chainLabel(p.chainId)} · {p.dex}</div></div><span className={'pill ' + (p.pnl >= 0 ? 'green' : 'red')}>{signedUsd(p.pnl)}</span></div>
                  <div className="tradeCardGrid">
                    <div className="tradeCardCell"><span>ENTRY</span><b>${price(p.entry)}</b></div><div className="tradeCardCell"><span>NOW</span><b>${price(p.price)}</b></div>
                    <div className="tradeCardCell"><span>SIZE</span><b>{usd(p.sizeUsd)}</b></div><div className="tradeCardCell"><span>AI / RUG</span><b>{p.aiScore ?? '—'} / {p.rugRisk ?? '—'}</b></div>
                  </div>
                  <div className="lvl"><i style={{ left: `${pos}%` }} /></div><div className="small">SL ${price(lo)} · TP ${price(hi)} · {pct((p.pnl / p.sizeUsd) * 100, 1)}</div>
                  <button className="btn ghost" disabled={busy === p.id} onClick={() => close(p.id)}>CLOSE POSITION</button>
                </article>;
              })}
              {!v.open.length && <div className="small">Tidak ada posisi terbuka.</div>}
            </div>
          </div>
        </section>

        <section className="panel section">
          <div className="panelHead"><span className="panelTitle">RIWAYAT TRADE</span><span className="pill">{v.stats.trades} total</span></div>
          <div className="panelBody tableWrap">
            <table className="table">
              <thead><tr><th>HASIL</th><th>TOKEN</th><th>ENTRY REASON</th><th>ENTRY → EXIT</th><th>SIZE / QTY</th><th>PNL</th><th>EXIT REASON</th><th>DURASI</th><th>WAKTU ENTRY</th><th>WAKTU EXIT</th></tr></thead>
              <tbody>
                {v.closed.map((c: any) => (
                  <tr key={c.id}>
                    <td><span className={'pill ' + (c.pnl >= 0 ? 'profit' : 'red')}>{c.pnl >= 0 ? 'WIN' : 'LOSS'}</span></td>
                    <td><b>{c.symbol}</b><div className="small">{chainLabel(c.chainId)}</div></td>
                    <td className="small">{c.openReason || '—'}</td>
                    <td className="mono">${price(c.entryPrice)} → ${price(c.exitPrice || c.entryPrice)}</td>
                    <td className="small">{usd(c.sizeUsd)} · {Number(c.quantity || 0).toPrecision(6)}</td>
                    <td className={c.pnl >= 0 ? 'positive' : 'negative'}>{signedUsd(c.pnl)} <span className="small">({pct(c.pnlPct, 1)})</span></td>
                    <td>{REASON[c.reason] || c.reason || '—'}</td>
                    <td className="small">{c.durationSec != null ? `${Math.floor(c.durationSec/60)}m ${c.durationSec%60}s` : '—'}</td>
                    <td className="small">{c.openedAt ? new Date(c.openedAt).toLocaleString('id-ID') : '—'}</td>
                    <td className="small">{c.closedAt ? new Date(c.closedAt).toLocaleString('id-ID') : '—'}</td>
                  </tr>
                ))}
                {!v.closed.length && <tr><td colSpan={10} className="small">Belum ada trade yang ditutup.</td></tr>}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </>
  );
}
