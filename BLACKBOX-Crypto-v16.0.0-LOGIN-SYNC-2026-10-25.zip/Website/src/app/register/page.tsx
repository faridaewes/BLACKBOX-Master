'use client';
import { useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import BlackboxLogo from '@/components/BlackboxLogo';

declare global {
  interface Window {
    google?: any;
  }
}

export default function RegisterPage() {
  const r = useRouter();
  const params = useSearchParams();
  const [f, setF] = useState({
    name: '',
    username: '',
    email: '',
    phone: '',
    password: '',
    referralCode: '',
  });
  const [phoneOtpChannel, setPhoneOtpChannel] = useState<'WHATSAPP' | 'SMS'>('WHATSAPP');
  const [agreement, setAgreement] = useState(false);
  const [almaAgreement, setAlmaAgreement] = useState(false);
  const [tradingRulesAgreement, setTradingRulesAgreement] = useState(false);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [refStatus, setRefStatus] = useState<'idle' | 'checking' | 'valid' | 'invalid'>('idle');
  const [sponsor, setSponsor] = useState('');
  const [refSource, setRefSource] = useState<string | null>(null);
  const googleEnabled = !!(process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID || '').trim();

  // Prefill from Google redirect or query
  useEffect(() => {
    const ge = params.get('googleEmail') || '';
    const gn = params.get('googleName') || '';
    if (ge || gn) {
      setF((x) => ({
        ...x,
        email: ge || x.email,
        name: gn || x.name,
      }));
    }
    const incoming =
      params.get('ref') || params.get('referral') || params.get('referralCode') || '';
    if (incoming) {
      setF((x) => ({ ...x, referralCode: incoming.toUpperCase() }));
      setRefSource('LINK');
    }
  }, [params]);

  useEffect(() => {
    if (!googleEnabled) return;
    const s = document.createElement('script');
    s.src = 'https://accounts.google.com/gsi/client';
    s.async = true;
    s.defer = true;
    s.onload = async () => {
      const clientId = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID || '';
      if (!window.google || !clientId) return;
      let nonce = '';
      try {
        const challengeResponse = await fetch('/api/auth/google/nonce', { method: 'GET', cache: 'no-store', credentials: 'same-origin' });
        const challenge = await challengeResponse.json().catch(() => ({}));
        if (!challengeResponse.ok || typeof challenge.nonce !== 'string' || !challenge.nonce) {
          setErr(challenge.error || 'Tidak dapat memulai verifikasi Google. Silakan muat ulang halaman.');
          return;
        }
        nonce = challenge.nonce;
      } catch {
        setErr('Tidak dapat memulai verifikasi Google. Periksa koneksi lalu muat ulang halaman.');
        return;
      }
      window.google.accounts.id.initialize({
        client_id: clientId,
        nonce,
        callback: async (res: any) => {
          // Decode email/name from credential via backend probe
          try {
            const x = await fetch('/api/auth/google', {
              method: 'POST',
              headers: { 'content-type': 'application/json' },
              body: JSON.stringify({ credential: res.credential, nonce }),
            });
            const j = await x.json();
            if (j.ok) {
              // Already registered — go dashboard
              r.push('/dashboard');
              return;
            }
            if (j.registrationRequired && j.email) {
              setF((prev) => ({
                ...prev,
                email: j.email || prev.email,
                name: j.name || prev.name,
              }));
              setErr(
                'Akun Google terdeteksi. Lengkapi data di bawah (username, HP, password) untuk menyelesaikan pendaftaran.',
              );
            } else {
              setErr(j.error === 'GOOGLE_LOGIN_NOT_CONFIGURED'
                ? 'Pendaftaran Google belum dikonfigurasi oleh pengelola. Silakan lanjutkan dengan formulir manual.'
                : j.error || 'Google tidak dapat diproses');
            }
          } catch {
            setErr('Gagal menghubungkan Google');
          }
        },
      });
      const target = document.getElementById('google-register');
      if (target) {
        target.innerHTML = '';
        window.google.accounts.id.renderButton(target, {
          theme: 'outline',
          size: 'large',
          width: Math.max(220, Math.floor(target.clientWidth || 360)),
          text: 'signup_with',
          shape: 'rectangular',
          logo_alignment: 'left',
        });
      }
    };
    document.head.appendChild(s);
    return () => {
      s.remove();
    };
  }, [googleEnabled, r]);

  async function validateReferral(): Promise<boolean> {
    const code = f.referralCode.trim().toUpperCase();
    if (!code) {
      setRefStatus('idle');
      setSponsor('');
      return true;
    }
    setRefStatus('checking');
    setErr('');
    try {
      const x = await fetch('/api/auth/referral/validate', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ referralCode: code }),
      });
      const j = await x.json().catch(() => ({}));
      if (j.valid) {
        setRefStatus('valid');
        setSponsor(j.sponsorUsername || '');
        return true;
      }
      setRefStatus('invalid');
      setSponsor('');
      setErr('Kode referral tidak aktif atau tidak ditemukan.');
      return false;
    } catch {
      setRefStatus('invalid');
      setErr('Tidak dapat memeriksa kode referral.');
      return false;
    }
  }

  async function go() {
    setBusy(true);
    setErr('');
    try {
      if (!agreement || !almaAgreement || !tradingRulesAgreement) {
        setErr('Anda harus menyetujui seluruh pernyataan registrasi, Trading Rules, risiko, privasi, dan kewajiban pendaftaran Penasihat Berjangka.');
        return;
      }
      if (f.referralCode) {
        const ok = await validateReferral();
        if (!ok) return;
      }
      const x = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          ...f,
          phoneOtpChannel,
          referralSource: f.referralCode ? refSource || 'MANUAL' : null,
          agreementAccepted: agreement,
          advisorRegistrationAccepted: almaAgreement,
          tradingRulesAccepted: tradingRulesAgreement,
          consentContext: { timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Jakarta', locale: navigator.language || 'id-ID', source: 'WEB_REGISTRATION', readAt: new Date().toISOString() },
        }),
      });
      const j = await x.json().catch(() => ({}));
      if (j.ok) r.push(`/verify?userId=${encodeURIComponent(j.userId)}`);
      else
        setErr(
          j.error === 'REFERRAL_CODE_NOT_ACTIVE'
            ? 'Kode referral tidak aktif.'
            : j.error || 'Gagal registrasi.',
        );
    } catch {
      setErr('Koneksi ke server gagal.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="authShell">
      <div className="authCard authCardWide">
        <div className="authBrand">
          <BlackboxLogo />
          <span className="badge">CREATE ACCOUNT</span>
        </div>
        <h1>Daftar BLACKBOX</h1>
        <p className="authLead">
          Isi data secara manual, atau hubungkan akun Google di perangkat Anda lalu lengkapi profil.
        </p>

        {googleEnabled ? (
          <>
            <div id="google-register" className="googleBtnWrap" />
            <div className="authDivider">
              <span>atau isi manual</span>
            </div>
          </>
        ) : (
          <p className="hint authProviderHint">Pendaftaran Google belum dikonfigurasi. Anda tetap dapat membuat akun menggunakan formulir di bawah.</p>
        )}

        <div className="authGrid2">
          <label className="authLabel">
            Nama lengkap
            <input
              className="input"
              value={f.name}
              onChange={(e) => setF({ ...f, name: e.target.value })}
              placeholder="Sesuai identitas"
            />
          </label>
          <label className="authLabel">
            Username
            <input
              className="input"
              value={f.username}
              onChange={(e) => setF({ ...f, username: e.target.value.toLowerCase() })}
              placeholder="huruf kecil, 4–24 karakter"
            />
          </label>
          <label className="authLabel">
            Email
            <input
              className="input"
              type="email"
              value={f.email}
              onChange={(e) => setF({ ...f, email: e.target.value })}
              placeholder="nama@email.com"
            />
          </label>
          <label className="authLabel">
            Nomor HP / WhatsApp
            <input
              className="input"
              value={f.phone}
              onChange={(e) => setF({ ...f, phone: e.target.value })}
              placeholder="08… atau +62…"
            />
          </label>
        </div>

        <div
          className="phoneChannelPick"
          style={{
            margin: '12px 0',
            padding: 12,
            borderRadius: 12,
            border: '1px solid rgba(255,211,67,.2)',
          }}
        >
          <div style={{ fontWeight: 600, marginBottom: 8 }}>Verifikasi nomor via</div>
          <label style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
            <input
              type="radio"
              checked={phoneOtpChannel === 'WHATSAPP'}
              onChange={() => setPhoneOtpChannel('WHATSAPP')}
            />
            WhatsApp saja
          </label>
          <label style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <input
              type="radio"
              checked={phoneOtpChannel === 'SMS'}
              onChange={() => setPhoneOtpChannel('SMS')}
            />
            SMS saja
          </label>
        </div>

        <label className="authLabel">
          Password
          <input
            className="input"
            type="password"
            value={f.password}
            onChange={(e) => setF({ ...f, password: e.target.value })}
            placeholder="Minimal sesuai kebijakan keamanan"
          />
        </label>
        <label className="authLabel">
          Kode referral (opsional)
          <input
            className="input"
            value={f.referralCode}
            onChange={(e) => {
              setF({ ...f, referralCode: e.target.value.toUpperCase() });
              setRefSource('MANUAL');
              setRefStatus('idle');
            }}
            onBlur={() => f.referralCode && validateReferral()}
            placeholder="Opsional"
          />
          {refStatus === 'valid' && (
            <span className="hint">Referral valid{sponsor ? ` · sponsor @${sponsor}` : ''}</span>
          )}
          {refStatus === 'invalid' && <span className="hint">Kode tidak valid</span>}
        </label>

        <div className="panel section" style={{ marginTop: 12 }}>
          <div className="panelHead"><span className="panelTitle">PERSETUJUAN REGISTRASI & KEPATUHAN</span></div>
          <div className="panelBody">
            <label className="authCheck agreementItem"><input type="checkbox" checked={agreement} onChange={(e) => setAgreement(e.target.checked)} /> Saya telah membaca, memahami, dan secara sadar menyetujui Syarat Penggunaan, Kebijakan Privasi, serta Pemberitahuan Risiko BLACKBOX. Saya memahami bahwa trading tidak menjamin keuntungan dan dapat menyebabkan kerugian nyata, termasuk kehilangan sebagian atau seluruh modal yang digunakan.</label>
            <div className="agreementHeading">Trading Rules &amp; User Control Agreement</div>
                <label className="authCheck agreementItem"><input type="checkbox" checked={tradingRulesAgreement} onChange={(e) => setTradingRulesAgreement(e.target.checked)} /> Saya telah membaca, memahami, dan secara sadar menyetujui <b>TRADING RULES &amp; USER CONTROL AGREEMENT</b>. Saya memahami bahwa kendali trading, koneksi pihak ketiga, modal, parameter risiko, dan keputusan transaksi berada pada saya; BLACKBOX dan AI hanya boleh bekerja dalam batas konfigurasi, mandat, safety gate, dan persetujuan yang saya berikan. Saya menyatakan persetujuan ini secara sadar, sukarela, dan tanpa paksaan serta, sejauh diperbolehkan dan dapat diberlakukan menurut hukum, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan, klaim, atau permintaan ganti rugi sehubungan dengan penggunaan layanan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, konfirmasi, izinkan, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku. Agreement dapat saya unduh kembali.</label>
            <label className="authCheck agreementItem"><input type="checkbox" checked={almaAgreement} onChange={(e) => setAlmaAgreement(e.target.checked)} /> Saya telah membaca, memahami, dan secara sadar menyetujui pemberitahuan bahwa sejak registrasi saya telah menerima pemberitahuan bahwa untuk layanan/fungsi BLACKBOX dalam ruang lingkup Penasihat Berjangka, saya wajib mendaftar, melakukan verifikasi, dan menerima perjanjian layanan PT Alma Indonesia Raya melalui kanal resminya. Saya memahami akun BLACKBOX tidak menggantikan hubungan hukum atau perjanjian saya dengan PT Alma Indonesia Raya.</label>
            <p className="small" style={{marginBottom:0}}>Sebelum menekan Daftar sekarang, baca dokumen lengkap pada <Link href="/legal" className="positive">Legal &amp; Consent Center</Link>. Persetujuan dicatat secara elektronik dengan versi dan hash dokumen, identitas pengguna pada saat persetujuan, tanggal dan waktu UTC, waktu lokal/zona waktu, sumber dan metode persetujuan, user-agent, serta bukti teknis yang relevan. Bukti persetujuan dapat diunduh kembali oleh pengguna. Persetujuan tidak menghapus hak pengguna atau tanggung jawab pihak mana pun yang menurut hukum tidak dapat dikesampingkan.</p>
          </div>
        </div>

        {err && <div className="banner warnBanner">{err}</div>}

        <button className="btn primary authSubmit" disabled={busy} onClick={go}>
          {busy ? 'Mendaftarkan…' : 'Daftar sekarang'}
        </button>

        <div className="authLinks">
          <Link href="/login">Sudah punya akun? Masuk</Link>
        </div>
        <p className="authFoot">Data dilindungi · Verifikasi email &amp; nomor wajib untuk aktivasi penuh</p>
      </div>
    </main>
  );
}
