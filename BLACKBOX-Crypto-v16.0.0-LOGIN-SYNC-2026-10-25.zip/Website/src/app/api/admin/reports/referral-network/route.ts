import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { authStatus } from '@/lib/auth';
import { assertAdminAssignment } from '@/lib/admin-policy';
import { MAX_REFERRAL_DEPTH } from '@/lib/referral-reward-v91';

const schema = z.object({ rootUserId:z.string().min(1), depth:z.coerce.number().int().min(1).max(MAX_REFERRAL_DEPTH).default(MAX_REFERRAL_DEPTH) });

export async function GET(req: Request) {
  try {
    const actor = await requirePermissionSession(PERMISSIONS.AUDIT_READ);
    const q = schema.parse(Object.fromEntries(new URL(req.url).searchParams.entries()));
    const root = await db.user.findUnique({where:{id:q.rootUserId},select:{id:true,username:true,name:true,email:true,referralCode:true,referredById:true,createdAt:true}});
    if (!root) return NextResponse.json({ok:false,error:'USER_NOT_FOUND'}, {status:404});
    if (actor.role==='ADMIN') {
      const assigned = await db.adminAssignment.findUnique({where:{adminId_userId:{adminId:actor.userId,userId:q.rootUserId}}});
      assertAdminAssignment(actor.role as any, !!assigned);
    }
    const rows = await db.$queryRaw<any[]>`
      WITH RECURSIVE network AS (
        SELECT u."id", u."referredById", 0::int AS "level", ARRAY[u."id"]::text[] AS path
        FROM "User" u WHERE u."id"=${q.rootUserId}
        UNION ALL
        SELECT c."id", c."referredById", n."level"+1, n.path || c."id"
        FROM network n JOIN "User" c ON c."referredById"=n."id"
        WHERE n."level" < ${q.depth} AND NOT c."id" = ANY(n.path)
      )
      SELECT n."level", u."id", u."username", u."name", u."email", u."status", u."kycStatus", u."hasEverActivated", u."referralPro", u."referralCode", u."referredById", u."createdAt"
      FROM network n JOIN "User" u ON u."id"=n."id"
      ORDER BY n."level" ASC, u."createdAt" ASC, u."username" ASC
    `;
    const levels=Array.from({length:q.depth+1},(_,i)=>({level:i,members:0}));
    for(const r of rows) levels[Number(r.level)].members++;
    const ids=rows.map(r=>String(r.id));
    const [ledger, events, moves] = await Promise.all([
      ids.length ? db.referralPointLedger.findMany({where:{userId:{in:ids}},orderBy:{createdAt:'desc'},take:5000,select:{userId:true,amount:true,kind:true,status:true,referenceType:true,referenceId:true,counterpartyUserId:true,description:true,createdAt:true}}) : [],
      ids.length ? db.referralOSEvent.findMany({where:{OR:[{userId:{in:ids}},{sponsorId:{in:ids}}]},orderBy:{createdAt:'desc'},take:5000}) : [],
      ids.length ? db.referralTreeMove.findMany({where:{OR:[{userId:{in:ids}},{fromSponsorId:{in:ids}},{toSponsorId:{in:ids}}]},orderBy:{createdAt:'desc'},take:1000}) : [],
    ]);
    await db.auditLog.create({data:{actorId:actor.userId,action:'REFERRAL_NETWORK_REPORT_EXPORTED',targetType:'USER',targetId:q.rootUserId,metadata:{depth:q.depth,members:rows.length}}}).catch(()=>{});
    return NextResponse.json({ok:true,generatedAt:new Date().toISOString(),root,depth:q.depth,totalMembers:Math.max(0,rows.length-1),levels,members:rows,ledger,events,moves},{headers:{'cache-control':'no-store'}});
  } catch(e) {
    const msg=e instanceof Error?e.message:String(e);
    if(e instanceof z.ZodError) return NextResponse.json({ok:false,error:'INPUT_TIDAK_VALID'},{status:400});
    if(msg==='USER_NOT_ASSIGNED_TO_ADMIN'||msg==='FORBIDDEN') return NextResponse.json({ok:false,error:msg},{status:403});
    return NextResponse.json({ok:false,error:'REFERRAL_NETWORK_REPORT_FAILED'},{status:authStatus(e)});
  }
}
