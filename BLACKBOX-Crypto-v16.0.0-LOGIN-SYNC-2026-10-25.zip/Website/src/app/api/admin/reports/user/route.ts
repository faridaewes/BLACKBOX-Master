import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { authStatus } from '@/lib/auth';
import { assertAdminAssignment } from '@/lib/admin-policy';

const schema = z.object({
  userId: z.string().min(1),
  from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  to: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  limit: z.coerce.number().int().min(1).max(2000).default(500),
});

function dateRange(from?: string, to?: string) {
  if (!from && !to) return undefined;
  const start = new Date(`${from || to}T00:00:00.000Z`);
  const end = new Date(`${to || from}T23:59:59.999Z`);
  if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || start > end) throw new Error('INVALID_DATE_RANGE');
  return { gte: start, lte: end };
}

async function assertCanView(actor: { userId: string; role: string }, userId: string) {
  if (actor.role === 'DEVELOPER') return;
  const assignment = await db.adminAssignment.findUnique({ where: { adminId_userId: { adminId: actor.userId, userId } } });
  assertAdminAssignment(actor.role as any, !!assignment);
}

export async function GET(req: Request) {
  try {
    const actor = await requirePermissionSession(PERMISSIONS.AUDIT_READ);
    const q = schema.parse(Object.fromEntries(new URL(req.url).searchParams.entries()));
    await assertCanView(actor, q.userId);
    const user = await db.user.findUnique({
      where: { id: q.userId },
      select: { id:true,name:true,username:true,email:true,phone:true,role:true,status:true,kycStatus:true,createdAt:true,updatedAt:true,hasEverActivated:true,referralPro:true,referralCode:true,referredBy:{select:{id:true,username:true,name:true}} },
    });
    if (!user) return NextResponse.json({ ok:false, error:'USER_NOT_FOUND' }, { status:404 });
    const range = dateRange(q.from, q.to);
    const [orders, executions, positions, fills, portfolioEvents, subscriptions, redemptions, points, referralAttribution, referralEvents, audits, activity, reconciliations] = await Promise.all([
      db.order.findMany({ where:{ bot:{userId:q.userId}, ...(range ? {createdAt:range}: {}) }, orderBy:{createdAt:'desc'}, take:q.limit }),
      db.execution.findMany({ where:{ userId:q.userId, ...(range ? {createdAt:range}: {}) }, orderBy:{createdAt:'desc'}, take:q.limit }),
      db.position.findMany({ where:{ bot:{userId:q.userId}, ...(range ? {openedAt:range}: {}) }, orderBy:{openedAt:'desc'}, take:q.limit }),
      db.positionFill.findMany({ where:{ position:{bot:{userId:q.userId}}, ...(range ? {createdAt:range}: {}) }, orderBy:{createdAt:'desc'}, take:q.limit }),
      db.portfolioEvent.findMany({ where:{userId:q.userId, ...(range ? {occurredAt:range}: {})}, orderBy:{occurredAt:'desc'}, take:q.limit }),
      db.subscription.findMany({ where:{userId:q.userId, ...(range ? {createdAt:range}: {})}, orderBy:{createdAt:'desc'}, take:q.limit, select:{id:true,status:true,startsAt:true,expiresAt:true,complimentary:true,createdAt:true,plan:{select:{id:true,name:true}}} }),
      db.referralRedemption.findMany({ where:{userId:q.userId, ...(range ? {createdAt:range}: {})}, orderBy:{createdAt:'desc'}, take:q.limit }),
      db.referralPointLedger.findMany({ where:{userId:q.userId, ...(range ? {createdAt:range}: {})}, orderBy:{createdAt:'desc'}, take:q.limit }),
      db.referralRegistrationAttribution.findUnique({ where:{userId:q.userId}, select:{id:true,sponsorId:true,referralCode:true,source:true,createdAt:true,sponsor:{select:{username:true,name:true}}} }),
      db.referralOSEvent.findMany({ where:{userId:q.userId, ...(range ? {createdAt:range}: {})}, orderBy:{createdAt:'desc'}, take:q.limit }),
      db.auditLog.findMany({ where:{targetId:q.userId, ...(range ? {createdAt:range}: {})}, orderBy:{createdAt:'desc'}, take:q.limit }),
      db.userActivityEvent.findMany({ where:{userId:q.userId, ...(range ? {occurredAt:range}: {})}, orderBy:{occurredAt:'desc'}, take:q.limit }),
      db.reconciliation.findMany({ where:{ execution:{userId:q.userId}, ...(range ? {checkedAt:range}: {}) }, orderBy:{checkedAt:'desc'}, take:q.limit }),
    ]);
    const pointsBalance = points.reduce((n, x) => n + x.amount, 0);
    await db.auditLog.create({ data:{ actorId:actor.userId, action:'USER_SUPPORT_REPORT_EXPORTED', targetType:'USER', targetId:q.userId, metadata:{from:q.from||null,to:q.to||null,limit:q.limit} } }).catch(()=>{});
    return NextResponse.json({ ok:true, generatedAt:new Date().toISOString(), actorRole:actor.role, filters:{from:q.from||null,to:q.to||null,limit:q.limit}, user, summary:{pointsBalance,orders:orders.length,executions:executions.length,positions:positions.length,fills:fills.length,portfolioEvents:portfolioEvents.length,subscriptions:subscriptions.length,referralRedemptions:redemptions.length,referralEvents:referralEvents.length,audits:audits.length,activity:activity.length,reconciliations:reconciliations.length}, referral:{attribution:referralAttribution, events:referralEvents, ledger:points, redemptions}, trading:{orders,executions,positions,fills,reconciliations,portfolioEvents}, access:{subscriptions}, audit:{audits,activity} }, { headers:{'cache-control':'no-store'} });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    if (e instanceof z.ZodError) return NextResponse.json({ok:false,error:'INPUT_TIDAK_VALID'}, {status:400});
    if (msg==='USER_NOT_ASSIGNED_TO_ADMIN' || msg==='FORBIDDEN') return NextResponse.json({ok:false,error:msg}, {status:403});
    if (msg==='INVALID_DATE_RANGE') return NextResponse.json({ok:false,error:msg}, {status:400});
    return NextResponse.json({ok:false,error:'USER_REPORT_FAILED'}, {status:authStatus(e)});
  }
}
