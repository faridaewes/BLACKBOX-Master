import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { authStatus, apiError } from '@/lib/auth';
import { assistedTransferPartner } from '@/lib/partner-transfer';
import { db } from '@/lib/prisma';
import { notifyUser } from '@/lib/notify-user';
const schema=z.object({userId:z.string().min(1),newSponsorId:z.string().min(1),reason:z.string().trim().min(5).max(500)});
export async function POST(req:Request){try{const actor=await requirePermissionSession(PERMISSIONS.REFERRAL_NETWORK_WRITE);const b=schema.parse(await req.json());const result=await assistedTransferPartner(actor.userId,b.userId,b.newSponsorId,b.reason);const user=await db.user.findUnique({where:{id:b.userId},select:{email:true}});await notifyUser({userId:b.userId,title:'Partner Anda telah diperbarui oleh tim',body:`Permintaan perpindahan partner Anda telah diproses. Partner baru: @${result.newSponsorUsername}. Alasan internal: ${b.reason}. Perubahan tercatat di audit log.`,email:user?.email,emailSubject:'BLACKBOX — Perubahan Partner Diproses',type:'PARTNER_TRANSFER_ASSISTED',priority:'HIGH',dedupeKey:`PARTNER_TRANSFER_ASSISTED:${result.movedAt}`});return NextResponse.json({ok:true,result});}catch(e){if(e instanceof z.ZodError)return NextResponse.json({ok:false,error:'INPUT_INVALID'},{status:400});return NextResponse.json({ok:false,error:apiError(e)},{status:authStatus(e)});}}
