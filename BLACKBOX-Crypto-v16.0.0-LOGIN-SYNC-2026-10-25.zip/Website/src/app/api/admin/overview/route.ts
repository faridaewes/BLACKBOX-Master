import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { NextResponse } from "next/server";
import { db } from "@/lib/prisma";
import { apiError,  authStatus } from "@/lib/auth";
import { getFlags } from "@/lib/emergency";

export async function GET() {
  try {
    const s = await requirePermissionSession(PERMISSIONS.USER_READ);
    const [users, activeUsers, bots, running, openPositions, aiCalls, audit] = await Promise.all([
      db.user.count(), db.user.count({ where: { status: "ACTIVE" } }), db.bot.count(), db.bot.count({ where: { status: "RUNNING" } }),
      db.position.count({ where: { status: "OPEN" } }), db.aiCall.count(),
      db.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 12, select: { action: true, targetType: true, createdAt: true } }),
    ]);
    return NextResponse.json({ ok: true, role: s.role, flags: await getFlags(), counts: { users, activeUsers, bots, running, openPositions, aiCalls }, audit });
  } catch (e) { return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) }); }
}
