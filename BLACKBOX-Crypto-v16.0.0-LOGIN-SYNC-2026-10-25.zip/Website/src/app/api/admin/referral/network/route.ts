import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { apiError,  authStatus } from '@/lib/auth';
import { moveReferralSubtree } from '@/lib/referral-tree-v98';

const moveSchema = z.object({
  userId: z.string().min(1),
  newSponsorId: z.string().min(1),
  reason: z.string().trim().max(500).optional(),
});

export async function GET(req: Request) {
  try {
    await requirePermissionSession(PERMISSIONS.USER_READ);
    const url = new URL(req.url);
    const q = (url.searchParams.get('q') || '').trim().toLowerCase();
    const users = await db.user.findMany({
      where: q ? { OR: [{ username: { contains: q, mode: 'insensitive' } }, { email: { contains: q, mode: 'insensitive' } }] } : undefined,
      select: { id: true, username: true, name: true, referredById: true, referredBy: { select: { username: true } }, referralCode: true },
      orderBy: { username: 'asc' },
      take: 100,
    });
    return NextResponse.json({ ok: true, version: '10.0.0', users });
  } catch (e) {
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}

export async function POST(req: Request) {
  try {
    const actor = await requirePermissionSession(PERMISSIONS.REFERRAL_NETWORK_WRITE);
    const body = moveSchema.parse(await req.json());
    const result = await db.$transaction(async tx => moveReferralSubtree(tx, body.userId, body.newSponsorId, actor.userId, body.reason), { isolationLevel: 'Serializable' });
    await db.auditLog.create({ data: { actorId: actor.userId, action: 'REFERRAL_SUBTREE_MOVED', targetType: 'USER', targetId: body.userId, metadata: result } });
    return NextResponse.json({ ok: true, ...result });
  } catch (e) {
    if (e instanceof z.ZodError) return NextResponse.json({ ok: false, error: 'INPUT_TIDAK_VALID' }, { status: 400 });
    const msg = e instanceof Error ? e.message : String(e);
    const known = ['REFERRAL_MOVE_SELF_NOT_ALLOWED','REFERRAL_MOVE_USER_NOT_FOUND','REFERRAL_MOVE_TARGET_NOT_FOUND','REFERRAL_MOVE_ALREADY_IN_TARGET_NETWORK','REFERRAL_MOVE_DESCENDANT_TARGET_NOT_ALLOWED','REFERRAL_MOVE_DEPTH_LIMIT_EXCEEDED','REFERRAL_TREE_CYCLE_DETECTED'];
    return NextResponse.json({ ok: false, error: known.includes(msg) ? msg : 'REFERRAL_TREE_MOVE_FAILED' }, { status: known.includes(msg) ? 409 : authStatus(e) });
  }
}
