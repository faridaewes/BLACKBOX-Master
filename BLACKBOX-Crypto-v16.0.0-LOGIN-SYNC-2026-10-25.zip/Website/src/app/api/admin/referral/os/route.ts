import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { NextResponse } from 'next/server';

import { getReferralOSAdminSummary, REFERRAL_OS_VERSION } from '@/lib/referral-os-v100';

export async function GET() {
  try {
    await requirePermissionSession(PERMISSIONS.USER_READ);
    const summary = await getReferralOSAdminSummary();
    return NextResponse.json({ ok:true, version:REFERRAL_OS_VERSION, summary }, { headers:{'Cache-Control':'no-store'} });
  } catch (e) {
    return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:403});
  }
}
