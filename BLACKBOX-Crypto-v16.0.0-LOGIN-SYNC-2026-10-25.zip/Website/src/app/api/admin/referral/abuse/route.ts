import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { apiError,  authStatus } from '@/lib/auth';
import { REFERRAL_ABUSE_STATUSES, assessReferralAbuse } from '@/lib/referral-abuse-v97';

const patchSchema = z.object({
  userId: z.string().min(1),
  action: z.enum(['REASSESS', 'REVIEW']),
  status: z.enum(REFERRAL_ABUSE_STATUSES).optional(),
  note: z.string().trim().max(500).optional(),
});

export async function GET(req: Request) {
  try {
    await requirePermissionSession(PERMISSIONS.AUDIT_READ);
    const url = new URL(req.url);
    const status = url.searchParams.get('status');
    const rows = await db.referralAbuseRisk.findMany({
      where: status && REFERRAL_ABUSE_STATUSES.includes(status as any) ? { status } : undefined,
      include: { user: { select: { id: true, username: true, status: true, hasEverActivated: true, kycStatus: true, referredById: true } } },
      orderBy: [{ score: 'desc' }, { updatedAt: 'desc' }],
      take: 200,
    });
    return NextResponse.json({ ok: true, version: '9.7.0', risks: rows });
  } catch (e) {
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}

export async function PATCH(req: Request) {
  try {
    const actor = await requirePermissionSession(PERMISSIONS.AUDIT_READ);
    const body = patchSchema.parse(await req.json());
    if (body.action === 'REASSESS') {
      const risk = await db.$transaction(tx => assessReferralAbuse(tx, body.userId));
      await db.auditLog.create({ data: { actorId: actor.userId, action: 'REFERRAL_ABUSE_REASSESSED', targetType: 'USER', targetId: body.userId, metadata: { score: risk.score, status: risk.status, flags: risk.flags } } });
      return NextResponse.json({ ok: true, risk });
    }
    if (!body.status) return NextResponse.json({ ok: false, error: 'STATUS_REQUIRED' }, { status: 400 });
    const risk = await db.referralAbuseRisk.upsert({
      where: { userId: body.userId },
      create: { userId: body.userId, score: body.status === 'BLOCKED' ? 100 : body.status === 'REVIEW' ? 50 : 0, status: body.status, flags: [], metrics: {}, reviewedAt: new Date(), reviewedById: actor.userId, reviewNote: body.note || null },
      update: { status: body.status, reviewedAt: new Date(), reviewedById: actor.userId, reviewNote: body.note || null },
    });
    await db.auditLog.create({ data: { actorId: actor.userId, action: 'REFERRAL_ABUSE_REVIEWED', targetType: 'USER', targetId: body.userId, metadata: { status: body.status, note: body.note || null } } });
    return NextResponse.json({ ok: true, risk });
  } catch (e) {
    if (e instanceof z.ZodError) return NextResponse.json({ ok: false, error: 'INPUT_TIDAK_VALID' }, { status: 400 });
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}
