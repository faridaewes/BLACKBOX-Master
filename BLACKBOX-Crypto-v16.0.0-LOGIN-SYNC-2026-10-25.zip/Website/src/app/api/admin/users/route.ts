import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/prisma";
import { apiError,  authStatus } from "@/lib/auth";
import { denyReason, clampDays, assertAdminAssignment } from "@/lib/admin-policy";
import { hashPassword } from "@/lib/auth";
import crypto from "node:crypto";
import { requirePermissionSession, requirePermission, PERMISSIONS, requirePrincipal, requireHighRiskAccess } from '@/lib/access-control';
import { resetUserPassword, resetUserEmail, permanentlyAnonymizeUser, suspendUser } from '@/lib/user-account-admin';

export async function GET() {
  try {
    const actor = await requirePermissionSession(PERMISSIONS.USER_READ);
    const userWhere: any = actor.role === "ADMIN"
      ? { role: "USER", assignmentsReceived: { some: { adminId: actor.userId } } }
      : {};
    const [users, plans] = await Promise.all([
      db.user.findMany({
        where: userWhere, orderBy: { createdAt: "desc" }, take: 200,
        select: {
          id: true, email: true, name: true, phone: true, role: true, status: true, createdAt: true, mfaEnabled: true, mfaRecoveryRequired: true,
          _count: { select: { bots: true } },
          subscriptions: { where: { status: "ACTIVE", expiresAt: { gt: new Date() } }, orderBy: { expiresAt: "desc" }, take: 1,
            select: { expiresAt: true, plan: { select: { id: true, name: true, entitlements: true } }, entitlementsOverride: true } },
          assignmentsReceived: { select: { admin: { select: { id: true, name: true, email: true } } }, take: 10 }
        }
      }),
      db.accessPlan.findMany({ where: { active: true }, select: { id: true, name: true, entitlements: true } }),
    ]);
    return NextResponse.json({
      ok: true, plans,
      users: users.map((u) => ({
        id: u.id, email: u.email, name: u.name, phone: u.phone, role: u.role, status: u.status, mfaEnabled: u.mfaEnabled, mfaRecoveryRequired: u.mfaRecoveryRequired,
        createdAt: u.createdAt, bots: u._count.bots, plan: u.subscriptions[0]?.plan.name ?? null,
        planExpiresAt: u.subscriptions[0]?.expiresAt ?? null, planId: u.subscriptions[0]?.plan.id ?? null, planEntitlements: u.subscriptions[0]?.plan.entitlements ?? null, entitlementsOverride: u.subscriptions[0]?.entitlementsOverride ?? null,
        assignedAdmins: u.assignmentsReceived.map((x) => x.admin)
      }))
    });
  } catch (e) { return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) }); }
}

const schema = z.discriminatedUnion("action", [
  z.object({ userId: z.string().min(1), action: z.literal("SET_STATUS"), status: z.enum(["ACTIVE", "SUSPENDED", "DISABLED"]) }),
  z.object({ userId: z.string().min(1), action: z.literal("GRANT_PLAN"), planId: z.string().min(1), days: z.number().optional() }),
  z.object({ userId: z.string().min(1), action: z.literal("REVOKE_PLAN") }),
  z.object({ userId: z.string().min(1), action: z.literal("SET_ROLE"), role: z.enum(["USER", "ADMIN"]) }),
  z.object({ userId: z.string().min(1), action: z.literal("RESET_SESSION") }),
  z.object({ userId: z.string().min(1), action: z.literal("RESET_MFA") }),
  z.object({ userId: z.string().min(1), action: z.literal("RESET_PASSWORD") }),
  z.object({ userId: z.string().min(1), action: z.literal("FORCE_PASSWORD_CHANGE") }),
  z.object({ userId: z.string().min(1), action: z.literal("RESET_EMAIL"), newEmail: z.string().email().max(320) }),
  z.object({ userId: z.string().min(1), action: z.literal("DELETE_ACCOUNT"), confirmation: z.literal("DELETE PERMANENTLY") }),
  z.object({ userId: z.string().min(1), action: z.literal("SET_ENTITLEMENT_OVERRIDE"), entitlements: z.object({ activeBots: z.number().int().min(0).max(10000), concurrentPositions: z.number().int().min(0).max(100000), exchanges: z.number().int().min(0).max(1000), scanSeconds: z.number().int().min(1).max(86400), marketPairs: z.number().int().min(0).max(100000), ai: z.string().min(1).max(32), marketTypes: z.array(z.enum(["SPOT","FUTURES","DEX"])).min(1).max(3), features: z.record(z.string(), z.boolean()).default({}) }) }),
]);

export async function PATCH(req: Request) {
  try {
    const actor = await requirePermissionSession(PERMISSIONS.USER_READ);
    const b = schema.parse(await req.json());
    const target = await db.user.findUnique({ where: { id: b.userId }, select: { id: true, role: true, email: true } });
    if (!target) return NextResponse.json({ ok: false, error: "USER_NOT_FOUND" }, { status: 404 });
    if (['DELETE_ACCOUNT','SET_ROLE'].includes(b.action)) await requireHighRiskAccess(req,b.action,'USER',target.id);
    const why = denyReason({ id: actor.userId, role: actor.role }, { id: target.id, role: target.role as any }, b.action);
    if (why) return NextResponse.json({ ok: false, error: why }, { status: 403 });

    if (actor.role === "ADMIN" && b.action === "REVOKE_PLAN") {
      return NextResponse.json({ ok: false, error: "ADMIN_CANNOT_REVOKE_TIER" }, { status: 403 });
    }

    const permissionByAction: Record<string,string> = { SET_STATUS: PERMISSIONS.USER_SUSPEND, SET_ROLE: PERMISSIONS.ROLE_ADMIN, RESET_PASSWORD: PERMISSIONS.USER_PASSWORD_RESET, RESET_EMAIL: PERMISSIONS.USER_EMAIL_RESET, RESET_MFA: PERMISSIONS.USER_MFA_RESET, DELETE_ACCOUNT: PERMISSIONS.USER_DELETE, FORCE_PASSWORD_CHANGE: PERMISSIONS.USER_PASSWORD_RESET, RESET_SESSION: PERMISSIONS.USER_READ, SET_ENTITLEMENT_OVERRIDE: PERMISSIONS.TIER_ACCESS_CODE, GRANT_PLAN: PERMISSIONS.TIER_ACCESS_CODE, REVOKE_PLAN: PERMISSIONS.TIER_ACCESS_CODE };
    if (actor.role === "DEVELOPER") {
      const principal = await db.user.findUnique({where:{id:actor.userId},select:{developerLevel:true}});
      if (principal?.developerLevel !== "PRINCIPAL") { try { await requirePermission(actor.userId, permissionByAction[b.action] || PERMISSIONS.USER_READ); } catch { return NextResponse.json({ok:false,error:"PERMISSION_DENIED"},{status:403}); } }
    } else {
      try { await requirePermission(actor.userId, permissionByAction[b.action] || PERMISSIONS.USER_READ, {scope:"ASSIGNED_USERS"}); } catch { return NextResponse.json({ok:false,error:"PERMISSION_DENIED"},{status:403}); }
    }
    if (actor.role === "ADMIN") {
      const assigned = await db.adminAssignment.findUnique({ where: { adminId_userId: { adminId: actor.userId, userId: target.id } } });
      try { assertAdminAssignment(actor.role, !!assigned); }
      catch (e) { return NextResponse.json({ ok: false, error: apiError(e) }, { status: 403 }); }
    }

    let meta: Record<string, unknown> = { email: target.email };
    if (b.action === "SET_STATUS") {
      await suspendUser(target.id, b.status);
      meta.status = b.status;
    } else if (b.action === "GRANT_PLAN") {
      const plan = await db.accessPlan.findFirst({ where: { id: b.planId, active: true } });
      if (!plan) return NextResponse.json({ ok: false, error: "PLAN_NOT_FOUND" }, { status: 404 });
      const days = clampDays(b.days);
      await db.subscription.updateMany({ where: { userId: target.id, status: "ACTIVE" }, data: { status: "REVOKED" } });
      const now = new Date();
      await db.subscription.create({ data: { userId: target.id, planId: plan.id, status: "ACTIVE", startsAt: now, expiresAt: new Date(now.getTime() + days * 86_400_000), grantedById: actor.userId, complimentary: true } });
      meta = { ...meta, plan: plan.name, days };
    } else if (b.action === "REVOKE_PLAN") {
      await db.subscription.updateMany({ where: { userId: target.id, status: "ACTIVE" }, data: { status: "REVOKED" } });
    } else if (b.action === "SET_ROLE") {
      await db.user.update({ where: { id: target.id }, data: { role: b.role } });
      meta.role = b.role;
    } else if (b.action === "RESET_SESSION") {
      await db.user.update({ where: { id: target.id }, data: { sessionVersion: { increment: 1 } } });
      meta.action = "SESSION_INVALIDATED";
    } else if (b.action === "SET_ENTITLEMENT_OVERRIDE") {
      const active = await db.subscription.findFirst({ where: { userId: target.id, status: 'ACTIVE', expiresAt: { gt: new Date() } }, orderBy: { expiresAt: 'desc' } });
      if (!active) return NextResponse.json({ ok: false, error: 'ACTIVE_PLAN_REQUIRED' }, { status: 409 });
      await db.subscription.update({ where: { id: active.id }, data: { entitlementsOverride: b.entitlements } });
      meta = { ...meta, action: 'USER_ENTITLEMENT_OVERRIDE', entitlements: b.entitlements };
    } else if (b.action === "RESET_MFA") {
      const now = new Date();
      await db.$transaction([
        db.user.update({ where: { id: target.id }, data: { mfaEnabled: false, mfaSecretEnc: null, mfaRecoveryRequired: true, sessionVersion: { increment: 1 } } }),
        db.session.updateMany({ where: { userId: target.id, revokedAt: null }, data: { revokedAt: now } }),
        db.auditLog.create({ data: { actorId: actor.userId, action: "ADMIN_MFA_RESET", targetType: "USER", targetId: target.id, metadata: { email: target.email, reason: "USER_LOST_MFA_ACCESS", forcedReenrollment: false, manualReenableByUser: true, sessionsRevoked: true } } }),
        db.userActivityEvent.create({ data: { userId: target.id, type: "MFA_RESET_BY_ADMIN", metadata: { forcedReenrollment: false, manualReenableByUser: true } } }),
      ]);
      meta = { ...meta, action: "MFA_RESET", forcedReenrollment: false, manualReenableByUser: true, sessionsRevoked: true };
    } else if (b.action === "RESET_PASSWORD") {
      const temp = await resetUserPassword(target.id);
      await db.auditLog.create({ data: { actorId: actor.userId, action: "ADMIN_RESET_PASSWORD", targetType: "USER", targetId: target.id, metadata: { email: target.email, delivery: "ADMIN_ONE_TIME_DISPLAY" } } });
      return NextResponse.json({ ok: true, temporaryPassword: temp, mustChangePassword: true });
    } else if (b.action === "RESET_EMAIL") {
      await resetUserEmail(target.id, b.newEmail);
      meta = { ...meta, action: "EMAIL_RESET", newEmail: b.newEmail.toLowerCase(), verificationRequired: true };
    } else if (b.action === "DELETE_ACCOUNT") {
      await permanentlyAnonymizeUser(target.id);
      meta = { ...meta, action: "ACCOUNT_PERMANENTLY_DELETED", irreversible: true };
    } else if (b.action === "FORCE_PASSWORD_CHANGE") {
      await db.$transaction([
        db.user.update({ where: { id: target.id }, data: { mustChangePassword: true, sessionVersion: { increment: 1 } } }),
        db.session.updateMany({ where: { userId: target.id, revokedAt: null }, data: { revokedAt: new Date() } }),
        db.auditLog.create({ data: { actorId: actor.userId, action: "ADMIN_FORCE_PASSWORD_CHANGE", targetType: "USER", targetId: target.id, metadata: { email: target.email } } }),
        db.userActivityEvent.create({ data: { userId: target.id, type: "PASSWORD_CHANGE_REQUIRED" } }),
      ]);
      meta.action = "FORCE_PASSWORD_CHANGE";
    }
    await db.auditLog.create({ data: { actorId: actor.userId, action: `ADMIN_${b.action}`, targetType: "USER", targetId: target.id, metadata: meta as any } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    if (e instanceof z.ZodError) return NextResponse.json({ ok: false, error: "Input tidak valid" }, { status: 400 });
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}
