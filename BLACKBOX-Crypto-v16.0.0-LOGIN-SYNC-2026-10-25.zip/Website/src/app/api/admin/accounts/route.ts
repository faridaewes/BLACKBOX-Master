import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import crypto from 'node:crypto';
import { db } from '@/lib/prisma';
import { apiError,  authStatus, hashPassword } from '@/lib/auth';
import { validatePassword } from '@/lib/password-policy';

const schema = z.object({
  name: z.string().trim().min(2).max(120),
  email: z.string().trim().email().max(320),
  phone: z.string().trim().regex(/^\+?[1-9]\d{7,14}$/),
  role: z.enum(['DEVELOPER', 'ADMIN']),
  password: z.string().min(12).max(128).optional(),
  planId: z.string().min(1).optional(),
  planDays: z.number().int().min(1).max(3650).optional(),
});

function generateTemporaryPassword() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';
  let out = '';
  do { out = Array.from(crypto.randomBytes(20), b => alphabet[b % alphabet.length]).join(''); }
  while (validatePassword(out) !== null);
  return out;
}

export async function GET() {
  try {
    const actor = await requirePermissionSession(PERMISSIONS.SECURITY_ADMIN);
    const [accounts, plans] = await Promise.all([
      db.user.findMany({
        where: { role: { in: ['DEVELOPER', 'ADMIN'] } }, orderBy: [{ createdAt: 'asc' }, { id: 'asc' }],
        select: { id: true, name: true, email: true, phone: true, role: true, status: true, createdAt: true, mustChangePassword: true, mfaEnabled: true,
          subscriptions: { orderBy: [{ expiresAt: 'desc' }, { createdAt: 'desc' }], take: 1, select: { expiresAt: true, status: true, plan: { select: { id: true, name: true } } } } }
      }),
      db.accessPlan.findMany({ where: { active: true }, orderBy: { name: 'asc' }, select: { id: true, name: true } }),
    ]);
    const counts: Record<string, number> = {};
    const rows = accounts.map(a => {
      counts[a.role] = (counts[a.role] || 0) + 1;
      const sub = a.subscriptions[0];
      return { ...a, roleLabel: `${a.role === 'DEVELOPER' ? 'Developer' : 'Admin'} ${counts[a.role]}`, plan: sub?.plan.name ?? null, planId: sub?.plan.id ?? null, planStatus: sub?.status ?? null, planExpiresAt: sub?.expiresAt ?? null };
    });
    return NextResponse.json({ ok: true, actor: actor.userId, accounts: rows, plans });
  } catch (e) { return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) }); }
}

export async function POST(req: Request) {
  try {
    const actor = await requirePermissionSession(PERMISSIONS.SECURITY_ADMIN);
    const b = schema.parse(await req.json());
    const email = b.email.toLowerCase();
    const duplicate = await db.user.findFirst({ where: { OR: [{ email }, { phone: b.phone }] }, select: { id: true } });
    if (duplicate) return NextResponse.json({ ok: false, error: 'EMAIL_OR_PHONE_ALREADY_EXISTS' }, { status: 409 });
    const initialPassword = b.password || generateTemporaryPassword();
    const passwordError = validatePassword(initialPassword);
    if (passwordError) return NextResponse.json({ ok: false, error: passwordError }, { status: 400 });
    const now = new Date();
    const usernameBase = b.email.split('@')[0].toLowerCase().replace(/[^a-z0-9_-]/g,'_').slice(0,16);
    let username = `${usernameBase}_${crypto.randomBytes(3).toString('hex')}`;
    for (let attempt = 0; attempt < 5; attempt++) { const taken = await db.user.findFirst({ where: { username: username.toLowerCase() }, select: { id: true } }); if (!taken) break; username = `${usernameBase}_${crypto.randomBytes(4).toString('hex')}`; }
    username = username.toLowerCase();
    const created = await db.$transaction(async tx => {
      const user = await tx.user.create({ data: { email, phone: b.phone, name: b.name, username, role: b.role, status: 'ACTIVE', passwordHash: await hashPassword(initialPassword), mustChangePassword: true, emailVerifiedAt: now, phoneVerifiedAt: now } });
      if (b.planId) {
        const plan = await tx.accessPlan.findFirst({ where: { id: b.planId, active: true } });
        if (!plan) throw new Error('PLAN_NOT_FOUND');
        const days = b.planDays ?? Number((plan.entitlements as any)?.durationDays ?? 30);
        await tx.subscription.create({ data: { userId: user.id, planId: plan.id, status: 'ACTIVE', startsAt: now, expiresAt: new Date(now.getTime() + days * 86_400_000), grantedById: actor.userId, complimentary: true } });
      }
      await tx.auditLog.create({ data: { actorId: actor.userId, action: 'PRIVILEGED_ACCOUNT_CREATED', targetType: 'USER', targetId: user.id, metadata: { email: user.email, name: user.name, role: user.role, planId: b.planId || null, planDays: b.planDays || null, credentials: 'ONE_TIME_HANDOFF', mustChangePassword: true } } });
      await tx.userActivityEvent.create({ data: { userId: user.id, type: 'PRIVILEGED_ACCOUNT_CREATED', metadata: { createdBy: actor.userId, role: user.role } } });
      return user;
    });
    return NextResponse.json({ ok: true, account: { id: created.id, name: created.name, email: created.email, phone: created.phone, role: created.role, mustChangePassword: true }, initialPassword, oneTimeCredentialHandoff: true });
  } catch (e) {
    if (e instanceof z.ZodError) return NextResponse.json({ ok: false, error: 'INPUT_TIDAK_VALID', details: e.flatten() }, { status: 400 });
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}
