import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { apiError,  requireVerifiedSession, authStatus } from '@/lib/auth';
import { getEntitlements } from '@/lib/entitlements';
import { fetchMultiTimeframeAnalysis } from '@/lib/candles';
import { evaluateMultiTimeframe, detectRegime } from '@/lib/signal-v2';
import { decideIntelligence } from '@/lib/ai-v69';
import { getMarketIntelligence, intelligenceRiskFlags } from '@/lib/market-intelligence';
import { evaluateTradingIntelligence, TRADING_INTELLIGENCE_VERSION } from '@/lib/trading-intelligence';
import { assertConnectionMarket, getConnectionMarket } from '@/lib/connection-market-universe';
import { fetchLiveDexMarkets } from '@/lib/paper/feed';
import { assessDexSafety } from '@/lib/dex-intelligence-v85';
import { getDexTokenSecurity } from '@/lib/dex-security-provider';

const input = z.object({
  botId: z.string(),
  symbol: z.string().trim().min(3).max(40),
  marketType: z.enum(['SPOT','FUTURES','DEX']).default('SPOT'),
  exchangeId: z.string().trim().min(2).optional(),
});

export async function GET(req: Request) {
  try {
    const s = await requireVerifiedSession();
    const u = new URL(req.url), botId = u.searchParams.get('botId');
    const where: any = { userId: s.userId };
    if (botId) where.botId = botId;
    const rows = await db.signal.findMany({ where, orderBy: { createdAt: 'desc' }, take: 100 });
    return NextResponse.json({ ok: true, signals: rows });
  } catch (e) {
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}

export async function POST(req: Request) {
  try {
    const s = await requireVerifiedSession();
    const b = input.parse(await req.json());
    const bot = await db.bot.findFirst({ where: { id: b.botId, userId: s.userId } });
    if (!bot) return NextResponse.json({ ok: false, error: 'BOT_NOT_FOUND' }, { status: 404 });
    const ent = await getEntitlements(s.userId, s.role);
    if (!ent.marketTypes.includes(b.marketType)) return NextResponse.json({ ok: false, error: 'MARKET_TYPE_NOT_ENTITLED' }, { status: 403 });

    const cfg: any = bot.config || {};
    let analysisExchange = b.exchangeId;
    let connectionKey: string | null = null;
    let exchangeAccountId: string | null = null;
    let walletId: string | null = null;
    let canonicalSymbol = b.symbol.toUpperCase(); let instrumentType: string | null = null;
    if (bot.mode === 'REAL') {
      if(b.marketType==='DEX'){
        const wallet=bot.walletId?await db.wallet.findFirst({where:{id:bot.walletId,userId:s.userId,status:'CONNECTED'}}):null;
        if(!wallet)return NextResponse.json({ok:false,error:'REAL_WALLET_CONNECTION_REQUIRED'},{status:423});
        walletId=wallet.id; connectionKey=`wallet:${wallet.id}`; canonicalSymbol=b.symbol.toUpperCase(); instrumentType='SPOT';
      } else {
        const account = bot.exchangeId ? await db.exchangeAccount.findFirst({ where: { id: bot.exchangeId, userId: s.userId, status: 'CONNECTED' }, select: { provider:true,id:true } }) : null;
        if (!account) return NextResponse.json({ ok: false, error: 'REAL_EXCHANGE_CONNECTION_REQUIRED' }, { status: 423 });
        analysisExchange = account.provider; exchangeAccountId = account.id; connectionKey = `cex:${account.id}`;
        const row = await getConnectionMarket(account.id,b.marketType,b.symbol); canonicalSymbol = row.canonicalSymbol; instrumentType = String((row as any).instrumentType || 'SPOT');
      }
    }
    if (bot.mode !== 'REAL' && bot.exchangeId) {
      const account = await db.exchangeAccount.findFirst({where:{id:bot.exchangeId,userId:s.userId,status:'CONNECTED'}});
      if(account && b.marketType!=='DEX'){ const row=await getConnectionMarket(account.id,b.marketType,b.symbol); exchangeAccountId=account.id; connectionKey=`cex:${account.id}`; canonicalSymbol=row.canonicalSymbol; analysisExchange=account.provider; }
    }
    if(bot.walletId){ walletId=bot.walletId; connectionKey=`wallet:${bot.walletId}`; }
    const symbols: string[] = Array.isArray(cfg.symbols) ? cfg.symbols.map(String) : [];
    if (symbols.length && !symbols.includes(b.symbol)) return NextResponse.json({ ok: false, error: 'SYMBOL_NOT_IN_BOT_UNIVERSE' }, { status: 403 });

    const intelligence = await getMarketIntelligence(b.symbol).catch(() => null);
    const intelligenceFlags = intelligence ? intelligenceRiskFlags(intelligence) : [];

    if (b.marketType === 'DEX') {
      const wallet = bot.walletId ? await db.wallet.findFirst({where:{id:bot.walletId,userId:s.userId,status:'CONNECTED'}}) : null;
      if (bot.mode==='REAL' && !wallet) return NextResponse.json({ok:false,error:'REAL_WALLET_CONNECTION_REQUIRED'},{status:423});
      const cfgChains=Array.isArray(cfg.chains)&&cfg.chains.length?cfg.chains.map(String):['solana','base','bsc','ethereum'];
      const market=(await fetchLiveDexMarkets(cfgChains,8000)).find((m:any)=>String(m.symbol).toUpperCase()===String(b.symbol).toUpperCase());
      if(!market||!market.baseTokenAddress||!market.quoteTokenAddress) {
        const signal=await db.signal.create({data:{botId:bot.id,userId:s.userId,symbol:b.symbol,canonicalSymbol:b.symbol.toUpperCase(),instrumentType:'SPOT',marketType:'DEX',connectionKey:wallet?`wallet:${wallet.id}`:null,walletId:wallet?.id||null,chain:market?.chainId||null,dex:market?.dexId||null,pairAddress:market?.pairAddress||null,baseTokenAddress:market?.baseTokenAddress||null,quoteTokenAddress:market?.quoteTokenAddress||null,action:'WAIT',status:'NO_SIGNAL',score:0,confidence:0,qualityScore:0,confirmationCount:0,marketVolatilityPct:0,noTradeReason:'DEX_MARKET_NOT_FOUND',strategyVersion:`DEX-${TRADING_INTELLIGENCE_VERSION}`,deterministicScore:0,regime:'UNKNOWN',timeframe:'LIVE_POOL',reasons:['DEX market/token identity belum tersedia'],riskFlags:['DEX_MARKET_NOT_FOUND'],lifecycle:'EXPIRED',resolvedAt:new Date(),result:'WAIT'}});
        return NextResponse.json({ok:true,signal,result:{action:'WAIT',score:0,confidence:0,reasons:['DEX market/token identity belum tersedia'],noTradeReasons:['DEX_MARKET_NOT_FOUND']},executionAllowed:false});
      }
      try{
        const sec=await getDexTokenSecurity(market.chainId,String(market.baseTokenAddress));
        const safety=assessDexSafety({chain:market.chainId,dexId:market.dexId,pairAddress:market.pairAddress,symbol:market.symbol,priceUsd:market.priceUsd,liquidityUsd:market.liquidityUsd,volume24h:market.volume24h,observedAt:market.observedAt,verifiedContract:sec.isOpenSource,honeypot:sec.honeypot,transferRestricted:sec.cannotSellAll,holderConcentrationPct:sec.holderConcentrationPct,deployerRisk:sec.deployerRisk,proxy:sec.proxy,freezeAuthority:sec.freezeAuthority,mintAuthority:sec.mintAuthority,buyTaxPct:sec.buyTaxPct,sellTaxPct:sec.sellTaxPct,liquidityLocked:sec.liquidityLocked});
        const action=safety.status==='LOW'&&safety.trustScore>=90&&market.priceChange5m>0&&market.priceChange1h>0?'BUY':'WAIT';
        const signal=await db.signal.create({data:{botId:bot.id,userId:s.userId,symbol:b.symbol,canonicalSymbol:b.symbol.toUpperCase(),instrumentType:'SPOT',marketType:'DEX',connectionKey:wallet?`wallet:${wallet.id}`:null,walletId:wallet?.id||null,chain:market.chainId,dex:market.dexId,pairAddress:market.pairAddress,baseTokenAddress:market.baseTokenAddress,quoteTokenAddress:market.quoteTokenAddress,action,status:action==='BUY'?'ELITE':'WATCH',score:safety.trustScore,confidence:safety.trustScore,qualityScore:safety.trustScore,confirmationCount:5,marketVolatilityPct:Math.abs(Number(market.priceChange1h||0)),noTradeReason:action==='WAIT'?safety.blockers.concat(safety.warnings).join('|'):null,strategyVersion:`DEX-${TRADING_INTELLIGENCE_VERSION}`,deterministicScore:safety.executionQualityScore,aiScore:safety.trustScore,liquidityUsd:market.liquidityUsd,rugRisk:100-safety.trustScore,regime:'DEX_TREND',timeframe:'LIVE_POOL',entry:market.priceUsd,stopLoss:market.priceUsd*(1-Number((cfg.guardrails||{}).stopLossPct||10)/100),takeProfit1:market.priceUsd*(1+Number((cfg.guardrails||{}).takeProfitPct||30)/100),riskReward:2,reasons:safety.evidence,riskFlags:safety.blockers.concat(safety.warnings),lifecycle:action==='BUY'?'CONFIRMED':'EXPIRED',marketObservedAt:new Date(),confirmedAt:action==='BUY'?new Date():null,resolvedAt:action==='WAIT'?new Date():null,result:action==='WAIT'?'WAIT':null}});
        return NextResponse.json({ok:true,signal,result:{action,score:safety.trustScore,confidence:safety.trustScore,reasons:safety.evidence,noTradeReasons:safety.blockers.concat(safety.warnings)},executionAllowed:false,executionPath:action==='BUY'?'AUTONOMOUS_SMART_ACCOUNT_INTENT':'NONE'});
      }catch(e){
        const signal=await db.signal.create({data:{botId:bot.id,userId:s.userId,symbol:b.symbol,canonicalSymbol:b.symbol.toUpperCase(),instrumentType:'SPOT',marketType:'DEX',connectionKey:wallet?`wallet:${wallet.id}`:null,walletId:wallet?.id||null,chain:market.chainId,dex:market.dexId,pairAddress:market.pairAddress,baseTokenAddress:market.baseTokenAddress,quoteTokenAddress:market.quoteTokenAddress,action:'WAIT',status:'NO_SIGNAL',score:0,confidence:0,qualityScore:0,confirmationCount:0,marketVolatilityPct:0,noTradeReason:'DEX_SECURITY_UNAVAILABLE',strategyVersion:`DEX-${TRADING_INTELLIGENCE_VERSION}`,deterministicScore:0,regime:'UNKNOWN',timeframe:'LIVE_POOL',reasons:[e instanceof Error?e.message:'DEX security unavailable'],riskFlags:['DEX_SECURITY_UNAVAILABLE'],lifecycle:'EXPIRED',resolvedAt:new Date(),result:'WAIT'}});
        return NextResponse.json({ok:true,signal,result:{action:'WAIT',score:0,confidence:0,reasons:['DEX security provider unavailable'],noTradeReasons:['DEX_SECURITY_UNAVAILABLE']},executionAllowed:false});
      }
    }

    let mtf: Awaited<ReturnType<typeof fetchMultiTimeframeAnalysis>>;
    try {
      mtf = await fetchMultiTimeframeAnalysis(b.symbol, b.marketType, analysisExchange, false);
    } catch {
      return NextResponse.json({ ok: true, signal: null, result: { action: 'WAIT', score: 0, confidence: 0, reasons: ['Market data sementara tidak tersedia'], noTradeReasons: ['MARKET_DATA_UNAVAILABLE'] }, intelligence, degraded: true, noOrderAction: true }, { status: 200, headers: { 'Cache-Control': 'no-store' } });
    }
    const tfInput: any = Object.fromEntries(Object.entries(mtf).map(([tf, v]: any) => [tf, {
      trend: v.trend, momentum: v.momentum, volume: v.volumeRatio, volatility: v.volatility, breakout: v.signal.breakout
    }]));
    const baseScore = Math.round(Object.values(mtf).reduce((n: number, v: any) => n + v.signal.confidence, 0) / Math.max(1, Object.keys(mtf).length));
    const guard = (cfg.guardrails || {}) as any;
    const minScore = Number(guard.minAiScore ?? 75);
    const mtfResult = evaluateMultiTimeframe({ timeframes: tfInput, baseScore, minScore, regime: detectRegime(tfInput) });
    const five = mtf['5m'], oneH = mtf['1h'];
    const marketVolatilityPct = Math.max(...Object.values(mtf).map((v:any)=>Number(v?.volatility)||0), 0);
    const price = Number(five?.candles.at(-1)?.[4] || 0);
    const liquidityUsd = Number((five?.candles.at(-1)?.[5] || 0));
    const rugRisk = Math.min(100, Math.max(0, 20 + (liquidityUsd < 100000 ? 20 : 0) + (mtfResult.conflicts.length ? 10 : 0)));

    const ai = await decideIntelligence({
      symbol: b.symbol, priceUsd: price, priceChange5m: five?.momentum || 0, priceChange1h: oneH?.momentum || 0,
      liquidityUsd, volume24h: liquidityUsd, buys24h: 0, sells24h: 0, fdv: 0, pairAgeHours: null,
      candlePattern: five?.signal.pattern, candleReason: five?.signal.reason, rugRiskEstimate: rugRisk,
      regime: mtfResult.regime, mtfAlignment: Object.keys(mtf).length ? (Object.keys(mtf).length - mtfResult.conflicts.length) / Object.keys(mtf).length : 0,
      score: Math.max(mtfResult.score, mtfResult.sellScore), minAiScore: minScore
    }, { allowRemote: true });

    const aiForGate = { ...ai.decision, score: ai.calibratedScore, confidence: ai.calibratedConfidence };

    const profile = String(guard.signalProfile || 'PRECISION').toUpperCase() === 'BALANCED' ? 'BALANCED' : 'PRECISION';
    const intelligenceResult = evaluateTradingIntelligence({
      timeframes: mtf as any,
      mtfScore: mtfResult.score,
      mtfSellScore: mtfResult.sellScore,
      regime: mtfResult.regime,
      ai: aiForGate,
      intelligenceFlags: [...intelligenceFlags, ...(ai.agreement !== 'ALIGNED' ? ['AI_INTELLIGENCE_NOT_ALIGNED'] : [])],
      rugRisk,
      maxRugRisk: Number(guard.maxRugRisk ?? 80),
      minLiquidityUsd: Number(guard.minLiquidityUsd ?? 1000),
      liquidityUsd,
      profile,
      targetWinRatePct: Number(guard.targetWinRatePct ?? 85),
    });

    const action = intelligenceResult.action;
    const entry = price || null;
    const stopLoss = entry ? (action === 'SELL' ? entry * (1 + intelligenceResult.stopLossPct / 100) : entry * (1 - intelligenceResult.stopLossPct / 100)) : null;
    const takeProfit1 = entry ? (action === 'SELL' ? entry * (1 - intelligenceResult.takeProfitPct / 100) : entry * (1 + intelligenceResult.takeProfitPct / 100)) : null;
    const reasons = [...new Set([...(mtfResult.reasons || []), ...intelligenceResult.reasons])].slice(0, 12);
    const riskFlags = [...new Set([...(mtfResult.conflicts || []), ...intelligenceResult.riskFlags])].slice(0, 12);
    const signal = await db.signal.create({ data: {
      botId: bot.id, userId: s.userId, symbol: b.symbol, canonicalSymbol, instrumentType, marketType:b.marketType, connectionKey, exchangeAccountId, walletId, action,
      status: action === 'WAIT' ? 'WATCH' : intelligenceResult.qualityScore >= 93 ? 'ELITE' : 'STRONG',
      score: intelligenceResult.score,
      confidence: intelligenceResult.confidence,
      qualityScore: intelligenceResult.qualityScore,
      confirmationCount: intelligenceResult.confirmations,
      noTradeReason: action === 'WAIT' ? intelligenceResult.noTradeReasons.join('|') : null,
      strategyVersion: `${TRADING_INTELLIGENCE_VERSION}-${profile.toLowerCase()}`,
      deterministicScore: mtfResult.score, aiScore: ai.calibratedScore, liquidityUsd, marketVolatilityPct, rugRisk,
      regime: mtfResult.regime, timeframe: 'MTF', entry, stopLoss, takeProfit1,
      riskReward: intelligenceResult.riskReward,
      reasons, riskFlags,
      lifecycle: action === 'WAIT' ? 'EXPIRED' : 'CONFIRMED',
      confirmedAt: action === 'WAIT' ? null : new Date(),
      resolvedAt: action === 'WAIT' ? new Date() : null,
      result: action === 'WAIT' ? 'WAIT' : null
    }});

    if (ai.attempted) await db.aiCall.create({ data: { userId: s.userId, botId: bot.id, provider: ai.provider, model: ai.model, latencyMs: ai.latencyMs, inputTokens: ai.inputTokens, outputTokens: ai.outputTokens, estimatedCost: ai.estimatedCost, decision: ai.error ? `ERROR:${ai.error}` : ai.decision.action, intelligenceVersion: ai.intelligenceVersion, inputHash: ai.inputHash, agreement: ai.agreement, safetyScore: ai.safetyScore, calibratedScore: ai.calibratedScore, calibratedConfidence: ai.calibratedConfidence, conflictFlags: ai.conflictFlags } });

    return NextResponse.json({
      ok: true, signal,
      result: { action, score: intelligenceResult.score, confidence: intelligenceResult.confidence, qualityScore: intelligenceResult.qualityScore,
        confirmations: intelligenceResult.confirmations, requiredConfirmations: intelligenceResult.requiredConfirmations,
        riskReward: intelligenceResult.riskReward, reasons, riskFlags, noTradeReasons: intelligenceResult.noTradeReasons,
        profile: intelligenceResult.profile, targetWinRatePct: Number(guard.targetWinRatePct ?? 85) },
      timeframes: mtf, intelligence, ai: { ...ai.decision, calibratedScore: ai.calibratedScore, calibratedConfidence: ai.calibratedConfidence, agreement: ai.agreement, safetyScore: ai.safetyScore, conflictFlags: ai.conflictFlags, intelligenceVersion: ai.intelligenceVersion }
    });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof z.ZodError ? 'INPUT_INVALID' : apiError(e) }, { status: authStatus(e) });
  }
}
