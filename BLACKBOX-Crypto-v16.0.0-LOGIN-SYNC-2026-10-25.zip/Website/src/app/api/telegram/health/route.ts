import { requireDeveloper } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { authStatus } from '@/lib/auth';
import { getGatewayConfig, testGateway } from '@/lib/telegram-gateway';

export async function GET() {
  try {
    await requireDeveloper();
    const cfg = await getGatewayConfig();
    return NextResponse.json({
      ok: true,
      mode: 'TELEGRAM_GATEWAY_HEALTH',
      official: { configured: Boolean(cfg.enabled && cfg.officialBotToken && cfg.officialChatId), chatIdConfigured: Boolean(cfg.officialChatId) },
      transaction: { configured: Boolean(cfg.enabled && cfg.transactionBotToken && cfg.transactionChatId), chatIdConfigured: Boolean(cfg.transactionChatId) },
    }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'TELEGRAM_HEALTH_UNAVAILABLE' }, { status: authStatus(e) });
  }
}
