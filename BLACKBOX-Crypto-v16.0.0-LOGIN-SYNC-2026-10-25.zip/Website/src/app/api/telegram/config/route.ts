import { requirePermissionSession, PERMISSIONS, requireDeveloper } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { authStatus } from '@/lib/auth';
import { clearGatewaySide, getGatewayConfig, saveGatewayConfig, testGateway } from '@/lib/telegram-gateway';

const schema = z.object({
  enabled: z.boolean().optional(),
  // New split credentials. null/empty explicitly clears a token.
  officialBotToken: z.string().trim().max(300).nullable().optional(),
  transactionBotToken: z.string().trim().max(300).nullable().optional(),
  // Legacy compatibility: updates both sides when supplied.
  botToken: z.string().trim().max(300).nullable().optional(),
  officialChatId: z.string().trim().max(120).optional(),
  transactionChatId: z.string().trim().max(120).optional(),
});

function publicConfig(c: Awaited<ReturnType<typeof getGatewayConfig>>) {
  return {
    ok: true,
    enabled: c.enabled,
    officialChatId: c.officialChatId,
    transactionChatId: c.transactionChatId,
    officialTokenConfigured: Boolean(c.officialBotToken),
    transactionTokenConfigured: Boolean(c.transactionBotToken),
  };
}

export async function GET() {
  try {
    await requireDeveloper();
    return NextResponse.json(publicConfig(await getGatewayConfig()));
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'TELEGRAM_CONFIG_UNAVAILABLE' }, { status: authStatus(e) });
  }
}

export async function POST(req: Request) {
  try {
    const actor = await requireDeveloper();
    const input = schema.parse(await req.json());
    const c = await saveGatewayConfig({ ...input, actorId: actor.userId });
    return NextResponse.json(publicConfig(c));
  } catch (e) {
    if (e instanceof z.ZodError) return NextResponse.json({ ok: false, error: 'INPUT_TIDAK_VALID' }, { status: 400 });
    return NextResponse.json({ ok: false, error: 'TELEGRAM_CONFIG_UPDATE_FAILED' }, { status: authStatus(e) });
  }
}

// PUT is the explicit live connection test. It tests bot authentication AND target delivery.
export async function PUT(req: Request) {
  try {
    const actor = await requireDeveloper();
    const body = await req.json().catch(() => ({}));
    const side = body?.side === 'TRANSACTION' ? 'TRANSACTION' : body?.side === 'OFFICIAL' ? 'OFFICIAL' : null;
    if (!side) return NextResponse.json({ ok: false, error: 'TELEGRAM_TEST_SIDE_REQUIRED' }, { status: 400 });
    const result = await testGateway(side, actor.userId);
    return NextResponse.json(result, { status: result.ok ? 200 : 502 });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'TELEGRAM_TEST_FAILED' }, { status: authStatus(e) });
  }
}

// DELETE explicitly clears one side, including token and target chat ID.
export async function DELETE(req: Request) {
  try {
    const actor = await requireDeveloper();
    const body = await req.json().catch(() => ({}));
    const side = body?.side === 'TRANSACTION' ? 'TRANSACTION' : body?.side === 'OFFICIAL' ? 'OFFICIAL' : null;
    if (!side) return NextResponse.json({ ok: false, error: 'TELEGRAM_DELETE_SIDE_REQUIRED' }, { status: 400 });
    await clearGatewaySide(side, actor.userId);
    return NextResponse.json({ ok: true, side, message: 'TELEGRAM_CONFIGURATION_CLEARED' });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'TELEGRAM_CONFIG_DELETE_FAILED' }, { status: authStatus(e) });
  }
}
