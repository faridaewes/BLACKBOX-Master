import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireVerifiedSession, apiError, authStatus } from '@/lib/auth';
import { findPartnerExact } from '@/lib/partner-transfer';
const schema=z.object({ query:z.string().trim().min(2).max(120) });
export async function POST(req:Request){try{const s=await requireVerifiedSession();const {query}=schema.parse(await req.json());const q=query.trim();const partner=await findPartnerExact(q.includes('@')?{email:q}:{username:/^[A-Z0-9_-]{4,80}$/i.test(q)&&/^\d+$/.test(q)?undefined:q,referralCode:/^\d+$/.test(q)?q:undefined});if(!partner)return NextResponse.json({ok:true,available:false,partner:null});if(partner.id===s.userId)return NextResponse.json({ok:true,available:false,partner:null,error:'SELF_NOT_AVAILABLE'});if(partner.status!=='ACTIVE')return NextResponse.json({ok:true,available:false,partner:null,error:'PARTNER_NOT_ACTIVE'});return NextResponse.json({ok:true,available:true,partner});}catch(e){return NextResponse.json({ok:false,error:e instanceof z.ZodError?'INPUT_INVALID':apiError(e)},{status:e instanceof z.ZodError?400:authStatus(e)});}}
