import { NextResponse } from 'next/server';
import { requireVerifiedSession, apiError, authStatus } from '@/lib/auth';
import { db } from '@/lib/prisma';
import { getPartnerState } from '@/lib/partner-transfer';

export async function GET() {
  try {
    const s = await requireVerifiedSession();
    const state = await getPartnerState(s.userId);
    const history = await db.referralTreeMove.findMany({
      where: { userId: s.userId },
      orderBy: { createdAt: 'desc' }, take: 50,
      select: { id:true, fromSponsorId:true, toSponsorId:true, subtreeSize:true, subtreeDepth:true, reason:true, createdAt:true, fromSponsor:{select:{username:true,name:true,referralCode:true}}, toSponsor:{select:{username:true,name:true,referralCode:true}} },
    });
    return NextResponse.json({ ok:true, version:'16.0.0', ...state, history });
  } catch(e) { return NextResponse.json({ok:false,error:apiError(e)},{status:authStatus(e)}); }
}
