import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireVerifiedSession, apiError, authStatus } from '@/lib/auth';
import { db } from '@/lib/prisma';
import { autoTransferPartner, findPartnerExact } from '@/lib/partner-transfer';
import { notifyUser } from '@/lib/notify-user';

const schema=z.object({ targetUserId:z.string().min(1).optional(), email:z.string().email().optional(), username:z.string().trim().min(2).max(80).optional(), referralCode:z.string().trim().min(2).max(80).optional(), confirmation:z.literal('PINDAH_PARTNER').optional() });
function fail(msg:string,status=400){return NextResponse.json({ok:false,error:msg},{status});}
export async function POST(req:Request){
 try{
  const s=await requireVerifiedSession(); const b=schema.parse(await req.json());
  if(b.confirmation!=='PINDAH_PARTNER')return fail('PARTNER_TRANSFER_CONFIRMATION_REQUIRED');
  let target=b.targetUserId?await db.user.findUnique({where:{id:b.targetUserId},select:{id:true,username:true,name:true,status:true,role:true}}):null;
  if(!target){const p=await findPartnerExact({email:b.email,username:b.username,referralCode:b.referralCode}); if(p) target=await db.user.findUnique({where:{id:p.id},select:{id:true,username:true,name:true,status:true,role:true}});}
  if(!target)return fail('PARTNER_TARGET_NOT_FOUND',404);
  if(target.id===s.userId)return fail('REFERRAL_MOVE_SELF_NOT_ALLOWED',409);
  if(target.role==='DEVELOPER'||target.status!=='ACTIVE')return fail('PARTNER_TARGET_NOT_AVAILABLE',409);
  const result=await autoTransferPartner(s.userId,target.id);
  const movedAt=new Date(result.movedAt);
  const nextAt=result.nextTransferAt;
  const body=`Partner Anda berhasil dipindahkan.\n\nPartner sebelumnya: ${result.previousSponsorUsername||'ROOT'}\nPartner baru: @${result.newSponsorUsername}\nWaktu: ${movedAt.toLocaleString('id-ID',{timeZone:process.env.APP_TIMEZONE||'Asia/Jakarta'})}\nSub-network terdampak: ${result.subtreeSize} akun\nPerpindahan berikutnya tersedia: ${nextAt.toLocaleString('id-ID',{timeZone:process.env.APP_TIMEZONE||'Asia/Jakarta'})}.\n\nHistori referral, point ledger, reward, tier, WPA, dan audit historis tidak diubah.`;
  await notifyUser({userId:s.userId,title:'Partner berhasil dipindahkan',body,emailSubject:'BLACKBOX — Konfirmasi Perpindahan Partner',type:'PARTNER_TRANSFER',priority:'HIGH',dedupeKey:`PARTNER_TRANSFER:${result.movedAt}`});
  return NextResponse.json({ok:true,result,message:'PARTNER_TRANSFER_COMPLETED'});
 }catch(e){
  const msg=e instanceof Error?e.message:String(e);
  if(msg.startsWith('PARTNER_TRANSFER_COOLDOWN:')){const next=msg.split(':')[1];return fail(`PARTNER_TRANSFER_COOLDOWN:${next}`,409);}
  const known=['PARTNER_TRANSFER_CONFIRMATION_REQUIRED','PARTNER_TARGET_NOT_FOUND','PARTNER_TARGET_NOT_AVAILABLE','REFERRAL_MOVE_SELF_NOT_ALLOWED','REFERRAL_MOVE_DESCENDANT_TARGET_NOT_ALLOWED','REFERRAL_MOVE_DEPTH_LIMIT_EXCEEDED','REFERRAL_TREE_CYCLE_DETECTED','REFERRAL_MOVE_ALREADY_IN_TARGET_NETWORK'];
  return fail(known.includes(msg)?msg:apiError(e),known.includes(msg)?409:authStatus(e));
 }
}
