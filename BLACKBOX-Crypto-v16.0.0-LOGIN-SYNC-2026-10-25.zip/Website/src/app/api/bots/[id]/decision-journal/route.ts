import { NextResponse } from "next/server";
import { db } from "@/lib/prisma";
import { apiError, requireVerifiedSession, authStatus } from "@/lib/auth";
import { explainRiskReason } from "@/lib/facade/risk";
import { explainSafetyBlockers } from "@/lib/facade/safety";

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const s = await requireVerifiedSession();
    const { id } = await params;
    const bot = await db.bot.findFirst({ where: { id, userId: s.userId } });
    if (!bot) return NextResponse.json({ ok: false, error: "BOT_NOT_FOUND" }, { status: 404 });

    const [blocks, logs] = await Promise.all([
      db.riskEvent.findMany({
        where: { botId: id, decision: "BLOCK" },
        orderBy: { createdAt: "desc" },
        take: 40,
      }),
      db.agentLog.findMany({
        where: { botId: id, stage: { in: ["BLOCK", "RISK", "GUARD"] } },
        orderBy: { createdAt: "desc" },
        take: 40,
      }),
    ]);

    const journal = blocks.map((e) => {
      const reason = String(e.reason || "");
      const meta = (e.metadata || {}) as Record<string, unknown>;
      const blockers = Array.isArray(meta.blockers) ? (meta.blockers as string[]) : [];
      const idExplain = explainRiskReason(reason);
      const safetyExplain = blockers.length ? explainSafetyBlockers(blockers) : [];
      return {
        id: e.id,
        at: e.createdAt,
        type: e.type,
        reason,
        symbol: (meta as any).symbol || null,
        explanationId: idExplain,
        safetyBlockersId: safetyExplain,
        summaryId:
          safetyExplain.length
            ? `Ditolak Safety Kernel: ${safetyExplain.join("; ")}`
            : `Ditolak: ${idExplain}`,
      };
    });

    return NextResponse.json({
      ok: true,
      journal,
      recentLogs: logs.map((l) => ({
        id: l.id,
        at: l.createdAt,
        stage: l.stage,
        level: l.level,
        message: l.message,
      })),
    });
  } catch (e) {
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}
