import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';
import { requireVerifiedSession, requireMfa, authStatus, apiError } from '@/lib/auth';
import { botGuardrails, closePaperPosition } from '@/lib/paper/service';
import { executeRealOrderForUser, applyRealSellFill } from '@/lib/real-execution';
import { getConnectionMarket } from '@/lib/connection-market-universe';
import { fetchLiveDexMarkets } from '@/lib/paper/feed';
import { prepareDexTradeIntent, dexTokenDecimals } from '@/lib/dex-execution';
import { recordConsent } from '@/lib/consent';

const ACK='Saya telah membaca, memahami, dan menyetujui dokumen ini secara sadar, sukarela, dan tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan saya serta, sejauh diperbolehkan dan dapat diberlakukan menurut hukum, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan, klaim, atau permintaan ganti rugi sehubungan dengan penggunaan layanan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, konfirmasi, izinkan, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.';

export async function POST(req: Request, { params }: { params: Promise<{ id:string; pid:string }> }) {
  try {
    const s=await requireVerifiedSession(); const {id,pid}=await params;
    const bot=await db.bot.findFirst({where:{id,userId:s.userId}}); if(!bot)return NextResponse.json({ok:false,error:'BOT_NOT_FOUND'},{status:404});
    const pos=await db.position.findFirst({where:{id:pid,botId:id,status:'OPEN'},include:{wallet:true}}); if(!pos)return NextResponse.json({ok:false,error:'POSITION_NOT_OPEN'},{status:404});
    await recordConsent(req,s.userId,'REAL_EXECUTION',{botId:id,positionId:pid,action:'MANUAL_CLOSE',acknowledgementText:ACK,consentMethod:'EXPLICIT_CONFIRMATION',readAt:new Date().toISOString()});
    if(bot.mode==='REAL'){await requireMfa(req)}
    if(bot.mode!=='REAL'){
      const r=await closePaperPosition(bot,botGuardrails(bot),pos,pos.currentPrice,'MANUAL'); if(!r)return NextResponse.json({ok:false,error:'POSITION_ALREADY_CLOSED'},{status:409});
      await db.auditLog.create({data:{actorId:s.userId,action:'MANUAL_CLOSE',targetType:'POSITION',targetId:pid,metadata:{pnl:r.pnl,mode:'PAPER'}}});
      return NextResponse.json({ok:true,pnl:r.pnl,closed:true,mode:'PAPER'});
    }
    const mt=String(pos.marketType||((bot.config as any)?.marketType)||'SPOT').toUpperCase();
    if(mt==='DEX'){
      if(!pos.walletId||!pos.wallet) return NextResponse.json({ok:false,error:'DEX_WALLET_REQUIRED'},{status:400});
      const sig=await db.signal.findFirst({where:{botId:id,userId:s.userId,marketType:'DEX',pairAddress:pos.pairAddress,walletId:pos.walletId,baseTokenAddress:{not:null},quoteTokenAddress:{not:null}},orderBy:{createdAt:'desc'}});
      if(!sig?.baseTokenAddress||!sig.quoteTokenAddress||!sig.chain) return NextResponse.json({ok:false,error:'DEX_POSITION_TOKEN_MAPPING_REQUIRED'},{status:409});
      const market=(await fetchLiveDexMarkets([sig.chain],8000)).find((m:any)=>m.pairAddress===pos.pairAddress);
      const exitSignal=await db.signal.create({data:{botId:id,userId:s.userId,symbol:pos.symbol,canonicalSymbol:pos.canonicalSymbol||pos.symbol,marketType:'DEX',connectionKey:`wallet:${pos.walletId}`,walletId:pos.walletId,chain:sig.chain,dex:sig.dex,pairAddress:pos.pairAddress,baseTokenAddress:sig.baseTokenAddress,quoteTokenAddress:sig.quoteTokenAddress,action:'SELL',status:'VALID',score:100,confidence:99,qualityScore:100,confirmationCount:5,noTradeReason:null,strategyVersion:'DEX-REAL-1.0-MANUAL-CLOSE',deterministicScore:100,aiScore:100,liquidityUsd:Number(market?.liquidityUsd||pos.liquidityUsd||0),rugRisk:Number(pos.rugRisk||0),regime:'MANUAL_EXIT',timeframe:'MANUAL',entry:Number(market?.priceUsd||pos.currentPrice||pos.entryPrice),stopLoss:null,takeProfit1:null,riskReward:null,reasons:['USER_MANUAL_CLOSE'],riskFlags:[],lifecycle:'CONFIRMED',marketObservedAt:new Date(),confirmedAt:new Date()}});
      const decimals=await dexTokenDecimals(sig.chain,sig.baseTokenAddress,pos.wallet.chainId); const base=String(Math.max(1,Math.floor(Number(pos.quantity)*10**decimals)));
      const intent=await prepareDexTradeIntent({userId:s.userId,botId:id,signalId:exitSignal.id,walletId:pos.walletId,side:'SELL',sellToken:sig.baseTokenAddress,buyToken:sig.quoteTokenAddress,sellAmountBaseUnits:base,slippageBps:Math.max(1,Math.min(300,Math.round(Number((bot.config as any)?.guardrails?.baseSlippagePct||0.5)*100))),chain:sig.chain,chainId:pos.wallet.chainId,symbol:pos.symbol,dex:sig.dex||undefined,pairAddress:pos.pairAddress||undefined});
      await db.auditLog.create({data:{actorId:s.userId,action:'MANUAL_CLOSE',targetType:'POSITION',targetId:pid,metadata:{mode:'REAL',marketType:'DEX',intentId:intent.intent.id,autonomous:Boolean((intent as any).autonomous)}}});
      return NextResponse.json({ok:true,mode:'REAL',marketType:'DEX',closed:false,autonomous:Boolean((intent as any).autonomous),intent:{id:intent.intent.id,status:intent.intent.status,txHash:(intent as any).txHash||null},transaction:intent.transaction,approval:intent.approval,message:(intent as any).autonomous?'DEX close submitted autonomously; reconciliation will finalize the position.':'DEX close intent prepared; user signature is required before submission.'});
    }
    if(!bot.exchangeId)return NextResponse.json({ok:false,error:'REAL_CONNECTION_REQUIRED'},{status:400});
    const cmt=mt==='FUTURES'?'FUTURES':'SPOT'; const cm=await getConnectionMarket(bot.exchangeId,cmt as any,pos.symbol);
    const signal=await db.signal.create({data:{botId:id,userId:s.userId,symbol:pos.symbol,canonicalSymbol:cm.canonicalSymbol,marketType:cmt,connectionKey:`cex:${bot.exchangeId}`,exchangeAccountId:bot.exchangeId,action:'SELL',status:'VALID',score:100,confidence:99,deterministicScore:100,regime:'MANUAL_EXIT',timeframe:'MANUAL',entry:pos.currentPrice,reasons:['MANUAL_CLOSE'],riskFlags:[],lifecycle:'CONFIRMED',marketObservedAt:new Date(),confirmedAt:new Date()}});
    const ex=await executeRealOrderForUser(s.userId,{botId:id,connectionId:bot.exchangeId,symbol:pos.symbol,side:'SELL',type:'market',quantity:pos.quantity,signalId:signal.id,marketType:cmt as any});
    if(ex.status!=='FILLED'&&ex.status!=='PARTIAL')return NextResponse.json({ok:false,error:'REAL_CLOSE_NOT_FILLED',execution:ex},{status:409});
    const price=Number(ex.averagePrice||pos.currentPrice); const settled=await applyRealSellFill(pid,Number(ex.filledQuantity||0),price,Number(ex.fee||0),'MANUAL',pos.currentPrice,ex.id); if(!settled.updated)return NextResponse.json({ok:false,error:'POSITION_UPDATE_FAILED'},{status:409});
    await db.auditLog.create({data:{actorId:s.userId,action:'MANUAL_CLOSE',targetType:'POSITION',targetId:pid,metadata:{pnl:settled.pnl,mode:'REAL',closed:settled.closed,remaining:settled.remaining}}});
    return NextResponse.json({ok:true,pnl:settled.pnl,closed:settled.closed,remaining:settled.remaining,execution:ex,mode:'REAL'});
  } catch(e){return NextResponse.json({ok:false,error:apiError(e)},{status:authStatus(e)});}
}
