import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/prisma";
import { apiError,  requireVerifiedSession, authStatus } from "@/lib/auth";
import { botGuardrails, isPaperMode } from "@/lib/paper/service";
import { newState } from "@/lib/paper/engine";

const schema = z.object({ confirm: z.literal(true) });

/** Reset sandbox state only. Real trading accounts can never use this endpoint. */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const s = await requireVerifiedSession();
    const { id } = await params;
    schema.parse(await req.json());
    const bot = await db.bot.findFirst({ where: { id, userId: s.userId, archivedAt: null } });
    if (!bot) return NextResponse.json({ ok: false, error: "BOT_NOT_FOUND" }, { status: 404 });
    if (!isPaperMode(bot.mode)) return NextResponse.json({ ok: false, error: "DEMO_RESET_PAPER_ONLY" }, { status: 409 });
    if (bot.status === "RUNNING") return NextResponse.json({ ok: false, error: "DEMO_RESET_REQUIRES_STOPPED_BOT" }, { status: 409 });

    const g = botGuardrails(bot);
    const now = new Date();
    const state = newState(g.capital, now.getTime());

    await db.$transaction(async (tx) => {
      await tx.position.deleteMany({ where: { botId: id } });
      await tx.order.deleteMany({ where: { botId: id } });
      await tx.signal.deleteMany({ where: { botId: id } });
      await tx.execution.deleteMany({ where: { botId: id } });
      await tx.agentLog.deleteMany({ where: { botId: id } });
      await tx.riskEvent.deleteMany({ where: { botId: id } });
      await tx.aiCall.deleteMany({ where: { botId: id } });
      await tx.portfolioEvent.deleteMany({ where: { botId: id } });
      await tx.bot.update({ where: { id }, data: { status: "STOPPED", state: state as any, startedAt: null, stoppedAt: now } });
      await tx.auditLog.create({ data: { actorId: s.userId, action: "DEMO_SESSION_RESET", targetType: "BOT", targetId: id, metadata: { capital: g.capital, resetAt: now.toISOString() } } });
    });

    return NextResponse.json({ ok: true, capital: g.capital, resetAt: now.toISOString() });
  } catch (e) {
    if (e instanceof z.ZodError) return NextResponse.json({ ok: false, error: "Konfirmasi reset tidak valid" }, { status: 400 });
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}
