import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/prisma";
import { requireVerifiedSession, requireMfa } from "@/lib/auth";
import { realExecutionReady } from "@/lib/execution-engine";
import { dexRealActivationReady } from "@/lib/dex-autonomous";
import { isExchangeCertified } from "@/lib/exchange-catalog";
import { getEntitlements } from "@/lib/entitlements";

const schema = z.object({ mode: z.enum(["DEMO", "REAL"]), connectionId: z.string().optional(), walletId: z.string().optional() });

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const s = await requireVerifiedSession(); const { id } = await params; const b = schema.parse(await req.json());
    const bot = await db.bot.findFirst({ where: { id, userId: s.userId } });
    if (!bot) return NextResponse.json({ ok: false, error: "BOT_NOT_FOUND" }, { status: 404 });
    if (bot.status === "RUNNING") return NextResponse.json({ ok: false, error: "Hentikan bot sebelum mengganti mode." }, { status: 409 });

    if (b.mode === "REAL") {
      // Developer Demo is an alert/reporting attribute only; it must never disable
      // the developer's independent LIVE/REAL trading capability. All normal
      // production safety gates below remain mandatory.
      await requireMfa(req);
      const ent=await getEntitlements(s.userId,s.role);
      const isDeveloper = s.role === "DEVELOPER";
      if (!isDeveloper && !ent.tradingEnabled) return NextResponse.json({ok:false,error:"TRADING_TIER_EXPIRED",message:"Akses LIVE/REAL trading sudah expired. Fitur non-trading tetap tersedia."},{status:403});
      const cfg:any=bot.config||{};
      const liveMarketTypes: string[] = Array.from(new Set((Array.isArray(cfg.marketTypes)&&cfg.marketTypes.length?cfg.marketTypes:[cfg.marketType||"SPOT"]).map((x:any)=>String(x).toUpperCase())));
      if(!isDeveloper && liveMarketTypes.some((m:string)=>!ent.marketTypes.includes(m))) return NextResponse.json({ok:false,error:"MARKET_TYPE_NOT_ENTITLED",marketTypes:liveMarketTypes,allowed:ent.marketTypes},{status:403});
      const needsCex=liveMarketTypes.some((m:string)=>m!=="DEX");
      const needsDex=liveMarketTypes.includes("DEX");
      // DEX-only REAL activation must not inherit the historical CEX exchange-certification gate.
      // Both paths remain fail-closed at the execution authority before any live transaction.
      if ((needsCex && !realExecutionReady()) || (needsDex && !dexRealActivationReady())) return NextResponse.json({ ok:false, error:needsCex?"REAL_TRADING_NOT_READY":"DEX_REAL_TRADING_NOT_READY" }, { status:423 });
      let conn:any=null; let wallet:any=null;
      if(needsCex){
        const selectedConnectionId=b.connectionId||bot.exchangeId;
        if(!selectedConnectionId) return NextResponse.json({ok:false,error:"REAL_CONNECTION_REQUIRED"},{status:400});
        conn=await db.exchangeAccount.findFirst({where:{id:selectedConnectionId,userId:s.userId,status:"CONNECTED"}});
        if(!conn) return NextResponse.json({ok:false,error:"REAL_CONNECTION_NOT_FOUND"},{status:404});
        if(conn.testnet) return NextResponse.json({ok:false,error:"REAL_TRADING_REQUIRES_NON_TESTNET_CONNECTION"},{status:423});
        const supportedMarketTypes=Array.isArray((conn.permissions as any)?.supportedMarketTypes)?(conn.permissions as any).supportedMarketTypes:[conn.marketType];
        if(liveMarketTypes.some((m:string)=>m!=='DEX'&&!supportedMarketTypes.includes(m))) return NextResponse.json({ok:false,error:'EXCHANGE_MARKET_TYPE_NOT_SUPPORTED_BY_CONNECTION',supportedMarketTypes,requested:liveMarketTypes},{status:400});
        if((conn.permissions as any)?.trade !== true) return NextResponse.json({ok:false,error:"EXCHANGE_TRADE_PERMISSION_REQUIRED"},{status:403});
        if(!isExchangeCertified(conn.provider) || conn.certificationStatus !== "CERTIFIED" || !conn.realTradingCertifiedAt || !conn.certificationCompletedAt || Date.now()-conn.certificationCompletedAt.getTime() > 7*24*60*60*1000) return NextResponse.json({ok:false,error:"EXCHANGE_CERTIFICATION_EXPIRED_OR_INCOMPLETE"},{status:423});
      }
      if(needsDex){
        const selectedWalletId=b.walletId||bot.walletId; if(!selectedWalletId)return NextResponse.json({ok:false,error:"REAL_WALLET_REQUIRED_FOR_DEX"},{status:400});
        wallet=await db.wallet.findFirst({where:{id:selectedWalletId,userId:s.userId,status:"CONNECTED"}}); if(!wallet)return NextResponse.json({ok:false,error:"REAL_WALLET_CONNECTION_NOT_FOUND"},{status:404});
      }
      const updated=await db.bot.update({where:{id},data:{mode:"REAL",exchangeId:conn?.id||null,walletId:wallet?.id||null}});
      await db.auditLog.create({data:{actorId:s.userId,action:"BOT_MODE_CHANGED",targetType:"BOT",targetId:id,metadata:{mode:"REAL",connectionId:conn?.id||null,walletId:wallet?.id||null,marketTypes:liveMarketTypes}}});
      return NextResponse.json({ok:true,bot:{id:updated.id,mode:updated.mode,exchangeId:updated.exchangeId,walletId:updated.walletId,marketTypes:liveMarketTypes}});
    }

    const updated = await db.bot.update({ where: { id }, data: { mode: "PAPER", exchangeId: null, walletId: null } });
    await db.auditLog.create({ data: { actorId: s.userId, action: "BOT_MODE_CHANGED", targetType: "BOT", targetId: id, metadata: { mode: "DEMO", connectionId: null } } });
    return NextResponse.json({ ok: true, bot: { id: updated.id, mode: updated.mode } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || "MODE_CHANGE_FAILED" }, { status: e?.message === "UNAUTHENTICATED" ? 401 : 400 });
  }
}
