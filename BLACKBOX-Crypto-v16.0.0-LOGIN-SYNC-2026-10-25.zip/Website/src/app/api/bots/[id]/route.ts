import { NextResponse } from "next/server";
import { apiError,  requireVerifiedSession, authStatus } from "@/lib/auth";
import { z } from "zod";
import { db } from "@/lib/prisma";
import { getEntitlements } from "@/lib/entitlements";
import { botView, botGuardrails } from "@/lib/paper/service";
import { sanitizeGuardrails } from "@/lib/paper/engine";
import { distributedRateLimit } from "@/lib/distributed-rate-limit";
import { recordConsentBundleWithTx } from "@/lib/consent";

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const s = await requireVerifiedSession(); const { id } = await params;
    const row=await db.bot.findFirst({where:{id,userId:s.userId,archivedAt:null},select:{id:true}});if(!row)return NextResponse.json({ok:false,error:"BOT_NOT_FOUND"},{status:404}); const v = await botView(id, s.userId);
    if (!v) return NextResponse.json({ ok: false, error: "BOT_NOT_FOUND" }, { status: 404 });
    return NextResponse.json({ ok: true, ...v });
  } catch (e) { return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) }); }
}

const patchSchema = z.object({
  name: z.string().trim().min(1).max(40).optional(),
  chains: z.array(z.enum(["solana", "base", "bsc", "ethereum"])).min(1).optional(),
  guardrails: z.record(z.string(), z.number()).optional(),
  capital: z.number().min(10).max(10_000_000).optional(),
  marketTypes: z.array(z.enum(['SPOT','FUTURES','DEX'])).min(1).max(3).optional(),
  symbols: z.array(z.string().trim().min(3).max(80)).max(500).optional(),
  preset: z.enum(['conservative','balanced','degen']).optional(),
  connectionId: z.string().min(1).nullable().optional(),
  walletId: z.string().min(1).nullable().optional(),
  consentAccepted: z.boolean().optional(),
  consentTypes: z.array(z.string()).optional(),
  consentContext: z.object({timezone:z.string().max(80).optional(),locale:z.string().max(40).optional(),source:z.string().max(80).optional()}).optional(),
});

/** "Hapus" = archive agar histori trading/audit tetap tersedia. */
export async function DELETE(_:Request,{params}:{params:Promise<{id:string}>}){try{const s=await requireVerifiedSession();const{id}=await params;const bot=await db.bot.findFirst({where:{id,userId:s.userId,archivedAt:null}});if(!bot)return NextResponse.json({ok:false,error:"BOT_NOT_FOUND"},{status:404});if(bot.status!=="STOPPED")return NextResponse.json({ok:false,error:"BOT_MUST_BE_STOPPED"},{status:409});const[open,pending]=await Promise.all([db.position.count({where:{botId:id,status:"OPEN"}}),db.order.count({where:{botId:id,status:{in:["PENDING","PARTIALLY_FILLED"]}}})]);if(open||pending)return NextResponse.json({ok:false,error:"BOT_HAS_ACTIVE_TRADING_STATE",openPositions:open,pendingOrders:pending},{status:409});await db.$transaction([db.bot.update({where:{id},data:{archivedAt:new Date(),status:"STOPPED"}}),db.auditLog.create({data:{actorId:s.userId,action:"BOT_ARCHIVED",targetType:"BOT",targetId:id,metadata:{permanentDelete:false}}})]);return NextResponse.json({ok:true,archived:true})}catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)})}}

/** Ubah nama/chain/guardrails dan modal DEMO. Modal hanya dapat diubah sebelum ada aktivitas trading agar equity tetap konsisten. */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const s = await requireVerifiedSession(); const { id } = await params;
    const b = patchSchema.parse(await req.json());
    const bot = await db.bot.findFirst({ where: { id, userId: s.userId } });
    if (!bot) return NextResponse.json({ ok: false, error: "BOT_NOT_FOUND" }, { status: 404 });
    const ent = await getEntitlements(s.userId, s.role);
    const cur = botGuardrails(bot);
    const events = await db.portfolioEvent.count({ where:{ botId:id } });
    const requestedCapital = b.capital == null ? cur.capital : b.capital;
    if (b.capital != null && b.capital !== cur.capital) {
      if (bot.status !== 'STOPPED') return NextResponse.json({ ok:false, error:'DEMO_CAPITAL_REQUIRES_STOPPED_BOT' }, { status:409 });
      const [open, pending] = await Promise.all([
        db.position.count({ where:{ botId:id, status:'OPEN' } }),
        db.order.count({ where:{ botId:id, status:{ in:['PENDING','PARTIALLY_FILLED'] } } }),
      ]);
      if (open || pending) return NextResponse.json({ ok:false, error:'DEMO_CAPITAL_REQUIRES_NO_ACTIVE_TRADES' }, { status:409 });
      if (events) return NextResponse.json({ ok:false, error:'DEMO_CAPITAL_LOCKED_AFTER_TRADING' }, { status:409 });
    }
    const g = sanitizeGuardrails({ ...cur, ...(b.guardrails || {}), capital: requestedCapital }, cur);
    g.maxPositions = Math.min(g.maxPositions, ent.concurrentPositions);
    g.decisionIntervalSec = Math.max(g.decisionIntervalSec, ent.scanSeconds);
    const cfg: any = bot.config || {};
    const existingTrades=events || 0;
    if ((b.marketTypes || b.symbols || b.preset) && bot.status !== 'STOPPED') return NextResponse.json({ok:false,error:'BOT_CONFIGURATION_REQUIRES_STOPPED_BOT'},{status:409});
    if ((b.marketTypes || b.symbols || b.preset) && existingTrades) return NextResponse.json({ok:false,error:'BOT_MARKET_CONFIGURATION_LOCKED_AFTER_TRADING'},{status:409});
    const marketTypes=Array.from(new Set((b.marketTypes || cfg.marketTypes || [cfg.marketType || 'SPOT']).map((x:any)=>String(x).toUpperCase())));
    const symbols = Array.from(new Set((b.symbols ?? cfg.symbols ?? []).map((x:any)=>String(x).trim().toUpperCase()).filter(Boolean)));
    if (b.connectionId !== undefined && b.walletId !== undefined && b.connectionId && b.walletId) return NextResponse.json({ok:false,error:'BOT_CONNECTION_AMBIGUOUS'},{status:400});
    if ((b.connectionId !== undefined || b.walletId !== undefined) && (bot.status !== 'STOPPED' || existingTrades)) return NextResponse.json({ok:false,error:'BOT_CONNECTION_CHANGE_REQUIRES_CLEAN_STOPPED_BOT'},{status:409});
    if (b.connectionId) { const c=await db.exchangeAccount.findFirst({where:{id:b.connectionId,userId:s.userId,status:'CONNECTED'}}); if(!c)return NextResponse.json({ok:false,error:'EXCHANGE_CONNECTION_NOT_FOUND'},{status:404}); const supported=Array.isArray((c.permissions as any)?.supportedMarketTypes)?(c.permissions as any).supportedMarketTypes:[c.marketType]; if(marketTypes.some((x:any)=>x!=='DEX'&&!supported.includes(x)))return NextResponse.json({ok:false,error:'EXCHANGE_MARKET_TYPE_NOT_SUPPORTED_BY_CONNECTION',supportedMarketTypes:supported},{status:400}); }
    if (b.walletId) { const w=await db.wallet.findFirst({where:{id:b.walletId,userId:s.userId,status:'CONNECTED'}}); if(!w)return NextResponse.json({ok:false,error:'WALLET_CONNECTION_NOT_FOUND'},{status:404}); if(marketTypes.some((x:any)=>x!=='DEX'))return NextResponse.json({ok:false,error:'WALLET_BOT_REQUIRES_DEX_MARKET_TYPE'},{status:400}); }

    if(marketTypes.some((x:any)=>!['SPOT','FUTURES','DEX'].includes(x))) return NextResponse.json({ok:false,error:'INVALID_MARKET_TYPES'},{status:400});
    if(symbols.length>ent.marketPairs) return NextResponse.json({ok:false,error:'MARKET_PAIR_LIMIT_EXCEEDED'},{status:403});
    const materialConfigChange = b.chains !== undefined || b.guardrails !== undefined || b.capital !== undefined || b.marketTypes !== undefined || b.symbols !== undefined || b.connectionId !== undefined || b.walletId !== undefined || b.preset !== undefined;
    if (materialConfigChange) {
      if (!b.consentAccepted) return NextResponse.json({ok:false,error:'CONSENT_REQUIRED: Anda harus membaca dan menyetujui kebijakan, privasi, risiko, dan persetujuan perubahan konfigurasi bot sebelum menyimpan perubahan.'},{status:400});
      const required=['TERMS','PRIVACY','RISK','BOT_CONFIGURATION'];
      const accepted=new Set((b.consentTypes||[]).map(String));
      if(required.some((t)=>!accepted.has(t))) return NextResponse.json({ok:false,error:'CONSENT_DOCUMENTS_REQUIRED'},{status:400});
      const docs=await db.legalDocument.findMany({where:{type:{in:required},active:true},orderBy:{createdAt:'desc'}});
      const available=new Set(docs.map((d:any)=>d.type));
      if(required.some((t)=>!available.has(t))) return NextResponse.json({ok:false,error:'LEGAL_DOCUMENTS_NOT_CONFIGURED'},{status:503});
      await db.$transaction(async(tx:any)=>{
        const consentUser=await tx.user.findUnique({where:{id:s.userId},select:{id:true,name:true,email:true}}); if(!consentUser) throw new Error('CONSENT_USER_NOT_FOUND');
        await recordConsentBundleWithTx(tx,req,consentUser,required.reduce((a:any,t)=>a.concat(t),[]),{botId:id,action:'CONFIG_UPDATE',mode:bot.mode,acknowledgementText:'Saya telah membaca, memahami, dan menyetujui dokumen ini secara sadar, sukarela, dan tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan saya serta, sejauh diperbolehkan dan dapat diberlakukan menurut hukum, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan, klaim, atau permintaan ganti rugi sehubungan dengan penggunaan layanan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, konfirmasi, izinkan, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.',consentMethod:'EXPLICIT_CHECKBOX',readAt:new Date().toISOString(),consentContext:b.consentContext||{source:'BOT_SETTINGS'}});
        await tx.bot.update({ where: { id }, data: { name: b.name ?? bot.name, exchangeId: b.connectionId !== undefined ? b.connectionId : bot.exchangeId, walletId: b.walletId !== undefined ? b.walletId : bot.walletId, config: { ...cfg, guardrails: g, chains: b.chains ?? cfg.chains, marketTypes, marketType:marketTypes[0], symbols, preset:b.preset ?? cfg.preset ?? 'balanced' } } });
        await tx.auditLog.create({ data: { actorId: s.userId, action: "BOT_CONFIGURATION_UPDATED", targetType: "BOT", targetId: id, metadata: { guardrails: g, marketTypes, symbols, consentTypes:required } } });
      });
    } else {
      await db.bot.update({ where: { id }, data: { name: b.name ?? bot.name } });
      await db.auditLog.create({ data: { actorId: s.userId, action: "BOT_NAME_UPDATED", targetType: "BOT", targetId: id, metadata: {} } });
    }
    return NextResponse.json({ ok: true, guardrails: g });
  } catch (e) {
    if (e instanceof z.ZodError) return NextResponse.json({ ok: false, error: "Input tidak valid" }, { status: 400 });
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}

