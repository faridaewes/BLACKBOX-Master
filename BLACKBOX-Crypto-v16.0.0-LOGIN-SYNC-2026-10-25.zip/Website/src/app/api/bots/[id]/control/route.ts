import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/prisma";
import { apiError,  requireVerifiedSession, requireMfa, authStatus } from "@/lib/auth";
import { getEntitlements } from "@/lib/entitlements";
import { botView, botGuardrails, closePaperPosition, isPaperMode } from "@/lib/paper/service";
import { newState } from "@/lib/paper/engine";
import { realExecutionReady } from "@/lib/execution-engine";
import { isExchangeCertified } from "@/lib/exchange-catalog";
import { verifyRealAccount } from "@/lib/real-execution";
import { recordConsent } from '@/lib/consent';
import { isUserTradeFrozen } from "@/lib/login-protect";
import { testExchangeConnection } from "@/lib/unified-exchange";
import { requireCurrentLegalConsent } from '@/lib/legal-registry';
import { fetchExchangeBalance } from '@/lib/unified-exchange';
import { fetchWalletBalance } from '@/lib/wallet-balances';
import { assessCexReadiness, assessWalletReadiness } from '@/lib/trading-connection-readiness';

const schema = z.object({ action: z.enum(["START", "PAUSE", "STOP", "SET_SPEED", "RESET_RISK", "DRY_RUN"]), riskAccepted: z.boolean().optional(), consentAccepted: z.boolean().optional(), consentTypes: z.array(z.string()).optional(), consentAcknowledgement: z.string().trim().min(20).max(500).optional(), consentMethod: z.enum(["EXPLICIT_CHECKBOX","EXPLICIT_CONFIRMATION","E_SIGNATURE"]).optional(), consentContext: z.object({timezone:z.string().max(80).optional(),locale:z.string().max(40).optional(),source:z.string().max(80).optional()}).optional(), speed: z.number().optional() });
const fail = (error: string, status = 400) => NextResponse.json({ ok: false, error }, { status });

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const s = await requireVerifiedSession(); const { id } = await params;
    const b = schema.parse(await req.json());
    const bot = await db.bot.findFirst({ where: { id, userId: s.userId } });
    if (!bot) return fail("BOT_NOT_FOUND", 404);
    const g = botGuardrails(bot);

    if (b.action === "START") {
      const flags = await db.systemControl.findMany({ where: { key: { in: ["GLOBAL_TRADING_HALT", "MAINTENANCE_MODE"] } } });
      if (flags.find((f) => f.key === "GLOBAL_TRADING_HALT")?.value === true) return fail("Bot tidak dapat dijalankan: trading sedang dihentikan oleh BLACKBOX Operations.", 423);
      if (flags.find((f) => f.key === "MAINTENANCE_MODE")?.value === true) return fail("Sistem sedang maintenance. Coba lagi nanti.", 423);
      if (!b.riskAccepted || !b.consentAccepted || !b.consentAcknowledgement) return fail("CONSENT_REQUIRED: Anda harus membaca, memahami, dan menyetujui seluruh dokumen sebelum menjalankan bot.", 400);
      await requireCurrentLegalConsent(s.userId,'TRADING_RULES');
      await requireCurrentLegalConsent(s.userId,'ALMA_ADVISOR_REGISTRATION');
      const requiredConsentTypes = ['TERMS','PRIVACY','RISK','BOT_START','TRADING_RULES','ALMA_ADVISOR_REGISTRATION', ...(isPaperMode(bot.mode) ? [] : ['REAL_EXECUTION'])];
      const acceptedTypes = new Set((b.consentTypes || []).map(String));
      if (requiredConsentTypes.some((t)=>!acceptedTypes.has(t))) return fail('CONSENT_DOCUMENTS_REQUIRED', 400);
      if (await isUserTradeFrozen(s.userId)) return fail("TRADING_AKUN_DIBEKUKAN: Reset password dan hubungi support untuk membuka kembali.", 423);
      if (!isPaperMode(bot.mode)) {
        await requireMfa(req);
        if (!realExecutionReady()) return fail("REAL_TRADING_NOT_READY", 423);
        if (!bot.exchangeId && !bot.walletId) return fail("REAL_CONNECTION_REQUIRED: Hubungkan exchange atau wallet di menu Connections, lalu tautkan ke bot.", 400);
        if (bot.exchangeId) {
          const conn = await db.exchangeAccount.findFirst({where:{id:bot.exchangeId,userId:s.userId,status:"CONNECTED"}});
          if (!conn) return fail("EXCHANGE_CONNECTION_NOT_FOUND: Sambungkan ulang exchange di Connections.", 404);
          if (!conn.encryptedRef) return fail("EXCHANGE_CREDENTIALS_MISSING", 400);
          if (!isExchangeCertified(conn.provider) || conn.certificationStatus !== "CERTIFIED" || !conn.realTradingCertifiedAt || !conn.certificationCompletedAt || Date.now()-conn.certificationCompletedAt.getTime() > 7*24*60*60*1000) return fail("EXCHANGE_CERTIFICATION_EXPIRED_OR_INCOMPLETE", 423);
          if ((conn.permissions as any)?.trade !== true) return fail("EXCHANGE_TRADE_PERMISSION_REQUIRED", 403);
          // Live connectivity probe before START
          try {
            await testExchangeConnection(conn.provider, conn.encryptedRef, conn.testnet, (conn.marketType as any) || "SPOT");
            const rawBalance = await fetchExchangeBalance(conn.provider, conn.encryptedRef, conn.testnet, (conn.marketType as any) || "SPOT");
            const assets = Object.keys(rawBalance?.total || {}).map(asset => ({ asset, total:Number(rawBalance?.total?.[asset]||0), free:Number(rawBalance?.free?.[asset]||0), used:Number(rawBalance?.used?.[asset]||0) })).filter(x => Math.abs(x.total)>1e-12 || Math.abs(x.free)>1e-12 || Math.abs(x.used)>1e-12);
            const readiness = assessCexReadiness({ provider:conn.provider, marketType:(conn.marketType as any)==='FUTURES'?'FUTURES':'SPOT', assets, permissions:(conn.permissions||{}) as Record<string,unknown>, checkedAt:new Date().toISOString() });
            await db.exchangeAccount.update({ where: { id: conn.id }, data: { lastHealthCheckAt: new Date() } });
            if (!readiness.ready) return fail(`TRADING_CONNECTION_NOT_READY: ${readiness.summary}`, 423);
          } catch (e) {
            await db.exchangeAccount.update({ where: { id: conn.id }, data: { status: "ERROR", lastHealthCheckAt: new Date() } }).catch(()=>{});
            return fail("EXCHANGE_HEALTH_FAILED: Koneksi exchange gagal diuji. Periksa API key/izin trade lalu hubungkan ulang.", 502);
          }
        }
        if (bot.walletId) {
          const w = await db.wallet.findFirst({ where: { id: bot.walletId, userId: s.userId, status: "CONNECTED" } });
          if (!w) return fail("WALLET_CONNECTION_NOT_FOUND: Hubungkan ulang wallet di Connections.", 404);
          const walletBalance = await fetchWalletBalance({ chain:w.chain, address:w.address, chainId:w.chainId });
          const readiness = assessWalletReadiness({ provider:w.provider, chain:walletBalance.chain==='SOLANA'?'SOLANA':'EVM', network:walletBalance.network, assets:walletBalance.assets, nativeBalance:walletBalance.nativeBalance, checkedAt:new Date().toISOString() });
          if (!readiness.ready) return fail(`TRADING_CONNECTION_NOT_READY: ${readiness.summary}`, 423);
          await db.wallet.update({ where: { id: w.id }, data: { lastUsedAt: new Date() } }).catch(()=>{});
        }
        if (!(await verifyRealAccount(s.userId))) return fail("ACCOUNT_VERIFICATION_REQUIRED", 403);
      }
      const ent = await getEntitlements(s.userId, s.role);
      const running = await db.bot.count({ where: { userId: s.userId, status: "RUNNING", NOT: { id } } as any });
      if (running >= ent.activeBots) return fail(`Batas bot aktif paket ${ent.label} tercapai (${ent.activeBots}).`, 403);
      const st = bot.state as any;
      if (st?.haltReason === "MAX_DRAWDOWN") return fail("Circuit breaker drawdown aktif. Tekan RESET RISIKO (sesi baru) bila Anda sengaja ingin melanjutkan.", 409);
      const docs = await db.legalDocument.findMany({ where: { type: { in: requiredConsentTypes }, active: true }, orderBy: { createdAt: "desc" } });
      const available = new Set(docs.map((d:any)=>d.type));
      if (requiredConsentTypes.some((t)=>!available.has(t))) return fail('LEGAL_DOCUMENTS_NOT_CONFIGURED', 503);
      const consentContext = b.consentContext || { source: 'BOT_START' };
      const acknowledgementText = b.consentAcknowledgement || 'Saya telah membaca, memahami, dan menyetujui dokumen ini secara sadar, sukarela, dan tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan saya serta, sejauh diperbolehkan dan dapat diberlakukan menurut hukum, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan, klaim, atau permintaan ganti rugi sehubungan dengan penggunaan layanan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, konfirmasi, izinkan, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.';
      const consentMethod = b.consentMethod || 'EXPLICIT_CHECKBOX';
      for (const type of requiredConsentTypes) { await recordConsent(req, s.userId, type, { botId: id, action: "START", mode: bot.mode, acknowledgementText, consentMethod, readAt:new Date().toISOString(), consentContext }); }
      await db.bot.update({ where: { id }, data: { status: "RUNNING", startedAt: bot.startedAt ?? new Date(), stoppedAt: null } });
      await db.auditLog.create({ data: { actorId: s.userId, action: "BOT_START", targetType: "BOT", targetId: id, metadata: { riskAccepted: true, consentAccepted: true, consentTypes: requiredConsentTypes, mode: bot.mode } } });
      await db.userActivityEvent.create({ data: { userId: s.userId, type: "BOT_STARTED" } }).catch(() => {});
    }

    if (b.action === "PAUSE") {
      await db.bot.update({ where: { id }, data: { status: "PAUSED" } });
      await db.auditLog.create({ data: { actorId: s.userId, action: "BOT_PAUSE", targetType: "BOT", targetId: id } });
    }

    if (b.action === "STOP") {
      // Paper positions are closed locally. REAL positions remain under the protective-exit worker; use CLOSE ALL / exchange execution for a deliberate remote close.
      const open = await db.position.findMany({ where: { botId: id, status: "OPEN" } });
      if (isPaperMode(bot.mode)) for (const p of open) await closePaperPosition(bot, g, p, p.currentPrice, "MANUAL");
      await db.bot.update({ where: { id }, data: { status: "STOPPED", stoppedAt: new Date() } });
      await db.auditLog.create({ data: { actorId: s.userId, action: "BOT_STOP", targetType: "BOT", targetId: id, metadata: { closed: open.length } } });
      await db.userActivityEvent.create({ data: { userId: s.userId, type: "BOT_STOPPED" } }).catch(() => {});
    }

    if (b.action === "SET_SPEED") {
      const speed = [1, 3, 10].includes(Number(b.speed)) ? Number(b.speed) : 1;
      await db.bot.update({ where: { id }, data: { config: { ...(bot.config as any), speed } } });
    }

    if (b.action === "RESET_RISK") {
      if (bot.status === "RUNNING") return fail("Hentikan (STOP) bot terlebih dahulu.", 409);
      const v = await botView(id, s.userId);
      await db.bot.update({ where: { id }, data: { state: newState(v!.account.equity, Date.now()) as any } });
      await db.auditLog.create({ data: { actorId: s.userId, action: "BOT_RESET_RISK", targetType: "BOT", targetId: id } });
    }

    if (b.action === "DRY_RUN") {
      // Educational: one simulated decision cycle without opening positions
      const open = await db.position.count({ where: { botId: id, status: "OPEN" } });
      const flags = await db.systemControl.findMany({ where: { key: { in: ["GLOBAL_TRADING_HALT", "MAINTENANCE_MODE"] } } });
      const halt = flags.find((f) => f.key === "GLOBAL_TRADING_HALT")?.value === true;
      const maintenance = flags.find((f) => f.key === "MAINTENANCE_MODE")?.value === true;
      const steps = [
        { stage: "SCAN", ok: true, detail: "Dry-run memindai universe pasar (simulasi)" },
        { stage: "THINK", ok: true, detail: "Dry-run memanggil jalur AI/heuristic (tanpa kuota produksi)" },
        { stage: "RISK", ok: !halt && !maintenance, detail: halt ? "GLOBAL_TRADING_HALT aktif" : maintenance ? "MAINTENANCE_MODE aktif" : `Risk gate siap · posisi terbuka ${open}/${g.maxPositions}` },
        { stage: "SAFETY", ok: true, detail: "Safety Kernel ENTRY akan dievaluasi sebelum open (fail-closed)" },
        { stage: "ROUTE", ok: true, detail: "Quote paper akan disimulasikan; tidak ada order nyata" },
        { stage: "FILL", ok: false, detail: "DRY_RUN: posisi TIDAK dibuka — ini hanya edukasi siklus keputusan" },
      ];
      await db.auditLog.create({ data: { actorId: s.userId, action: "BOT_DRY_RUN", targetType: "BOT", targetId: id, metadata: { steps } } });
      await db.agentLog.create({ data: { botId: id, userId: s.userId, stage: "SCAN", level: "INFO", message: "DRY_RUN: simulasi 1 siklus tanpa membuka posisi" } }).catch(() => {});
      return NextResponse.json({ ok: true, dryRun: true, steps, message: "Dry-run selesai. Tidak ada posisi yang dibuka." });
    }

    return NextResponse.json({ ok: true });
  } catch (e) {
    if (e instanceof z.ZodError) return fail("Input tidak valid");
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}
