import { NextResponse } from "next/server";
import { db } from "@/lib/prisma";
import { apiError,  requireVerifiedSession, requireMfa, authStatus } from "@/lib/auth";
import { botGuardrails, closePaperPosition } from "@/lib/paper/service";
import { executeRealOrderForUser, applyRealSellFill } from "@/lib/real-execution";
import { recordConsent } from "@/lib/consent";
import { getConnectionMarket } from "@/lib/connection-market-universe";
import { fetchLiveDexMarkets } from '@/lib/paper/feed';
import { prepareDexTradeIntent, dexTokenDecimals } from '@/lib/dex-execution';

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const s = await requireVerifiedSession(); const { id } = await params;
    const bot = await db.bot.findFirst({ where: { id, userId: s.userId } });
    if (!bot) return NextResponse.json({ ok: false, error: "BOT_NOT_FOUND" }, { status: 404 });
    const open=await db.position.findMany({where:{botId:id,status:"OPEN"},include:{wallet:true}}); let n=0,pnl=0;
    if(bot.mode==='REAL') await requireMfa(req);
    await recordConsent(req,s.userId,'REAL_EXECUTION',{botId:id,action:'CLOSE_ALL',positionCount:open.length,acknowledgementText:'Saya telah membaca, memahami, dan menyetujui dokumen ini secara sadar, sukarela, dan tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan saya serta, sejauh diperbolehkan dan dapat diberlakukan menurut hukum, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan, klaim, atau permintaan ganti rugi sehubungan dengan penggunaan layanan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, konfirmasi, izinkan, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.',consentMethod:'EXPLICIT_CONFIRMATION',readAt:new Date().toISOString()});
    for(const p of open){
      if(bot.mode==='REAL'){
        const mt=String(p.marketType||((bot.config as any)?.marketType)||'SPOT').toUpperCase();
        if(mt==='DEX'){
          if(!p.walletId||!p.wallet) { continue; }
          const sig=await db.signal.findFirst({where:{botId:id,userId:s.userId,marketType:'DEX',pairAddress:p.pairAddress,walletId:p.walletId,baseTokenAddress:{not:null},quoteTokenAddress:{not:null}},orderBy:{createdAt:'desc'}});
          if(!sig?.baseTokenAddress||!sig.quoteTokenAddress||!sig.chain) continue;
          const market=(await fetchLiveDexMarkets([sig.chain],8000)).find((m:any)=>m.pairAddress===p.pairAddress);
          const signal=await db.signal.create({data:{botId:id,userId:s.userId,symbol:p.symbol,canonicalSymbol:p.canonicalSymbol||p.symbol,marketType:'DEX',connectionKey:`wallet:${p.walletId}`,walletId:p.walletId,chain:sig.chain,dex:sig.dex,pairAddress:p.pairAddress,baseTokenAddress:sig.baseTokenAddress,quoteTokenAddress:sig.quoteTokenAddress,action:'SELL',status:'VALID',score:100,confidence:99,qualityScore:100,confirmationCount:5,noTradeReason:null,strategyVersion:'DEX-REAL-1.0-MANUAL-CLOSE-ALL',deterministicScore:100,aiScore:100,liquidityUsd:Number(market?.liquidityUsd||p.liquidityUsd||0),rugRisk:Number(p.rugRisk||0),regime:'MANUAL_EXIT',timeframe:'MANUAL',entry:Number(market?.priceUsd||p.currentPrice||p.entryPrice),reasons:['MANUAL_CLOSE_ALL'],riskFlags:[],lifecycle:'CONFIRMED',marketObservedAt:new Date(),confirmedAt:new Date()}});
          const decimals=await dexTokenDecimals(sig.chain,sig.baseTokenAddress,p.wallet.chainId); const base=String(Math.max(1,Math.floor(Number(p.quantity)*10**decimals)));
          try{await prepareDexTradeIntent({userId:s.userId,botId:id,signalId:signal.id,walletId:p.walletId,side:'SELL',sellToken:sig.baseTokenAddress,buyToken:sig.quoteTokenAddress,sellAmountBaseUnits:base,slippageBps:Math.max(1,Math.min(300,Math.round(Number((bot.config as any)?.guardrails?.baseSlippagePct||0.5)*100))),chain:sig.chain,chainId:p.wallet.chainId,symbol:p.symbol,dex:sig.dex||undefined,pairAddress:p.pairAddress||undefined});}catch(e){return NextResponse.json({ok:false,error:'DEX_CLOSE_FAILED',detail:String(e),closed:n,pnl},{status:502});}
        } else {
          if(!bot.exchangeId) continue; const cm=await getConnectionMarket(String(bot.exchangeId),mt as any,p.symbol); const signal=await db.signal.create({data:{botId:id,userId:s.userId,symbol:p.symbol,canonicalSymbol:cm.canonicalSymbol,marketType:mt,connectionKey:`cex:${bot.exchangeId}`,exchangeAccountId:bot.exchangeId,action:'SELL',status:'VALID',score:100,confidence:99,deterministicScore:100,regime:'MANUAL_EXIT',timeframe:'MANUAL',entry:p.currentPrice,reasons:['MANUAL_CLOSE_ALL'],riskFlags:[],lifecycle:'CONFIRMED',marketObservedAt:new Date(),confirmedAt:new Date()}});
          try{const ex=await executeRealOrderForUser(s.userId,{botId:id,connectionId:String(bot.exchangeId),symbol:p.symbol,side:'SELL',type:'market',quantity:p.quantity,signalId:signal.id,marketType:mt as any});if(ex.status==='FILLED'||ex.status==='PARTIAL'){const price=Number(ex.averagePrice||p.currentPrice);const r=await applyRealSellFill(p.id,Number(ex.filledQuantity||0),price,Number(ex.fee||0),'MANUAL',p.currentPrice,ex.id);if(r.updated){if(r.closed)n++;pnl+=r.pnl;}}}catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED',closed:n,pnl},{status:502});}
        }
      }else{const r=await closePaperPosition(bot,botGuardrails(bot),p,p.currentPrice,'MANUAL');if(r){n++;pnl+=r.pnl;}}
    }
    await db.auditLog.create({data:{actorId:s.userId,action:'CLOSE_ALL',targetType:'BOT',targetId:id,metadata:{closed:n,pnl,mode:bot.mode}}});
    return NextResponse.json({ok:true,closed:n,pnl});
  } catch (e) { return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) }); }
}
