import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/prisma";
import { apiError,  requireVerifiedSession, authStatus } from "@/lib/auth";
import { getEntitlements } from "@/lib/entitlements";
import { PRESETS, sanitizeGuardrails, type Preset } from "@/lib/paper/engine";
import { recordConsent } from "@/lib/consent";
import { getProfileIdentity } from '@/lib/profile';
import { requireDeveloper } from '@/lib/access-control';

const schema = z.object({
  name: z.string().trim().min(1).max(40).default("BLACKBOX Bot"),
  preset: z.enum(["conservative", "balanced", "degen"]).default("balanced"),
  capital: z.number().min(10).max(10_000_000).default(1000),
  chains: z.array(z.enum(["solana", "base", "bsc", "ethereum"])).min(1).default(["solana", "base", "bsc", "ethereum"]),
  guardrails: z.object({
    capital: z.number().optional(),
    maxDrawdownPct: z.number().optional(),
    riskPerTradePct: z.number().optional(),
    sessionTargetPct: z.number().optional(),
    dailyLossLimitPct: z.number().optional(),
    maxPositions: z.number().optional(),
    allocationPct: z.number().optional(),
    stopLossPct: z.number().optional(),
    takeProfitPct: z.number().optional(),
    minAiScore: z.number().optional(),
    maxRugRisk: z.number().optional(),
    minLiquidityUsd: z.number().optional(),
    feePct: z.number().optional(),
    baseSlippagePct: z.number().optional(),
    maxPriceImpactPct: z.number().optional(),
    decisionIntervalSec: z.number().optional(),
    signalProfile: z.enum(["PRECISION", "BALANCED"]).optional(),
    targetWinRatePct: z.number().optional(),
  }).partial().optional(),
  marketType: z.enum(["SPOT","FUTURES","DEX"]).default("SPOT"),
  marketTypes: z.array(z.enum(["SPOT","FUTURES","DEX"])).min(1).max(3).optional(),
  symbols: z.array(z.string().trim().min(3).max(80)).max(500).default(["BTC/USDT","ETH/USDT","SOL/USDT"]).transform(xs => Array.from(new Set(xs.map(x => x.toUpperCase())))),
  connectionId: z.string().trim().min(1).optional(),
  walletId: z.string().trim().min(1).optional(),
  developerDemo: z.boolean().optional().default(false),
});

export async function GET() {
  try {
    const s = await requireVerifiedSession();
    const bots = await db.bot.findMany({ where: { userId: s.userId, archivedAt: null }, orderBy: { id: "desc" } });
    const ent = await getEntitlements(s.userId, s.role);
    const sub=await db.subscription.findFirst({where:{userId:s.userId,status:"ACTIVE",startsAt:{lte:new Date()},expiresAt:{gt:new Date()}},include:{plan:true},orderBy:{expiresAt:"desc"}}); const profile=await getProfileIdentity(s.userId); return NextResponse.json({ ok: true, bots: bots.map((b) => ({ id: b.id, name: b.name, status: b.status, mode: b.mode, exchangeId:(b as any).exchangeId ?? null, walletId:(b as any).walletId ?? null, developerDemo: Boolean((b as any).developerDemo) })), entitlements: ent, currentTier: ent.label, tierExpiresAt: sub?.expiresAt ?? null, profile });
  } catch (e) { return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) }); }
}

export async function POST(req: Request) {
  try {
    const s = await requireVerifiedSession();
    const b = schema.parse(await req.json());
    if (b.developerDemo && s.role !== 'DEVELOPER') return NextResponse.json({ ok:false, error:'DEVELOPER_DEMO_ONLY' }, { status:403 });
    const requestedMarketTypes = Array.from(new Set((b.marketTypes?.length ? b.marketTypes : [b.marketType])));
    const needsCex = requestedMarketTypes.some(x => x !== "DEX");
    const needsDex = requestedMarketTypes.includes("DEX");
    if (needsCex && !b.connectionId) return NextResponse.json({ok:false,error:"CEX_CONNECTION_REQUIRED_FOR_SELECTED_MARKETS"},{status:400});
    if (needsDex && !b.walletId) return NextResponse.json({ok:false,error:"DEX_WALLET_REQUIRED_FOR_SELECTED_MARKETS"},{status:400});
    if (b.connectionId) { const c=await db.exchangeAccount.findFirst({where:{id:b.connectionId,userId:s.userId,status:"CONNECTED"}}); if(!c)return NextResponse.json({ok:false,error:"EXCHANGE_CONNECTION_NOT_FOUND"},{status:404}); const supported=Array.isArray((c.permissions as any)?.supportedMarketTypes)?(c.permissions as any).supportedMarketTypes:[c.marketType]; if(requestedMarketTypes.some(x=>x!=="DEX"&&!supported.includes(x))) return NextResponse.json({ok:false,error:"BOT_MARKET_TYPE_CONNECTION_MISMATCH",connectionMarketType:c.marketType,requested:requestedMarketTypes},{status:400}); }
    if (b.walletId) { const w=await db.wallet.findFirst({where:{id:b.walletId,userId:s.userId,status:"CONNECTED"}}); if(!w)return NextResponse.json({ok:false,error:"WALLET_CONNECTION_NOT_FOUND"},{status:404}); if(!needsDex)return NextResponse.json({ok:false,error:"WALLET_ONLY_VALID_FOR_DEX_MARKET"},{status:400}); }
    const ent = await getEntitlements(s.userId, s.role);
    const count = await db.bot.count({ where: { userId: s.userId, status: { in: ["RUNNING", "PAUSED"] } } });
    if (count >= ent.activeBots) return NextResponse.json({ ok: false, error: `Batas bot paket ${ent.label} tercapai (${ent.activeBots}).` }, { status: 403 });
    const selectedMarketTypes: Array<'SPOT'|'FUTURES'|'DEX'> = Array.from(new Set((b.marketTypes?.length ? b.marketTypes : [b.marketType])));
    // DEMO/PAPER market selection is intentionally independent from paid LIVE entitlements.
    // Plan entitlements remain authoritative for REAL/live signal and execution routes.
    if (selectedMarketTypes.some((m) => !["SPOT","FUTURES","DEX"].includes(m))) return NextResponse.json({ ok:false, error:"INVALID_MARKET_TYPES" },{status:400});
    if (b.symbols.length > ent.marketPairs) return NextResponse.json({ ok:false,error:`Tier ${ent.label} maksimal ${ent.marketPairs} pair.`},{status:403});
    const preset = b.preset as Preset;
    const g = sanitizeGuardrails({ ...PRESETS[preset], ...(b.guardrails || {}), capital: b.capital }, PRESETS[preset]);
    g.maxPositions = Math.min(g.maxPositions, ent.concurrentPositions);
    g.decisionIntervalSec = Math.max(g.decisionIntervalSec, ent.scanSeconds);
    await recordConsent(req,s.userId,"SETUP_STEP",{step:"BOT_CREATE",preset:b.preset,marketType:b.marketType,symbols:b.symbols.slice(0,ent.marketPairs),acknowledgementText:'Saya telah membaca, memahami, dan menyetujui dokumen ini secara sadar, sukarela, dan tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan saya serta, sejauh diperbolehkan dan dapat diberlakukan menurut hukum, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan, klaim, atau permintaan ganti rugi sehubungan dengan penggunaan layanan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, konfirmasi, izinkan, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.',consentMethod:'EXPLICIT_CHECKBOX',readAt:new Date().toISOString()});
    const bot = await db.bot.create({ data: { userId: s.userId, name: b.name, status: "STOPPED", mode: "PAPER", exchangeId: b.connectionId ?? null, walletId: b.walletId ?? null, developerDemo: b.developerDemo === true, config: { guardrails: g, preset: b.preset, chains: b.chains, speed: 1, marketType:selectedMarketTypes[0], marketTypes:selectedMarketTypes, symbols:b.symbols.slice(0,ent.marketPairs) } } });
    await db.auditLog.create({ data: { actorId: s.userId, action: "BOT_CREATED", targetType: "BOT", targetId: bot.id, metadata: { preset: b.preset, capital: g.capital, connectionId: b.connectionId ?? null, walletId: b.walletId ?? null } } });
    return NextResponse.json({ ok: true, id: bot.id });
  } catch (e) {
    if (e instanceof z.ZodError) return NextResponse.json({ ok: false, error: "Input tidak valid", details: (e as any).issues.map((i: any) => i.path.join(".") + ": " + i.message) }, { status: 400 });
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}
