import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession, authStatus } from '@/lib/auth';
import { db } from '@/lib/prisma';
import { getVisibleConsentUserIds, latestConsentWhere, requireLegalExport } from '@/lib/legal-registry';
import { buildLegalAgreementDoc, buildLegalAgreementExcel, buildLegalAgreementPdf, type LegalConsentExport } from '@/lib/export/legal';

export const runtime='nodejs';
const schema=z.object({format:z.enum(['pdf','doc','xlsx']).default('xlsx'),q:z.string().max(120).optional(),type:z.string().max(80).optional(),userId:z.string().optional(),from:z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),to:z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional()});

export async function GET(req:Request){
  try{
    const s=await requireSession(); await requireLegalExport(s); const q=schema.parse(Object.fromEntries(new URL(req.url).searchParams.entries()));
    const visible=await getVisibleConsentUserIds(s);
    const rows=await db.consent.findMany({where:latestConsentWhere(visible,q),orderBy:{acceptedAt:'desc'},take:1000,include:{user:{select:{id:true,name:true,username:true,email:true,phone:true,role:true}},document:{select:{id:true,type:true,version:true,title:true,contentHash:true}}}});
    const data=rows.map((x:any):LegalConsentExport=>({consentId:x.id,acceptedAt:x.acceptedAt,document:x.document,user:x.user,subjectSnapshot:x.subjectSnapshot,documentBodySnapshot:x.documentBodySnapshot,documentHash:x.documentHash,ipHash:x.ipHash,userAgent:x.userAgent,consentTimezone:x.consentTimezone,consentLocale:x.consentLocale,consentSource:x.consentSource,consentMethod:x.consentMethod,acknowledgementText:x.acknowledgementText,readAt:x.readAt,consentContextHash:x.consentContextHash,evidenceHash:x.evidenceHash,metadata:x.metadata}));
    await db.auditLog.create({data:{actorId:s.userId,action:'LEGAL_AGREEMENT_EXPORT',targetType:'LEGAL_CONSENT',metadata:{format:q.format,count:data.length,filters:q}}}).catch(()=>{});
    const date=new Date().toISOString().slice(0,10);
    if(q.format==='pdf'){const out=await buildLegalAgreementPdf(data);return new NextResponse(new Uint8Array(out),{headers:{'Content-Type':'application/pdf','Content-Disposition':`attachment; filename="blackbox-agreements-${date}.pdf"`}})}
    if(q.format==='doc'){const out=buildLegalAgreementDoc(data);return new NextResponse(out,{headers:{'Content-Type':'application/msword; charset=utf-8','Content-Disposition':`attachment; filename="blackbox-agreements-${date}.doc"`}})}
    const out=buildLegalAgreementExcel(data);return new NextResponse(new Uint8Array(out),{headers:{'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','Content-Disposition':`attachment; filename="blackbox-agreements-${date}.xlsx"`}});
  }catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)})}
}
