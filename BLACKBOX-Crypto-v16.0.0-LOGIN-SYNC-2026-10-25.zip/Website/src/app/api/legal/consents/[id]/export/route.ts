import { NextResponse } from 'next/server';
import { requireSession, authStatus } from '@/lib/auth';
import { db } from '@/lib/prisma';
import { getConsentById, requireLegalExport } from '@/lib/legal-registry';
import { buildLegalAgreementDoc, buildLegalAgreementExcel, buildLegalAgreementPdf, type LegalConsentExport } from '@/lib/export/legal';

export const runtime='nodejs';

function mapConsent(x:any):LegalConsentExport{return {consentId:x.id,acceptedAt:x.acceptedAt,document:x.document,user:x.user,subjectSnapshot:x.subjectSnapshot,documentBodySnapshot:x.documentBodySnapshot,documentHash:x.documentHash,ipHash:x.ipHash,userAgent:x.userAgent,consentTimezone:x.consentTimezone,consentLocale:x.consentLocale,consentSource:x.consentSource,consentMethod:x.consentMethod,acknowledgementText:x.acknowledgementText,readAt:x.readAt,consentContextHash:x.consentContextHash,evidenceHash:x.evidenceHash,metadata:x.metadata};}

export async function GET(req:Request,{params}:{params:Promise<{id:string}>}){
  try{
    const s=await requireSession(); await requireLegalExport(s);
    const {id}=await params; const consent=await getConsentById(s,id);
    const format=(new URL(req.url).searchParams.get('format')||'pdf').toLowerCase();
    const row=mapConsent(consent);
    await db.auditLog.create({data:{actorId:s.userId,action:'LEGAL_AGREEMENT_DOWNLOAD',targetType:'LEGAL_CONSENT',targetId:consent.id,metadata:{format,documentType:consent.document.type,documentVersion:consent.document.version,userId:consent.user.id}}}).catch(()=>{});
    if(format==='pdf'){
      const out=await buildLegalAgreementPdf([row]);
      return new NextResponse(new Uint8Array(out),{headers:{'Content-Type':'application/pdf','Content-Disposition':`attachment; filename="blackbox-agreement-${consent.id}.pdf"`}});
    }
    if(format==='doc'){
      const out=buildLegalAgreementDoc([row]);
      return new NextResponse(out,{headers:{'Content-Type':'application/msword; charset=utf-8','Content-Disposition':`attachment; filename="blackbox-agreement-${consent.id}.doc"`}});
    }
    if(format==='xlsx'){
      const out=buildLegalAgreementExcel([row]);
      return new NextResponse(new Uint8Array(out),{headers:{'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','Content-Disposition':`attachment; filename="blackbox-agreement-${consent.id}.xlsx"`}});
    }
    return NextResponse.json({ok:false,error:'FORMAT_NOT_SUPPORTED'},{status:400});
  }catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)})}
}
