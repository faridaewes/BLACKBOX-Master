import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession, authStatus } from '@/lib/auth';
import { db } from '@/lib/prisma';
import { getVisibleConsentUserIds, latestConsentWhere, requireLegalRead } from '@/lib/legal-registry';

const schema = z.object({ q:z.string().max(120).optional(), type:z.string().max(80).optional(), userId:z.string().optional(), from:z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), to:z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), limit:z.coerce.number().int().min(1).max(500).optional() });

export async function GET(req:Request){
  try {
    const s=await requireSession(); await requireLegalRead(s);
    const q=schema.parse(Object.fromEntries(new URL(req.url).searchParams.entries()));
    const visible=await getVisibleConsentUserIds(s);
    const rows=await db.consent.findMany({where:latestConsentWhere(visible,q),orderBy:{acceptedAt:'desc'},take:q.limit??200,include:{user:{select:{id:true,name:true,username:true,email:true,phone:true,role:true}},document:{select:{id:true,type:true,version:true,title:true,contentHash:true}}}});
    return NextResponse.json({ok:true,scope:s.role,rows:rows.map(x=>({id:x.id,acceptedAt:x.acceptedAt,user:x.user,document:x.document,documentHash:x.documentHash||x.document.contentHash,evidenceHash:x.evidenceHash,ipHash:x.ipHash,userAgent:x.userAgent,consentTimezone:x.consentTimezone,consentLocale:x.consentLocale,consentSource:x.consentSource,consentMethod:x.consentMethod,acknowledgementText:x.acknowledgementText,readAt:x.readAt,consentContextHash:x.consentContextHash,metadata:x.metadata}))},{headers:{'Cache-Control':'private,no-store'}});
  } catch(e) { return NextResponse.json({ok:false,error:String(e instanceof Error?e.message:e)},{status:authStatus(e)}); }
}
