import { NextResponse } from 'next/server';
import { z } from 'zod';
import crypto from 'node:crypto';
import { requireSession, authStatus } from '@/lib/auth';
import { db } from '@/lib/prisma';
import { LEGAL_TYPES, legalHash, requireLegalManage, requireLegalStaffRead } from '@/lib/legal-registry';
import { BLACKBOX_RELEASE_VERSION } from '@/lib/release-version';

const createSchema=z.object({type:z.enum(LEGAL_TYPES as any),title:z.string().trim().min(5).max(240),body:z.string().trim().min(20).max(200000),changeNote:z.string().trim().min(3).max(1000)});

export async function GET(){
  try{
    const s=await requireSession(); await requireLegalStaffRead(s);
    const docs=await db.legalDocument.findMany({where:{type:{in:[...LEGAL_TYPES]}},orderBy:{createdAt:'desc'},take:1000,select:{id:true,type:true,version:true,title:true,body:true,contentHash:true,active:true,workflowState:true,changeNote:true,editorId:true,publishedAt:true,createdAt:true}});
    return NextResponse.json({ok:true,documents:docs});
  }catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)})}
}

export async function POST(req:Request){
  try{
    const s=await requireSession(); await requireLegalManage(s);
    const b=createSchema.parse(await req.json());
    const current=await db.legalDocument.findFirst({where:{type:b.type,active:true},orderBy:{createdAt:'desc'}});
    const stamp=new Date().toISOString().replace(/[-:TZ.]/g,'').slice(0,14);
    const version=`${BLACKBOX_RELEASE_VERSION}-LEGAL-${stamp}`;
    const hash=legalHash(b.type,version,b.title,b.body);
    const created=await db.$transaction(async tx=>{
      await tx.legalDocument.updateMany({where:{type:b.type,active:true},data:{active:false,workflowState:'SUPERSEDED'}});
      const d=await tx.legalDocument.create({data:{id:`legal_${crypto.randomUUID().replace(/-/g,'')}`,type:b.type,version,title:b.title,body:b.body,contentHash:hash,active:true,workflowState:'PUBLISHED',changeNote:b.changeNote,editorId:s.userId,publishedAt:new Date(),supersedesId:current?.id||null}});
      await tx.auditLog.create({data:{actorId:s.userId,action:'LEGAL_DOCUMENT_PUBLISHED',targetType:'LEGAL_DOCUMENT',targetId:d.id,metadata:{type:b.type,version,previousVersion:current?.version||null,changeNote:b.changeNote,contentHash:hash}}});
      return d;
    });
    return NextResponse.json({ok:true,document:created});
  }catch(e){return NextResponse.json({ok:false,error:e instanceof z.ZodError?'INPUT_INVALID':String(e instanceof Error?e.message:e)},{status:authStatus(e)})}
}
