import { NextResponse } from 'next/server';
import { requireSession, authStatus } from '@/lib/auth';
import { db } from '@/lib/prisma';
import { LEGAL_TYPES } from '@/lib/legal-registry';

export async function GET(){
  try{
    const s=await requireSession();
    const docs=await db.legalDocument.findMany({where:{type:{in:[...LEGAL_TYPES]},active:true},orderBy:{createdAt:'desc'},select:{type:true,version:true,title:true,contentHash:true,createdAt:true}});
    const latest=new Map<string,any>(); for(const d of docs) if(!latest.has(d.type)) latest.set(d.type,d);
    const consents=await db.consent.findMany({where:{userId:s.userId,documentVersion:{not:null}},orderBy:{acceptedAt:'desc'},select:{documentVersion:true,document:{select:{type:true}},acceptedAt:true}});
    const accepted=new Map<string,any>(); for(const c of consents) if(!accepted.has(c.document.type)) accepted.set(c.document.type,c);
    const items=[...latest.values()].map(d=>({type:d.type,title:d.title,currentVersion:d.version,acceptedVersion:accepted.get(d.type)?.documentVersion||null,acceptedAt:accepted.get(d.type)?.acceptedAt||null,current:d.version===accepted.get(d.type)?.documentVersion}));
    return NextResponse.json({ok:true,items});
  }catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)})}
}
