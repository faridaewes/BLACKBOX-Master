import { NextResponse } from 'next/server';
import { requireSession, authStatus } from '@/lib/auth';
import { getHealthCenterSnapshot } from '@/lib/health-center';
import { buildControlCenterItems, classifyControlCenterState, P2_CONTROL_CENTER_VERSION, recoveryMessage } from '@/lib/p2-control-center-v1181';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    await requireSession();
    const health = await getHealthCenterSnapshot().catch(() => null);
    const healthOk = !!health && health.overall !== 'FAILED';
    const healthStatus = health?.overall === 'HEALTHY' ? 'healthy' : health?.overall === 'DEGRADED' ? 'degraded' : 'unhealthy';
    const liveOk = true;
    const readyOk = healthOk && !!health?.components?.some((x: any) => x.id === 'database' && x.state === 'HEALTHY');
    const tradingAuthorization = health?.recovery?.tradingAuthorization || 'LOCKED_UNTIL_EXPLICIT_CERTIFICATION';
    const state = classifyControlCenterState({ healthOk, healthStatus, liveOk, readyOk, tradingAuthorization });
    return NextResponse.json({
      ok: true,
      version: P2_CONTROL_CENTER_VERSION,
      state,
      message: recoveryMessage(state),
      score: health?.score ?? null,
      generatedAt: health?.generatedAt ?? new Date().toISOString(),
      items: buildControlCenterItems({ health, liveOk, readyOk }),
      safety: { executionAllowed: false, noOrderSigning: true, noOrderSubmission: true, noRouterAuthorization: true },
    }, { headers: { 'cache-control': 'no-store' } });
  } catch (e) {
    const status = authStatus(e);
    if (status === 401 || status === 403) return NextResponse.json({ ok:false, error: status === 401 ? 'AUTH_REQUIRED' : 'FORBIDDEN' }, { status, headers: { 'cache-control': 'no-store' } });
    return NextResponse.json({
      ok: true,
      version: P2_CONTROL_CENTER_VERSION,
      state: 'RECOVERY',
      message: recoveryMessage('RECOVERY'),
      score: null,
      generatedAt: new Date().toISOString(),
      items: buildControlCenterItems({ liveOk: false, readyOk: false }),
      safety: { executionAllowed: false, noOrderSigning: true, noOrderSubmission: true, noRouterAuthorization: true },
    }, { status: 200, headers: { 'cache-control': 'no-store' } });
  }
}
