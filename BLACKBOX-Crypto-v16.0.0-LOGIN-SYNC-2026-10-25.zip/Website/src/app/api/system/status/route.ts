import { NextResponse } from 'next/server';
import { apiError,  requireSession, authStatus } from '@/lib/auth';
import { getFlags } from '@/lib/emergency';

export async function GET() {
  try {
    await requireSession();
    return NextResponse.json({ ok: true, ...(await getFlags()), checkedAt: new Date().toISOString() }, { headers: { 'cache-control': 'no-store' } });
  } catch (e) {
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}
