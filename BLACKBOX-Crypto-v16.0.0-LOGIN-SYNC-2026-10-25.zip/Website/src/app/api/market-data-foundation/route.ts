import { rateLimitUserKey } from '@/lib/rate-limit';
import { NextResponse } from 'next/server';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { fetchExchangeMarkets, fetchLiveDexMarkets } from '@/lib/paper/feed';
import { buildCanonicalUniverse, MARKET_DATA_FOUNDATION_VERSION, type FoundationMarketType } from '@/lib/market-data-foundation-v118';
import { db } from '@/lib/prisma';
import { bestEffortPersistence, marketDegradedPayload, safeProviderSettled, sanitizeProviderError, P3_MARKET_RUNTIME_VERSION } from '@/lib/market-runtime-resilience-v1181';

const allowed=new Set(['ALL','SPOT','FUTURES','DEX']);
const chains=new Set(['all','solana','base','bsc','ethereum','arbitrum','polygon','avalanche']);
const finite=(v:string|null,d:number,min:number,max:number)=>{const n=Number(v);return Number.isFinite(n)?Math.max(min,Math.min(max,n)):d};
export async function GET(req:Request){
 try{
  const s=await requireVerifiedSession(); const rl=await distributedRateLimit(rateLimitUserKey(s.userId, "market-data-foundation-p2"),3,60);
  if(!rl.ok)return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429,headers:{'Retry-After':String(rl.retryAfterSec)}});
  const u=new URL(req.url), marketType=(u.searchParams.get('marketType')||'ALL').toUpperCase(), chain=(u.searchParams.get('chain')||'all').toLowerCase();
  if(!allowed.has(marketType)||!chains.has(chain))return NextResponse.json({ok:false,error:'INVALID_MARKET_FILTER'},{status:400});
  const chainList=chain==='all'?['solana','base','bsc','ethereum']:[chain]; const tasks:Promise<{type:FoundationMarketType,data:any[]}>[]=[];
  if(marketType==='DEX'||marketType==='ALL')tasks.push(fetchLiveDexMarkets(chainList).then(data=>({type:'DEX',data})));
  if(marketType==='SPOT'||marketType==='ALL')tasks.push(fetchExchangeMarkets('SPOT',[],Number.POSITIVE_INFINITY).then(data=>({type:'SPOT',data})));
  if(marketType==='FUTURES'||marketType==='ALL')tasks.push(fetchExchangeMarkets('FUTURES',[],Number.POSITIVE_INFINITY).then(data=>({type:'FUTURES',data})));
  const settled=await Promise.allSettled(tasks); const providerState=safeProviderSettled(settled); const observations=settled.flatMap(x=>x.status==='fulfilled'?x.value.data.map(m=>({key:m.key,provider:String(m.provider||m.dexId||'UNKNOWN').replace(/^ccxt:/i,''),source:String(m.source||m.provider||m.dexId||'UNKNOWN'),marketType:x.value.type,symbol:String(m.symbol||'UNKNOWN'),chain:String(m.chainId||'CEX'),priceUsd:Number(m.priceUsd),bidUsd:m.bidUsd,askUsd:m.askUsd,liquidityUsd:Number(m.liquidityUsd),volume24h:Number(m.volume24h),spreadBps:m.spreadBps,observedAt:m.observedAt,sourceUpdatedAt:m.sourceUpdatedAt,fetchedAt:m.fetchedAt,ohlcv:m.ohlcv,analysisComplete:m.analysisComplete,ok:true})):[]);
  const q=(u.searchParams.get('q')||'').trim().toLowerCase(); const filtered=q?observations.filter(m=>`${m.symbol} ${m.provider} ${m.chain}`.toLowerCase().includes(q)):observations;
  const universe=buildCanonicalUniverse(filtered,{minLiquidityUsd:finite(u.searchParams.get('minLiquidityUsd'),25000,0,1e9),minVolumeUsd:finite(u.searchParams.get('minVolumeUsd'),10000,0,1e10),maxSpreadBps:finite(u.searchParams.get('maxSpreadBps'),150,0,5000),minQuality:finite(u.searchParams.get('minQuality'),85,0,100)});
  const limit=Math.floor(finite(u.searchParams.get('limit'),200,1,500)); const rows=universe.slice(0,limit);
  const persisted=rows.length?await bestEffortPersistence(()=>db.marketDataQualitySnapshot.createMany({data:rows.map(x=>({marketKey:x.observation.key!,marketType:x.observation.marketType,provider:x.observation.provider!,symbol:x.observation.symbol!,source:x.observation.source,qualityScore:x.assessment.qualityScore,status:x.assessment.status,freshnessScore:x.assessment.freshnessScore,completenessScore:x.assessment.completenessScore,consistencyScore:x.assessment.consistencyScore,latencyScore:x.assessment.latencyScore,liquidityScore:x.assessment.liquidityScore,universeEligible:x.assessment.universeEligible,intelligenceAllowed:x.assessment.intelligenceAllowed,blockers:x.assessment.blockers,warnings:x.assessment.warnings,observedAt:x.observation.observedAt?new Date(x.observation.observedAt as any):null}))})): ({ok:true,value:null} as const);
  const summary={inventory:filtered.length,canonical:universe.length,eligible:universe.filter(x=>x.assessment.universeEligible).length,degraded:universe.filter(x=>x.assessment.status==='DEGRADED').length,blocked:universe.filter(x=>x.assessment.status==='BLOCKED').length};
  const persistenceDegraded=!persisted.ok;
  const runtimeError=providerState.providerDegraded?'MARKET_DATA_DEGRADED':persistenceDegraded?'MARKET_DATA_PERSISTENCE_DEGRADED':null;
  return NextResponse.json({ok:true,version:MARKET_DATA_FOUNDATION_VERSION,runtimeVersion:P3_MARKET_RUNTIME_VERSION,summary,universe:rows,providerErrors:providerState.providerErrors,persistence:{ok:persisted.ok,error:persisted.ok?null:persisted.error},degraded:!!runtimeError,noOrderAction:!!runtimeError,mode:'READ_ONLY_INTELLIGENCE',executionAllowed:false,contract:{executionAllowed:false,noOrderSigning:true,noOrderSubmission:true,noRouterAuthorization:true},recovery:runtimeError?marketDegradedPayload(runtimeError):null},{headers:{'Cache-Control':'no-store'}});
 }catch(e){const status=authStatus(e);if(status===401||status===403)return NextResponse.json({ok:false,error:status===401?'AUTH_REQUIRED':'FORBIDDEN'},{status});return NextResponse.json({ok:true,...marketDegradedPayload('MARKET_DATA_UNAVAILABLE',e),version:MARKET_DATA_FOUNDATION_VERSION,runtimeVersion:P3_MARKET_RUNTIME_VERSION,summary:{inventory:0,canonical:0,eligible:0,degraded:0,blocked:0},universe:[],providerErrors:[sanitizeProviderError(e)],mode:'READ_ONLY_INTELLIGENCE'},{status:200,headers:{'Cache-Control':'no-store'}});}
}
