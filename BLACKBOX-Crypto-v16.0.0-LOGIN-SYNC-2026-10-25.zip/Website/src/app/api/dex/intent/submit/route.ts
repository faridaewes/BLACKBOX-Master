import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireVerifiedSession, authStatus, apiError } from '@/lib/auth';
import { submitDexIntent } from '@/lib/dex-execution';
const schema=z.object({intentId:z.string(),walletAddress:z.string().min(20),signature:z.string().optional(),txHash:z.string().min(20),approvalTxHash:z.string().min(20).optional()});
export async function POST(req:Request){try{const s=await requireVerifiedSession();const b=schema.parse(await req.json());const r=await submitDexIntent({userId:s.userId,...b});return NextResponse.json({ok:true,intent:r});}catch(e){return NextResponse.json({ok:false,error:e instanceof z.ZodError?'INPUT_INVALID':apiError(e)},{status:e instanceof z.ZodError?400:authStatus(e)});}}
