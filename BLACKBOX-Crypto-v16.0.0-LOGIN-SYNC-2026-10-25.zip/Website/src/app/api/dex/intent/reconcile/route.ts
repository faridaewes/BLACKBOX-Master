import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireVerifiedSession, authStatus, apiError } from '@/lib/auth';
import { reconcileDexIntent } from '@/lib/dex-execution';
const schema=z.object({intentId:z.string()});
export async function POST(req:Request){try{const s=await requireVerifiedSession();const b=schema.parse(await req.json());const row=await import('@/lib/prisma').then(x=>x.db.dexTradeIntent.findFirst({where:{id:b.intentId,userId:s.userId},select:{id:true}}));if(!row)throw new Error('DEX_INTENT_NOT_FOUND');const r=await reconcileDexIntent(b.intentId);return NextResponse.json({ok:true,result:r});}catch(e){return NextResponse.json({ok:false,error:e instanceof z.ZodError?'INPUT_INVALID':apiError(e)},{status:e instanceof z.ZodError?400:authStatus(e)});}}
