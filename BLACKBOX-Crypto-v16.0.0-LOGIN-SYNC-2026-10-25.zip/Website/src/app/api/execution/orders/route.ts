import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { apiError,  requireVerifiedSession, requireMfa, authStatus } from '@/lib/auth';
import { realExecutionReady } from '@/lib/execution-engine';
import { executeRealOrderForUser } from '@/lib/real-execution';
import { recordConsent } from '@/lib/consent';
import { requireCurrentLegalConsent } from '@/lib/legal-registry';

const schema = z.object({
  botId: z.string(), connectionId: z.string(), symbol: z.string().trim().min(3), side: z.enum(['BUY','SELL']), type: z.enum(['market','limit']),
  quantity: z.number().positive().finite(), price: z.number().positive().finite().optional(), signalId: z.string()
});

export async function GET(req: Request) {
  try {
    const s = await requireVerifiedSession(); const u = new URL(req.url), botId = u.searchParams.get('botId');
    const where: any = { userId: s.userId }; if (botId) where.botId = botId;
    const rows = await db.execution.findMany({ where, orderBy: { createdAt: 'desc' }, take: 100 });
    return NextResponse.json({ ok: true, executions: rows });
  } catch (e) { return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) }); }
}

export async function POST(req: Request) {
  try {
    const s = await requireVerifiedSession();
    await requireMfa(req);
    await requireCurrentLegalConsent(s.userId,'TRADING_RULES');
    await requireCurrentLegalConsent(s.userId,'CONNECTION_AUTHORIZATION');
    await requireCurrentLegalConsent(s.userId,'ALMA_ADVISOR_REGISTRATION');
    if (!realExecutionReady()) return NextResponse.json({ ok: false, error: 'REAL_TRADING_NOT_READY' }, { status: 423 });
    const b = schema.parse(await req.json());
    const bot = await db.bot.findFirst({ where: { id: b.botId, userId: s.userId } });
    if (!bot) return NextResponse.json({ ok: false, error: 'BOT_NOT_FOUND' }, { status: 404 });
    await recordConsent(req, s.userId, 'REAL_EXECUTION', { botId: b.botId, connectionId: b.connectionId, symbol: b.symbol, side: b.side, quantity: b.quantity, signalId: b.signalId, acknowledgementText:'Saya telah membaca, memahami, dan menyetujui dokumen ini secara sadar, sukarela, dan tanpa paksaan. Saya menerima risiko penggunaan layanan dan keputusan saya serta, sejauh diperbolehkan dan dapat diberlakukan menurut hukum, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan, klaim, atau permintaan ganti rugi sehubungan dengan penggunaan layanan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, konfirmasi, izinkan, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.', consentMethod:'EXPLICIT_CONFIRMATION', readAt:new Date().toISOString() });
    const execution = await executeRealOrderForUser(s.userId, b);
    return NextResponse.json({ ok: true, execution });
  } catch (e) {
    if (e instanceof z.ZodError) return NextResponse.json({ ok: false, error: 'INPUT_INVALID' }, { status: 400 });
    const message = String(e instanceof Error ? e.message : e);
    return NextResponse.json({ ok: false, error: message }, { status: message.startsWith('REAL_') ? 423 : authStatus(e) });
  }
}
