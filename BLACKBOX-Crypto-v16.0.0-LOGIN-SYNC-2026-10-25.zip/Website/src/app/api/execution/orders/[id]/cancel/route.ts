import {NextResponse} from 'next/server';
import {requireVerifiedSession,requireMfa,authStatus} from '@/lib/auth';
import {db} from '@/lib/prisma';
import {cancelExchangeOrder,fetchExchangeOrder} from '@/lib/unified-exchange';

export async function POST(_req:Request,{params}:{params:Promise<{id:string}>}){
 try{
  const s=await requireVerifiedSession(); await requireMfa(_req); const {id}=await params;
  const ex=await db.execution.findFirst({where:{id,userId:s.userId}});
  if(!ex||!ex.externalId||!['ACK','PARTIAL'].includes(ex.status))return NextResponse.json({ok:false,error:'EXECUTION_NOT_CANCELLABLE'},{status:400});
  const bot=await db.bot.findFirst({where:{id:ex.botId,userId:s.userId}});
  if(!bot?.exchangeId)return NextResponse.json({ok:false,error:'EXCHANGE_CONNECTION_REQUIRED'},{status:400});
  const acc=await db.exchangeAccount.findFirst({where:{id:bot.exchangeId,userId:s.userId,status:'CONNECTED'}});
  if(!acc?.encryptedRef)return NextResponse.json({ok:false,error:'EXCHANGE_CONNECTION_REQUIRED'},{status:400});
  await db.execution.update({where:{id},data:{status:'CANCEL_PENDING',cancelRequestedAt:new Date()}});
  try{
   const r=await cancelExchangeOrder(acc.provider,acc.encryptedRef,acc.testnet,ex.externalId,ex.symbol);
   const updated=await db.execution.update({where:{id},data:{status:'CANCELLED',nextAttemptAt:null}});
   await db.order.updateMany({where:{botId:ex.botId,externalId:ex.externalId},data:{status:'CANCELED'}});
   return NextResponse.json({ok:true,remote:r,execution:updated});
  }catch(err){
   // Cancel can race with a fill. Re-read exchange state instead of assuming cancellation succeeded.
   try{
    const remote:any=await fetchExchangeOrder(acc.provider,acc.encryptedRef,acc.testnet,ex.externalId,ex.symbol);
    const rs=String(remote?.status||'').toLowerCase();
    const next=rs==='closed'||rs==='filled'?'FILLED':Number(remote?.filled||0)>0?'PARTIAL':'RECONCILE';
    const updated=await db.execution.update({where:{id},data:{status:next,lastError:next==='RECONCILE'?String(err):null,filledQuantity:Number(remote?.filled||ex.filledQuantity||0),averagePrice:remote?.average??remote?.price??ex.averagePrice}});
    return NextResponse.json({ok:false,error:'CANCEL_RACE_RECONCILE_REQUIRED',execution:updated,remote},{status:409});
   }catch{
    await db.execution.update({where:{id},data:{status:'RECONCILE',lastError:String(err)}}).catch(()=>{});
    return NextResponse.json({ok:false,error:'CANCEL_UNCERTAIN_RECONCILE_REQUIRED'},{status:409});
   }
  }
 }catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)});}
}
