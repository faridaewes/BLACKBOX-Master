import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';
import { requireSession } from '@/lib/auth';

function validHttpsUrl(value: string) {
  try { return new URL(value).protocol === 'https:'; } catch { return false; }
}

export async function GET() {
  await requireSession();
  const configured = process.env.ANDROID_DOWNLOAD_URL || process.env.NEXT_PUBLIC_ANDROID_DOWNLOAD_URL || '';
  let url = configured;
  try {
    const setting = await db.platformSetting.findUnique({ where: { key: 'ANDROID_DOWNLOAD_URL' } });
    url = String(setting?.value || url);
  } catch {
    // Environment remains authoritative if the optional setting cannot be read.
  }
  if (!url || !validHttpsUrl(url)) {
    return NextResponse.json({ ok: false, error: 'ANDROID_DOWNLOAD_NOT_CONFIGURED' }, { status: 503 });
  }
  return NextResponse.redirect(url, 302);
}
