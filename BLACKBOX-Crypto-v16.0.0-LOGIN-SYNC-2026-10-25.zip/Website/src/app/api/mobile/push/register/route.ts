import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { requireSession, authStatus } from '@/lib/auth';

const schema = z.object({
  deviceId: z.string().trim().min(4).max(200),
  platform: z.literal('ANDROID'),
  token: z.string().trim().min(20).max(4096),
  appVersion: z.string().trim().min(1).max(64),
});

export async function POST(req: Request) {
  try {
    const session = await requireSession();
    const body = schema.parse(await req.json());
    const now = new Date();

    // FCM tokens rotate. The device identity is therefore the stable key;
    // the token is the replaceable credential. A token can also migrate
    // between installations, so remove the previous owner inside one
    // transaction before claiming it for the authenticated device.
    const row = await db.$transaction(async (tx) => {
      const existingToken = await tx.pushDevice.findUnique({ where: { token: body.token } });
      if (existingToken && (existingToken.userId !== session.userId || existingToken.deviceId !== body.deviceId)) {
        await tx.pushDevice.delete({ where: { id: existingToken.id } });
      }

      return tx.pushDevice.upsert({
        where: { userId_deviceId: { userId: session.userId, deviceId: body.deviceId } },
        update: {
          token: body.token,
          platform: body.platform,
          appVersion: body.appVersion,
          enabled: true,
          lastSeenAt: now,
        },
        create: {
          userId: session.userId,
          deviceId: body.deviceId,
          platform: body.platform,
          token: body.token,
          appVersion: body.appVersion,
          enabled: true,
          lastSeenAt: now,
        },
      });
    });

    return NextResponse.json({ ok: true, deviceId: row.deviceId, pushEnabled: row.enabled });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: 'PUSH_REGISTRATION_FAILED' },
      { status: authStatus(error) },
    );
  }
}

export async function DELETE(req: Request) {
  try {
    const session = await requireSession();
    const body = z.object({ deviceId: z.string().trim().min(4).max(200) }).parse(await req.json());
    await db.pushDevice.updateMany({
      where: { userId: session.userId, deviceId: body.deviceId },
      data: { enabled: false, lastSeenAt: new Date() },
    });
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: 'PUSH_UNREGISTRATION_FAILED' },
      { status: authStatus(error) },
    );
  }
}
