import { rateLimitUserKey } from '@/lib/rate-limit';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { quotePaper, quoteEvm0x, quoteSolana, evmChainId } from '@/lib/router';
import { bestExecutableRoute, quoteToCandidate } from '@/lib/router-v81';

const schema = z.object({
  inputAmount:z.coerce.number().finite().positive().max(1e12),
  price:z.coerce.number().finite().positive().max(1e12).default(1),
  slippageBps:z.coerce.number().int().min(0).max(5000).default(50),
  chain:z.enum(['solana','ethereum','base','bsc','polygon','arbitrum']).optional(),
  tokenIn:z.string().trim().min(1).max(100).optional(),
  tokenOut:z.string().trim().min(1).max(100).optional(),
  sellAmountBaseUnits:z.string().regex(/^\d+$/).optional(),
  taker:z.string().trim().max(100).optional(),
});

const errorMessage=(e:unknown)=>e instanceof z.ZodError?'INPUT_INVALID':e instanceof Error?e.message:'ROUTER_ERROR';

export async function POST(req:Request){
  try{
    const s=await requireVerifiedSession();
    const rl=await distributedRateLimit(rateLimitUserKey(s.userId, "router-quote-v81"),30,60);
    if(!rl.ok)return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429,headers:{'Retry-After':String(rl.retryAfterSec)}});
    const len=Number(req.headers.get('content-length')||0);if(len>32_768) return NextResponse.json({ok:false,error:'REQUEST_TOO_LARGE'},{status:413});
    const b=schema.parse(await req.json());
    const mode=(process.env.ROUTER_MODE||'paper').toLowerCase();
    if(!['paper','live','compare'].includes(mode)) return NextResponse.json({ok:false,error:'INVALID_ROUTER_MODE'},{status:400});
    if(mode==='paper'){
      const quote=await quotePaper(b.inputAmount,b.price,b.slippageBps);
      const ranked=bestExecutableRoute([quoteToCandidate(quote,{venue:'DEX',marketType:'DEX'})]);
      return NextResponse.json({ok:true,version:'8.1.0',mode,quote,route:ranked,executionAllowed:false});
    }
    if(!b.chain||!b.tokenIn||!b.tokenOut) throw new Error('ROUTER_LIVE_PARAMS_REQUIRED');
    const amount=b.sellAmountBaseUnits || (Number.isSafeInteger(b.inputAmount)?String(b.inputAmount):'');
    if(!amount) throw new Error('BASE_UNIT_AMOUNT_REQUIRED');
    const quote=b.chain==='solana'
      ? await quoteSolana({inputMint:b.tokenIn,outputMint:b.tokenOut,amount,slippageBps:b.slippageBps})
      : await quoteEvm0x({chainId:evmChainId(b.chain),sellToken:b.tokenIn,buyToken:b.tokenOut,sellAmount:amount,taker:b.taker});
    const ranked=bestExecutableRoute([quoteToCandidate(quote,{venue:'DEX',marketType:'DEX'})]);
    return NextResponse.json({ok:true,version:'8.1.0',mode,quote,route:ranked,executionAllowed:false});
  }catch(e){
    const msg=errorMessage(e);
    const status=e instanceof z.ZodError?400:authStatus(e);
    const providerError=/ROUTER_PROVIDER|ZEROX_API_KEY|UNSUPPORTED_|INVALID_|BASE_UNIT|LIVE_PARAMS/.test(msg);
    return NextResponse.json({ok:false,error:msg},{status:status===400?400:providerError?502:status});
  }
}
