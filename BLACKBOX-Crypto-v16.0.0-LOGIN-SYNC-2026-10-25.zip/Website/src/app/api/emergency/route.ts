import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { NextResponse } from "next/server";
import { CONFIRM, getFlags, stopAllBots, revokeAllExchangeConnections, liftGlobalHalt, liftApiRevoke, setMaintenance, getMaintenanceDraft, saveMaintenanceDraft } from "@/lib/emergency";
import { authStatus } from "@/lib/auth";

export async function GET(){
  try { await requirePermissionSession(PERMISSIONS.MAINTENANCE_MANAGE); return NextResponse.json({ok:true,...(await getFlags()),maintenanceDraft:await getMaintenanceDraft()}); }
  catch(e){ return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)}); }
}

export async function POST(req:Request){
  try {
    const b=await req.json();
    const action=String(b.action||'');
    if(action==='SET_MAINTENANCE'){
      const s=await requirePermissionSession(PERMISSIONS.MAINTENANCE_MANAGE);
      const on=b.on===true;
      if (b.draft) await saveMaintenanceDraft(s.userId, b.draft);
      const need=on?CONFIRM.START_MAINTENANCE:CONFIRM.STOP_MAINTENANCE;
      if(String(b.confirm||'').trim()!==need)return NextResponse.json({ok:false,error:`Ketik persis: ${need}`},{status:400});
      const result=await setMaintenance(s.userId,on,b.draft);
      return NextResponse.json({ok:true,...result});
    }
    const need=(CONFIRM as Record<string,string>)[action];
    if(!need)return NextResponse.json({ok:false,error:'UNKNOWN_ACTION'},{status:400});
    const s=await requirePermissionSession(PERMISSIONS.GLOBAL_KILL_SWITCH);
    if(String(b.confirm||'').trim()!==need)return NextResponse.json({ok:false,error:`Ketik persis: ${need}`},{status:400});
    if(action==='STOP_ALL_BOTS')return NextResponse.json({ok:true,affected:await stopAllBots(s.userId)});
    if(action==='GLOBAL_API_REVOKE')return NextResponse.json({ok:true,affected:await revokeAllExchangeConnections(s.userId)});
    if(action==='LIFT_GLOBAL_HALT')return NextResponse.json({ok:true,affected:await liftGlobalHalt(s.userId)});
    await liftApiRevoke(s.userId); return NextResponse.json({ok:true,affected:0});
  }catch(e){ return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)}); }
}
