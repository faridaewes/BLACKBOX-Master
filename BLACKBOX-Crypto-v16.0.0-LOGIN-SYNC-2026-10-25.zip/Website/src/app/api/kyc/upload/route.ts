import { NextResponse } from 'next/server';
import { requireSession, authStatus } from '@/lib/auth';
import { db } from '@/lib/prisma';
import { recordConsentWithTx } from '@/lib/consent';
import { deleteKycDocument, storeKycDocument } from '@/lib/kyc-storage';

export async function POST(req:Request){
  let storageRef:string|undefined;
  try{
    const s=await requireSession();
    const contentLength=Number(req.headers.get('content-length')||0);
    if(contentLength>11*1024*1024)return NextResponse.json({ok:false,error:'KYC_REQUEST_TOO_LARGE'},{status:413});
    const form=await req.formData();
    const file=form.get('file');
    const type=String(form.get('type')||'IDENTITY').trim().toUpperCase();
    if(!['IDENTITY','ADDRESS','SELFIE','OTHER'].includes(type))return NextResponse.json({ok:false,error:'KYC_DOCUMENT_TYPE_INVALID'},{status:400});
    if(!(file instanceof File))return NextResponse.json({ok:false,error:'FILE_REQUIRED'},{status:400});
    storageRef=await storeKycDocument(s.userId,file);
    const doc=await db.$transaction(async tx=>{
      const user=await tx.user.findUnique({where:{id:s.userId},select:{id:true,name:true,email:true}});
      if(!user) throw new Error('USER_NOT_FOUND');
      await tx.user.update({where:{id:s.userId},data:{kycStatus:'PENDING'}});
      await tx.auditLog.create({data:{actorId:s.userId,action:'KYC_DOCUMENT_UPLOADED',targetType:'USER',targetId:s.userId,metadata:{type,mimeType:file.type,size:file.size}}});
      const doc=await tx.kycDocument.create({data:{userId:s.userId,type,storageRef:storageRef!,mimeType:file.type,status:'PENDING'}});
      await recordConsentWithTx(tx,req,user,'KYC_DOCUMENT_UPLOAD',{type,mimeType:file.type,size:file.size});
      return doc;
    });
    return NextResponse.json({ok:true,documentId:doc.id,status:'PENDING'});
  }catch(e){
    if(storageRef) await deleteKycDocument(storageRef).catch(()=>{});
    return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)});
  }
}
