import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { apiError,  requireSession, authStatus } from '@/lib/auth';

export async function GET(req: Request) {
  try {
    const s = await requireSession();
    const url = new URL(req.url);
    const limit = Math.min(50, Math.max(1, Number(url.searchParams.get('limit') || 20)));
    const [notifications, unread] = await Promise.all([
      db.notification.findMany({ where: { userId: s.userId }, orderBy: { createdAt: 'desc' }, take: limit }),
      db.notification.count({ where: { userId: s.userId, readAt: null } }),
    ]);
    return NextResponse.json({ ok: true, unread, notifications });
  } catch (e) {
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}

export async function PATCH(req: Request) {
  try {
    const s = await requireSession();
    const body = z.object({ id: z.string().optional(), all: z.boolean().optional() }).parse(await req.json());
    if (body.all) {
      await db.notification.updateMany({ where: { userId: s.userId, readAt: null }, data: { readAt: new Date() } });
    } else if (body.id) {
      await db.notification.updateMany({ where: { id: body.id, userId: s.userId, readAt: null }, data: { readAt: new Date() } });
    } else {
      return NextResponse.json({ ok: false, error: 'NOTIFICATION_ID_REQUIRED' }, { status: 400 });
    }
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}
