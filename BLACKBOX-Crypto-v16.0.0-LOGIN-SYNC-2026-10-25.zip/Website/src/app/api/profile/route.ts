import { NextResponse } from 'next/server';
import { apiError,  requireSession, authStatus } from '@/lib/auth';
import { getProfileIdentity } from '@/lib/profile';

export async function GET() {
  try {
    const session = await requireSession();
    const profile = await getProfileIdentity(session.userId);
    if (!profile) return NextResponse.json({ ok: false, error: 'PROFILE_NOT_FOUND' }, { status: 404 });
    return NextResponse.json({ ok: true, profile });
  } catch (e) {
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}

export async function PATCH(req:Request) {
  try {
    const session=await requireSession();
    const body=await req.json();
    if(typeof body.telegramChatId!=='string' || body.telegramChatId.trim().length>120) return NextResponse.json({ok:false,error:'TELEGRAM_CHAT_ID_INVALID'},{status:400});
    const value=body.telegramChatId.trim() || null;
    await (await import('@/lib/prisma')).db.user.update({where:{id:session.userId},data:{telegramChatId:value}});
    await (await import('@/lib/prisma')).db.auditLog.create({data:{actorId:session.userId,action:'TELEGRAM_USER_TARGET_UPDATED',targetType:'USER',targetId:session.userId,metadata:{configured:Boolean(value)}}});
    return NextResponse.json({ok:true,telegramChatIdConfigured:Boolean(value)});
  } catch(e) { return NextResponse.json({ok:false,error:'PROFILE_UPDATE_FAILED'},{status:authStatus(e)}); }
}
