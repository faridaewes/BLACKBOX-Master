import { NextResponse } from 'next/server';
import { requireSession, authStatus } from '@/lib/auth';
import { db } from '@/lib/prisma';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

const MAX = 5 * 1024 * 1024;
const MAX_MULTIPART = MAX + 512 * 1024;
const allowed = new Map([['image/jpeg','jpg'],['image/png','png'],['image/webp','webp']]);

function detectImageType(buf: Buffer): 'jpg'|'png'|'webp'|null {
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.length >= 8 && buf.subarray(0,8).equals(Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]))) return 'png';
  if (buf.length >= 12 && buf.subarray(0,4).toString('ascii') === 'RIFF' && buf.subarray(8,12).toString('ascii') === 'WEBP') return 'webp';
  return null;
}

export async function POST(req: Request) {
  try {
    const s = await requireSession();
    const contentLength = Number(req.headers.get('content-length') || 0);
    if (contentLength > MAX_MULTIPART) {
      return NextResponse.json({ok:false,error:'PROFILE_IMAGE_TOO_LARGE'}, {status:413});
    }
    const f = (await req.formData()).get('file');
    if (!(f instanceof File)) return NextResponse.json({ok:false,error:'FILE_REQUIRED'},{status:400});
    if (!allowed.has(f.type) || f.size > MAX) {
      return NextResponse.json({ok:false,error:'PROFILE_IMAGE_INVALID_MAX_5MB_JPG_PNG_WEBP'},{status:400});
    }
    const buf = Buffer.from(await f.arrayBuffer());
    if (buf.length > MAX) return NextResponse.json({ok:false,error:'PROFILE_IMAGE_TOO_LARGE'},{status:413});
    const detected = detectImageType(buf);
    const expected = allowed.get(f.type);
    if (!detected || detected !== expected) {
      return NextResponse.json({ok:false,error:'PROFILE_IMAGE_CONTENT_TYPE_MISMATCH'},{status:400});
    }
    const root = path.resolve(process.env.PUBLIC_UPLOAD_DIR || './public/uploads');
    const dir = path.join(root, 'profile');
    await fs.mkdir(dir,{recursive:true});
    const name = `${s.userId}-${crypto.randomUUID()}.${detected}`;
    const filePath = path.join(dir,name);
    await fs.writeFile(filePath,buf,{flag:'wx'});
    const url = `/uploads/profile/${name}`;
    await db.user.update({where:{id:s.userId},data:{avatarUrl:url}});
    await db.auditLog.create({data:{actorId:s.userId,action:'PROFILE_AVATAR_UPDATED',targetType:'USER',targetId:s.userId,metadata:{url,detectedType:detected,size:buf.length}}});
    return NextResponse.json({ok:true,avatarUrl:url});
  } catch(e) {
    return NextResponse.json({ok:false,error:'PROFILE_AVATAR_UPLOAD_FAILED'},{status:authStatus(e)});
  }
}
