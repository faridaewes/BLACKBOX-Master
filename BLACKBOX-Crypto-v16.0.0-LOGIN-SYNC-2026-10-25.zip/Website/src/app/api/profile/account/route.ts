import { NextResponse } from 'next/server';
import crypto from 'node:crypto';
import { db } from '@/lib/prisma';
import { authStatus, requireSession } from '@/lib/auth';
import { verifyPassword } from '@/lib/auth';

/**
 * Penghapusan permanen akun user:
 * PII/login identifier dianonimkan secara irreversible agar username/email/HP
 * dapat didaftarkan kembali, sementara audit/legal evidence tetap utuh.
 * Ini bukan "soft delete": akses login diputus dan data identitas aktif dihapus.
 */
export async function DELETE(req: Request) {
  try {
    const s = await requireSession();
    if (s.role !== 'USER') return NextResponse.json({ ok:false, error:'ONLY_USER_ACCOUNT' }, { status:403 });
    const body = await req.json().catch(() => ({}));
    const password = String(body.password || '');
    if (!password) return NextResponse.json({ok:false,error:'PASSWORD_REQUIRED'},{status:400});
    const user = await db.user.findUnique({where:{id:s.userId}});
    if (!user || !(await verifyPassword(password,user.passwordHash))) return NextResponse.json({ok:false,error:'PASSWORD_INVALID'},{status:403});

    const now = new Date();
    const tombstone = `deleted-${user.id}-${crypto.randomBytes(8).toString('hex')}`;
    await db.$transaction(async tx => {
      // Hentikan layanan aktif sebelum identitas dinonaktifkan.
      await tx.bot.updateMany({where:{userId:user.id,status:{in:['RUNNING','PAUSED']}},data:{status:'STOPPED',stoppedAt:now}});
      await tx.session.updateMany({where:{userId:user.id,revokedAt:null},data:{revokedAt:now}});
      await tx.user.update({where:{id:user.id},data:{
        email:`${tombstone}@deleted.invalid`,
        phone:`+999${String(Math.abs(user.id.split('').reduce((a,c)=>a+c.charCodeAt(0),0))).padStart(10,'0').slice(0,10)}`,
        username:tombstone.slice(0,24),
        name:'Deleted User',
        passwordHash:crypto.randomBytes(32).toString('hex'),
        status:'DISABLED',
        emailVerifiedAt:null, phoneVerifiedAt:null, mfaEnabled:false, mfaSecretEnc:null,
        telegramChatId:null, avatarUrl:null, referralCode:null, referredById:null,
        hasEverActivated:false, referralPro:false, mustChangePassword:false, sessionVersion:{increment:1}
      }});
      await tx.auditLog.create({data:{actorId:user.id,action:'ACCOUNT_PERMANENTLY_DELETED',targetType:'USER',targetId:user.id,metadata:{irreversible:true,piiAnonymized:true,deletedAt:now.toISOString()}}});
      await tx.userActivityEvent.create({data:{userId:user.id,type:'ACCOUNT_PERMANENTLY_DELETED',metadata:{deletedAt:now.toISOString()}}});
    });
    // File/KYC cleanup is intentionally best-effort here; the database record is
    // already access-blocked. A dedicated retention worker can purge encrypted blobs.
    return NextResponse.json({ok:true,deleted:true});
  } catch(e) {
    return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)});
  }
}
