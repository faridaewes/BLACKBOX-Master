import { requirePermissionSession, PERMISSIONS, hasPermission } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { requireSession, authStatus } from '@/lib/auth';
import {
  SUPPORT_CATEGORIES,
  normalizeCategory,
  resolveGreetingTemplate,
  logSupportWorkActivity,
  teamsForCategory,
} from '@/lib/support-ops';

const create = z.object({
  category: z.string().min(2).max(40),
  priority: z.enum(['LOW', 'NORMAL', 'HIGH', 'URGENT']).default('NORMAL'),
  subject: z.string().min(3).max(120),
  body: z.string().min(5).max(4000),
});
const message = z.object({ ticketId: z.string().min(1), body: z.string().min(1).max(4000) });

async function canAccessTicket(s: any, ticket: any) {
  if (!ticket) return false;
  if (s.role === 'DEVELOPER') return true;
  if (s.role === 'USER') return ticket.userId === s.userId;
  if (await hasPermission(s.userId, PERMISSIONS.SUPPORT_CHAT)) {
    if (ticket.assignedAgentId === s.userId) return true;
    if (ticket.assignedTeamId) {
      return !!(await db.accessTeamMember.findUnique({
        where: { teamId_userId: { teamId: ticket.assignedTeamId, userId: s.userId } },
      }));
    }
    // unassigned queue visible to any support agent
    return true;
  }
  return (
    ticket.userId === s.userId ||
    !!(await db.adminAssignment.findUnique({
      where: { adminId_userId: { adminId: s.userId, userId: ticket.userId } },
    }))
  );
}

export async function GET(req: Request) {
  try {
    const s = await requireSession();
    const url = new URL(req.url);
    const meta = url.searchParams.get('meta');
    if (meta === 'categories') {
      return NextResponse.json({ ok: true, categories: SUPPORT_CATEGORIES });
    }
    if (meta === 'teams') {
      const category = normalizeCategory(url.searchParams.get('category') || 'GENERAL');
      const teams = await teamsForCategory(category);
      return NextResponse.json({ ok: true, category, teams });
    }

    let where: any = s.role === 'USER' ? { userId: s.userId } : {};
    if (s.role === 'ADMIN' && !(await hasPermission(s.userId, PERMISSIONS.SUPPORT_CHAT))) {
      where = {
        userId: {
          in: (await db.adminAssignment.findMany({ where: { adminId: s.userId }, select: { userId: true } })).map(
            (x) => x.userId,
          ),
        },
      };
    }
    if (s.role !== 'USER' && (await hasPermission(s.userId, PERMISSIONS.SUPPORT_CHAT))) {
      const memberships = await db.accessTeamMember.findMany({
        where: { userId: s.userId, team: { active: true, accessKilled: false } },
        select: { teamId: true },
      });
      where = {
        OR: [
          { assignedAgentId: s.userId },
          { assignedTeamId: { in: memberships.map((x) => x.teamId) } },
          { assignedTeamId: null, status: { in: ['OPEN', 'PENDING'] } },
        ],
      };
    }

    const rows = await db.supportTicket.findMany({
      where,
      include: {
        user: { select: { name: true, email: true } },
        handledBy: { select: { name: true } },
        assignedTeam: { select: { id: true, code: true, name: true, supportCategories: true, leadUserId: true } },
        assignedAgent: { select: { id: true, name: true, email: true } },
        transfers: {
          orderBy: { createdAt: 'desc' },
          take: 50,
          include: {
            toTeam: { select: { id: true, name: true, code: true } },
            fromTeam: { select: { id: true, name: true, code: true } },
          },
        },
        messages: {
          orderBy: { createdAt: 'asc' },
          take: 200,
          include: { sender: { select: { id: true, name: true, role: true } } },
        },
      },
      orderBy: { updatedAt: 'desc' },
      take: 200,
    });
    const ticketId = url.searchParams.get('ticketId');
    return NextResponse.json({
      ok: true,
      role: s.role,
      categories: SUPPORT_CATEGORIES,
      tickets: rows.map((t) => ({
        ...t,
        messages: t.messages.map((m) => ({ ...m, mine: m.senderId === s.userId })),
      })),
      selectedTicketId:
        ticketId && rows.some((t) => t.id === ticketId) ? ticketId : rows[0]?.id || null,
    });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'REQUEST_FAILED' }, { status: authStatus(e) });
  }
}

export async function POST(req: Request) {
  try {
    const s = await requireSession();
    const body = await req.json();

    if (body?.action === 'message') {
      const b = message.parse(body);
      const ticket = await db.supportTicket.findUnique({
        where: { id: b.ticketId },
        select: { id: true, userId: true, status: true, assignedTeamId: true, assignedAgentId: true, category: true },
      });
      if (!(await canAccessTicket(s, ticket)))
        return NextResponse.json({ ok: false, error: 'TICKET_NOT_FOUND' }, { status: 404 });
      if (ticket!.status === 'CLOSED')
        return NextResponse.json({ ok: false, error: 'TICKET_CLOSED' }, { status: 409 });

      const m = await db.supportMessage.create({
        data: { ticketId: b.ticketId, senderId: s.userId, body: b.body },
      });
      await db.supportTicket.update({
        where: { id: b.ticketId },
        data: {
          status: s.role === 'USER' ? 'OPEN' : 'IN_PROGRESS',
          handledById: s.role === 'USER' ? undefined : s.userId,
          assignedAgentId:
            s.role === 'USER' ? ticket!.assignedAgentId : ticket!.assignedAgentId || s.userId,
        },
      });
      await db.auditLog.create({
        data: {
          actorId: s.userId,
          action: 'SUPPORT_MESSAGE_SENT',
          targetType: 'SUPPORT_TICKET',
          targetId: b.ticketId,
          metadata: { role: s.role },
        },
      });
      if (s.role !== 'USER') {
        await logSupportWorkActivity({
          userId: s.userId,
          teamId: ticket!.assignedTeamId,
          type: 'SUPPORT_MESSAGE',
          metadata: { ticketId: b.ticketId, category: ticket!.category, targetUserId: ticket!.userId },
        });
      }
      return NextResponse.json({ ok: true, message: m });
    }

    if (body?.action === 'CLAIM') {
      const s2 = await requirePermissionSession(PERMISSIONS.SUPPORT_CHAT);
      const b = z.object({ ticketId: z.string(), teamId: z.string().optional() }).parse(body);
      const ticket = await db.supportTicket.findUnique({
        where: { id: b.ticketId },
        include: { user: { select: { name: true } } },
      });
      if (!ticket) return NextResponse.json({ ok: false, error: 'TICKET_NOT_FOUND' }, { status: 404 });

      let teamId = b.teamId || ticket.assignedTeamId;
      if (!teamId) {
        const memberships = await db.accessTeamMember.findMany({
          where: { userId: s2.userId, team: { active: true, accessKilled: false } },
          select: { teamId: true, team: { select: { name: true } } },
          take: 1,
        });
        teamId = memberships[0]?.teamId || null;
      }
      const team = teamId
        ? await db.accessTeam.findUnique({ where: { id: teamId }, select: { id: true, name: true } })
        : null;
      const agent = await db.user.findUnique({ where: { id: s2.userId }, select: { name: true } });

      const updated = await db.supportTicket.update({
        where: { id: b.ticketId },
        data: {
          assignedAgentId: s2.userId,
          assignedTeamId: teamId,
          handledById: s2.userId,
          status: 'IN_PROGRESS',
          routedAt: new Date(),
        },
      });

      // Auto greeting once when agent first claims
      const priorAgentMsgs = await db.supportMessage.count({
        where: { ticketId: b.ticketId, sender: { role: { in: ['ADMIN', 'DEVELOPER'] } } },
      });
      if (priorAgentMsgs === 0) {
        const greet = await resolveGreetingTemplate(
          agent?.name || 'Petugas Support',
          team?.name || 'Customer Support',
          ticket.user?.name || 'Pengguna',
          normalizeCategory(ticket.category),
        );
        await db.supportMessage.create({
          data: { ticketId: b.ticketId, senderId: s2.userId, body: greet },
        });
      }

      await logSupportWorkActivity({
        userId: s2.userId,
        teamId,
        type: 'SUPPORT_CLAIM',
        metadata: { ticketId: b.ticketId, category: ticket.category, targetUserId: ticket.userId },
      });
      await db.auditLog.create({
        data: {
          actorId: s2.userId,
          action: 'SUPPORT_TICKET_CLAIMED',
          targetType: 'SUPPORT_TICKET',
          targetId: b.ticketId,
          metadata: { teamId },
        },
      });
      return NextResponse.json({ ok: true, ticket: updated });
    }

    // User creates ticket
    const b = create.parse(body);
    const category = normalizeCategory(b.category);
    // Auto-route to a team that handles this category (if any)
    const candidates = await teamsForCategory(category);
    const assignedTeamId = candidates[0]?.id || null;

    const t = await db.supportTicket.create({
      data: {
        userId: s.userId,
        category,
        priority: b.priority,
        subject: b.subject,
        body: b.body,
        assignedTeamId,
        routedAt: assignedTeamId ? new Date() : null,
      },
    });
    await db.supportMessage.create({
      data: { ticketId: t.id, senderId: s.userId, body: b.body },
    });
    // System-style ack to user (from first available system - use user as sender only for their message; optional bot note)
    await db.auditLog.create({
      data: {
        actorId: s.userId,
        action: 'SUPPORT_TICKET_CREATED',
        targetType: 'USER',
        targetId: s.userId,
        metadata: { ticketId: t.id, category, priority: t.priority, assignedTeamId },
      },
    });
    return NextResponse.json({ ok: true, ticket: t });
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: String(e instanceof Error ? e.message : 'REQUEST_FAILED') },
      { status: authStatus(e) },
    );
  }
}

export async function PATCH(req: Request) {
  try {
    const raw = await req.json();

    const action = raw?.action;
    if (action==='TRANSFER') {
      const s = await requirePermissionSession(PERMISSIONS.SUPPORT_TRANSFER);
      const b = z
        .object({
          action: z.literal('TRANSFER'),
          ticketId: z.string(),
          toTeamId: z.string(),
          toAgentId: z.string().nullable().optional(),
          reason: z.string().trim().min(3).max(500),
          category: z.string().optional(),
        })
        .parse(raw);
      const ticket = await db.supportTicket.findUnique({
        where: { id: b.ticketId },
        select: {
          id: true,
          userId: true,
          assignedTeamId: true,
          assignedAgentId: true,
          status: true,
          category: true,
          user: { select: { name: true } },
        },
      });
      if (!ticket) throw new Error('TICKET_NOT_FOUND');
      const team = await db.accessTeam.findUnique({
        where: { id: b.toTeamId },
        select: { id: true, name: true, active: true, accessKilled: true, supportCategories: true },
      });
      if (!team || !team.active || team.accessKilled) throw new Error('TARGET_TEAM_UNAVAILABLE');
      if (b.toAgentId) {
        const m = await db.accessTeamMember.findUnique({
          where: { teamId_userId: { teamId: b.toTeamId, userId: b.toAgentId } },
        });
        if (!m) throw new Error('TARGET_AGENT_NOT_IN_TEAM');
      }
      const newCategory = b.category ? normalizeCategory(b.category) : ticket.category;
      const updated = await db.$transaction(async (tx) => {
        const t = await tx.supportTicket.update({
          where: { id: b.ticketId },
          data: {
            assignedTeamId: b.toTeamId,
            assignedAgentId: b.toAgentId || null,
            category: newCategory,
            routedAt: new Date(),
            status: 'IN_PROGRESS',
            handledById: s.userId,
          },
        });
        await tx.supportTicketTransfer.create({
          data: {
            ticketId: b.ticketId,
            fromTeamId: ticket.assignedTeamId,
            toTeamId: b.toTeamId,
            fromAgentId: ticket.assignedAgentId,
            toAgentId: b.toAgentId || null,
            reason: b.reason,
            createdById: s.userId,
          },
        });
        await tx.supportMessage.create({
          data: {
            ticketId: b.ticketId,
            senderId: s.userId,
            body: `[TRANSFER] Tiket dialihkan ke tim ${team.name}${b.toAgentId ? ' (petugas spesifik)' : ''}. Alasan: ${b.reason}`,
          },
        });
        await tx.auditLog.create({
          data: {
            actorId: s.userId,
            action: 'SUPPORT_TICKET_TRANSFERRED',
            targetType: 'SUPPORT_TICKET',
            targetId: b.ticketId,
            metadata: {
              fromTeamId: ticket.assignedTeamId,
              toTeamId: b.toTeamId,
              toAgentId: b.toAgentId || null,
              reason: b.reason,
              category: newCategory,
            },
          },
        });
        return t;
      });
      await logSupportWorkActivity({
        userId: s.userId,
        teamId: ticket.assignedTeamId,
        type: 'SUPPORT_TRANSFER',
        metadata: {
          ticketId: b.ticketId,
          toTeamId: b.toTeamId,
          category: newCategory,
          targetUserId: ticket.userId,
          reason: b.reason,
        },
      });
      return NextResponse.json({ ok: true, ticket: updated });
    }

    const s = await requirePermissionSession(PERMISSIONS.SUPPORT_CHAT);
    const b = z
      .object({
        ticketId: z.string(),
        status: z.enum(['OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED']),
      })
      .parse(raw);
    const ticket = await db.supportTicket.findUnique({
      where: { id: b.ticketId },
      select: { id: true, userId: true, assignedTeamId: true, assignedAgentId: true, category: true },
    });
    if (!ticket) return NextResponse.json({ ok: false, error: 'TICKET_NOT_FOUND' }, { status: 404 });
    if (!(await canAccessTicket(s, ticket)))
      return NextResponse.json(
        { ok: false, error: s.role === 'ADMIN' ? 'USER_NOT_ASSIGNED_TO_ADMIN' : 'TICKET_ACCESS_DENIED' },
        { status: 403 },
      );

    const t = await db.supportTicket.update({
      where: { id: b.ticketId },
      data: { status: b.status, handledById: s.userId },
    });
    if (b.status === 'CLOSED' || b.status === 'RESOLVED') {
      await db.supportMessage.create({
        data: {
          ticketId: b.ticketId,
          senderId: s.userId,
          body:
            b.status === 'CLOSED'
              ? '[SISTEM] Obrolan ditutup oleh petugas. Terima kasih telah menghubungi BLACKBOX Support. Jika masih ada kendala, silakan buka tiket baru.'
              : '[SISTEM] Tiket ditandai RESOLVED oleh petugas. Anda dapat membalas lagi bila masalah berlanjut, atau tutup tiket.',
        },
      });
    }
    await db.auditLog.create({
      data: {
        actorId: s.userId,
        action: 'SUPPORT_TICKET_UPDATED',
        targetType: 'USER',
        targetId: ticket.userId,
        metadata: { ticketId: t.id, status: b.status, category: ticket.category },
      },
    });
    await logSupportWorkActivity({
      userId: s.userId,
      teamId: ticket.assignedTeamId,
      type: b.status === 'CLOSED' ? 'SUPPORT_CLOSE' : 'SUPPORT_STATUS',
      metadata: { ticketId: t.id, status: b.status, targetUserId: ticket.userId, category: ticket.category },
    });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'REQUEST_FAILED' }, { status: authStatus(e) });
  }
}
