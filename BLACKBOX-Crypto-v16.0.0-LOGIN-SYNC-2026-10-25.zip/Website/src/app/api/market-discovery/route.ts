import { rateLimitUserKey } from '@/lib/rate-limit';
import { NextResponse } from 'next/server';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { getEntitlements } from '@/lib/entitlements';
import { db } from '@/lib/prisma';
import { discoverCexMarkets, discoverDexMarkets, filterAndSortDiscovery, MARKET_DISCOVERY_VERSION, normalizeDiscoveryQuery, type MarketRegistryRecord } from '@/lib/market-discovery-v82';
import { discoverExhaustiveCexUniverse, MARKET_DATA_RUNTIME_P3_VERSION } from '@/lib/market-data-runtime-v118-p3';
import { P4_MARKET_RUNTIME_VERSION, p4DegradedPayload, safeP4Persistence } from '@/lib/market-runtime-resilience-v1181-p4';

const ALLOWED_CHAINS = new Set(['all','solana','base','bsc','ethereum','arbitrum','polygon','avalanche']);
const redact = (e: unknown) => e instanceof Error ? e.message.replace(/https?:\/\/\S+/gi, '[provider]').slice(0,180) : 'DISCOVERY_PROVIDER_ERROR';

async function persist(rows: MarketRegistryRecord[]) {
  let persisted = 0;
  for (let i=0;i<rows.length;i+=250) {
    const batch=rows.slice(i,i+250);
    await db.$transaction(batch.map(r=>db.marketRegistry.upsert({
      where:{marketKey:r.marketKey},
      create:{...r,canonicalSymbol:String((r.metadata as any)?.canonicalSymbol||`${r.baseAsset}/${r.quoteAsset}`),settlementAsset:((r.metadata as any)?.settlementAsset as string|null)||null,instrumentType:((r.metadata as any)?.instrumentType as string|null)||null,contractKind:((r.metadata as any)?.contractKind as string|null)||null,metadata:r.metadata},
      update:{provider:r.provider,marketType:r.marketType,venue:r.venue,symbol:r.symbol,canonicalSymbol:String((r.metadata as any)?.canonicalSymbol||`${r.baseAsset}/${r.quoteAsset}`),settlementAsset:((r.metadata as any)?.settlementAsset as string|null)||null,instrumentType:((r.metadata as any)?.instrumentType as string|null)||null,contractKind:((r.metadata as any)?.contractKind as string|null)||null,baseAsset:r.baseAsset,quoteAsset:r.quoteAsset,chain:r.chain,contractAddress:r.contractAddress,status:r.status,active:r.active,tickSize:r.tickSize,stepSize:r.stepSize,minOrder:r.minOrder,lastSeenAt:new Date(r.lastSeenAt),dataQuality:r.dataQuality,source:r.source,metadata:r.metadata}
    })));
    persisted += batch.length;
  }
  return persisted;
}

export async function GET(req: Request) {
  try {
    const session = await requireVerifiedSession();
    const rl = await distributedRateLimit(rateLimitUserKey(session.userId, "market-discovery-v82"), 6, 60);
    if (!rl.ok) return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429,headers:{'Retry-After':String(rl.retryAfterSec)}});
    const u = new URL(req.url);
    const query = normalizeDiscoveryQuery({ provider:u.searchParams.get('provider')||'binance', marketType:u.searchParams.get('marketType')||'SPOT', chain:u.searchParams.get('chain')||'all', q:u.searchParams.get('q')||'', limit:u.searchParams.get('limit')||500 });
    if (!ALLOWED_CHAINS.has(query.chain)) return NextResponse.json({ok:false,error:'INVALID_CHAIN'},{status:400});
    const ent = await getEntitlements(session.userId, session.role);
    if (!ent.marketTypes.includes(query.marketType) && query.marketType !== 'DEX') return NextResponse.json({ok:false,error:'MARKET_TYPE_NOT_ENTITLED'},{status:403});

    let rows: MarketRegistryRecord[] = [];
    let providerError: string | null = null;
    let p3Coverage: any = null;
    let p3Heartbeats: any[] = [];
    try {
      if (query.marketType !== 'DEX' && query.provider === 'all') {
        const exhaustive = await discoverExhaustiveCexUniverse(query.marketType, undefined, Number(process.env.MARKET_DATA_EXHAUSTIVE_TIMEOUT_MS || 15000));
        rows = exhaustive.rows as MarketRegistryRecord[];
        p3Coverage = exhaustive.coverage;
        p3Heartbeats = exhaustive.heartbeats;
      } else {
        rows = query.marketType === 'DEX' ? await discoverDexMarkets(query.chain === 'all' ? ['solana','base','bsc','ethereum'] : [query.chain]) : await discoverCexMarkets(query.provider, query.marketType);
      }
    } catch (e) { providerError = redact(e); }
    const filtered = filterAndSortDiscovery(rows, query);
    let persisted = 0;
    try { persisted = await persist(filtered); } catch { /* fail-open for read-only discovery; never enable execution */ }
    return NextResponse.json({ok:true,version:MARKET_DISCOVERY_VERSION,runtimeVersion:P4_MARKET_RUNTIME_VERSION,mode:'DISCOVERY_ONLY',executionAllowed:false,provider:query.provider,marketType:query.marketType,inventory:rows.length,returned:filtered.length,persisted,providerError,rows:filtered,contract:{allMarketsMeans:'all active markets exposed by the selected provider/API, subject to provider rate limits and permissions',executionAllowed:false}}, {headers:{'Cache-Control':'no-store'} });
  } catch(e) { return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)}); }
}

export async function POST(req: Request) {
  try {
    const session = await requireVerifiedSession();
    if (session.role !== 'DEVELOPER' && session.role !== 'ADMIN') return NextResponse.json({ok:false,error:'ADMIN_REQUIRED'},{status:403});
    const rl = await distributedRateLimit(rateLimitUserKey(session.userId, "admin:market-discovery-refresh-v82"), 2, 60);
    if (!rl.ok) return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429});
    const body = await req.json().catch(()=>({}));
    const marketType = String(body?.marketType||'SPOT').toUpperCase();
    const provider = String(body?.provider||'binance').toLowerCase();
    const chain = String(body?.chain||'all').toLowerCase();
    if (!['SPOT','FUTURES','DEX'].includes(marketType)) return NextResponse.json({ok:false,error:'INVALID_MARKET_TYPE'},{status:400});
    if (!ALLOWED_CHAINS.has(chain)) return NextResponse.json({ok:false,error:'INVALID_CHAIN'},{status:400});
    let rows: MarketRegistryRecord[] = [];
    let providerError: string | null = null;
    try { rows = marketType === 'DEX' ? await discoverDexMarkets(chain==='all'?['solana','base','bsc','ethereum']:[chain]) : await discoverCexMarkets(provider,marketType as 'SPOT'|'FUTURES'); }
    catch(e) { providerError = redact(e); }
    const filtered = filterAndSortDiscovery(rows,{limit:5000});
    const persistedResult = await safeP4Persistence(()=>persist(filtered));
    const persisted = persistedResult.ok ? persistedResult.value : 0;
    const persistenceError = persistedResult.ok ? null : persistedResult.error;
    const degraded = Boolean(providerError) || !persistedResult.ok;
    return NextResponse.json({ok:true,version:MARKET_DISCOVERY_VERSION,runtimeVersion:P4_MARKET_RUNTIME_VERSION,refreshed:filtered.length,persisted,providerError,persistence:{ok:persistedResult.ok,error:persistenceError},executionAllowed:false,recovery:degraded?{...p4DegradedPayload(providerError?'MARKET_DATA_DEGRADED':'MARKET_DATA_PERSISTENCE_DEGRADED',providerError||persistenceError)}:null});
  } catch(e) { const status=authStatus(e); if(status===401||status===403)return NextResponse.json({ok:false,error:status===401?'AUTH_REQUIRED':'FORBIDDEN'},{status}); return NextResponse.json({ok:true,...p4DegradedPayload('MARKET_DATA_UNAVAILABLE',e),version:MARKET_DISCOVERY_VERSION,runtimeVersion:P4_MARKET_RUNTIME_VERSION,mode:'DISCOVERY_ONLY',inventory:0,returned:0,persisted:0,rows:[],contract:{executionAllowed:false}},{status:200,headers:{'Cache-Control':'no-store'}}); }
}
