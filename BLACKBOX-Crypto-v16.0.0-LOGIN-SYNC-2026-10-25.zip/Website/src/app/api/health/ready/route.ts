import { NextResponse } from 'next/server';
import { getHealthCenterSnapshot } from '@/lib/health-center';

export const dynamic = 'force-dynamic';

export async function GET() {
  const health = await getHealthCenterSnapshot();
  const ready = health.overall !== 'FAILED' && health.components.some(x => x.id === 'database' && x.state === 'HEALTHY');
  return NextResponse.json({ ok: ready, status: ready ? 'ready' : 'not_ready', health }, { status: ready ? 200 : 503, headers: { 'cache-control': 'no-store' } });
}
