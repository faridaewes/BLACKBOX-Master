import { NextResponse } from 'next/server';
import { getRuntimeSnapshot } from '@/lib/deployment-intelligence';
import { requireDeveloper } from '@/lib/access-control';
import { authStatus } from '@/lib/auth';
export const dynamic='force-dynamic';
export async function GET(request: Request) {
  try { await requireDeveloper(); } catch(e) { return NextResponse.json({ok:false,error:'DEVELOPER_ACCESS_REQUIRED'},{status:authStatus(e)}); }
  const origin = request.headers.get('origin') || request.headers.get('referer') || undefined;
  return NextResponse.json({ ok:true, runtime:getRuntimeSnapshot(origin), recoveryGate:process.env.RECOVERY_GATE_REQUIRED !== 'false' ? 'REQUIRED' : 'OPTIONAL' }, { headers:{'cache-control':'no-store'} });
}
