import { NextResponse } from 'next/server';
import { getHealthCenterSnapshot } from '@/lib/health-center';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
  const health = await getHealthCenterSnapshot();
  const workerHealthy = health.components.find(x => x.id === 'worker')?.state === 'HEALTHY';
  const workerStatus = workerHealthy?'healthy':'degraded';
  const status = health.overall === 'HEALTHY' ? 'healthy' : health.overall === 'DEGRADED' ? 'degraded' : 'unhealthy';
  const healthyResponse = {status:200};
  return NextResponse.json({
    ok: health.overall !== 'FAILED',
    status,
    database: health.components.find(x => x.id === 'database')?.state === 'HEALTHY' ? 'ok' : 'error',
    worker: workerStatus === 'healthy' ? 'ok' : 'stale',
    score: health.score,
    components: health.components,
    recovery: health.recovery,
    timestamp: health.generatedAt,
  }, health.overall === 'FAILED' ? { status: 503, headers: { 'cache-control': 'no-store' } } : { ...healthyResponse, headers: { 'cache-control': 'no-store' } });
  } catch {
    return NextResponse.json({ ok:false, status:'degraded', error:'HEALTH_SNAPSHOT_UNAVAILABLE', message:'Status sistem sementara tidak dapat dibaca. Aplikasi tetap berjalan dalam safe mode.', recovery:{tradingAuthorization:'LOCKED_UNTIL_EXPLICIT_CERTIFICATION'} }, { status:503, headers:{'cache-control':'no-store'} });
  }
}
