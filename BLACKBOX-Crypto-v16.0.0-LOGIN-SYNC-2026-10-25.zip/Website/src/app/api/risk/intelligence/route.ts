import { NextResponse } from 'next/server';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { getUserRiskIntelligence, persistRiskIntelligence } from '@/lib/risk-intelligence-v74';

export async function GET(req:Request){
  try{
    const s=await requireVerifiedSession();
    const u=new URL(req.url); const regime=u.searchParams.get('regime')||undefined; const quality=Number(u.searchParams.get('quality')); const ai=Number(u.searchParams.get('aiScore'));
    return NextResponse.json({ok:true,risk:await getUserRiskIntelligence(s.userId,{regime,qualityScore:Number.isFinite(quality)?quality:undefined,aiScore:Number.isFinite(ai)?ai:undefined})},{headers:{'cache-control':'no-store'}});
  }catch(e){return NextResponse.json({ok:false,error:'RISK_INTELLIGENCE_UNAVAILABLE'},{status:authStatus(e)})}
}
export async function POST(req:Request){
  try{
    const s=await requireVerifiedSession(); const body=await req.json().catch(()=>({}));
    return NextResponse.json({ok:true,...await persistRiskIntelligence(s.userId,{regime:String(body?.regime||'UNKNOWN'),qualityScore:Number(body?.qualityScore||75),aiScore:Number(body?.aiScore||75)})});
  }catch(e){return NextResponse.json({ok:false,error:'RISK_INTELLIGENCE_SNAPSHOT_FAILED'},{status:authStatus(e)})}
}
