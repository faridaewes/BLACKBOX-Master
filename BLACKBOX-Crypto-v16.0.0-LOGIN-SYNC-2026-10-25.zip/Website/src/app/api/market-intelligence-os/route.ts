import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireVerifiedSession } from '@/lib/auth';
import { buildMarketIntelligenceOs } from '@/lib/market-intelligence-os-v90';
const schema=z.object({marketKey:z.string().trim().min(1).max(200)});
export async function POST(req:Request){
  try{const session=await requireVerifiedSession(); const input=schema.parse(await req.json()); const result=await buildMarketIntelligenceOs(session.userId,input.marketKey); return NextResponse.json({ok:true,mode:'READ_ONLY_MARKET_INTELLIGENCE_OS',executionAllowed:false,result},{headers:{'cache-control':'no-store'}})}
  catch(e){if(e instanceof z.ZodError)return NextResponse.json({ok:false,error:'INPUT_TIDAK_VALID'},{status:400}); const msg=String(e instanceof Error?e.message:e); const status=msg==='MARKET_EVIDENCE_NOT_FOUND'?404:msg==='MARKET_KEY_REQUIRED'?400:msg.includes('AUTH')?401:500; return NextResponse.json({ok:false,error:status===500?'MARKET_INTELLIGENCE_OS_FAILED':msg},{status,headers:{'cache-control':'no-store'}})}
}
export async function GET(req:Request){
  try{const session=await requireVerifiedSession(); const key=new URL(req.url).searchParams.get('marketKey')||''; const input=schema.parse({marketKey:key}); const result=await buildMarketIntelligenceOs(session.userId,input.marketKey); return NextResponse.json({ok:true,mode:'READ_ONLY_MARKET_INTELLIGENCE_OS',executionAllowed:false,result},{headers:{'cache-control':'no-store'}})}
  catch(e){if(e instanceof z.ZodError)return NextResponse.json({ok:false,error:'MARKET_KEY_REQUIRED'},{status:400}); const msg=String(e instanceof Error?e.message:e); return NextResponse.json({ok:false,error:msg==='MARKET_EVIDENCE_NOT_FOUND'?'MARKET_EVIDENCE_NOT_FOUND':'MARKET_INTELLIGENCE_OS_FAILED'},{status:msg==='MARKET_EVIDENCE_NOT_FOUND'?404:500,headers:{'cache-control':'no-store'}})}
}
