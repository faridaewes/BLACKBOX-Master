import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';
import { requireSession, authStatus } from '@/lib/auth';
import { MAX_REFERRAL_DEPTH } from '@/lib/referral-reward-v91';

export async function GET() {
  try {
    const s = await requireSession();
    const rows = await db.$queryRaw<any[]>`
      WITH RECURSIVE network AS (
        SELECT u."id" AS "rootId", u."id" AS "memberId", 0 AS "level"
        FROM "User" u WHERE u."id" = ${s.userId}
        UNION ALL
        SELECT n."rootId", child."id", n."level" + 1
        FROM network n
        JOIN "User" child ON child."referredById" = n."memberId"
        WHERE n."level" < ${MAX_REFERRAL_DEPTH}
      ), latest_tier AS (
        SELECT DISTINCT ON (s."userId") s."userId", p."name" AS "tierName", s."expiresAt"
        FROM "Subscription" s
        JOIN "AccessPlan" p ON p."id" = s."planId"
        WHERE s."status" = 'ACTIVE' AND s."expiresAt" > NOW()
        ORDER BY s."userId", s."expiresAt" DESC
      )
      SELECT n."level", u."id", u."username", u."name", u."status" AS "userStatus",
             u."hasEverActivated", u."referralPro", u."createdAt",
             COALESCE(lt."tierName", 'NONE') AS "tierName", lt."expiresAt" AS "tierExpiresAt"
      FROM network n
      JOIN "User" u ON u."id" = n."memberId"
      LEFT JOIN latest_tier lt ON lt."userId" = u."id"
      WHERE n."level" > 0
      ORDER BY n."level" ASC, u."createdAt" ASC, u."username" ASC
    `;

    const levels = Array.from({ length: MAX_REFERRAL_DEPTH }, (_, i) => ({ level: i + 1, members: 0 }));
    for (const r of rows) levels[r.level - 1].members++;
    return NextResponse.json({
      ok: true,
      depth: MAX_REFERRAL_DEPTH,
      totalMembers: rows.length,
      levels,
      members: rows,
      generatedAt: new Date().toISOString(),
    }, { headers: { 'cache-control': 'no-store' } });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'REFERRAL_NETWORK_UNAVAILABLE' }, { status: authStatus(e) });
  }
}
