import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';
import { MAX_REFERRAL_DEPTH } from '@/lib/referral-reward-v91';

const LIMIT = 100; // LIMIT 100 public rows per category

function pct(current: number, previous: number) {
  if (previous === 0) return current > 0 ? 100 : 0;
  return Math.round(((current - previous) / previous) * 10000) / 100;
}

function rank(rows: any[], metric: string, direction: 'desc' | 'asc' = 'desc') {
  return [...rows]
    .sort((a, b) => {
      const av = Number(a[metric] ?? 0), bv = Number(b[metric] ?? 0);
      if (av !== bv) return direction === 'desc' ? bv - av : av - bv;
      const ad = Number(a.directCount ?? 0), bd = Number(b.directCount ?? 0);
      if (ad !== bd) return bd - ad;
      const aq = Number(a.qualifiedNetwork ?? 0), bq = Number(b.qualifiedNetwork ?? 0);
      if (aq !== bq) return bq - aq;
      return String(a.username).localeCompare(String(b.username));
    })
    .slice(0, LIMIT)
    .map((row, i) => ({ rank: i + 1, ...row }));
}

export async function GET() {
  try {
    const rows = await db.$queryRaw<any[]>`
      WITH RECURSIVE walk AS (
        SELECT child."id" AS "memberId", parent."id" AS "ancestorId", 1 AS "level"
        FROM "User" child
        JOIN "User" parent ON parent."id" = child."referredById"
        UNION ALL
        SELECT w."memberId", parent."id", w."level" + 1
        FROM walk w
        JOIN "User" child ON child."id" = w."ancestorId"
        JOIN "User" parent ON parent."id" = child."referredById"
        WHERE w."level" < ${MAX_REFERRAL_DEPTH}
      ), latest_tier AS (
        SELECT DISTINCT ON (s."userId") s."userId", p."name" AS "tierName", s."expiresAt"
        FROM "Subscription" s JOIN "AccessPlan" p ON p."id" = s."planId"
        WHERE s."status" = 'ACTIVE' AND s."expiresAt" > NOW()
        ORDER BY s."userId", s."expiresAt" DESC
      ), member_state AS (
        SELECT w."ancestorId" AS "userId", w."memberId", w."level", u."createdAt", u."status" AS "memberStatus",
               u."hasEverActivated", u."kycStatus", (lt."userId" IS NOT NULL) AS "hasActiveTier"
        FROM walk w
        JOIN "User" u ON u."id" = w."memberId"
        LEFT JOIN latest_tier lt ON lt."userId" = u."id"
      ), agg AS (
        SELECT "userId",
          COUNT(*)::int AS "networkSize",
          COUNT(*) FILTER (WHERE "level" = 1)::int AS "directCount",
          COUNT(*) FILTER (WHERE "hasEverActivated" = TRUE AND "kycStatus" = 'APPROVED')::int AS "qualifiedNetwork",
          COUNT(*) FILTER (WHERE "memberStatus" = 'ACTIVE')::int AS "activeNetwork",
          COUNT(*) FILTER (WHERE "hasActiveTier" = TRUE)::int AS "activeTierNetwork",
          COUNT(*) FILTER (WHERE "level" = 1 AND "hasEverActivated" = TRUE AND "kycStatus" = 'APPROVED')::int AS "qualifiedDirectCount",
          COUNT(*) FILTER (WHERE "createdAt" >= NOW() - INTERVAL '7 days')::int AS "new7d",
          COUNT(*) FILTER (WHERE "createdAt" >= NOW() - INTERVAL '14 days' AND "createdAt" < NOW() - INTERVAL '7 days')::int AS "previous7d",
          COUNT(*) FILTER (WHERE "createdAt" >= NOW() - INTERVAL '30 days')::int AS "new30d",
          COUNT(*) FILTER (WHERE "createdAt" >= NOW() - INTERVAL '60 days' AND "createdAt" < NOW() - INTERVAL '30 days')::int AS "previous30d",
          COUNT(*) FILTER (WHERE "createdAt" >= NOW() - INTERVAL '90 days')::int AS "new90d",
          COUNT(*) FILTER (WHERE "createdAt" >= NOW() - INTERVAL '180 days' AND "createdAt" < NOW() - INTERVAL '90 days')::int AS "previous90d"
        FROM member_state GROUP BY "userId"
      )
      SELECT u."username", u."avatarUrl",
             COALESCE(a."networkSize",0) AS "networkSize", COALESCE(a."directCount",0) AS "directCount",
             COALESCE(a."qualifiedNetwork",0) AS "qualifiedNetwork", COALESCE(a."activeNetwork",0) AS "activeNetwork",
             COALESCE(a."activeTierNetwork",0) AS "activeTierNetwork", COALESCE(a."qualifiedDirectCount",0) AS "qualifiedDirectCount",
             COALESCE(a."new7d",0) AS "new7d", COALESCE(a."previous7d",0) AS "previous7d",
             COALESCE(a."new30d",0) AS "new30d", COALESCE(a."previous30d",0) AS "previous30d",
             COALESCE(a."new90d",0) AS "new90d", COALESCE(a."previous90d",0) AS "previous90d",
             COALESCE(lt."tierName", 'NONE') AS "tierName"
      FROM "User" u
      JOIN agg a ON a."userId" = u."id"
      LEFT JOIN latest_tier lt ON lt."userId" = u."id"
      WHERE a."networkSize" > 0
    `;

    const enriched = rows.map((r) => ({
      ...r,
      growth7dPct: pct(Number(r.new7d), Number(r.previous7d)),
      growth30dPct: pct(Number(r.new30d), Number(r.previous30d)),
      growth90dPct: pct(Number(r.new90d), Number(r.previous90d)),
      activeRatePct: Number(r.networkSize) ? Math.round(Number(r.activeNetwork) / Number(r.networkSize) * 10000) / 100 : 0,
      qualifiedRatePct: Number(r.networkSize) ? Math.round(Number(r.qualifiedNetwork) / Number(r.networkSize) * 10000) / 100 : 0,
      activeTierRatePct: Number(r.networkSize) ? Math.round(Number(r.activeTierNetwork) / Number(r.networkSize) * 10000) / 100 : 0,
      fastestGrowthScore: Number(r.networkSize) ? Math.round(Number(r.new30d) / Math.max(Number(r.networkSize) - Number(r.new30d), 1) * 10000) / 100 : 0,
    }));

    const categories = {
      network: rank(enriched, 'networkSize'),
      direct: rank(enriched, 'directCount'),
      qualified: rank(enriched, 'qualifiedNetwork'),
      active: rank(enriched, 'activeNetwork'),
      activeTier: rank(enriched, 'activeTierNetwork'),
      fastestGrowth: rank(enriched, 'fastestGrowthScore'),
    };

    return NextResponse.json({
      ok: true, depth: MAX_REFERRAL_DEPTH, limit: LIMIT,
      categories,
      leaderboard: categories.network,
      methodology: {
        network: 'Total members across L1-L10.',
        direct: 'Direct L1 members.',
        qualified: 'Network members with KYC APPROVED and first activation completed.',
        active: 'Network members with UserStatus ACTIVE.',
        activeTier: 'Network members with a currently active tier subscription.',
        fastestGrowth: '30-day new-member growth normalized by the estimated pre-window network size; ties use direct and qualified network.',
      },
      generatedAt: new Date().toISOString(),
    }, { headers: { 'cache-control': 'public, max-age=30, stale-while-revalidate=60' } });
  } catch {
    return NextResponse.json({ ok: false, error: 'REFERRAL_LEADERBOARD_UNAVAILABLE' }, { status: 503 });
  }
}
