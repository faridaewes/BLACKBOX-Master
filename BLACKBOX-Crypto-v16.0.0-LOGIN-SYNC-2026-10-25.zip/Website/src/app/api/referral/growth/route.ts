import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';
import { requireSession, authStatus } from '@/lib/auth';
import { MAX_REFERRAL_DEPTH } from '@/lib/referral-reward-v91';

const DAY = 24 * 60 * 60 * 1000;
function pct(current: number, previous: number) { if (previous === 0) return current > 0 ? 100 : 0; return Math.round(((current - previous) / previous) * 10000) / 100; }

export async function GET() {
  try {
    const s = await requireSession();
    const rows = await db.$queryRaw<any[]>`
      WITH RECURSIVE network AS (
        SELECT u."id" AS "memberId", 0 AS "level" FROM "User" u WHERE u."id" = ${s.userId}
        UNION ALL
        SELECT child."id", n."level" + 1 FROM network n JOIN "User" child ON child."referredById" = n."memberId" WHERE n."level" < ${MAX_REFERRAL_DEPTH}
      ), latest_tier AS (
        SELECT DISTINCT ON (sub."userId") sub."userId", sub."expiresAt" FROM "Subscription" sub
        WHERE sub."status" = 'ACTIVE' AND sub."expiresAt" > NOW() ORDER BY sub."userId", sub."expiresAt" DESC
      )
      SELECT n."level", u."id", u."createdAt", u."status" AS "userStatus", u."hasEverActivated", u."kycStatus",
             (lt."userId" IS NOT NULL) AS "hasActiveTier"
      FROM network n JOIN "User" u ON u."id" = n."memberId" LEFT JOIN latest_tier lt ON lt."userId" = u."id" WHERE n."level" > 0
    `;
    const now = Date.now();
    const windows = [7, 30, 90].map(days => {
      const cutoff = now - days * DAY, previousCutoff = now - days * 2 * DAY;
      const current = rows.filter(r => new Date(r.createdAt).getTime() >= cutoff);
      const previous = rows.filter(r => { const t = new Date(r.createdAt).getTime(); return t >= previousCutoff && t < cutoff; });
      const activeMembers = current.filter(r => r.userStatus === 'ACTIVE').length;
      const qualifiedMembers = current.filter(r => r.hasEverActivated && r.kycStatus === 'APPROVED').length;
      const activeTierMembers = current.filter(r => r.hasActiveTier).length;
      return { days, newMembers: current.length, previousMembers: previous.length, growthRatePct: pct(current.length, previous.length), activeMembers, qualifiedMembers, activeTierMembers,
        activeRatePct: current.length ? Math.round(activeMembers / current.length * 10000) / 100 : 0,
        qualifiedRatePct: current.length ? Math.round(qualifiedMembers / current.length * 10000) / 100 : 0,
        activeTierRatePct: current.length ? Math.round(activeTierMembers / current.length * 10000) / 100 : 0 };
    });
    const activeNetwork = rows.filter(r => r.userStatus === 'ACTIVE').length;
    const qualifiedNetwork = rows.filter(r => r.hasEverActivated && r.kycStatus === 'APPROVED').length;
    const activeTierNetwork = rows.filter(r => r.hasActiveTier).length;
    const levels = Array.from({ length: MAX_REFERRAL_DEPTH }, (_, i) => {
      const level = i + 1, members = rows.filter(r => r.level === level);
      return { level, members: members.length,
        new7d: members.filter(r => new Date(r.createdAt).getTime() >= now - 7 * DAY).length,
        new30d: members.filter(r => new Date(r.createdAt).getTime() >= now - 30 * DAY).length,
        new90d: members.filter(r => new Date(r.createdAt).getTime() >= now - 90 * DAY).length };
    });
    const daily: Array<{date:string; newMembers:number; qualifiedMembers:number; activeTierMembers:number}> = [];
    for (let i = 29; i >= 0; i--) {
      const start = new Date(now - (i + 1) * DAY), end = new Date(now - i * DAY);
      const dayRows = rows.filter(r => { const t = new Date(r.createdAt).getTime(); return t >= start.getTime() && t < end.getTime(); });
      daily.push({ date: start.toISOString().slice(0, 10), newMembers: dayRows.length,
        qualifiedMembers: dayRows.filter(r => r.hasEverActivated && r.kycStatus === 'APPROVED').length,
        activeTierMembers: dayRows.filter(r => r.hasActiveTier).length });
    }
    return NextResponse.json({ ok: true, depth: MAX_REFERRAL_DEPTH,
      summary: { totalNetwork: rows.length, directNetwork: rows.filter(r => r.level === 1).length, activeNetwork, qualifiedNetwork, activeTierNetwork,
        activeRatePct: rows.length ? Math.round(activeNetwork / rows.length * 10000) / 100 : 0,
        qualifiedRatePct: rows.length ? Math.round(qualifiedNetwork / rows.length * 10000) / 100 : 0,
        activeTierRatePct: rows.length ? Math.round(activeTierNetwork / rows.length * 10000) / 100 : 0 },
      windows, levels, daily, generatedAt: new Date().toISOString() }, { headers: { 'cache-control': 'no-store' } });
  } catch (e) { return NextResponse.json({ ok: false, error: 'REFERRAL_GROWTH_UNAVAILABLE' }, { status: authStatus(e) }); }
}
