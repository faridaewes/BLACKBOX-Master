import { NextResponse } from 'next/server';
import crypto from 'node:crypto';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { runIdempotentTransaction } from '@/lib/idempotency';
import { requireSession, authStatus } from '@/lib/auth';
import { notifyTierActivation } from '@/lib/tier-activation-notifications';
import { normalizeUsername, normalizeReferralCode, validCustomReferralCode, pointBalance, redeemTier, getRedemptionTiers, REDEMPTION_TIERS, MAX_REFERRAL_DEPTH, REGISTRATION_REWARD_BY_LEVEL } from '@/lib/referral-reward-v91';

const schema = z.discriminatedUnion('action', [
  z.object({ action: z.literal('TRANSFER'), username: z.string().min(1).max(24), amount: z.coerce.number().int().min(10).max(1000) }),
  z.object({ action: z.literal('REDEEM'), tier: z.string().trim().min(2).max(24), wpaEnrollmentId: z.string().optional() }),
  z.object({ action: z.literal('CREATE_CUSTOM'), code: z.string().min(5).max(24) }),
]);

export async function GET() {
  try {
    const s = await requireSession();
    const u = await db.user.findUnique({ where: { id: s.userId }, select: { id:true, username:true, referralCode:true, referralPro:true, hasEverActivated:true, referredBy:{select:{username:true}}, downlines:{select:{id:true,username:true,name:true,hasEverActivated:true,createdAt:true},orderBy:{createdAt:'desc'},take:100} } });
    if (!u) return NextResponse.json({ok:false,error:'USER_NOT_FOUND'},{status:404});
    const balance = await pointBalance(s.userId);
    const tiers = await getRedemptionTiers();
    const ledger = await db.referralPointLedger.findMany({ where:{userId:s.userId}, orderBy:{createdAt:'desc'}, take:60 });
    return NextResponse.json({ok:true, profile:{username:u.username,referralCode:u.referralCode,referralPro:u.referralPro,hasEverActivated:u.hasEverActivated,sponsor:u.referredBy?.username||null}, balance, tiers, referralDepth:MAX_REFERRAL_DEPTH, registrationRewards:REGISTRATION_REWARD_BY_LEVEL, downlines:u.downlines, ledger});
  } catch(e) { return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)}); }
}

export async function POST(req:Request) {
  try {
    const s = await requireSession();
    const b = schema.parse(await req.json());
    if (b.action === 'REDEEM') {
      const idempotencyKey = req.headers.get('idempotency-key')?.trim();
      if (!idempotencyKey) return NextResponse.json({ok:false,error:'IDEMPOTENCY_KEY_REQUIRED'},{status:400});
      const operation = await redeemTier(s.userId,b.tier,idempotencyKey,b.wpaEnrollmentId);
      if(!operation.replay){ const r:any=operation.result; await notifyTierActivation({userId:s.userId,subscriptionId:r.subscriptionId,source:'POINT_REDEMPTION',tier:r.tier,pointsSpent:r.pointsSpent,balanceAfter:r.balanceAfter,startsAt:new Date(r.startsAt),expiresAt:new Date(r.expiresAt)}).catch(()=>null); }
      return NextResponse.json({ok:true,...operation.result});
    }
    if (b.action === 'CREATE_CUSTOM') {
      const code = normalizeReferralCode(b.code);
      if (!validCustomReferralCode(code)) return NextResponse.json({ok:false,error:'CUSTOM_REFERRAL_INVALID'},{status:400});
      const idempotencyKey = req.headers.get('idempotency-key')?.trim();
      if (!idempotencyKey) return NextResponse.json({ok:false,error:'IDEMPOTENCY_KEY_REQUIRED'},{status:400});
      const operation = await runIdempotentTransaction({
        key: idempotencyKey,
        scope: `referral-custom-code:${s.userId}`,
        request: { action: b.action, code },
        execute: async (tx:any) => {
          const u = await tx.user.findUnique({where:{id:s.userId},select:{referralPro:true,hasEverActivated:true,referralCode:true}});
          if (!u?.referralPro || !u.hasEverActivated) throw new Error('PRO_ACTIVATION_REQUIRED');
          if (u.referralCode) throw new Error('CUSTOM_REFERRAL_ALREADY_CREATED');
          const existing = await tx.user.findFirst({where:{OR:[{referralCode:code},{username:code}]},select:{id:true}});
          if (existing) throw new Error('CUSTOM_REFERRAL_TAKEN');
          const crossProfile = await tx.referralProfile.findFirst({where:{customCode:code},select:{id:true}});
          if (crossProfile) throw new Error('CUSTOM_REFERRAL_TAKEN');
          await tx.user.update({where:{id:s.userId},data:{referralCode:code}});
          const created = await tx.referralProfile.upsert({where:{userId:s.userId},update:{customCode:code},create:{userId:s.userId,customCode:code}});
          const result = {code:created.customCode};
          await tx.auditLog.create({data:{actorId:s.userId,action:'CUSTOM_REFERRAL_CREATED',targetType:'USER',targetId:s.userId,metadata:result}});
          return result;
        }
      });
      return NextResponse.json({ok:true,...operation.result});
    }
    const recipientName = normalizeUsername(b.username);
    const idempotencyKey = req.headers.get('idempotency-key')?.trim();
    if (!idempotencyKey) return NextResponse.json({ok:false,error:'IDEMPOTENCY_KEY_REQUIRED'},{status:400});
    const operation = await runIdempotentTransaction({
      key: idempotencyKey,
      scope: `referral-points-transfer:${s.userId}`,
      request: { action: b.action, recipientName, amount: b.amount },
      execute: async (tx:any) => {
        const sender = await tx.user.findUnique({where:{id:s.userId},select:{username:true,hasEverActivated:true,referralPro:true,wpaProfile:{select:{id:true,active:true}}}});
        const recipient = await tx.user.findUnique({where:{username:recipientName},select:{id:true,username:true,hasEverActivated:true,referralPro:true,status:true}});
        if (!sender || (!(sender.hasEverActivated && sender.referralPro) && !sender.wpaProfile?.active)) throw new Error('PRO_ACTIVATION_REQUIRED');
        if (!recipient) throw new Error('RECIPIENT_NOT_FOUND');
        if (recipient.id===s.userId) throw new Error('SELF_TRANSFER_NOT_ALLOWED');
        if (recipient.status !== 'ACTIVE') throw new Error('RECIPIENT_NOT_ACTIVE');
        const lockIds = [s.userId, recipient.id].sort();
        for (const lockId of lockIds) await tx.$queryRawUnsafe('SELECT pg_advisory_xact_lock(hashtext($1))', `blackbox:referral:points:${lockId}`);
        const balance = await pointBalance(s.userId,tx);
        if (balance < b.amount) throw new Error('INSUFFICIENT_POINTS');
        const transferId = crypto.randomUUID();
        await tx.referralPointLedger.create({data:{userId:s.userId,amount:-b.amount,kind:'TRANSFER_SENT',referenceType:'POINT_TRANSFER',referenceId:transferId,idempotencyKey,counterpartyUserId:recipient.id,description:`Transfer poin ke @${recipient.username}`} });
        await tx.referralPointLedger.create({data:{userId:recipient.id,amount:b.amount,kind:'TRANSFER_RECEIVED',referenceType:'POINT_TRANSFER',referenceId:transferId,idempotencyKey,counterpartyUserId:s.userId,description:`Menerima poin dari @${sender.username}`} });
        const result = {transferId,amount:b.amount,to:recipient.username,balanceAfter:balance-b.amount};
        await tx.auditLog.create({data:{actorId:s.userId,action:'REFERRAL_POINTS_TRANSFERRED',targetType:'USER',targetId:s.userId,metadata:result}});
        return result;
      }
    });
    const result = operation.result;
    return NextResponse.json({ok:true,...result});
  } catch(e) {
    const msg=e instanceof Error?e.message:String(e); const known=['IDEMPOTENCY_KEY_REQUIRED','IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_REQUEST','IDEMPOTENCY_REQUEST_IN_PROGRESS','ACTIVATION_REQUIRED','TIER_PLAN_NOT_CONFIGURED','CUSTOM_REFERRAL_ALREADY_CREATED','CUSTOM_REFERRAL_TAKEN','CUSTOM_REFERRAL_INVALID','IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_REQUEST','IDEMPOTENCY_REQUEST_IN_PROGRESS','PRO_ACTIVATION_REQUIRED','RECIPIENT_NOT_FOUND','SELF_TRANSFER_NOT_ALLOWED','RECIPIENT_NOT_PRO','INSUFFICIENT_POINTS','WPA_SERVICE_NOT_APPROVED_FOR_TIER','RECIPIENT_NOT_ACTIVE'];
    return NextResponse.json({ok:false,error:known.includes(msg)?msg:'REFERRAL_OPERATION_FAILED'},{status:known.includes(msg)?400:authStatus(e)});
  }
}
