import { NextResponse } from 'next/server';
import { requireSession, authStatus } from '@/lib/auth';
import { getReferralOSSummary } from '@/lib/referral-os-v100';

export async function GET() {
  try { const s=await requireSession(); return NextResponse.json({ok:true,...await getReferralOSSummary(s.userId)},{headers:{'Cache-Control':'no-store'}}); }
  catch(e){ return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)}); }
}
