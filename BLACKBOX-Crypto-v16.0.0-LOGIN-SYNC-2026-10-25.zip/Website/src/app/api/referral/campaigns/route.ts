import { NextResponse } from 'next/server';
import { requireSession, authStatus } from '@/lib/auth';
import { db } from '@/lib/prisma';
import { claimCampaigns } from '@/lib/referral-campaign-v97';
export async function GET(){try{const s=await requireSession();const now=new Date();const campaigns=await db.referralCampaign.findMany({where:{status:'ACTIVE',startsAt:{lte:now},OR:[{endsAt:null},{endsAt:{gt:now}}]},include:{_count:{select:{rewards:true}}},orderBy:{startsAt:'desc'},take:50});const rewards=await db.referralCampaignReward.findMany({where:{userId:s.userId},include:{campaign:true},orderBy:{createdAt:'desc'},take:100});return NextResponse.json({ok:true,campaigns,rewards});}catch(e){return NextResponse.json({ok:false,error:'REFERRAL_CAMPAIGNS_UNAVAILABLE'},{status:authStatus(e)})}}
export async function POST(){try{const s=await requireSession();const awarded=await claimCampaigns(s.userId);return NextResponse.json({ok:true,awarded});}catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)})}}
