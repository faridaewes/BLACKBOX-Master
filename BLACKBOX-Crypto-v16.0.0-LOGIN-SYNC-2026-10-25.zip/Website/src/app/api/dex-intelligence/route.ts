import { rateLimitUserKey } from '@/lib/rate-limit';
import { NextResponse } from 'next/server';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { fetchLiveDexMarkets } from '@/lib/paper/feed';
import { assessDexSafety, rankDexIntelligence, DEX_INTELLIGENCE_VERSION } from '@/lib/dex-intelligence-v85';
import { db } from '@/lib/prisma';
import { marketDegradedPayload, P3_MARKET_RUNTIME_VERSION } from '@/lib/market-runtime-resilience-v1181';

const chains=new Set(['all','solana','base','bsc','ethereum','arbitrum','polygon','avalanche']);
const n=(v:string|null,d:number,min:number,max:number)=>{const x=Number(v);return Number.isFinite(x)?Math.max(min,Math.min(max,x)):d};
function red(e:unknown){const m=e instanceof Error?e.message:String(e);return m.replace(/https?:\/\/\S+/gi,'[provider]').slice(0,180)}
export async function GET(req:Request){
 try{
  const s=await requireVerifiedSession(); const rl=await distributedRateLimit(rateLimitUserKey(s.userId, "dex-intelligence-v85"),4,60);
  if(!rl.ok)return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429,headers:{'Retry-After':String(rl.retryAfterSec)}});
  const u=new URL(req.url); const chain=(u.searchParams.get('chain')||'all').toLowerCase(); const q=(u.searchParams.get('q')||'').trim().toLowerCase(); const limit=Math.floor(n(u.searchParams.get('limit'),50,1,200));
  if(!chains.has(chain))return NextResponse.json({ok:false,error:'INVALID_CHAIN'},{status:400});
  const list=chain==='all'?['solana','base','bsc','ethereum','arbitrum','polygon','avalanche']:[chain];
  let markets:any[];
  try { markets=await fetchLiveDexMarkets(list); } catch(e) { return NextResponse.json({ok:true,...marketDegradedPayload('MARKET_DATA_UNAVAILABLE',e),version:DEX_INTELLIGENCE_VERSION,runtimeVersion:P3_MARKET_RUNTIME_VERSION,summary:{total:0,low:0,medium:0,high:0,blocked:0,insufficient:1},rows:[],mode:'READ_ONLY_DEX_INTELLIGENCE'},{status:200,headers:{'Cache-Control':'no-store'}}); }
  const filtered=q?markets.filter((m:any)=>`${m.symbol||''} ${m.dexId||''} ${m.chainId||''} ${m.pairAddress||''}`.toLowerCase().includes(q)):markets;
  const assessments=filtered.map((m:any)=>assessDexSafety({chain:m.chainId,dexId:m.dexId,pairAddress:m.pairAddress,symbol:m.symbol,priceUsd:m.priceUsd,liquidityUsd:m.liquidityUsd,volume24h:m.volume24h,priceImpactPct:m.priceImpactPct,poolAgeHours:m.pairAgeHours,liquidityChange24hPct:m.liquidityChange24hPct,volumeChange24hPct:m.volumeChange24hPct,observedAt:m.observedAt,source:m.source,honeypot:m.honeypot,buyTaxPct:m.buyTaxPct,sellTaxPct:m.sellTaxPct,transferRestricted:m.transferRestricted,blacklist:m.blacklist,mintAuthority:m.mintAuthority,freezeAuthority:m.freezeAuthority,proxy:m.proxy,ownerRenounced:m.ownerRenounced,liquidityLocked:m.liquidityLocked,holderConcentrationPct:m.holderConcentrationPct,verifiedContract:m.verifiedContract,deployerRisk:m.deployerRisk}));
  const rows=rankDexIntelligence(assessments,limit);
  try{await db.dexIntelligenceSnapshot.createMany({data:rows.map(r=>({marketKey:r.marketKey,chain:r.chain,dex:r.dex,symbol:r.symbol,trustScore:r.trustScore,tokenRiskScore:r.tokenRiskScore,poolHealthScore:r.poolHealthScore,executionQualityScore:r.executionQualityScore,status:r.status,blockers:r.blockers,warnings:r.warnings,evidence:r.evidence,observedAt:new Date()}))})}catch{}
  const summary={total:rows.length,low:rows.filter(r=>r.status==='LOW').length,medium:rows.filter(r=>r.status==='MEDIUM').length,high:rows.filter(r=>r.status==='HIGH').length,blocked:rows.filter(r=>r.status==='BLOCKED').length,insufficient:rows.filter(r=>r.status==='INSUFFICIENT_DATA').length};
  return NextResponse.json({ok:true,version:DEX_INTELLIGENCE_VERSION,runtimeVersion:P3_MARKET_RUNTIME_VERSION,mode:'READ_ONLY_DEX_INTELLIGENCE',executionAllowed:false,summary,rows,contract:{executionAllowed:false,noOrderSigning:true,noRouterAuthorization:true}},{headers:{'Cache-Control':'no-store'}});
 }catch(e){const status=authStatus(e);if(status===401||status===403)return NextResponse.json({ok:false,error:status===401?'AUTH_REQUIRED':'FORBIDDEN'},{status});return NextResponse.json({ok:true,...marketDegradedPayload('MARKET_DATA_UNAVAILABLE',e),version:DEX_INTELLIGENCE_VERSION,runtimeVersion:P3_MARKET_RUNTIME_VERSION,summary:{total:0,low:0,medium:0,high:0,blocked:0,insufficient:1},rows:[],mode:'READ_ONLY_DEX_INTELLIGENCE'},{status:200,headers:{'Cache-Control':'no-store'}})}
}
