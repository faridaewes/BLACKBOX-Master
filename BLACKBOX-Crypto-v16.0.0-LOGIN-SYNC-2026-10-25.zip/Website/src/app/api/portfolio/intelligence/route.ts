import {NextResponse} from 'next/server';
import {requireVerifiedSession,authStatus} from '@/lib/auth';
import {calculatePortfolioIntelligence} from '@/lib/portfolio-intelligence-v76';
export async function GET(){try{const s=await requireVerifiedSession();return NextResponse.json({ok:true,portfolio:await calculatePortfolioIntelligence(s.userId)},{headers:{'cache-control':'no-store'}})}catch(e){return NextResponse.json({ok:false,error:'PORTFOLIO_INTELLIGENCE_UNAVAILABLE'},{status:authStatus(e)})}}
