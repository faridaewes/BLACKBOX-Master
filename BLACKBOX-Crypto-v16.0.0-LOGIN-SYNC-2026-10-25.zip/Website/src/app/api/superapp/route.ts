import { NextResponse } from 'next/server';
import { authStatus } from '@/lib/auth';
import { getSuperAppControlPlane } from '@/lib/superapp/control-plane';
export const dynamic='force-dynamic';
export async function GET(){
  try { return NextResponse.json(await getSuperAppControlPlane(),{headers:{'cache-control':'no-store'}}); }
  catch(e){ const status=authStatus(e); return NextResponse.json({ok:false,error:status===401?'AUTH_REQUIRED':status===403?'FORBIDDEN':'SUPERAPP_CONTROL_PLANE_UNAVAILABLE',safety:{executionAllowed:false,noOrderSigning:true,noOrderSubmission:true,noRouterAuthorization:true}},{status,headers:{'cache-control':'no-store'}}); }
}
