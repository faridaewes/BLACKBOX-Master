import { NextResponse } from 'next/server';
import { BLACKBOX_RELEASE_VERSION } from '@/lib/release-version';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
export async function GET(){try{await requireVerifiedSession();return NextResponse.json({ok:true,version:BLACKBOX_RELEASE_VERSION,scale:{multiRegion:{enabled:false,mode:'FOUNDATION_READY'},institutional:{enabled:false,mode:'FOUNDATION_READY'},dataResidency:'POLICY_DRIVEN'},executionAllowed:false,noOrderSigning:true,noOrderSubmission:true,noRouterAuthorization:true},{headers:{'cache-control':'no-store'}})}catch(e){return NextResponse.json({ok:false,error:'SCALE_STATUS_UNAVAILABLE'},{status:authStatus(e)})}}
