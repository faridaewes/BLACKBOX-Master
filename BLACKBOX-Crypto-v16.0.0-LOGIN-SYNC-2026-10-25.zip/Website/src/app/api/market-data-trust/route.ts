import { rateLimitUserKey } from '@/lib/rate-limit';
import { NextResponse } from 'next/server';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { fetchExchangeMarkets, fetchLiveDexMarkets } from '@/lib/paper/feed';
import { assessBatchTrust, MARKET_DATA_TRUST_VERSION, type MarketObservation, type TrustMarketType } from '@/lib/market-data-trust-v84';
import { marketDegradedPayload, safeProviderSettled, P3_MARKET_RUNTIME_VERSION } from '@/lib/market-runtime-resilience-v1181';

const allowed = new Set(['ALL','SPOT','FUTURES','DEX']);
const chains = new Set(['all','solana','base','bsc','ethereum','arbitrum','polygon','avalanche']);
const safeLimit = (v: string | null) => { const n=Number(v); return Number.isFinite(n) ? Math.max(1, Math.min(500, Math.floor(n))) : 100; };

export async function GET(req: Request) {
  try {
    const s = await requireVerifiedSession();
    const rl = await distributedRateLimit(rateLimitUserKey(s.userId, "market-data-trust-v84"), 4, 60);
    if (!rl.ok) return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429,headers:{'Retry-After':String(rl.retryAfterSec)}});
    const u = new URL(req.url);
    const marketType = (u.searchParams.get('marketType') || 'ALL').toUpperCase();
    const chain = (u.searchParams.get('chain') || 'all').toLowerCase();
    if (!allowed.has(marketType)) return NextResponse.json({ok:false,error:'INVALID_MARKET_TYPE'},{status:400});
    if (!chains.has(chain)) return NextResponse.json({ok:false,error:'INVALID_CHAIN'},{status:400});
    const chainList = chain === 'all' ? ['solana','base','bsc','ethereum'] : [chain];
    const tasks: Promise<{type:TrustMarketType;data:any[]}>[] = [];
    if (marketType === 'DEX' || marketType === 'ALL') tasks.push(fetchLiveDexMarkets(chainList).then(data=>({type:'DEX',data})));
    if (marketType === 'SPOT' || marketType === 'ALL') tasks.push(fetchExchangeMarkets('SPOT',[],Number.POSITIVE_INFINITY).then(data=>({type:'SPOT',data})));
    if (marketType === 'FUTURES' || marketType === 'ALL') tasks.push(fetchExchangeMarkets('FUTURES',[],Number.POSITIVE_INFINITY).then(data=>({type:'FUTURES',data})));
    const settled = await Promise.allSettled(tasks);
    const providerState = safeProviderSettled(settled);
    const observations: MarketObservation[] = settled.flatMap(x => x.status === 'fulfilled' ? x.value.data.map(m => ({
      key: `${x.value.type}:${String(m.chainId || 'CEX')}:${String(m.symbol || 'UNKNOWN')}`.toUpperCase(),
      provider: String(m.dexId || 'UNKNOWN').replace(/^ccxt:/i,''), venue: String(m.dexId || 'UNKNOWN'), marketType:x.value.type,
      chain:String(m.chainId || 'CEX'), symbol:String(m.symbol || 'UNKNOWN'), priceUsd:Number(m.priceUsd), liquidityUsd:Number(m.liquidityUsd), volume24h:Number(m.volume24h),
      spreadBps:m.spreadBps == null ? undefined : Number(m.spreadBps), observedAt:m.observedAt, ok:true, analysisComplete:m.analysisComplete,
    } as MarketObservation)) : []);
    const q=(u.searchParams.get('q')||'').trim().toLowerCase();
    const filtered=q ? observations.filter(o=>`${o.symbol} ${o.provider} ${o.chain}`.toLowerCase().includes(q)) : observations;
    const assessments=assessBatchTrust(filtered).slice(0,safeLimit(u.searchParams.get('limit')));
    const summary={total:assessments.length,trusted:assessments.filter(x=>x.assessment.status==='TRUSTED').length,degraded:assessments.filter(x=>x.assessment.status==='DEGRADED').length,untrusted:assessments.filter(x=>x.assessment.status==='UNTRUSTED').length,blocked:assessments.filter(x=>x.assessment.status==='BLOCKED').length,conflicts:assessments.filter(x=>x.crossProvider.conflict).length};
    const providerErrors=providerState.providerErrors;
    return NextResponse.json({ok:true,version:MARKET_DATA_TRUST_VERSION,runtimeVersion:P3_MARKET_RUNTIME_VERSION,marketType,chain,summary,assessments,providerErrors,degraded:providerState.providerDegraded,noOrderAction:providerState.providerDegraded,recovery:providerState.providerDegraded?marketDegradedPayload('MARKET_DATA_DEGRADED'):null,mode:'READ_ONLY_INTELLIGENCE',executionAllowed:false},{headers:{'Cache-Control':'no-store'}});
  } catch(e) { const status=authStatus(e); if(status===401||status===403)return NextResponse.json({ok:false,error:status===401?'AUTH_REQUIRED':'FORBIDDEN'},{status}); return NextResponse.json({ok:true,...marketDegradedPayload('MARKET_DATA_UNAVAILABLE',e),version:MARKET_DATA_TRUST_VERSION,runtimeVersion:P3_MARKET_RUNTIME_VERSION,marketType:'UNKNOWN',chain:'unknown',summary:{total:0,trusted:0,degraded:1,untrusted:0,blocked:0,conflicts:0},assessments:[],providerErrors:[String(e instanceof Error?e.message:e).replace(/https?:\/\/\S+/gi,'[provider]').slice(0,180)],mode:'READ_ONLY_INTELLIGENCE'},{status:200,headers:{'Cache-Control':'no-store'}}); }
}
