import { rateLimitUserKey } from '@/lib/rate-limit';
import {NextResponse} from 'next/server';
import crypto from 'node:crypto';
import {z} from 'zod';
import {db} from '@/lib/prisma';
import {requireMfa,authStatus} from '@/lib/auth';
import {distributedRateLimit} from '@/lib/distributed-rate-limit';
const schema=z.object({provider:z.enum(['PHANTOM','METAMASK','COINBASE_WALLET','WALLETCONNECT','TRUST_WALLET','OTHER']),chain:z.enum(['SOLANA','EVM']),chainId:z.number().int().positive().optional(),address:z.string().min(20).max(128)});
export async function POST(req:Request){try{const s=await requireMfa(req);const rl=await distributedRateLimit(rateLimitUserKey(s.userId, "wallet-challenge"),12,60);if(!rl.ok)return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429,headers:{'Retry-After':String(rl.retryAfterSec)}});const b=schema.parse(await req.json());const nonce=crypto.randomBytes(24).toString('hex');const exp=new Date(Date.now()+5*60_000);const domain=new URL(req.url).host;const message=`BLACKBOX Crypto wallet ownership verification\n\nDomain: ${domain}\nUser: ${s.userId}\nAddress: ${b.address}\nNonce: ${nonce}\nExpires: ${exp.toISOString()}\n\nThis signature proves control of the wallet. It does not authorize a trade, transfer, withdrawal, or asset movement. By continuing, the user is only proving wallet ownership/control for BLACKBOX connection setup.`;await db.walletChallenge.create({data:{userId:s.userId,provider:b.provider,chain:b.chain,chainId:b.chainId,address:b.address,nonce,message,expiresAt:exp}});return NextResponse.json({ok:true,message,nonce,expiresAt:exp});}catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)})}}
