import { rateLimitUserKey } from '@/lib/rate-limit';
import {NextResponse} from 'next/server';
import {z} from 'zod';
import bs58 from 'bs58';
import nacl from 'tweetnacl';
import {verifyMessage, getAddress} from 'viem';
import {db} from '@/lib/prisma';
import {requireMfa,authStatus} from '@/lib/auth';
import {distributedRateLimit} from '@/lib/distributed-rate-limit';
import {requireCurrentLegalConsent} from '@/lib/legal-registry';
import {recordConsentWithTx} from '@/lib/consent';
const schema=z.object({nonce:z.string().min(20),signature:z.string().min(20),connectionConsentAccepted:z.literal(true),consentAcknowledgement:z.string().trim().min(20).max(500)});
export async function POST(req:Request){try{const s=await requireMfa(req); await requireCurrentLegalConsent(s.userId,'TRADING_RULES'); await requireCurrentLegalConsent(s.userId,'ALMA_ADVISOR_REGISTRATION');const rl=await distributedRateLimit(rateLimitUserKey(s.userId, "wallet-verify"),12,60);if(!rl.ok)return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429,headers:{'Retry-After':String(rl.retryAfterSec)}});const b=schema.parse(await req.json());const c=await db.walletChallenge.findUnique({where:{nonce:b.nonce}});if(!c||c.userId!==s.userId)return NextResponse.json({ok:false,error:'WALLET_CHALLENGE_NOT_FOUND'},{status:400});if(c.consumedAt||c.expiresAt<=new Date())return NextResponse.json({ok:false,error:'WALLET_CHALLENGE_EXPIRED'},{status:400});let valid=false;if(c.chain==='EVM'){const recovered=await verifyMessage({address:getAddress(c.address),message:c.message,signature:b.signature as `0x${string}`}).catch(()=>false as const);valid=recovered===true;}else{const sig=bs58.decode(b.signature);const pub=bs58.decode(c.address);valid=nacl.sign.detached.verify(new TextEncoder().encode(c.message),sig,pub);}if(!valid)return NextResponse.json({ok:false,error:'WALLET_SIGNATURE_INVALID'},{status:400});const row=await db.$transaction(async tx=>{
  const now=new Date();
  const claimed=await tx.walletChallenge.updateMany({where:{id:c.id,userId:s.userId,consumedAt:null,expiresAt:{gt:now}},data:{consumedAt:now}});
  if(claimed.count!==1)throw new Error('WALLET_CHALLENGE_ALREADY_CONSUMED');
  const consentUser=await tx.user.findUnique({where:{id:s.userId},select:{id:true,name:true,email:true}}); if(!consentUser) throw new Error('CONSENT_USER_NOT_FOUND');
  const wallet=await tx.wallet.upsert({where:{userId_chain_address:{userId:s.userId,chain:c.chain,address:c.address}},update:{provider:c.provider,chainId:c.chainId,status:'CONNECTED',verifiedAt:now,lastUsedAt:now},create:{userId:s.userId,provider:c.provider,chain:c.chain,chainId:c.chainId,status:'CONNECTED',address:c.address,verifiedAt:now,lastUsedAt:now}});
  await recordConsentWithTx(tx,req,consentUser,'CONNECTION_AUTHORIZATION',{connectionType:'WALLET',connectionId:wallet.id,provider:wallet.provider,chain:wallet.chain,chainId:wallet.chainId,address:wallet.address,ownershipSignatureVerified:true,tradeAuthorizationGranted:false,acknowledgementText:b.consentAcknowledgement,consentMethod:'EXPLICIT_CONFIRMATION',readAt:new Date().toISOString(),consentContext:{source:'WALLET_CONNECTION'}});
  return wallet;
});await db.auditLog.create({data:{actorId:s.userId,action:'WALLET_VERIFIED',targetType:'WALLET',targetId:row.id,metadata:{provider:row.provider,chain:row.chain,address:row.address}}});return NextResponse.json({ok:true,wallet:{id:row.id,provider:row.provider,chain:row.chain,chainId:row.chainId,address:row.address,verifiedAt:row.verifiedAt}});}catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)})}}
