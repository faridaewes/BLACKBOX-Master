import { rateLimitUserKey } from '@/lib/rate-limit';
import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { fetchExchangeBalance } from '@/lib/unified-exchange';
import { fetchWalletBalance } from '@/lib/wallet-balances';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { assessCexReadiness, assessWalletReadiness } from '@/lib/trading-connection-readiness';

const STABLES = new Set(['USDT', 'USDC', 'USD', 'BUSD', 'FDUSD', 'TUSD', 'DAI']);
const finite = (v: unknown) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };

function normalizeExchangeBalance(provider: string, label: string, marketType: string, raw: any) {
  const total = raw?.total || {};
  const free = raw?.free || {};
  const used = raw?.used || {};
  const assets = Object.keys(total)
    .map(asset => ({ asset, total: finite(total[asset]), free: finite(free[asset]), used: finite(used[asset]) }))
    .filter(x => Math.abs(x.total) > 1e-12 || Math.abs(x.free) > 1e-12 || Math.abs(x.used) > 1e-12)
    .sort((a,b) => Math.abs(b.total) - Math.abs(a.total));
  const stableTotal = assets.filter(x => STABLES.has(x.asset.toUpperCase())).reduce((sum,x)=>sum+x.total,0);
  return { provider, label, marketType, assets, stableTotal };
}

export async function GET() {
  try {
    const session = await requireVerifiedSession();
    const rl = await distributedRateLimit(rateLimitUserKey(session.userId, "balance-sync"), 6, 60);
    if (!rl.ok) return NextResponse.json({ ok:false, error:'BALANCE_SYNC_RATE_LIMITED', retryAfterSec:rl.retryAfterSec, refreshAfterMs:15000 }, { status:429, headers:{'Retry-After':String(rl.retryAfterSec)} });
    const [exchanges, wallets] = await Promise.all([
      db.exchangeAccount.findMany({ where: { userId: session.userId, status: 'CONNECTED', encryptedRef: { not: null } }, orderBy: { createdAt: 'asc' } }),
      db.wallet.findMany({ where: { userId: session.userId, status: 'CONNECTED' }, orderBy: { createdAt: 'asc' } }),
    ]);

    const exchangeResults = await Promise.all(exchanges.map(async row => {
      try {
        const raw = await fetchExchangeBalance(row.provider, row.encryptedRef!, row.testnet, row.marketType === 'FUTURES' ? 'FUTURES' : 'SPOT');
        await db.exchangeAccount.update({ where: { id: row.id }, data: { status: 'CONNECTED', lastHealthCheckAt: new Date() } });
        const checkedAt = new Date().toISOString();
        const normalized = normalizeExchangeBalance(row.provider, row.label, row.marketType, raw);
        const readiness = assessCexReadiness({ provider: row.provider, marketType: row.marketType === 'FUTURES' ? 'FUTURES' : 'SPOT', assets: normalized.assets, permissions: (row.permissions || {}) as Record<string,unknown>, checkedAt });
        await db.connectionReadinessSnapshot.upsert({ where:{connectionId:row.id}, create:{userId:session.userId,connectionId:row.id,connectionType:'CEX',provider:row.provider,marketType:row.marketType,state:readiness.state,ready:readiness.ready,summary:readiness.summary,observed:readiness.observed,guidance:readiness.guidance,checkedAt:new Date(checkedAt)}, update:{state:readiness.state,ready:readiness.ready,summary:readiness.summary,observed:readiness.observed,guidance:readiness.guidance,checkedAt:new Date(checkedAt)}}).catch(()=>{});
        return { id: row.id, status: 'CONNECTED', checkedAt, ...normalized, readiness };
      } catch (e: any) {
        await db.exchangeAccount.update({ where: { id: row.id }, data: { status: 'ERROR', lastHealthCheckAt: new Date() } }).catch(()=>{});
        const checkedAt = new Date().toISOString();
        return { id: row.id, provider: row.provider, label: row.label, marketType: row.marketType, status: 'ERROR', checkedAt, error: e?.message || 'BALANCE_READ_FAILED', assets: [], stableTotal: 0, readiness: assessCexReadiness({ provider: row.provider, marketType: row.marketType === 'FUTURES' ? 'FUTURES' : 'SPOT', assets: [], permissions: (row.permissions || {}) as Record<string,unknown>, checkedAt, error: true }) };
      }
    }));

    const walletResults = await Promise.all(wallets.map(async row => {
      try {
        const balance = await fetchWalletBalance({ chain: row.chain, address: row.address, chainId: row.chainId });
        await db.wallet.update({ where: { id: row.id }, data: { status: 'CONNECTED', lastUsedAt: new Date() } }).catch(()=>{});
        const checkedAt = new Date().toISOString();
        const readiness = assessWalletReadiness({ provider: row.provider, chain: balance.chain === 'SOLANA' ? 'SOLANA' : 'EVM', network: balance.network, assets: balance.assets, nativeBalance: balance.nativeBalance, checkedAt });
        await db.connectionReadinessSnapshot.upsert({ where:{connectionId:row.id}, create:{userId:session.userId,connectionId:row.id,connectionType:'WALLET',provider:row.provider,chain:balance.chain,state:readiness.state,ready:readiness.ready,summary:readiness.summary,observed:readiness.observed,guidance:readiness.guidance,checkedAt:new Date(checkedAt)}, update:{state:readiness.state,ready:readiness.ready,summary:readiness.summary,observed:readiness.observed,guidance:readiness.guidance,checkedAt:new Date(checkedAt)}}).catch(()=>{});
        return { id: row.id, provider: row.provider, address: row.address, status: 'CONNECTED', checkedAt, ...balance, readiness };
      } catch (e: any) {
        await db.wallet.update({ where: { id: row.id }, data: { status: 'ERROR' } }).catch(()=>{});
        const checkedAt = new Date().toISOString();
        return { id: row.id, provider: row.provider, address: row.address, status: 'ERROR', checkedAt, assets: [], nativeBalance: 0, network: row.chain, error: e?.message || 'WALLET_BALANCE_READ_FAILED', readiness: assessWalletReadiness({ provider: row.provider, chain: row.chain === 'SOLANA' ? 'SOLANA' : 'EVM', network: row.chain, assets: [], nativeBalance: 0, checkedAt, error: true }) };
      }
    }));

    return NextResponse.json({ ok: true, serverTime: new Date().toISOString(), refreshAfterMs: 15000, exchanges: exchangeResults, wallets: walletResults });
  } catch (e: any) {
    const status = authStatus(e);
    if (status === 401 || status === 403) return NextResponse.json({ ok: false, error: status === 401 ? 'AUTH_REQUIRED' : 'FORBIDDEN' }, { status });
    return NextResponse.json({
      ok: true,
      degraded: true,
      error: 'BALANCE_DATA_UNAVAILABLE',
      message: 'Balance provider atau runtime database sedang mengalami gangguan. Dashboard tetap aktif dan tidak melakukan order.',
      exchanges: [],
      wallets: [],
      executionAllowed: false,
      noOrderSigning: true,
      noOrderSubmission: true,
      noRouterAuthorization: true,
      noOrderAction: true,
      serverTime: new Date().toISOString(),
      refreshAfterMs: 15000,
    }, { status: 200, headers: { 'Cache-Control': 'no-store' } });
  }
}
