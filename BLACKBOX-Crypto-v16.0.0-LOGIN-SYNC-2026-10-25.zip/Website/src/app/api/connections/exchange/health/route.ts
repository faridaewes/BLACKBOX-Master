import { rateLimitUserKey } from '@/lib/rate-limit';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { testExchangeConnection } from '@/lib/unified-exchange';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';

const schema = z.object({ connectionId: z.string().min(1) });

/** Re-test a connected exchange — used by Connections UI and before bot REAL start. */
export async function POST(req: Request) {
  try {
    const s = await requireVerifiedSession();
    const rl = await distributedRateLimit(rateLimitUserKey(s.userId, "exchange-health"), 20, 60);
    if (!rl.ok) {
      return NextResponse.json({ ok: false, error: 'TOO_MANY_REQUESTS' }, { status: 429 });
    }
    const b = schema.parse(await req.json());
    const conn = await db.exchangeAccount.findFirst({
      where: { id: b.connectionId, userId: s.userId },
    });
    if (!conn) return NextResponse.json({ ok: false, error: 'NOT_FOUND' }, { status: 404 });
    if (!conn.encryptedRef) {
      return NextResponse.json({ ok: false, error: 'NO_CREDENTIALS' }, { status: 400 });
    }
    try {
      const result = await testExchangeConnection(
        conn.provider,
        conn.encryptedRef,
        conn.testnet,
        (conn.marketType as any) || 'SPOT',
      );
      await db.exchangeAccount.update({
        where: { id: conn.id },
        data: { status: 'CONNECTED', lastHealthCheckAt: new Date() },
      });
      return NextResponse.json({ ok: true, health: 'OK', result, connectionId: conn.id });
    } catch (e) {
      await db.exchangeAccount.update({
        where: { id: conn.id },
        data: { status: 'ERROR', lastHealthCheckAt: new Date() },
      }).catch(() => {});
      return NextResponse.json({
        ok: false,
        error: 'HEALTH_FAILED',
        message: String(e instanceof Error ? e.message : e),
      }, { status: 502 });
    }
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'REQUEST_FAILED' }, { status: authStatus(e) });
  }
}
