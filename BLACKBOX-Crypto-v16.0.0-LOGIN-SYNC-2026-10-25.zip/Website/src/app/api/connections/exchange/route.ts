import { rateLimitUserKey } from '@/lib/rate-limit';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { requireVerifiedSession, requireMfa } from '@/lib/auth';
import { encryptSecret, fingerprint } from '@/lib/secret-vault';
import { testExchangeConnection } from '@/lib/unified-exchange';
import { getEntitlements } from '@/lib/entitlements';
import { getIndonesiaExchanges, getGlobalExchanges, getCatalogExchange, isExchangeCertified } from '@/lib/exchange-catalog';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { requireCurrentLegalConsent } from '@/lib/legal-registry';
import { recordConsentWithTx } from '@/lib/consent';

const schema=z.object({mfaCode:z.string().regex(/^\d{6}$/).optional(),provider:z.string().min(1),label:z.string().min(1),apiKey:z.string().min(1),secret:z.string().min(1),password:z.string().optional(),uid:z.string().optional(),testnet:z.boolean().default(false),marketType:z.enum(['SPOT','FUTURES']).default('SPOT'),marketTypes:z.array(z.enum(['SPOT','FUTURES'])).min(1).max(2).optional(),maxLeverage:z.number().int().min(1).max(20).default(1),permissions:z.record(z.string(),z.any()).default({}),connectionConsentAccepted:z.literal(true),consentAcknowledgement:z.string().trim().min(20).max(500),consentMethod:z.enum(['EXPLICIT_CHECKBOX','EXPLICIT_CONFIRMATION','E_SIGNATURE']).default('EXPLICIT_CHECKBOX'),consentContext:z.object({timezone:z.string().max(80).optional(),locale:z.string().max(40).optional(),source:z.string().max(80).optional()}).optional()});

export async function POST(req:Request){
 try{
  const s=await requireMfa(req);
  const rl=await distributedRateLimit(rateLimitUserKey(s.userId, "exchange-connect"),10,60);
  if(!rl.ok)return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429,headers:{'Retry-After':String(rl.retryAfterSec)}});
  const parsed=schema.parse(await req.json());
  await requireCurrentLegalConsent(s.userId,'TRADING_RULES');
  await requireCurrentLegalConsent(s.userId,'ALMA_ADVISOR_REGISTRATION');
  const body={...parsed,provider:parsed.provider.trim().toLowerCase(),label:parsed.label.trim(),marketTypes:Array.from(new Set(parsed.marketTypes?.length?parsed.marketTypes:[parsed.marketType]))};
  const ent=await getEntitlements(s.userId,s.role);
  if (!ent.tradingEnabled) throw new Error('TRADING_TIER_EXPIRED');
  const existingCount=await db.exchangeAccount.count({where:{userId:s.userId,status:'CONNECTED'}});
  if(existingCount>=ent.exchanges) throw new Error(`EXCHANGE_TIER_LIMIT:${ent.exchanges}`);
  const meta=getCatalogExchange(body.provider) || (getGlobalExchanges().find(x=>x.id===body.provider));
  if(!meta) throw new Error('EXCHANGE_NOT_CATALOGED');
  if(body.marketTypes.includes('FUTURES') && !meta.futures) throw new Error('FUTURES_NOT_SUPPORTED_BY_EXCHANGE');
  if(body.marketTypes.includes('SPOT') && !meta.spot) throw new Error('SPOT_NOT_SUPPORTED_BY_EXCHANGE');
  if(meta.adapter!=='ccxt') throw new Error('EXCHANGE_ADAPTER_NOT_AVAILABLE');
  // Connection/testing is allowed before certification; REAL order submission remains gated by the certification flags.
  const providerAllowed=isExchangeCertified(body.provider);
  if((body.permissions as any)?.withdraw) throw new Error('WITHDRAWAL_PERMISSION_FORBIDDEN');
  const encryptedRef=encryptSecret({apiKey:body.apiKey,secret:body.secret,password:body.password,uid:body.uid});
  for (const mt of body.marketTypes) await testExchangeConnection(body.provider,encryptedRef,body.testnet,mt);
  const row=await db.$transaction(async tx=>{
    const consentUser=await tx.user.findUnique({where:{id:s.userId},select:{id:true,name:true,email:true}}); if(!consentUser) throw new Error('CONSENT_USER_NOT_FOUND');
    const created=await tx.exchangeAccount.create({data:{userId:s.userId,provider:body.provider,label:body.label,type:'CEX',status:'CONNECTED',encryptedRef,permissions:{...body.permissions,apiKeyFingerprint:fingerprint(body.apiKey),withdraw:false,supportedMarketTypes:body.marketTypes},testnet:body.testnet,marketType:body.marketTypes.length===2?'MULTI':body.marketTypes[0],maxLeverage:body.maxLeverage,lastHealthCheckAt:new Date()}});
    await recordConsentWithTx(tx,req,consentUser,'CONNECTION_AUTHORIZATION',{connectionType:'EXCHANGE',connectionId:created.id,provider:created.provider,label:created.label,marketTypes:body.marketTypes,testnet:body.testnet,tradePermission:Boolean((body.permissions as any)?.trade),withdrawPermission:false,acknowledgementText:body.consentAcknowledgement,consentMethod:body.consentMethod,readAt:new Date().toISOString(),consentContext:body.consentContext||{source:'EXCHANGE_CONNECTION'}});
    await tx.auditLog.create({data:{actorId:s.userId,action:'EXCHANGE_CONNECTION_AUTHORIZED',targetType:'EXCHANGE_ACCOUNT',targetId:created.id,metadata:{provider:created.provider,label:created.label,marketTypes:body.marketTypes,withdraw:false}}});
    return created;
  });
  return NextResponse.json({ok:true,id:row.id,provider:row.provider,label:row.label,testnet:row.testnet,realTradingCertified:false,providerAllowedForCertification:providerAllowed,supportedMarketTypes:body.marketTypes});
 }catch(e:any){return NextResponse.json({ok:false,error:e?.message||'EXCHANGE_CONNECTION_FAILED'},{status:400})}
}

export async function GET(){
 try{const s=await requireVerifiedSession();const rows=await db.exchangeAccount.findMany({where:{userId:s.userId},select:{id:true,provider:true,label:true,status:true,testnet:true,marketType:true,maxLeverage:true,realTradingCertifiedAt:true,certificationVersion:true,certificationStatus:true,certificationCompletedAt:true,lastHealthCheckAt:true,permissions:true,createdAt:true,updatedAt:true}});return NextResponse.json({ok:true,connections:rows.map((r:any)=>({...r,supportedMarketTypes:Array.isArray(r.permissions?.supportedMarketTypes)?r.permissions.supportedMarketTypes:[String(r.marketType||'SPOT')]}))})}
 catch(e:any){return NextResponse.json({ok:false,error:e?.message||'UNAUTHENTICATED'},{status:401})}
}


export async function DELETE(req: Request) {
  try {
    const s = await requireMfa(req);
    const rl = await distributedRateLimit(rateLimitUserKey(s.userId, "exchange-disconnect"), 10, 60);
    if (!rl.ok) return NextResponse.json({ ok: false, error: 'TOO_MANY_REQUESTS', retryAfterSec: rl.retryAfterSec }, { status: 429, headers: { 'Retry-After': String(rl.retryAfterSec) } });
    const body = z.object({ id: z.string().min(1) }).parse(await req.json());
    const row = await db.exchangeAccount.findFirst({ where: { id: body.id, userId: s.userId } });
    if (!row) return NextResponse.json({ ok: false, error: 'EXCHANGE_CONNECTION_NOT_FOUND' }, { status: 404 });
    const activeRealBots = await db.bot.count({ where: { userId: s.userId, exchangeId: row.id, mode: 'REAL', status: { in: ['RUNNING', 'PAUSED'] } } });
    if (activeRealBots > 0) return NextResponse.json({ ok: false, error: 'EXCHANGE_IN_USE_BY_REAL_BOT' }, { status: 409 });
    await db.$transaction([
      db.auditLog.create({ data: { actorId: s.userId, action: 'EXCHANGE_DISCONNECTED', targetType: 'EXCHANGE_ACCOUNT', targetId: row.id, metadata: { provider: row.provider, label: row.label } } }),
      db.exchangeAccount.update({ where: { id: row.id }, data: { status: 'DISCONNECTED', encryptedRef: null, permissions: { withdraw: false }, realTradingCertifiedAt: null, certificationVersion: null, certificationStatus: 'NOT_CERTIFIED', certificationTests: {}, certificationCompletedAt: null, lastHealthCheckAt: null } }),
    ]);
    return NextResponse.json({ ok: true, id: row.id });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || 'EXCHANGE_DISCONNECT_FAILED' }, { status: e?.name === 'ZodError' ? 400 : 400 });
  }
}
