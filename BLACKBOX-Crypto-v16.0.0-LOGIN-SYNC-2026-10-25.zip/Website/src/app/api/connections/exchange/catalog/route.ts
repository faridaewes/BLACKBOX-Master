import { NextResponse } from 'next/server';
import { requireSession } from '@/lib/auth';
import { getIndonesiaExchanges, getGlobalExchanges } from '@/lib/exchange-catalog';
export async function GET(){try{await requireSession();return NextResponse.json({ok:true,indonesia:getIndonesiaExchanges(),global:getGlobalExchanges()});}catch(e:any){return NextResponse.json({ok:false,error:e?.message||'UNAUTHENTICATED'},{status:401})}}
