import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { authStatus } from '@/lib/auth';
import { getGatewayConfig, sendGatewayText } from '@/lib/telegram-gateway';
import { evaluateAlertSignal, shouldDeliverAlert } from '@/lib/alert-intelligence-v89';

const schema = z.object({
  key: z.string().trim().min(1).max(180),
  status: z.string().trim().min(1).max(40),
  title: z.string().trim().min(3).max(240),
  body: z.string().trim().min(3).max(3500),
  severity: z.enum(['INFO','WARNING','CRITICAL']).optional(),
  source: z.string().trim().max(120).optional(),
  metadata: z.record(z.string(), z.unknown()).optional(),
});

export async function GET() {
  try {
    const actor = await requirePermissionSession(PERMISSIONS.BOT_OPERATIONS);
    const events = await db.alertIntelligenceEvent.findMany({ where:{ OR:[{userId:actor.userId},{userId:null}] }, orderBy:{createdAt:'desc'}, take:50 });
    return NextResponse.json({ok:true,version:'8.9.0',events});
  } catch (e) {
    return NextResponse.json({ok:false,error:['AUTH_REQUIRED','FORBIDDEN'].includes(String(e instanceof Error?e.message:e)) ? String(e instanceof Error?e.message:e) : 'ALERT_QUERY_FAILED'},{status:authStatus(e)});
  }
}

export async function POST(req: Request) {
  try {
    const actor = await requirePermissionSession(PERMISSIONS.BOT_OPERATIONS);
    const input = schema.parse(await req.json());
    const decision = evaluateAlertSignal(input);
    const previous = await db.alertIntelligenceEvent.findFirst({ where:{dedupeKey:decision.dedupeKey,status:'TRIGGERED'}, orderBy:{createdAt:'desc'}, select:{deliveredAt:true} });
    const cfg = await getGatewayConfig();
    const deliver = cfg.enabled && Boolean(cfg.officialBotToken && cfg.officialChatId) && shouldDeliverAlert(decision, previous?.deliveredAt);
    let delivered = 0, failed = 0;
    if (deliver) {
      const result = await sendGatewayText({ eventKey:`official:intelligence:${decision.dedupeKey}`, chatId:cfg.officialChatId, text:`BLACKBOX ALERT [${decision.severity}]\n${decision.title}\n\n${decision.body}`, kind:'OFFICIAL_BROADCAST', side:'OFFICIAL' });
      delivered = result.ok ? 1 : 0; failed = result.ok ? 0 : 1;
    }
    const event = await db.alertIntelligenceEvent.create({ data:{userId:actor.userId,alertKey:decision.alertKey,dedupeKey:decision.dedupeKey,version:decision.version,severity:decision.severity,status:deliver ? (failed && !delivered ? 'BLOCKED' : 'TRIGGERED') : decision.status,title:decision.title,body:decision.body,reason:deliver ? decision.reason : (cfg.enabled && cfg.officialBotToken && cfg.officialChatId ? 'DEDUPLICATED_OR_SUPPRESSED' : 'OFFICIAL_TELEGRAM_NOT_CONFIGURED'),source:input.source,metadata:{...(input.metadata||{}),telegram:{configured:Boolean(cfg.enabled && cfg.officialBotToken && cfg.officialChatId),delivered,failed}},observedAt:new Date(decision.observedAt),deliveredAt:delivered > 0 ? new Date() : null} });
    await db.auditLog.create({data:{actorId:actor.userId,action:'ALERT_INTELLIGENCE_EVALUATED',targetType:'ALERT_INTELLIGENCE_EVENT',targetId:event.id,metadata:{status:event.status,severity:event.severity,telegramDelivered:delivered,telegramFailed:failed}}});
    return NextResponse.json({ok:true,event,telegram:{configured:Boolean(cfg.enabled && cfg.officialBotToken && cfg.officialChatId),delivered,failed}});
  } catch (e) {
    if (e instanceof z.ZodError) return NextResponse.json({ok:false,error:'INPUT_TIDAK_VALID'},{status:400});
    return NextResponse.json({ok:false,error:['AUTH_REQUIRED','FORBIDDEN'].includes(String(e instanceof Error?e.message:e)) ? String(e instanceof Error?e.message:e) : 'ALERT_EVALUATION_FAILED'},{status:authStatus(e)});
  }
}
