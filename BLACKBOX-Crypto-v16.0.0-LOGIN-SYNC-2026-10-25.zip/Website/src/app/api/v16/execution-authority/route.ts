import { NextResponse } from 'next/server';
import { requireVerifiedSession } from '@/lib/auth';
import { evaluateReleaseExecutionAuthority } from '@/lib/execution-authority';
export const dynamic='force-dynamic';
export async function GET(){try{await requireVerifiedSession(); const result=evaluateReleaseExecutionAuthority({realTradingEnabled:process.env.REAL_TRADING_ENABLED==='true',productionReady:process.env.REAL_TRADING_PRODUCTION_READY==='true',certificationMode:process.env.REAL_CERTIFICATION_MODE==='true',externalCertification:process.env.V16_EXTERNAL_CERTIFICATION==='true',reconciliationMatched:false,protectiveExit:false}); return NextResponse.json({ok:true,contract:'16.0.0',authority:result},{headers:{'cache-control':'no-store'}})}catch{return NextResponse.json({ok:false,error:'RELEASE_AUTHORITY_UNAVAILABLE'},{status:503})}}
