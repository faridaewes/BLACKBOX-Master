import { NextResponse } from 'next/server';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { phaseReadiness } from '@/lib/v16/phase-services';
export const dynamic='force-dynamic';
export async function GET(){try{await requireVerifiedSession(); const readiness=await phaseReadiness(); return NextResponse.json({ok:true,...readiness},{headers:{'cache-control':'no-store'}})}catch(e){return NextResponse.json({ok:false,error:'V16_PHASE_READINESS_UNAVAILABLE'},{status:authStatus(e)})}}
