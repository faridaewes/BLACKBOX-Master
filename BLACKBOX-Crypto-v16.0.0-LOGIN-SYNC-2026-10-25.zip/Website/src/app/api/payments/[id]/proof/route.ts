import {NextResponse} from 'next/server';
import {db} from '@/lib/prisma';
import {requireSession,authStatus} from '@/lib/auth';
import {hasPermission,PERMISSIONS} from '@/lib/access-control';
import {readPaymentProof} from '@/lib/payment-storage';
export async function GET(_req:Request,{params}:{params:Promise<{id:string}>}){try{const s=await requireSession();const {id}=await params;const row=await db.paymentOrder.findUnique({where:{id},select:{userId:true,proofStorageRef:true,proofMimeType:true}});if(!row||!row.proofStorageRef)return NextResponse.json({ok:false,error:'PROOF_NOT_FOUND'},{status:404});const allowed=row.userId===s.userId||await hasPermission(s.userId,PERMISSIONS.PAYMENT_REVIEW);if(!allowed)return NextResponse.json({ok:false,error:'FORBIDDEN'},{status:403});const data=await readPaymentProof(row.proofStorageRef);return new NextResponse(data,{status:200,headers:{'Content-Type':row.proofMimeType||'application/octet-stream','Cache-Control':'private,no-store','Content-Disposition':'inline'}});}catch(e){return NextResponse.json({ok:false,error:'PROOF_READ_FAILED'},{status:authStatus(e)})}}
