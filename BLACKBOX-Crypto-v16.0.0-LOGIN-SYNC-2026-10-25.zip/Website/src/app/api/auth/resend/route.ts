import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { clientIp } from '@/lib/rate-limit';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { issueVerification, sendEmailOtp, sendSmsOtp } from '@/lib/verification';
const schema=z.object({userId:z.string().min(1),channel:z.enum(['EMAIL','PHONE']),phoneOtpChannel:z.enum(['WHATSAPP','SMS','AUTO']).optional()});
export async function POST(req:Request){try{const rl=await distributedRateLimit(`otp-resend:${clientIp(req)}`,6,15*60,{onBackendFailure:'closed'});if(!rl.ok)return NextResponse.json({ok:false,error:'TERLALU_BANYAK_PERMINTAAN',retryAfterSec:rl.retryAfterSec},{status:429});const b=schema.parse(await req.json());
    const perUser=await distributedRateLimit(`otp-resend-user:${b.userId}`,3,15*60,{onBackendFailure:'closed'});
    if(!perUser.ok)return NextResponse.json({ok:false,error:'TERLALU_BANYAK_PERMINTAAN',retryAfterSec:perUser.retryAfterSec},{status:429});
    const u=await db.user.findUnique({where:{id:b.userId},select:{email:true,phone:true,status:true,emailVerifiedAt:true,phoneVerifiedAt:true}});
    const latest=await db.verificationToken.findFirst({where:{userId:b.userId,channel:b.channel,consumedAt:null},orderBy:{createdAt:'desc'},select:{createdAt:true}});
    if(latest && Date.now()-latest.createdAt.getTime()<60_000){
      const retryAfterSec=Math.max(1,Math.ceil((60_000-(Date.now()-latest.createdAt.getTime()))/1000));
      return NextResponse.json({ok:false,error:'OTP_RESEND_COOLDOWN',retryAfterSec},{status:429});
    }
    // Do not expose whether an arbitrary user id exists. Resend is only useful for
    // accounts still pending on the requested channel.
    if(!u || ['DISABLED','SUSPENDED'].includes(u.status) || (b.channel==='EMAIL' && u.emailVerifiedAt) || (b.channel==='PHONE' && u.phoneVerifiedAt))return NextResponse.json({ok:true,channel:b.channel,sent:false});
    const token=await issueVerification(b.userId,b.channel);const sent=b.channel==='EMAIL'?await sendEmailOtp(u.email,token):await sendSmsOtp(u.phone,token,u.email,b.phoneOtpChannel||'AUTO');return NextResponse.json({ok:true,channel:b.channel,sent:sent.sent,...(process.env.NODE_ENV!=='production'?{devToken:sent.devToken}: {})});}catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:400});}}
