import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { clientIp, hashRateLimitIdentifier } from '@/lib/rate-limit';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { issueVerification, sendPasswordResetOtp } from '@/lib/verification';
import { notifyUser } from '@/lib/notify-user';

const schema = z.object({ email: z.string().email() });
const generic = { ok: true, message: 'Jika email terdaftar, kode reset telah dikirim.' };

export async function POST(req: Request) {
  try {
    const rl = await distributedRateLimit(`password-reset:${clientIp(req)}`, 20, 15 * 60, { onBackendFailure: 'closed' });
    if (!rl.ok) return NextResponse.json({ ok: false, error: 'TERLALU_BANYAK_PERMINTAAN', retryAfterSec: rl.retryAfterSec }, { status: 429 });
    const { email } = schema.parse(await req.json());
    const normalizedEmail = email.toLowerCase().trim();
    const accountRl = await distributedRateLimit(`password-reset-account:${hashRateLimitIdentifier(normalizedEmail)}`, 5, 15 * 60, { onBackendFailure: 'closed' });
    if (!accountRl.ok) return NextResponse.json(generic, { status: 200, headers: { 'Retry-After': String(accountRl.retryAfterSec) } });
    const user = await db.user.findUnique({ where: { email: normalizedEmail }, select: { id: true, email: true, status: true } });
    if (!user || user.status === 'DISABLED') return NextResponse.json(generic);
    const token = await issueVerification(user.id, 'PASSWORD_RESET');
    const sent = await sendPasswordResetOtp(user.email, token);
    await notifyUser({
      userId: user.id,
      title: 'Permintaan reset password',
      body: 'Kami menerima permintaan reset password. Cek email Anda untuk kode OTP. Jika bukan Anda, segera amankan akun.',
      email: user.email,
      emailSubject: 'BLACKBOX — Reset password',
      type: 'PASSWORD_RESET',
    }).catch(() => {});
    return NextResponse.json({ ...generic, sent: sent.sent, ...(process.env.NODE_ENV !== 'production' ? { devToken: sent.devToken } : {}) });
  } catch (e) {
    if (String(e).includes('SMTP_NOT_CONFIGURED')) return NextResponse.json({ ok: false, error: 'RESET_EMAIL_NOT_CONFIGURED' }, { status: 503 });
    return NextResponse.json({ ok: false, error: 'RESET_REQUEST_FAILED' }, { status: 400 });
  }
}
