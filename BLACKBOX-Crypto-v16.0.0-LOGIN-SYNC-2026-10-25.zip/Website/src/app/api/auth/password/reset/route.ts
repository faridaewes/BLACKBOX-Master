import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { hashPassword } from '@/lib/auth';
import { validatePassword } from '@/lib/password-policy';
import { consumeVerification } from '@/lib/verification';
import { clientIp, hashRateLimitIdentifier } from '@/lib/rate-limit';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';

const schema = z.object({ email: z.string().email(), code: z.string().regex(/^\d{6}$/), newPassword: z.string().min(12).max(128) });
export async function POST(req: Request) {
  try {
    const rl = await distributedRateLimit(`password-reset-confirm-ip:${clientIp(req)}`, 30, 15 * 60, { onBackendFailure: 'closed' });
    if (!rl.ok) return NextResponse.json({ ok: false, error: 'TERLALU_BANYAK_PERMINTAAN', retryAfterSec: rl.retryAfterSec }, { status: 429 });
    const b = schema.parse(await req.json());
    const normalizedEmail = b.email.toLowerCase().trim();
    const accountRl = await distributedRateLimit(`password-reset-confirm-account:${hashRateLimitIdentifier(normalizedEmail)}`, 8, 15 * 60, { onBackendFailure: 'closed' });
    if (!accountRl.ok) return NextResponse.json({ ok: false, error: 'TERLALU_BANYAK_PERMINTAAN', retryAfterSec: accountRl.retryAfterSec }, { status: 429 });
    const passwordError = validatePassword(b.newPassword);
    if (passwordError) return NextResponse.json({ ok: false, error: passwordError }, { status: 400 });
    const user = await db.user.findUnique({ where: { email: normalizedEmail }, select: { id: true, email: true, role: true, name: true, status: true } });
    if (!user || user.status === 'DISABLED') return NextResponse.json({ ok: false, error: 'RESET_CODE_INVALID' }, { status: 400 });
    const valid = await consumeVerification(user.id, 'PASSWORD_RESET', b.code);
    if (!valid) return NextResponse.json({ ok: false, error: 'RESET_CODE_INVALID_OR_EXPIRED' }, { status: 403 });
    const passwordHash = await hashPassword(b.newPassword);
    await db.$transaction([
      db.user.update({ where: { id: user.id }, data: { passwordHash, mustChangePassword: false, sessionVersion: { increment: 1 } } }),
      db.session.updateMany({ where: { userId: user.id, revokedAt: null }, data: { revokedAt: new Date() } }),
      db.auditLog.create({ data: { actorId: user.id, action: 'PASSWORD_RESET_COMPLETED', targetType: 'USER', targetId: user.id, metadata: { method: 'EMAIL_OTP' } } }),
      db.userActivityEvent.create({ data: { userId: user.id, type: 'PASSWORD_RESET_COMPLETED' } }),
    ]);
    return NextResponse.json({ ok: true });
  } catch (e) { return NextResponse.json({ ok: false, error: 'RESET_FAILED' }, { status: 400 }); }
}
