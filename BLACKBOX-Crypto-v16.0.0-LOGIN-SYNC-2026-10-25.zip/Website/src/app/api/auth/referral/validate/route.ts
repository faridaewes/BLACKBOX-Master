import { NextResponse } from 'next/server';
import { z } from 'zod';
import { clientIp } from '@/lib/rate-limit';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { validateReferralCode } from '@/lib/referral-registration-v99';

const schema = z.object({ referralCode: z.string().trim().min(1).max(64) });

export async function POST(req: Request) {
  try {
    const rl = await distributedRateLimit(`referral-validate:${clientIp(req)}`, 30, 15 * 60, { onBackendFailure: 'closed' });
    if (!rl.ok) return NextResponse.json({ ok: false, error: 'TOO_MANY_ATTEMPTS', retryAfterSec: rl.retryAfterSec }, { status: 429 });
    const body = schema.parse(await req.json().catch(() => ({})));
    const result = await validateReferralCode(body.referralCode);
    return NextResponse.json({ ok: true, ...result }, { status: result.valid ? 200 : 400, headers: { 'cache-control': 'no-store' } });
  } catch (e) {
    if (e instanceof z.ZodError) return NextResponse.json({ ok: false, error: 'REFERRAL_CODE_INVALID' }, { status: 400 });
    return NextResponse.json({ ok: false, error: 'REFERRAL_VALIDATION_FAILED' }, { status: 400 });
  }
}
