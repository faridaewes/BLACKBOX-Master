import { timingSafeEqual } from 'node:crypto';
import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import { createRemoteJWKSet, jwtVerify } from 'jose';
import { db } from '@/lib/prisma';
import { createSession, authStatus } from '@/lib/auth';
import { clientIp } from '@/lib/rate-limit';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { GOOGLE_NONCE_COOKIE, GOOGLE_NONCE_COOKIE_PATH } from '@/lib/google-oauth-nonce';

export const runtime = 'nodejs';

const issuer = 'https://accounts.google.com';
const jwks = createRemoteJWKSet(new URL('https://www.googleapis.com/oauth2/v3/certs'));

function sameNonce(a: string, b: string): boolean {
  const left = Buffer.from(a, 'utf8');
  const right = Buffer.from(b, 'utf8');
  return left.length > 0 && left.length === right.length && timingSafeEqual(left, right);
}

function reply(body: unknown, status = 200) {
  const res = NextResponse.json(body, { status, headers: { 'Cache-Control': 'no-store', Pragma: 'no-cache' } });
  // A challenge is one-use from the browser's perspective. Clear it on both
  // success and failure so the same browser cannot casually replay the POST.
  res.cookies.set(GOOGLE_NONCE_COOKIE, '', {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: GOOGLE_NONCE_COOKIE_PATH,
    maxAge: 0,
  });
  return res;
}

export async function POST(req: Request) {
  try {
    const rl = await distributedRateLimit(`google-login:${clientIp(req)}`, 12, 10 * 60, { onBackendFailure: 'closed' });
    if (!rl.ok) {
      return reply(
        { ok: false, error: rl.backendUnavailable ? 'AUTH_RATE_LIMIT_UNAVAILABLE' : 'TOO_MANY_REQUESTS', retryAfterSec: rl.retryAfterSec },
        rl.backendUnavailable ? 503 : 429,
      );
    }

    const jar = await cookies();
    const issuedNonce = jar.get(GOOGLE_NONCE_COOKIE)?.value || '';
    const b = await req.json().catch(() => ({} as Record<string, unknown>));
    const clientNonce = String(b.nonce || '');
    if (!issuedNonce || !clientNonce || !sameNonce(issuedNonce, clientNonce)) {
      return reply({ ok: false, error: 'GOOGLE_NONCE_INVALID_OR_EXPIRED' }, 401);
    }

    const credential = String(b.credential || '');
    if (!credential) return reply({ ok: false, error: 'GOOGLE_CREDENTIAL_REQUIRED' }, 400);

    const aud = (process.env.GOOGLE_CLIENT_ID || process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID || '').trim();
    if (!aud) return reply({ ok: false, error: 'GOOGLE_LOGIN_NOT_CONFIGURED' }, 503);

    const { payload } = await jwtVerify(credential, jwks, { issuer, audience: aud, nonce: issuedNonce });
    if (payload.email_verified !== true || !payload.email || !payload.sub) {
      return reply({ ok: false, error: 'GOOGLE_EMAIL_NOT_VERIFIED' }, 401);
    }

    const email = String(payload.email).trim().toLowerCase();
    const u = await db.user.findUnique({ where: { email } });
    if (!u) {
      return reply({
        ok: false,
        error: 'GOOGLE_ACCOUNT_NOT_REGISTERED',
        registrationRequired: true,
        email,
        name: String(payload.name || ''),
        picture: String(payload.picture || ''),
      }, 404);
    }
    // Do not create sessions for pending, suspended, disabled, or unknown states.
    if (u.status !== 'ACTIVE') return reply({ ok: false, error: 'ACCOUNT_NOT_ACTIVE' }, 403);

    await createSession({ id: u.id, role: u.role, email: u.email, name: u.name }, {
      ip: clientIp(req),
      userAgent: req.headers.get('user-agent') || '',
      deviceLabel: req.headers.get('x-device-name') || 'Google / Web',
    });
    await db.userActivityEvent.create({
      data: { userId: u.id, type: 'LOGIN_GOOGLE', metadata: { provider: 'google', loggedAt: new Date().toISOString() } },
    }).catch(() => {});

    return reply({
      ok: true,
      role: u.role,
      mustChangePassword: u.mustChangePassword,
      emailVerified: true,
      phoneVerified: !!u.phoneVerifiedAt,
      verificationRequired: u.role === 'USER' && !u.phoneVerifiedAt,
    });
  } catch (e) {
    const status = authStatus(e) === 401 ? 401 : 400;
    return reply({ ok: false, error: 'GOOGLE_LOGIN_FAILED' }, status);
  }
}
