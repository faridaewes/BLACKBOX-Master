import { randomBytes } from 'node:crypto';
import { NextResponse } from 'next/server';
import { clientIp } from '@/lib/rate-limit';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { GOOGLE_NONCE_COOKIE, GOOGLE_NONCE_COOKIE_PATH, GOOGLE_NONCE_TTL_SECONDS } from '@/lib/google-oauth-nonce';

export const runtime = 'nodejs';


/**
 * Issue a short-lived, browser-bound nonce for Google Identity Services.
 * The matching HttpOnly cookie is the server-side trust anchor; a value sent
 * only in the request body is not sufficient to authenticate the challenge.
 */
export async function GET(req: Request) {
  try {
    const rl = await distributedRateLimit(
      `google-nonce:${clientIp(req)}`,
      30,
      10 * 60,
      { onBackendFailure: 'closed' },
    );
    if (!rl.ok) {
      return NextResponse.json(
        { ok: false, error: rl.backendUnavailable ? 'AUTH_RATE_LIMIT_UNAVAILABLE' : 'TOO_MANY_REQUESTS', retryAfterSec: rl.retryAfterSec },
        { status: rl.backendUnavailable ? 503 : 429, headers: { 'Cache-Control': 'no-store', 'Retry-After': String(rl.retryAfterSec) } },
      );
    }

    const nonce = randomBytes(32).toString('base64url');
    const res = NextResponse.json({ ok: true, nonce }, { headers: { 'Cache-Control': 'no-store', Pragma: 'no-cache' } });
    res.cookies.set(GOOGLE_NONCE_COOKIE, nonce, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: GOOGLE_NONCE_COOKIE_PATH,
      maxAge: GOOGLE_NONCE_TTL_SECONDS,
    });
    return res;
  } catch {
    return NextResponse.json({ ok: false, error: 'GOOGLE_NONCE_UNAVAILABLE' }, { status: 503, headers: { 'Cache-Control': 'no-store' } });
  }
}
