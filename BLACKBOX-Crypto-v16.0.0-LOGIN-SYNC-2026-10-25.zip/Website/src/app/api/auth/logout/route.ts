import {NextResponse} from "next/server";
import {logout, requireSession} from "@/lib/auth";
import {db} from "@/lib/prisma";
export async function POST(){
  try { const s=await requireSession(); await db.userActivityEvent.create({data:{userId:s.userId,type:"LOGOUT"}}).catch(()=>{}); await db.auditLog.create({data:{actorId:s.userId,action:"LOGOUT",targetType:"USER",targetId:s.userId}}).catch(()=>{}); } catch {}
  await logout();
  return NextResponse.json({ok:true});
}