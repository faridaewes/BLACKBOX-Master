import { NextResponse } from 'next/server';
import { z } from 'zod';
import { apiError,  authStatus, createSession, requireSession, verifyPassword } from '@/lib/auth';
import { db } from '@/lib/prisma';
import { decryptMfaSecret, verifyTotp } from '@/lib/mfa';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { clientIp } from '@/lib/rate-limit';

const schema = z.object({
  currentPassword: z.string().min(8).max(128),
  currentCode: z.string().regex(/^\d{6}$/),
});

/** User self-service MFA disable. Requires the current password and current TOTP.
 * This never exposes or transfers the MFA secret and never enables a replacement MFA.
 */
export async function POST(req: Request) {
  try {
    const s = await requireSession();
    const rl = await distributedRateLimit(`mfa-disable:${clientIp(req)}:${s.userId}`, 5, 15 * 60, { onBackendFailure: 'closed' });
    if (!rl.ok) return NextResponse.json({ ok: false, error: 'TOO_MANY_ATTEMPTS' }, { status: 429 });

    const b = schema.parse(await req.json());
    const u = await db.user.findUnique({ where: { id: s.userId } });
    if (!u) return NextResponse.json({ ok: false, error: 'USER_NOT_FOUND' }, { status: 404 });
    if (!u.mfaEnabled || !u.mfaSecretEnc) {
      return NextResponse.json({ ok: false, error: 'MFA_NOT_ACTIVE' }, { status: 409 });
    }
    if (!(await verifyPassword(b.currentPassword, u.passwordHash))) {
      return NextResponse.json({ ok: false, error: 'CURRENT_PASSWORD_INVALID' }, { status: 403 });
    }
    if (!verifyTotp(decryptMfaSecret(u.mfaSecretEnc), b.currentCode)) {
      return NextResponse.json({ ok: false, error: 'CURRENT_MFA_CODE_INVALID' }, { status: 403 });
    }

    const now = new Date();
    await db.$transaction([
      db.user.update({
        where: { id: u.id },
        data: {
          mfaEnabled: false,
          mfaSecretEnc: null,
          mfaRecoveryRequired: false,
          sessionVersion: { increment: 1 },
        },
      }),
      db.session.updateMany({ where: { userId: u.id, revokedAt: null }, data: { revokedAt: now } }),
      db.auditLog.create({
        data: {
          actorId: u.id,
          action: 'MFA_DISABLED_BY_USER',
          targetType: 'USER',
          targetId: u.id,
          metadata: { selfService: true, sessionsRevoked: true },
        },
      }),
      db.userActivityEvent.create({
        data: { userId: u.id, type: 'MFA_DISABLED_BY_USER', metadata: { selfService: true, sessionsRevoked: true } },
      }),
    ]);

    // The security downgrade is authenticated again by the same password + TOTP proof.
    // The old session is invalidated; issue a fresh ordinary session with MFA disabled.
    const fresh = await db.user.findUnique({ where: { id: u.id }, select: { id: true, role: true, email: true, name: true } });
    if (fresh) {
      await createSession(fresh, {
        ip: clientIp(req),
        userAgent: req.headers.get('user-agent') || '',
        deviceLabel: req.headers.get('x-device-name') || 'Web / MFA Disabled',
      });
    }

    return NextResponse.json({ ok: true, enabled: false, requiresManualReenable: true });
  } catch (e) {
    if (e instanceof z.ZodError) return NextResponse.json({ ok: false, error: 'Input tidak valid' }, { status: 400 });
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}
