import {NextResponse} from 'next/server';import {db} from '@/lib/prisma';import {createSession,verifyPassword} from '@/lib/auth';import {clientIp,hashRateLimitIdentifier} from '@/lib/rate-limit';import crypto from 'node:crypto';
import {distributedRateLimit} from '@/lib/distributed-rate-limit';import {decryptMfaSecret,verifyTotp} from '@/lib/mfa';
import {sendLoginSecurityNotice} from '@/lib/verification';
import {noteAuthFailureAndMaybeProtect} from '@/lib/auto-protect';
import {applyLoginFailureProtect, clearLoginFailures} from '@/lib/login-protect';
export async function POST(req:Request){try{const {email,username,identifier,password,mfaCode}=await req.json();const loginId=String(identifier||email||username||'').trim();if(!loginId||!password)return NextResponse.json({ok:false,error:'Email dan password wajib.'},{status:400});const normalized=loginId.toLowerCase();const ipKey=clientIp(req);const ipRl=await distributedRateLimit(`login-ip:${ipKey}`,40,10*60,{onBackendFailure:'closed'});if(!ipRl.ok)return NextResponse.json({ok:false,error:`Terlalu banyak percobaan dari jaringan ini. Coba lagi dalam ${ipRl.retryAfterSec} detik.`},{status:429});const accountRl=await distributedRateLimit(`login-account:${hashRateLimitIdentifier(normalized)}`,8,10*60,{onBackendFailure:'closed'});if(!accountRl.ok)return NextResponse.json({ok:false,error:`Terlalu banyak percobaan untuk akun ini. Coba lagi dalam ${accountRl.retryAfterSec} detik.`},{status:429});const u=normalized.includes('@') ? await db.user.findUnique({where:{email:normalized}}) : await db.user.findUnique({where:{username:normalized}});if(!u||!(await verifyPassword(String(password),u.passwordHash))){ if(u) await db.userActivityEvent.create({data:{userId:u.id,type:'LOGIN_FAILED',metadata:{reason:'INVALID_CREDENTIALS',ipHash:crypto.createHash('sha256').update(clientIp(req)).digest('hex').slice(0,32)}}}).catch(()=>{}); await noteAuthFailureAndMaybeProtect(crypto.createHash('sha256').update(clientIp(req)).digest('hex').slice(0,32)).catch(()=>{});
      const protect = await applyLoginFailureProtect(normalized, u?.id || null).catch(()=>({fails:0,stage:0 as const}));
      if(protect.stage>=1){
        return NextResponse.json({
          ok:false,
          error:'Login ditolak.',
          code:'SUGGEST_PASSWORD_RESET',
          suggestPasswordReset:true,
          message: protect.stage>=2
            ? 'Percobaan gagal berulang. Demi keamanan, trading akun ini dihentikan sementara. Silakan reset password lalu hubungi support.'
            : 'Terlalu banyak percobaan gagal. Demi keamanan, silakan reset password akun Anda.',
          tradeFrozen: protect.stage>=2,
          stage: protect.stage,
          fails: protect.fails,
        },{status:401});
      }
      return NextResponse.json({ok:false,error:'Login ditolak.'},{status:401}); }if(['SUSPENDED','DISABLED'].includes(u.status)){ await db.userActivityEvent.create({data:{userId:u.id,type:'LOGIN_BLOCKED',metadata:{status:u.status}}}).catch(()=>{}); return NextResponse.json({ok:false,error:u.status==='SUSPENDED'?'ACCOUNT_SUSPENDED':'ACCOUNT_NOT_ACTIVE'},{status:403}); }if(u.mfaEnabled){if(!mfaCode||!u.mfaSecretEnc||!verifyTotp(decryptMfaSecret(u.mfaSecretEnc),String(mfaCode)))return NextResponse.json({ok:false,error:'MFA_REQUIRED_OR_INVALID'},{status:401});}clearLoginFailures(normalized);
await createSession({id:u.id,role:u.role,email:u.email,name:u.name},{ip:clientIp(req),userAgent:req.headers.get('user-agent')||'',deviceLabel:req.headers.get('x-device-name')||'Web / Unknown Device'});await db.userActivityEvent.create({data:{userId:u.id,type:'LOGIN',metadata:{ipHash:crypto.createHash('sha256').update(clientIp(req)).digest('hex').slice(0,32),userAgent:req.headers.get('user-agent')||'',loggedAt:new Date().toISOString()}}}).catch(()=>{});
await sendLoginSecurityNotice({email:u.email,name:u.name,role:u.role,loggedAt:new Date(),ipLabel:crypto.createHash('sha256').update(clientIp(req)).digest('hex').slice(0,16),userAgent:req.headers.get('user-agent')||''}).catch(()=>{});
return NextResponse.json({ok:true,role:u.role,mustChangePassword:u.mustChangePassword,emailVerified:!!u.emailVerifiedAt,phoneVerified:!!u.phoneVerifiedAt,verificationRequired:u.role==='USER'&&(!u.emailVerifiedAt||!u.phoneVerifiedAt),mfaRecoveryRequired:u.mfaRecoveryRequired===true});}catch(e){return NextResponse.json({ok:false,error:'Server error'},{status:500});}}
