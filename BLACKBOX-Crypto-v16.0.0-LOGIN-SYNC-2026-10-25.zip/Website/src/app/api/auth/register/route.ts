import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';
import { apiError,  hashPassword } from '@/lib/auth';
import { clientIp, hashRateLimitIdentifier } from '@/lib/rate-limit';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { issueVerificationWithTx, sendEmailOtp, sendSmsOtp } from '@/lib/verification';
import { recordConsentWithTx, recordConsentBundleWithTx } from '@/lib/consent';
import { validatePassword } from '@/lib/password-policy';
import { ensureUserVault, removeUserVault } from '@/lib/user-vault';
import { onRegistration } from '@/lib/referral-reward-v91';
import { recordReferralAttribution } from '@/lib/referral-registration-v99';
import { recordRegistrationOSEvent, resolveReferralForRegistration } from '@/lib/referral-os-v100';
import { notifyUser } from '@/lib/notify-user';

export async function POST(req: Request) {
  try {
    const ip = clientIp(req);
    if (process.env.NODE_ENV === 'production' && (ip === 'direct-unknown' || ip === 'proxy-unknown')) {
      return NextResponse.json({ ok: false, error: 'REGISTRATION_TRUSTED_PROXY_REQUIRED' }, { status: 503 });
    }
    const rl = await distributedRateLimit(`register:${ip}`, 5, 60 * 60, { onBackendFailure: 'closed' });
    if (rl.backendUnavailable) return NextResponse.json({ ok: false, error: 'REGISTRATION_RATE_LIMIT_UNAVAILABLE' }, { status: 503 });
    if (!rl.ok) return NextResponse.json({ ok: false, error: 'Terlalu banyak registrasi dari alamat ini. Coba lagi nanti.' }, { status: 429 });

    const b = await req.json();
    const email = String(b.email || '').trim().toLowerCase();
    const phone = String(b.phone || '').trim();
    const phoneOtpChannel = (['WHATSAPP','SMS'].includes(String(b.phoneOtpChannel||'').toUpperCase()) ? String(b.phoneOtpChannel).toUpperCase() : 'AUTO') as 'WHATSAPP'|'SMS'|'AUTO';
    const name = String(b.name || '').trim();
    const password = String(b.password || '');
    const username = String(b.username || '').trim().toLowerCase();
    const referralCode = String(b.referralCode || '').trim().toUpperCase();
    const referralSource = String(b.referralSource || '').trim() || null;
    const agreementAccepted = b.agreementAccepted === true;
    const advisorRegistrationAccepted = b.advisorRegistrationAccepted === true;
    const tradingRulesAccepted = b.tradingRulesAccepted === true;
    if (!agreementAccepted || !advisorRegistrationAccepted || !tradingRulesAccepted) return NextResponse.json({ ok:false, error:'REGISTRATION_AGREEMENTS_REQUIRED' }, {status:400});

    if (!email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || !phone || !name || !username || !password) {
      return NextResponse.json({ ok: false, error: 'Nama, username, email, HP dan password wajib.' }, { status: 400 });
    }
    if (!/^[a-z0-9_-]{4,24}$/.test(username)) return NextResponse.json({ ok: false, error: 'Username 4-24 karakter: huruf kecil, angka, _ atau -.' }, { status: 400 });
    const passwordError = validatePassword(password);
    if (passwordError) return NextResponse.json({ ok: false, error: passwordError }, { status: 400 });
    if (!/^\+?[1-9]\d{7,14}$/.test(phone)) return NextResponse.json({ ok: false, error: 'Format nomor HP tidak valid.' }, { status: 400 });

    const emailLimit = await distributedRateLimit(`register-email:${hashRateLimitIdentifier(email)}`, 3, 60 * 60, { onBackendFailure: 'closed' });
    const phoneLimit = await distributedRateLimit(`register-phone:${hashRateLimitIdentifier(phone)}`, 3, 60 * 60, { onBackendFailure: 'closed' });
    if (emailLimit.backendUnavailable || phoneLimit.backendUnavailable) return NextResponse.json({ ok: false, error: 'REGISTRATION_RATE_LIMIT_UNAVAILABLE' }, { status: 503 });
    if (!emailLimit.ok || !phoneLimit.ok) return NextResponse.json({ ok: false, error: 'REGISTRATION_IDENTIFIER_RATE_LIMITED' }, { status: 429 });

    const exists = await db.user.findFirst({ where: { OR: [{ email }, { phone }, { username }] }, select: { id: true } });
    if (exists) return NextResponse.json({ ok: false, error: 'Email, username atau nomor HP sudah terdaftar.' }, { status: 409 });

    // Registration is evidence-bearing. Do not create an account that can never
    // receive the required registration consent record. This also prevents a
    // missing legal-document configuration from producing a half-registered user.
    const legalDocuments = await db.legalDocument.findMany({ where: { type: { in: ['REGISTRATION','TERMS','PRIVACY','RISK','TRADING_RULES','ALMA_ADVISOR_REGISTRATION'] }, active: true }, orderBy: { createdAt: 'desc' } });
    const legalTypes = new Set(legalDocuments.map((d:any)=>d.type));
    if (['REGISTRATION','TERMS','PRIVACY','RISK','TRADING_RULES','ALMA_ADVISOR_REGISTRATION'].some((type)=>!legalTypes.has(type))) return NextResponse.json({ ok: false, error: 'REGISTRATION_LEGAL_DOCUMENTS_NOT_CONFIGURED' }, { status: 503 });

    // Fail before the database transaction when production verification delivery
    // is not configured. In development the existing dev-token flow remains valid.
    const demoVerificationAllowed = process.env.ALLOW_DEMO_VERIFICATION === 'true'
      && String(process.env.DEPLOYMENT_MODE || '').toLowerCase() === 'demo'
      && process.env.REAL_TRADING_ENABLED !== 'true'
      && process.env.REAL_TRADING_PRODUCTION_READY !== 'true';
    if (process.env.NODE_ENV === 'production' && !demoVerificationAllowed) {
      if (!process.env.SMTP_HOST) return NextResponse.json({ ok: false, error: 'REGISTRATION_EMAIL_VERIFICATION_NOT_CONFIGURED' }, { status: 503 });
      if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN || !process.env.TWILIO_FROM) {
        return NextResponse.json({ ok: false, error: 'REGISTRATION_PHONE_VERIFICATION_NOT_CONFIGURED' }, { status: 503 });
      }
    }

    // Registration, sponsor resolution, immutable attribution and referral rewards
    // are one atomic transaction. If any referral step fails, no orphan account is created.
    let result: any;
    let createdUserForCleanup: any = null;
    try {
      result = await db.$transaction(async (tx: any) => {
        const resolved = await resolveReferralForRegistration(tx, referralCode, referralSource);
        const sponsor = resolved.sponsor;
        const u = await tx.user.create({
          data: {
            email,
            phone,
            name,
            username,
            referralCode: null,
            referredById: sponsor?.id || null,
            passwordHash: await hashPassword(password),
            status: 'PENDING',
          },
        });
        createdUserForCleanup = u;
        // All database-side registration evidence is created in the same transaction.
        // External delivery is deliberately after commit because SMTP/SMS cannot be
        // part of a PostgreSQL transaction; a delivery failure leaves a valid PENDING
        // account that can safely use the resend-verification flow.
        await ensureUserVault({ id: u.id, name: u.name, email: u.email, phone: u.phone, role: u.role, status: u.status, createdAt: u.createdAt });
        const registrationMetadata={ email, phone, name, referralCode: referralCode || null, sponsorUsername: sponsor?.username || null, referralSource: resolved.source, acknowledgementText:'Saya menyatakan telah membaca, memahami, dan menyetujui seluruh dokumen registrasi, risiko, privasi, Trading Rules, dan kewajiban pendaftaran Penasihat Berjangka secara sadar, sukarela, dan tanpa paksaan. Saya menerima risiko penggunaan layanan dan, sejauh diperbolehkan dan dapat diberlakukan menurut hukum, membebaskan BLACKBOX Technology dan pihak terkait dari tuntutan, klaim, atau permintaan ganti rugi sehubungan dengan penggunaan layanan, koneksi, konfigurasi, instruksi, keputusan, atau risiko yang saya pilih, setujui, konfirmasi, izinkan, atau terima; hak dan tanggung jawab yang wajib menurut hukum tetap berlaku.', consentMethod:'EXPLICIT_CHECKBOX', readAt:new Date().toISOString(), consentContext: b.consentContext || { source: 'WEB_REGISTRATION' } };
        await recordConsentBundleWithTx(tx, req, { id: u.id, name: u.name, email: u.email }, ['REGISTRATION','TERMS','PRIVACY','RISK','TRADING_RULES'], registrationMetadata);
        await recordConsentWithTx(tx, req, { id: u.id, name: u.name, email: u.email }, 'ALMA_ADVISOR_REGISTRATION', { advisorRegistrationAccepted: true, acknowledgementText:'Saya menyatakan secara sadar, sukarela, dan tanpa paksaan memahami serta menyetujui kewajiban pendaftaran pada PT Alma Indonesia Raya untuk fitur yang mensyaratkan hubungan Penasihat Berjangka, termasuk penerimaan risiko dan ketentuan pembebasan tuntutan sejauh diperbolehkan hukum.', consentMethod:'EXPLICIT_CHECKBOX', readAt:new Date().toISOString(), consentContext: b.consentContext || { source: 'WEB_REGISTRATION' } });
        if (sponsor) {
          await recordReferralAttribution(tx, {
            userId: u.id,
            sponsorId: sponsor.id,
            referralCode: sponsor.referralCode || referralCode,
            source: resolved.source,
          });
        }
        await onRegistration(tx, u.id, sponsor?.id || null);
        await recordRegistrationOSEvent(tx, { userId: u.id, sponsorId: sponsor?.id || null, referralCode: resolved.code, source: resolved.source });
        const [emailToken, phoneToken] = await Promise.all([
          issueVerificationWithTx(tx, u.id, 'EMAIL'),
          issueVerificationWithTx(tx, u.id, 'PHONE'),
        ]);
        return { u, emailToken, phoneToken, sponsorUsername: sponsor?.username || null, referralSource: resolved.source };
      }, { isolationLevel: 'Serializable' });
    } catch (error) {
      // The vault is filesystem state, so compensate for a transaction rollback.
      if (createdUserForCleanup) await removeUserVault(createdUserForCleanup).catch(() => {});
      throw error;
    }

    const u = result.u;
    let emailSent: any = { sent:false }, phoneSent: any = { sent:false };
    let emailError: string | null = null, phoneError: string | null = null;
    try { emailSent = await sendEmailOtp(email, result.emailToken); } catch (e) { emailError = String(e instanceof Error ? e.message : e); }
    try { phoneSent = await sendSmsOtp(phone, result.phoneToken, email, phoneOtpChannel); } catch (e) { phoneError = String(e instanceof Error ? e.message : e); }
    const deliveryPending = !emailSent.sent || !phoneSent.sent;
    const agreementText = 'Saya menyatakan telah mendaftar dengan sadar, memahami Trading Rules dan risiko trading, memahami bahwa BLACKBOX tidak menjamin keuntungan dan tidak menghimpun atau mengelola dana pengguna, serta memahami kewajiban pendaftaran layanan Penasihat Berjangka pada PT Alma Indonesia Raya untuk fitur yang terhubung dengan layanan tersebut.';
    const welcome = await (await import('@/lib/registration-welcome')).sendRegistrationWelcome({to:u.email,name:u.name,username:u.username,phone:u.phone,registeredAt:u.createdAt,agreementVersion:'v12.0.8',agreementText}).catch(e=>({sent:false,error:String(e)}));
    if (deliveryPending) {
      await db.auditLog.create({ data:{ actorId:u.id, action:'REGISTRATION_VERIFICATION_DELIVERY_PENDING', targetType:'USER', targetId:u.id, metadata:{ emailSent:emailSent.sent, phoneSent:phoneSent.sent, emailError, phoneError } } }).catch(()=>{});
    }

    try {
      await notifyUser({
        userId: u.id,
        title: 'Selamat datang di BLACKBOX',
        body: 'Registrasi berhasil. Segera verifikasi email dan nomor HP/WhatsApp agar akun aktif penuh. Cek kotak masuk email untuk kode OTP.',
        email,
        emailSubject: 'BLACKBOX — Registrasi berhasil',
        type: 'REGISTER',
      });
    } catch { /* non-fatal */ }

    return NextResponse.json({
      ok: true,
      userId: u.id,
      referral: { applied: Boolean(result.sponsorUsername), sponsorUsername: result.sponsorUsername, source: result.referralSource },
      verification: {
        emailSent: emailSent.sent,
        phoneSent: phoneSent.sent,
        deliveryPending,
        welcomeEmailSent: welcome.sent,
        ...((process.env.NODE_ENV !== 'production' || demoVerificationAllowed) ? { devEmailToken: emailSent.devToken, devPhoneToken: phoneSent.devToken } : {}),
      },
    }, { status: deliveryPending ? 202 : 200 });
  } catch (e) {
    const msg = String(e instanceof Error ? e.message : e);
    if (msg === 'REFERRAL_CODE_NOT_ACTIVE') return NextResponse.json({ ok: false, error: msg }, { status: 400 });
    if (msg.includes('REFERRAL_IDENTIFIER_') || msg.includes('USERNAME_AND_REFERRAL_IDENTIFIER')) return NextResponse.json({ ok: false, error: 'REFERRAL_IDENTIFIER_CONFLICT' }, { status: 409 });
    if ((e as any)?.code === 'P2034') return NextResponse.json({ ok: false, error: 'REGISTRATION_RETRY_REQUIRED' }, { status: 409 });
    if ((e as any)?.code === 'P2002') return NextResponse.json({ ok: false, error: 'EMAIL_USERNAME_PHONE_OR_REFERRAL_ALREADY_EXISTS' }, { status: 409 });
    return NextResponse.json({ ok: false, error: msg }, { status: 500 });
  }
}
