import {NextResponse} from 'next/server';
import {db} from '@/lib/prisma';
import {requireSession,authStatus} from '@/lib/auth';

export async function GET(){
  try{
    const s=await requireSession();
    const u=await db.user.findUnique({where:{id:s.userId},select:{id:true,status:true,emailVerifiedAt:true,phoneVerifiedAt:true,kycStatus:true}});
    if(!u)return NextResponse.json({ok:false,error:'USER_NOT_FOUND'},{status:404});
    return NextResponse.json({ok:true,userId:u.id,status:u.status,emailVerified:!!u.emailVerifiedAt,phoneVerified:!!u.phoneVerifiedAt,verificationRequired:s.role==='USER'&&(!u.emailVerifiedAt||!u.phoneVerifiedAt),kycStatus:u.kycStatus});
  }catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)})}
}
