import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { evaluateAiOpsProposal } from '@/lib/era-release-orchestrator-current';
import { rateLimitUserKey } from '@/lib/rate-limit';
const schema=z.object({action:z.enum(['REFRESH_MARKET_DATA','REBUILD_CACHE','RETRY_FAILED_WORKER','GENERATE_REPORT','OPEN_SUPPORT_ESCALATION','RUN_HEALTH_CHECK']),reason:z.string().trim().min(3).max(500),healthOk:z.boolean(),approval:z.boolean().optional(),evidence:z.record(z.string(),z.unknown()).optional()});
export async function POST(req:Request){try{const s=await requireVerifiedSession();const rl=await distributedRateLimit(rateLimitUserKey(s.userId, "ai-ops"),10,60);if(!rl.ok)return NextResponse.json({ok:false,error:'AI_OPS_RATE_LIMITED',retryAfterSec:rl.retryAfterSec},{status:429});const b=schema.parse(await req.json());const proposal=evaluateAiOpsProposal(b);return NextResponse.json({ok:true,proposal,userId:s.userId},{headers:{'cache-control':'no-store'}})}catch(e){return NextResponse.json({ok:false,error:e instanceof z.ZodError?'AI_OPS_INPUT_INVALID':'AI_OPS_UNAVAILABLE'},{status:e instanceof z.ZodError?400:authStatus(e)})}}
