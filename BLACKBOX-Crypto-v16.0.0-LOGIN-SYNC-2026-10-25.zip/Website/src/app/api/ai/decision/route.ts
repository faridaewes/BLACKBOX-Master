import { NextResponse } from "next/server";
import { apiError,  requireVerifiedSession, authStatus } from "@/lib/auth";
import { decideIntelligence } from "@/lib/ai-v69";
import { rateLimit } from "@/lib/rate-limit";

// Decision Lab: uji satu kandidat secara manual. Dibatasi agar tidak menghabiskan kuota AI gratis.
export async function POST(req: Request) {
  try {
    const s = await requireVerifiedSession();
    const rl = rateLimit(`ai-lab:${s.userId}`, 6, 60_000);
    if (!rl.ok) return NextResponse.json({ ok: false, error: `Terlalu cepat. Coba lagi dalam ${rl.retryAfterSec} detik.` }, { status: 429 });
    const m = await req.json();
    const input = {
      symbol: String(m.symbol || "TEST/SOL").slice(0, 24), priceChange5m: Number(m.priceChange5m) || 0, priceChange1h: Number(m.priceChange1h) || 0,
      liquidityUsd: Number(m.liquidityUsd) || 0, volume24h: Number(m.volume24h) || 0, score: Number(m.score) || 0, minAiScore: Number(m.minAiScore) || 75,
    };
    const out = await decideIntelligence(input, { allowRemote: true });
    return NextResponse.json({ ok: true, ...out });
  } catch (e) { return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) }); }
}
