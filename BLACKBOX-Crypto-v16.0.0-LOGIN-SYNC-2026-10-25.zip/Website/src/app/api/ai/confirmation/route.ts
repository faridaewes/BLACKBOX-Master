import { rateLimitUserKey } from '@/lib/rate-limit';
import { NextResponse } from 'next/server';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { db } from '@/lib/prisma';
import { confirmOpportunity, P7_AI_CONFIRMATION_CONTRACT, P7_AI_CONFIRMATION_VERSION } from '@/lib/ai-confirmation-v120';

export async function GET(req:Request){
  try{
    const s=await requireVerifiedSession();
    const rl=await distributedRateLimit(rateLimitUserKey(s.userId, "ai-confirmation-p7"),10,60);
    if(!rl.ok)return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429,headers:{'Retry-After':String(rl.retryAfterSec)}});
    const u=new URL(req.url);const marketKey=u.searchParams.get('marketKey')||'';const limit=Math.max(1,Math.min(100,Number(u.searchParams.get('limit')||25)));
    if(marketKey){
      const row=await db.opportunityRadarSnapshot.findFirst({where:{marketKey,executionAllowed:false},orderBy:{createdAt:'desc'}});
      if(!row)return NextResponse.json({ok:false,error:'P6_RADAR_SNAPSHOT_NOT_FOUND'},{status:404});
      const decision=confirmOpportunity(row);
      return NextResponse.json({ok:true,version:P7_AI_CONFIRMATION_VERSION,mode:'P7_EVIDENCE_GROUNDED_CONFIRMATION',decision,contract:P7_AI_CONFIRMATION_CONTRACT},{headers:{'Cache-Control':'no-store'}});
    }
    const rows=await db.opportunityRadarSnapshot.findMany({where:{executionAllowed:false,status:{in:['STRONG_WATCH','WATCH']}},orderBy:{createdAt:'desc'},take:100000});
    const decisions=rows.map((row:any)=>confirmOpportunity(row)).sort((a,b)=>b.confirmationStrength-a.confirmationStrength).slice(0,limit);
    return NextResponse.json({ok:true,version:P7_AI_CONFIRMATION_VERSION,mode:'P7_EVIDENCE_GROUNDED_CONFIRMATION',inventory:rows.length,confirmed:decisions.filter(x=>x.status==='CONFIRMED').length,conditional:decisions.filter(x=>x.status==='CONDITIONAL').length,blocked:decisions.filter(x=>x.status==='BLOCKED').length,rejected:decisions.filter(x=>x.status==='REJECTED').length,decisions,contract:P7_AI_CONFIRMATION_CONTRACT},{headers:{'Cache-Control':'no-store'}});
  }catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e),headers:{'Cache-Control':'no-store'}})}
}
