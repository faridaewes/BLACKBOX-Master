import { rateLimitUserKey } from '@/lib/rate-limit';
import { NextResponse } from 'next/server';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { db } from '@/lib/prisma';
import { buildDecisionLedger, dueHorizons, P8_CONTRACT, P8_DECISION_QUALITY_VERSION } from '@/lib/decision-quality-v120';

export async function GET(req:Request){
  try{
    const s=await requireVerifiedSession();
    const rl=await distributedRateLimit(rateLimitUserKey(s.userId, "ai-outcomes-p8"),10,60);
    if(!rl.ok)return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429,headers:{'Retry-After':String(rl.retryAfterSec)}});
    const u=new URL(req.url);const marketKey=u.searchParams.get('marketKey')||'';const limit=Math.max(1,Math.min(100,Number(u.searchParams.get('limit')||25)));
    const where:any=marketKey?{marketKey}:{ };
    const rows=await db.decisionQualitySnapshot.findMany({where,orderBy:{createdAt:'desc'},take:limit});
    return NextResponse.json({ok:true,version:P8_DECISION_QUALITY_VERSION,mode:'P8_DECISION_QUALITY_READ_ONLY',inventory:rows.length,results:rows,contract:P8_CONTRACT,leakageGuard:'OUTCOME_DATA_IS_NOT_REUSED_AS_P7_DECISION_EVIDENCE'},{headers:{'Cache-Control':'no-store'}});
  }catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e),headers:{'Cache-Control':'no-store'}})}
}
