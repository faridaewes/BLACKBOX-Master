import { rateLimitUserKey } from '@/lib/rate-limit';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { buildMarketIntelligence, AI_MARKET_INTELLIGENCE_CONTRACT, AI_MARKET_INTELLIGENCE_VERSION } from '@/lib/ai-market-intelligence-v87';

const body=z.object({marketKey:z.string().trim().min(1).max(200),question:z.string().trim().min(3).max(500).optional()}).strict();
const apiError=(e:unknown)=>{const m=e instanceof Error?e.message:String(e);if(m==='AI_MARKET_INTELLIGENCE_PERSISTENCE_FAILED')return {error:'PERSISTENCE_UNAVAILABLE',status:503};if(m==='MARKET_EVIDENCE_NOT_FOUND')return {error:'MARKET_EVIDENCE_NOT_FOUND',status:404};return {error:'INTERNAL_ERROR',status:500};};
export async function GET(req:Request){
  try{const s=await requireVerifiedSession();const rl=await distributedRateLimit(rateLimitUserKey(s.userId, "ai-market-intelligence-v87"),10,60);if(!rl.ok)return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429,headers:{'Retry-After':String(rl.retryAfterSec)}});
    const u=new URL(req.url);const marketKey=u.searchParams.get('marketKey')||'';const question=u.searchParams.get('question')||undefined;const b=body.parse({marketKey,question});const result=await buildMarketIntelligence(s.userId,b.marketKey,b.question);return NextResponse.json({ok:true,version:AI_MARKET_INTELLIGENCE_VERSION,mode:'READ_ONLY_AI_MARKET_INTELLIGENCE',executionAllowed:false,contract:AI_MARKET_INTELLIGENCE_CONTRACT,intelligence:result},{headers:{'Cache-Control':'no-store'}});
  }catch(e){return NextResponse.json({ok:false,error:e instanceof z.ZodError?'INPUT_INVALID':apiError(e).error},{status:e instanceof z.ZodError?400:apiError(e).status,headers:{'Cache-Control':'no-store'}})}
}
export async function POST(req:Request){
  try{const s=await requireVerifiedSession();const rl=await distributedRateLimit(rateLimitUserKey(s.userId, "ai-market-intelligence-v87"),8,60);if(!rl.ok)return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429,headers:{'Retry-After':String(rl.retryAfterSec)}});const len=Number(req.headers.get('content-length')||0);if(len>32_000)return NextResponse.json({ok:false,error:'REQUEST_TOO_LARGE'},{status:413});const b=body.parse(await req.json());const result=await buildMarketIntelligence(s.userId,b.marketKey,b.question);return NextResponse.json({ok:true,version:AI_MARKET_INTELLIGENCE_VERSION,mode:'READ_ONLY_AI_MARKET_INTELLIGENCE',executionAllowed:false,contract:AI_MARKET_INTELLIGENCE_CONTRACT,intelligence:result},{headers:{'Cache-Control':'no-store'}});
  }catch(e){return NextResponse.json({ok:false,error:e instanceof z.ZodError?'INPUT_INVALID':apiError(e).error},{status:e instanceof z.ZodError?400:apiError(e).status,headers:{'Cache-Control':'no-store'}})}
}
