import { NextResponse } from "next/server";
import { db } from "@/lib/prisma";
import { apiError,  requireVerifiedSession, authStatus } from "@/lib/auth";
import { configuredProvider } from "@/lib/ai";
import { AI_INTELLIGENCE_VERSION } from "@/lib/ai-v69";

export async function GET() {
  try {
    await requireVerifiedSession();
    const provider = configuredProvider();
    const used = provider === "local-fallback" || provider === "ollama" ? 0 : await db.aiCall.count({ where: { createdAt: { gte: new Date(Date.now() - 24 * 3600_000) }, provider: { not: "local-fallback" } } });
    return NextResponse.json({
      ok: true, intelligenceVersion: AI_INTELLIGENCE_VERSION, provider,
      model: provider === "ollama" ? process.env.OLLAMA_MODEL || "qwen3:4b" : provider === "local-fallback" ? "rule-based" : process.env.AI_MODEL || "openrouter/free",
      endpoint: provider === "ollama" ? process.env.OLLAMA_BASE_URL || "http://127.0.0.1:11434" : provider === "local-fallback" ? "-" : process.env.AI_BASE_URL || "https://openrouter.ai/api/v1",
      hasKey: !!process.env.AI_API_KEY, dailyBudget: Number(process.env.AI_DAILY_BUDGET || 40), usedToday: used,
      marketMode: (process.env.MARKET_MODE || "auto").toLowerCase(),
    });
  } catch (e) { return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) }); }
}
