import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { buildCopilotInsight, persistCopilotInsight } from '@/lib/ai-copilot-v75';
import { rateLimit } from '@/lib/rate-limit';
const schema=z.object({question:z.string().trim().min(3).max(500),persist:z.boolean().optional().default(false)});
export async function POST(req:Request){try{const s=await requireVerifiedSession();const rl=rateLimit(`copilot:${s.userId}`,10,60_000);if(!rl.ok)return NextResponse.json({ok:false,error:'COPILOT_RATE_LIMITED',retryAfterSec:rl.retryAfterSec},{status:429});const b=schema.parse(await req.json());const result=b.persist?await persistCopilotInsight(s.userId,b.question):await buildCopilotInsight(s.userId,b.question);return NextResponse.json({ok:true,copilot:result},{headers:{'cache-control':'no-store'}})}catch(e){if(e instanceof z.ZodError)return NextResponse.json({ok:false,error:'COPILOT_INPUT_INVALID'},{status:400});return NextResponse.json({ok:false,error:'COPILOT_UNAVAILABLE'},{status:authStatus(e)})}}
