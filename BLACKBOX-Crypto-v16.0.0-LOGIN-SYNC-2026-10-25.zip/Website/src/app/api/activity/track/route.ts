import { rateLimitUserKey } from '@/lib/rate-limit';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession, authStatus } from '@/lib/auth';
import { db } from '@/lib/prisma';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
const schema=z.object({type:z.enum(['PAGE_VIEW','USER_ACTION','ACTION_ERROR']).default('PAGE_VIEW'),path:z.string().max(300).optional(),metadata:z.record(z.string(),z.unknown()).default({})});
export async function POST(req:Request){try{const s=await requireSession();const rl=await distributedRateLimit(rateLimitUserKey(s.userId, "activity-track"),120,60);if(!rl.ok)return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429,headers:{'Retry-After':String(rl.retryAfterSec)}});const b=schema.parse(await req.json());await db.userActivityEvent.create({data:{userId:s.userId,type:b.type,path:b.path?.slice(0,300),metadata:b.metadata as any}});return NextResponse.json({ok:true});}catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)})}}
