import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { authStatus } from '@/lib/auth';
import { broadcastNotification } from '@/lib/notifications';
import { hasPermission } from '@/lib/access-control';

async function requireOptionalPermission(userId:string, permission:string){ return hasPermission(userId,permission); }

const schema = z.object({
  title: z.string().trim().min(3).max(120),
  body: z.string().trim().min(3).max(4000),
  priority: z.enum(['LOW','NORMAL','HIGH','URGENT']).default('HIGH'),
  targetUserIds: z.array(z.string().min(1)).max(500).optional(),
  channels: z.array(z.enum(['DASHBOARD','EMAIL'])).min(1).max(2).default(['DASHBOARD','EMAIL']),
  // Backward-compatible UI/API flag.
  email: z.boolean().optional(),
});

async function scopedUsers(actor:{userId:string;role:string}) {
  return actor.role === 'DEVELOPER'
    ? db.user.findMany({where:{role:'USER',status:'ACTIVE'},select:{id:true,name:true,email:true},orderBy:{name:'asc'}})
    : db.user.findMany({where:{role:'USER',status:'ACTIVE',assignmentsReceived:{some:{adminId:actor.userId}}},select:{id:true,name:true,email:true},orderBy:{name:'asc'}});
}

export async function GET() {
  try {
    const actor = await requirePermissionSession(PERMISSIONS.USER_BROADCAST_SEND);
    return NextResponse.json({ok:true,users:await scopedUsers(actor),channels:['DASHBOARD','EMAIL'],canTargetAll:actor.role==='DEVELOPER'||await requireOptionalPermission(actor.userId,PERMISSIONS.USER_BROADCAST_TARGET_ALL)});
  } catch(e) { return NextResponse.json({ok:false,error:['AUTH_REQUIRED','FORBIDDEN','NO_RECIPIENTS','NO_CHANNELS','BROADCAST_CHANNEL_REQUIRED','BROADCAST_CREATOR_REQUIRED'].includes(String(e instanceof Error?e.message:e)) ? String(e instanceof Error?e.message:e) : 'BROADCAST_DELIVERY_FAILED'},{status:authStatus(e)}); }
}

export async function POST(req:Request) {
  try {
    const actor = await requirePermissionSession(PERMISSIONS.USER_BROADCAST_SEND);
    const input = schema.parse(await req.json());
    if (!input.targetUserIds?.length && actor.role !== 'DEVELOPER' && !(await hasPermission(actor.userId, PERMISSIONS.USER_BROADCAST_TARGET_ALL))) throw new Error('BROADCAST_TARGET_ALL_NOT_ALLOWED');
    const allowed = await scopedUsers(actor);
    const selected = input.targetUserIds?.length ? allowed.filter(u => input.targetUserIds!.includes(u.id)) : allowed;
    if (!selected.length) return NextResponse.json({ok:false,error:'NO_RECIPIENTS'},{status:400});
    const channels = input.email === false ? input.channels.filter(c => c !== 'EMAIL') : input.channels;
    if (!channels.length) return NextResponse.json({ok:false,error:'NO_CHANNELS'},{status:400});
    const result = await broadcastNotification({title:input.title,body:input.body,priority:input.priority,emailSubject:input.title,users:selected.map(u=>({id:u.id,email:u.email})),channels,createdById:actor.userId});
    await db.auditLog.create({data:{actorId:actor.userId,action:'USER_BROADCAST_SENT',targetType:'USER_BROADCAST',targetId:result.broadcastId,metadata:{recipientCount:selected.length,channels,priority:input.priority}}});
    return NextResponse.json({ok:true,...result});
  } catch(e) {
    if(e instanceof z.ZodError)return NextResponse.json({ok:false,error:'INPUT_TIDAK_VALID'},{status:400});
    return NextResponse.json({ok:false,error:['AUTH_REQUIRED','FORBIDDEN','NO_RECIPIENTS','NO_CHANNELS','BROADCAST_CHANNEL_REQUIRED','BROADCAST_CREATOR_REQUIRED'].includes(String(e instanceof Error?e.message:e)) ? String(e instanceof Error?e.message:e) : 'BROADCAST_DELIVERY_FAILED'},{status:authStatus(e)});
  }
}
