import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';
import { requireSession } from '@/lib/auth';
export async function GET(){try{const s=await requireSession();const rows=await db.serviceOrder.findMany({where:{userId:s.userId},include:{service:true,deliveries:{select:{id:true,fileName:true,emailStatus:true,sha256:true,expiresAt:true,createdAt:true}}},orderBy:{requestedAt:'desc'}});return NextResponse.json({ok:true,orders:rows});}catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:401})}}
