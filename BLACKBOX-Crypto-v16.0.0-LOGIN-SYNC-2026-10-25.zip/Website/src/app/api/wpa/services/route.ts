import { NextResponse } from 'next/server';
import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { db } from '@/lib/prisma';
import { requireSession, authStatus } from '@/lib/auth';
import { hasPermission, PERMISSIONS } from '@/lib/access-control';

const schema = z.object({
  id: z.string().optional(), advisorId: z.string().optional(),
  name: z.string().trim().min(1).max(120), description: z.string().max(2000).optional(),
  category: z.string().max(80).optional(), durationMinutes: z.number().int().min(1).max(10080).nullable().optional(),
  active: z.boolean().default(true), sortOrder: z.number().int().min(0).max(999), rewardPoints: z.number().int().min(0).max(1000000).optional(),
});

async function actor(){
  const s=await requireSession();
  const p=await db.publicAdvisor.findUnique({where:{userId:s.userId},select:{id:true}});
  const staff=s.role==='DEVELOPER'||await hasPermission(s.userId,PERMISSIONS.WPA_MANAGE);
  if(!p&&!staff) throw new Error('WPA_ACCESS_REQUIRED');
  return {s,advisorId:p?.id||null,staff};
}

export async function GET(req:Request){try{
  const {advisorId,staff}=await actor(); const q=new URL(req.url).searchParams.get('advisorId'); const target=staff&&q?q:advisorId;
  if(!target)return NextResponse.json({ok:true,services:[]});
  return NextResponse.json({ok:true,services:await db.wpaService.findMany({where:{advisorId:target},orderBy:{sortOrder:'asc'}})});
}catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)})}}

export async function POST(req:Request){try{
  const {s,advisorId,staff}=await actor(); const b=schema.parse(await req.json()); const targetId=advisorId||b.advisorId||null;
  if(!targetId)return NextResponse.json({ok:false,error:'WPA_PROFILE_REQUIRED'},{status:400});
  if(b.id){const old=await db.wpaService.findUnique({where:{id:b.id},select:{advisorId:true}});if(!old||old.advisorId!==targetId)return NextResponse.json({ok:false,error:'SERVICE_NOT_FOUND'},{status:404});}
  const data:any={name:b.name,description:b.description||null,category:b.category||null,durationMinutes:b.durationMinutes??null,active:b.active,sortOrder:b.sortOrder};
  if(staff && b.rewardPoints !== undefined) data.rewardPoints=b.rewardPoints;
  if(!staff) delete data.rewardPoints;
  const row=b.id?await db.wpaService.update({where:{id:b.id},data}):await db.wpaService.create({data:{advisorId:targetId,...data}});
  await db.auditLog.create({data:{actorId:s.userId,action:b.id?'WPA_SERVICE_UPDATE':'WPA_SERVICE_CREATE',targetType:'PUBLIC_ADVISOR',targetId,metadata:{serviceId:row.id}}});
  revalidatePath('/wpa'); revalidatePath(`/wpa/${targetId}`);
  return NextResponse.json({ok:true,service:row});
}catch(e){return NextResponse.json({ok:false,error:e instanceof z.ZodError?'INPUT_INVALID':'REQUEST_FAILED'},{status:authStatus(e)})}}

export async function DELETE(req:Request){try{
  const {s,advisorId,staff}=await actor(); const u=new URL(req.url); const id=u.searchParams.get('id'); const requestedAdvisor=u.searchParams.get('advisorId'); const targetAdvisor=staff&&requestedAdvisor?requestedAdvisor:advisorId; if(!id)return NextResponse.json({ok:false,error:'SERVICE_ID_REQUIRED'},{status:400});
  const old=await db.wpaService.findUnique({where:{id},select:{advisorId:true}}); if(!old||old.advisorId!==targetAdvisor)return NextResponse.json({ok:false,error:'SERVICE_NOT_FOUND'},{status:404});
  await db.wpaService.delete({where:{id}}); await db.auditLog.create({data:{actorId:s.userId,action:'WPA_SERVICE_DELETE',targetType:'PUBLIC_ADVISOR',targetId:targetAdvisor!,metadata:{serviceId:id}}});
  revalidatePath('/wpa'); revalidatePath(`/wpa/${targetAdvisor}`); return NextResponse.json({ok:true});
}catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)})}}
