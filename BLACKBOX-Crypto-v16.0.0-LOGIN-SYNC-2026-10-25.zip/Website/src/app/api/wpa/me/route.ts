import { NextResponse } from 'next/server'; import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { authStatus, requireSession } from '@/lib/auth';

const updateSchema = z.object({
  title: z.string().trim().min(1).max(160).optional(),
  specialization: z.string().trim().max(240).optional(),
  licenseNumber: z.string().max(120).optional(),
  company: z.string().max(160).optional(),
  photoUrl: z.string().max(2000).optional().or(z.literal('')),
  bio: z.string().trim().min(1).max(8000).optional(),
  phone: z.string().max(40).optional(),
  whatsapp: z.string().max(80).optional(),
  telegram: z.string().max(120).optional(),
  tiktok: z.string().max(160).optional(),
  instagram: z.string().max(200).optional(),
  experienceYears: z.number().int().min(0).max(80).nullable().optional(),
});

export async function GET() {
  try {
    const s = await requireSession();
    const profile = await db.publicAdvisor.findUnique({ where: { userId: s.userId } });
    if (!profile) {
      return NextResponse.json({ ok: false, error: 'NOT_WPA', isWpa: false }, { status: 404 });
    }
    return NextResponse.json({ ok: true, isWpa: true, profile });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'REQUEST_FAILED' }, { status: authStatus(e) });
  }
}

export async function PATCH(req: Request) {
  try {
    const s = await requireSession();
    const profile = await db.publicAdvisor.findUnique({ where: { userId: s.userId } });
    if (!profile || !profile.active) {
      return NextResponse.json({ ok: false, error: 'NOT_WPA' }, { status: 403 });
    }
    const b = updateSchema.parse(await req.json());
    // Self-edit cannot force PUBLISHED if currently ARCHIVED; can save fields; status stays unless already allowed
    const data: any = { ...b };
    if (data.photoUrl === '') data.photoUrl = null;
    // Sync name from account
    const user = await db.user.findUnique({ where: { id: s.userId }, select: { name: true } });
    if (user) data.name = user.name;
    // If was ARCHIVED, keep archived until staff re-activates
    if (profile.workflowStatus === 'ARCHIVED') {
      delete data.workflowStatus;
    }
    const row = await db.publicAdvisor.update({ where: { id: profile.id }, data });
    await db.auditLog.create({
      data: {
        actorId: s.userId,
        action: 'WPA_SELF_UPDATE',
        targetType: 'PUBLIC_ADVISOR',
        targetId: profile.id,
        metadata: { fields: Object.keys(b) },
      },
    });
    revalidatePath('/wpa'); revalidatePath(`/wpa/${profile.id}`); return NextResponse.json({ ok: true, profile: row });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'REQUEST_FAILED' }, { status: authStatus(e) });
  }
}
