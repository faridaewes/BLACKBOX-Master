import { onActivation } from '@/lib/referral-reward-v91';
import { NextResponse } from 'next/server';
import crypto from 'node:crypto';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { apiError,  requireSession, requireVerifiedSession, authStatus } from '@/lib/auth';
import { recordConsentWithTx } from '@/lib/consent';
import { runIdempotentTransaction } from '@/lib/idempotency';
import { notifyTierActivation, ensureTierActivationDeliveryTx } from '@/lib/tier-activation-notifications';
import { maybeRewardWpaEnrollmentTx } from '@/lib/wpa-tier-reward';

const hash = (s: string) => crypto.createHash('sha256').update(s.trim().toUpperCase()).digest('hex');
const schema = z.object({ code: z.string().trim().min(8).max(64), wpaEnrollmentId: z.string().optional() });

export async function GET() {
  try {
    const s = await requireSession();
    const now = new Date();
    const sub = await db.subscription.findFirst({
      where: { userId: s.userId, status: 'ACTIVE', startsAt: { lte: now }, expiresAt: { gt: now } },
      include: { plan: true }, orderBy: { expiresAt: 'desc' },
    });
    return NextResponse.json({ ok: true, tier: sub?.plan.name || 'DEMO', expiresAt: sub?.expiresAt || null, entitlements: sub?.plan.entitlements || null });
  } catch (e) {
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}

export async function POST(req: Request) {
  try {
    const s = await requireVerifiedSession();
    const b = schema.parse(await req.json());
    const idempotencyKey = req.headers.get('idempotency-key')?.trim();
    if (!idempotencyKey) return NextResponse.json({ ok: false, error: 'IDEMPOTENCY_KEY_REQUIRED' }, { status: 400 });

    const codeHash = hash(b.code);
    const operation = await runIdempotentTransaction({
      key: idempotencyKey,
      scope: `access-code-redeem:${s.userId}`,
      request: { userId: s.userId, codeHash, wpaEnrollmentId: b.wpaEnrollmentId || null },
      execute: async (tx: any) => {
        const now = new Date();
        // Serialize ALL tier grants for this user, including code redemption and point redemption,
        // so two concurrent grants always extend from the latest subscription instead of overlapping.
        await tx.$queryRawUnsafe('SELECT pg_advisory_xact_lock(hashtext($1))', `blackbox:user:subscription:${s.userId}`);
        const c = await tx.accessCode.findUnique({ where: { codeHash }, include: { plan: true } });
        const redeemingUser = await tx.user.findUnique({ where: { id: s.userId }, select: { username: true, email: true } });
        if (!redeemingUser) return { error: 'USER_NOT_FOUND' };
        if (!c || c.status !== 'ACTIVE' || c.expiresAt <= now || c.startsAt > now) return { error: 'KODE_TIDAK_AKTIF' };
        if (c.targetEmail && c.targetEmail.toLowerCase() !== redeemingUser.email.toLowerCase()) return { error: 'KODE_KHUSUS_EMAIL_LAIN' };
        if (c.targetUsername && c.targetUsername.toLowerCase() !== redeemingUser.username.toLowerCase()) return { error: 'KODE_KHUSUS_USERNAME_LAIN' };
        if (c.targetUserId && c.targetUserId !== s.userId) return { error: 'KODE_KHUSUS_USER_LAIN' };
        if (c.redemptionCount >= c.maxRedemptions) return { error: 'KODE_SUDAH_HABIS' };

        const used = await tx.codeRedemption.findUnique({ where: { codeId_userId: { codeId: c.id, userId: s.userId } } });
        if (used) return { error: 'KODE_SUDAH_DIREDEEM' };
        let wpaEnrollment: any = null;
        if (b.wpaEnrollmentId) {
          wpaEnrollment = await tx.wpaServiceEnrollment.findUnique({ where: { id: b.wpaEnrollmentId }, include: { service: true, advisor: true } });
          if (!wpaEnrollment || wpaEnrollment.userId !== s.userId || wpaEnrollment.planId !== c.planId || wpaEnrollment.status !== 'APPROVED') return { error: 'WPA_SERVICE_NOT_APPROVED_FOR_TIER' };
        }

        const reserved = await tx.accessCode.updateMany({
          where: { id: c.id, status: 'ACTIVE', redemptionCount: { lt: c.maxRedemptions } },
          data: { redemptionCount: { increment: 1 } },
        });
        if (reserved.count !== 1) return { error: 'KODE_SUDAH_HABIS' };

        const sub = await tx.subscription.findFirst({ where: { userId: s.userId, status: 'ACTIVE', expiresAt: { gt: now } }, orderBy: { expiresAt: 'desc' } });
        const start = sub && sub.expiresAt > now ? sub.expiresAt : now;
        const durationDays = Math.max(1, Number((c.plan.entitlements as any)?.durationDays || 30));
        const expires = new Date(start.getTime() + durationDays * 86400000);
        const redemption = await tx.codeRedemption.create({ data: { codeId: c.id, userId: s.userId } });
        await onActivation(tx, s.userId, redemption.id);
        await tx.subscription.create({ data: { userId: s.userId, planId: c.planId, status: 'ACTIVE', startsAt: start, expiresAt: expires, grantedById: c.createdById, complimentary: c.complimentary } });

        const user = await tx.user.findUnique({ where: { id: s.userId }, select: { id: true, name: true, email: true } });
        if (!user) throw new Error('CONSENT_USER_NOT_FOUND');
        const subscription = await tx.subscription.findFirst({where:{userId:s.userId,planId:c.planId,status:'ACTIVE',startsAt:start,expiresAt:expires},orderBy:{createdAt:'desc'},select:{id:true,startsAt:true,expiresAt:true}});
        if (!subscription) throw new Error('SUBSCRIPTION_CREATE_FAILED');
        await ensureTierActivationDeliveryTx(tx,{userId:s.userId,subscriptionId:subscription.id,source:'ACCESS_CODE',tier:c.plan.name,startsAt:start,expiresAt:expires});
        const wpaReward = wpaEnrollment ? await maybeRewardWpaEnrollmentTx(tx, wpaEnrollment.id, subscription.id) : null;
        const result = { plan: c.plan.name, tier: c.plan.name, expiresAt: expires, startsAt: start, subscriptionId: subscription.id, source: 'ACCESS_CODE' as const, targetEmail: c.targetEmail || null, targetUsername: c.targetUsername || null, wpaEnrollmentId: b.wpaEnrollmentId || null, wpaReward };
        await recordConsentWithTx(tx, req, user, 'ACCESS_CODE_REDEEM', result);
        await tx.auditLog.create({ data: { actorId: s.userId, action: 'ACCESS_CODE_REDEEMED', targetType: 'USER', targetId: s.userId, metadata: result } });
        return result;
      },
    });

    if (!(operation.result as any).error && !operation.replay) {
      const r:any=operation.result;
      await notifyTierActivation({userId:s.userId,subscriptionId:r.subscriptionId,source:'ACCESS_CODE',tier:r.tier,startsAt:new Date(r.startsAt),expiresAt:new Date(r.expiresAt)}).catch(()=>null);
    }
    if ((operation.result as any).error) return NextResponse.json({ ok: false, error: (operation.result as any).error }, { status: 400 });
    return NextResponse.json({ ok: true, ...operation.result, replay: operation.replay });
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    if (['IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_REQUEST', 'IDEMPOTENCY_REQUEST_IN_PROGRESS', 'INVALID_IDEMPOTENCY_KEY', 'IDEMPOTENCY_KEY_REQUIRED'].includes(message)) {
      return NextResponse.json({ ok: false, error: message }, { status: 409 });
    }
    return NextResponse.json({ ok: false, error: message }, { status: authStatus(e) });
  }
}
