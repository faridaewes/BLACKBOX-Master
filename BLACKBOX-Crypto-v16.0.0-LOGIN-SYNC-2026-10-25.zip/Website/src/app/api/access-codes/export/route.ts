import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';
import { authStatus } from '@/lib/auth';
import XLSX from 'xlsx';
import PDFDocument from 'pdfkit';

export async function GET(req: Request) {
  try {
    const actor = await requirePermissionSession(PERMISSIONS.TIER_ACCESS_CODE);
    const format = new URL(req.url).searchParams.get('format') || 'xlsx';
    const where:any = actor.role === 'DEVELOPER' ? {} : {
      OR: [
        { createdById: actor.userId },
        { targetUser: { assignmentsReceived: { some: { adminId: actor.userId } } } }
      ]
    };
    const rows = await db.accessCode.findMany({
      where, orderBy:{createdAt:'desc'}, take:5000,
      include:{plan:{select:{name:true}},targetUser:{select:{email:true,username:true,name:true}},redemptions:{orderBy:{redeemedAt:'desc'},take:100,include:{user:{select:{email:true,username:true,name:true}}}}}
    });
    const data:any[]=[];
    for(const r of rows) {
      if(!r.redemptions.length) data.push({Kode:r.displayPrefix+'••••',Tier:r.plan.name,Status:r.status,Dibuat:r.createdAt.toISOString(),Kadaluarsa:r.expiresAt.toISOString(),TargetEmail:r.targetEmail||r.targetUser?.email||'',TargetUsername:r.targetUser?.username||'',Redemptions:0,RedemEmail:'',RedemUsername:'',RedemWaktu:''});
      for(const d of r.redemptions) data.push({Kode:r.displayPrefix+'••••',Tier:r.plan.name,Status:r.status,Dibuat:r.createdAt.toISOString(),Kadaluarsa:r.expiresAt.toISOString(),TargetEmail:r.targetEmail||r.targetUser?.email||'',TargetUsername:r.targetUser?.username||'',Redemptions:r.redemptionCount,RedemEmail:d.user?.email||'',RedemUsername:d.user?.username||'',RedemWaktu:d.redeemedAt.toISOString()});
    }
    await db.auditLog.create({data:{actorId:actor.userId,action:'ACCESS_CODE_HISTORY_EXPORTED',targetType:'ACCESS_CODE_REPORT',metadata:{format,rowCount:data.length}}});
    if(format==='csv') {
      const headers=Object.keys(data[0]||{Kode:'',Tier:'',Status:''});
      const csv=[headers,...data.map(r=>headers.map(h=>String(r[h]??'').replaceAll('"','""')))].map(r=>r.map(v=>`"${v}"`).join(',')).join('\n');
      return new NextResponse('\uFEFF'+csv,{headers:{'content-type':'text/csv; charset=utf-8','content-disposition':'attachment; filename="blackbox-access-code-history.csv"'}});
    }
    if(format==='pdf') {
      const doc=new PDFDocument({size:'A4',margin:36});
      const chunks:Buffer[]=[]; doc.on('data',c=>chunks.push(c));
      doc.fontSize(16).text('BLACKBOX Crypto — Access Code History'); doc.moveDown().fontSize(8).text(`Dibuat: ${new Date().toLocaleString('id-ID')}`);
      doc.moveDown();
      for(const r of data.slice(0,300)){ doc.text(`${r.Kode} | ${r.Tier} | ${r.Status} | ${r.RedemEmail||'-'} | ${r.RedemUsername||'-'} | ${r.RedemWaktu||'-'}`); if(doc.y>760)doc.addPage(); }
      doc.end();
      await new Promise<void>(resolve=>doc.on('end',()=>resolve()));
      return new NextResponse(Buffer.concat(chunks),{headers:{'content-type':'application/pdf','content-disposition':'attachment; filename="blackbox-access-code-history.pdf"'}});
    }
    const wb=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(data),'Access Code History');
    const out=XLSX.write(wb,{type:'buffer',bookType:'xlsx'});
    return new NextResponse(out,{headers:{'content-type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','content-disposition':'attachment; filename="blackbox-access-code-history.xlsx"'}});
  } catch(e) { return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)}); }
}
