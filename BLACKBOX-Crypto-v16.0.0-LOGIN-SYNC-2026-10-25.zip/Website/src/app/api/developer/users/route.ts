import { NextResponse } from "next/server";
import { z } from "zod";
import { apiError,  authStatus } from "@/lib/auth";
import { db } from "@/lib/prisma";
import { denyReason } from "@/lib/admin-policy";
import { permanentlyAnonymizeUser } from '@/lib/user-account-admin';
import { requirePermissionSession, requirePermission, PERMISSIONS, requirePrincipal, requireHighRiskAccess, hasPermission } from '@/lib/access-control';
import { canViewUserDetail, redactUserForStaff } from '@/lib/user-privacy';

/** Developer: role management + assignment Admin -> User. */
export async function GET() {
  try {
    const actor = await requirePermissionSession(PERMISSIONS.USER_READ);
    const principal = await db.user.findUnique({where:{id:actor.userId},select:{developerLevel:true}});
    if (principal?.developerLevel !== "PRINCIPAL") await requirePermission(actor.userId, PERMISSIONS.USER_READ);
    const users = await db.user.findMany({
      select: {
        id: true, name: true, email: true, phone: true, role: true, status: true, createdAt: true, kycStatus: true,
        assignedUsers: { select: { user: { select: { id: true, name: true, email: true } } } }
      },
      orderBy: { createdAt: "desc" }, take: 500
    });
    const full = actor.role === 'DEVELOPER' || (await canViewUserDetail(actor.userId, actor.role));
    return NextResponse.json({ ok: true, users: users.map(u => {
      const row = { ...u, assignedUsers: u.assignedUsers.map(a => a.user) };
      return full ? row : redactUserForStaff(row, false);
    }), profileDetail: full });
  } catch (e) { return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) }); }
}

const roleSchema = z.object({ action: z.literal("SET_ROLE"), userId: z.string().min(1), role: z.enum(["ADMIN", "USER"]) });
const statusSchema = z.object({ action: z.literal("SET_STATUS"), userId: z.string().min(1), status: z.enum(["ACTIVE","SUSPENDED","DISABLED"]) });
const deleteSchema = z.object({ action: z.literal("DELETE_ACCOUNT"), userId: z.string().min(1), confirmation: z.literal("DELETE PERMANENTLY") });
const assignmentSchema = z.object({ action: z.enum(["ASSIGN_USER","UNASSIGN_USER"]), adminId: z.string().min(1), userId: z.string().min(1) });

export async function POST(req: Request) {
  try {
    const actor = await requirePermissionSession(PERMISSIONS.USER_READ);
    const b = await req.json();
    const principal = await db.user.findUnique({where:{id:actor.userId},select:{developerLevel:true}});
    if (principal?.developerLevel !== "PRINCIPAL") { const map:any={SET_STATUS:PERMISSIONS.USER_SUSPEND,DELETE_ACCOUNT:PERMISSIONS.USER_DELETE,SET_ROLE:PERMISSIONS.ROLE_ADMIN,ASSIGN_USER:PERMISSIONS.USER_READ,UNASSIGN_USER:PERMISSIONS.USER_READ}; await requirePermission(actor.userId,map[b.action]||PERMISSIONS.USER_READ); }

    if (b.action === "SET_STATUS") {
      const x = statusSchema.parse(b);
      const target = await db.user.findUnique({where:{id:x.userId},select:{id:true,role:true,email:true}});
      if(!target || target.role==="DEVELOPER") return NextResponse.json({ok:false,error:"TARGET_NOT_ALLOWED"},{status:403});
      await db.user.update({where:{id:target.id},data:{status:x.status,sessionVersion:{increment:1}}});
      if(x.status!=="ACTIVE") await db.bot.updateMany({where:{userId:target.id,status:{in:["RUNNING","PAUSED"]}},data:{status:"STOPPED",stoppedAt:new Date()}});
      await db.auditLog.create({data:{actorId:actor.userId,action:"DEVELOPER_SET_USER_STATUS",targetType:"USER",targetId:target.id,metadata:{status:x.status,email:target.email}}});
      return NextResponse.json({ok:true});
    }
    if (b.action === "DELETE_ACCOUNT") {
      const x = deleteSchema.parse(b);
      const target = await db.user.findUnique({where:{id:x.userId},select:{id:true,role:true}});
      if(!target || target.role==="DEVELOPER") return NextResponse.json({ok:false,error:"TARGET_NOT_ALLOWED"},{status:403});
      await permanentlyAnonymizeUser(target.id);
      await db.auditLog.create({data:{actorId:actor.userId,action:"DEVELOPER_ACCOUNT_PERMANENTLY_DELETED",targetType:"USER",targetId:target.id,metadata:{irreversible:true,piiAnonymized:true}}});
      return NextResponse.json({ok:true});
    }

    if (b.action === "SET_ROLE") {
      const x = roleSchema.parse(b);
      const target = await db.user.findUnique({ where: { id: x.userId }, select: { id: true, role: true } });
      if (!target) return NextResponse.json({ ok: false, error: "USER_NOT_FOUND" }, { status: 404 });
      const why = denyReason({ id: actor.userId, role: actor.role }, { id: target.id, role: target.role as any }, "SET_ROLE");
      if (why) return NextResponse.json({ ok: false, error: why }, { status: 403 });
      const updated = await db.user.update({ where: { id: target.id }, data: { role: x.role } });
      if (x.role !== "ADMIN") await db.adminAssignment.deleteMany({ where: { adminId: target.id } });
      await db.auditLog.create({ data: { actorId: actor.userId, action: "ROLE_CHANGED", targetType: "USER", targetId: target.id, metadata: { from: target.role, to: x.role } } });
      return NextResponse.json({ ok: true, user: { id: updated.id, role: updated.role } });
    }

    const x = assignmentSchema.parse(b);
    const [admin, user] = await Promise.all([
      db.user.findUnique({ where: { id: x.adminId }, select: { id: true, role: true } }),
      db.user.findUnique({ where: { id: x.userId }, select: { id: true, role: true } })
    ]);
    if (!admin || admin.role !== "ADMIN") return NextResponse.json({ ok: false, error: "ADMIN_NOT_FOUND" }, { status: 404 });
    if (!user || user.role !== "USER") return NextResponse.json({ ok: false, error: "USER_NOT_FOUND_OR_NOT_USER" }, { status: 404 });

    if (x.action === "ASSIGN_USER") {
      await db.adminAssignment.upsert({
        where: { adminId_userId: { adminId: x.adminId, userId: x.userId } },
        update: { assignedById: actor.userId },
        create: { adminId: x.adminId, userId: x.userId, assignedById: actor.userId }
      });
    } else {
      await db.adminAssignment.delete({ where: { adminId_userId: { adminId: x.adminId, userId: x.userId } } }).catch(() => {});
    }
    await db.auditLog.create({ data: { actorId: actor.userId, action: x.action, targetType: "ADMIN_ASSIGNMENT", metadata: { adminId: x.adminId, userId: x.userId } } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    if (e instanceof z.ZodError) return NextResponse.json({ ok: false, error: "Input tidak valid" }, { status: 400 });
    return NextResponse.json({ ok: false, error: apiError(e) }, { status: authStatus(e) });
  }
}
