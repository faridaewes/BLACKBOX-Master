import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { authStatus } from '@/lib/auth';
import { getHealthCenterSnapshot, persistHealthCenterSnapshot } from '@/lib/health-center';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    await requirePermissionSession(PERMISSIONS.SYSTEM_HEALTH);
    return NextResponse.json({ ok: true, health: await getHealthCenterSnapshot() }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return NextResponse.json({ ok: false, error: 'HEALTH_CENTER_ACCESS_DENIED' }, { status: authStatus(error) === 401 || authStatus(error) === 403 ? authStatus(error) : 500 });
  }
}

export async function POST() {
  try {
    await requirePermissionSession(PERMISSIONS.SYSTEM_HEALTH);
    return NextResponse.json({ ok: true, health: await persistHealthCenterSnapshot() }, { headers: { 'cache-control': 'no-store' } });
  } catch {
    return NextResponse.json({ ok: false, error: 'HEALTH_CENTER_SNAPSHOT_FAILED' }, { status: 500 });
  }
}
