import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { requirePrincipal } from '@/lib/access-control';
import { authStatus } from '@/lib/auth';
import { loadSmtpConfig } from '@/lib/smtp';

export async function GET() {
  try {
    await requirePrincipal();
    const cfg = await loadSmtpConfig();
    return NextResponse.json({
      ok: true,
      configured: !!cfg,
      config: cfg
        ? { host: cfg.host, port: cfg.port, secure: cfg.secure, user: cfg.user || '', from: cfg.from, passSet: !!cfg.pass }
        : null,
      source: cfg ? 'dynamic_or_env' : 'none',
    });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'FORBIDDEN' }, { status: authStatus(e) });
  }
}

const schema = z.object({
  host: z.string().min(1).max(200),
  port: z.coerce.number().int().min(1).max(65535).default(587),
  secure: z.boolean().default(false),
  user: z.string().max(200).optional().or(z.literal('')),
  pass: z.string().max(200).optional().or(z.literal('')),
  from: z.string().max(200).optional().or(z.literal('')),
});

export async function POST(req: Request) {
  try {
    const s = await requirePrincipal();
    const b = schema.parse(await req.json());
    const existing = await loadSmtpConfig();
    const value = {
      host: b.host.trim(),
      port: b.port,
      secure: b.secure,
      user: b.user || undefined,
      // keep old pass if blank
      pass: b.pass || existing?.pass || undefined,
      from: b.from || b.user || 'no-reply@blackbox.local',
    };
    await db.systemControl.upsert({
      where: { key: 'SMTP_CONFIG' },
      update: { value, updatedBy: s.userId },
      create: { key: 'SMTP_CONFIG', value, updatedBy: s.userId },
    });
    await db.auditLog.create({
      data: {
        actorId: s.userId,
        action: 'SMTP_CONFIG_UPDATED',
        targetType: 'SYSTEM',
        metadata: { host: value.host, port: value.port, from: value.from },
      },
    });
    return NextResponse.json({ ok: true, configured: true });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'REQUEST_FAILED' }, { status: authStatus(e) });
  }
}
