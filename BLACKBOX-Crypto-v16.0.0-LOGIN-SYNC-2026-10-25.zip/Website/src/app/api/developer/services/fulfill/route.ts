import { NextResponse } from 'next/server';
import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { authStatus } from '@/lib/auth';
import { deliverServiceFile } from '@/lib/service-delivery';
export async function POST(req:Request){try{const s=await requirePermissionSession(PERMISSIONS.SERVICE_FULFILLMENT);const fd=await req.formData();const orderId=String(fd.get('orderId')||'');const file=fd.get('file');if(!orderId||!(file instanceof File))return NextResponse.json({ok:false,error:'ORDER_AND_FILE_REQUIRED'},{status:400});const r=await deliverServiceFile(orderId,s.userId,file);return NextResponse.json({ok:true,...r});}catch(e){return NextResponse.json({ok:false,error:e instanceof Error?e.message:'REQUEST_FAILED'},{status:authStatus(e)})}}
