import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';
import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { authStatus } from '@/lib/auth';
export async function GET(){try{await requirePermissionSession(PERMISSIONS.SERVICE_FULFILLMENT);const rows=await db.serviceOrder.findMany({include:{service:true,user:{select:{id:true,name:true,email:true,username:true}},deliveries:{orderBy:{createdAt:'desc'},take:3}},orderBy:{requestedAt:'desc'},take:200});return NextResponse.json({ok:true,orders:rows});}catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)})}}
