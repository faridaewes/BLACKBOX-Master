import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { apiError, authStatus } from '@/lib/auth';
import { PERMISSIONS, requirePermissionSession } from '@/lib/access-control';

const qSchema = z.object({
  from: z.string().datetime(),
  to: z.string().datetime(),
  teamId: z.string().optional(),
  userId: z.string().optional(),
  bucket: z.enum(['DAY','WEEK','MONTH']).default('DAY'),
});
const SLA_MINUTES: Record<string, number> = { URGENT: 15, HIGH: 30, NORMAL: 120, LOW: 240 };
const finite = (n: unknown, d = 0) => Number.isFinite(Number(n)) ? Number(n) : d;
function bucketKey(date: Date, bucket: 'DAY'|'WEEK'|'MONTH') {
  if (bucket === 'MONTH') return `${date.getUTCFullYear()}-${String(date.getUTCMonth()+1).padStart(2,'0')}`;
  if (bucket === 'WEEK') {
    const d = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
    const day = d.getUTCDay() || 7; d.setUTCDate(d.getUTCDate() - day + 1);
    return d.toISOString().slice(0,10);
  }
  return date.toISOString().slice(0,10);
}
async function scope(s: any, teamId?: string) {
  if (s.role === 'DEVELOPER') return;
  if (teamId) {
    const m = await db.accessTeamMember.findUnique({where:{teamId_userId:{teamId,userId:s.userId}}});
    if (!m) throw new Error('TEAM_ACCESS_DENIED');
  }
}
export async function GET(req: Request) {
  try {
    const s = await requirePermissionSession(PERMISSIONS.WORK_ACTIVITY_READ);
    const q = qSchema.parse(Object.fromEntries(new URL(req.url).searchParams));
    const from = new Date(q.from), to = new Date(q.to);
    if (to <= from) throw new Error('INVALID_DATE_RANGE');
    await scope(s, q.teamId);
    if (s.role !== 'DEVELOPER' && q.userId && q.userId !== s.userId) {
      if (!q.teamId) throw new Error('USER_SCOPE_REQUIRES_TEAM');
      const target = await db.accessTeamMember.findUnique({where:{teamId_userId:{teamId:q.teamId,userId:q.userId}}});
      if (!target) throw new Error('USER_SCOPE_DENIED');
    }

    const sessionWhere:any = {startedAt:{lt:to}, OR:[{endedAt:null},{endedAt:{gt:from}}]};
    if (q.teamId) sessionWhere.teamId=q.teamId;
    if (q.userId) sessionWhere.userId=q.userId;
    const taskWhere:any = {createdAt:{lt:to}};
    if (q.teamId) taskWhere.teamId=q.teamId;
    if (q.userId) taskWhere.assigneeId=q.userId;
    const ticketWhere:any = {createdAt:{lt:to}, OR:[{updatedAt:{gte:from}},{createdAt:{gte:from}}]};
    if (q.teamId) ticketWhere.assignedTeamId=q.teamId;
    if (q.userId) ticketWhere.assignedAgentId=q.userId;
    const transferWhere:any = {createdAt:{gte:from,lt:to}};
    if (q.teamId) transferWhere.toTeamId=q.teamId;
    if (q.userId) transferWhere.OR=[{fromAgentId:q.userId},{toAgentId:q.userId},{createdById:q.userId}];

    const [sessions,tasks,tickets,transfers,teams] = await Promise.all([
      db.workSession.findMany({where:sessionWhere,include:{user:{select:{id:true,name:true,email:true}},team:{select:{id:true,name:true,code:true}}},orderBy:{startedAt:'asc'},take:20000}),
      db.teamTask.findMany({where:taskWhere,include:{assignee:{select:{id:true,name:true,email:true}},team:{select:{id:true,name:true,code:true}}},orderBy:{createdAt:'asc'},take:20000}),
      db.supportTicket.findMany({where:ticketWhere,include:{assignedAgent:{select:{id:true,name:true,email:true}},assignedTeam:{select:{id:true,name:true,code:true}},messages:{orderBy:{createdAt:'asc'},select:{senderId:true,createdAt:true}}},orderBy:{createdAt:'asc'},take:10000}),
      db.supportTicketTransfer.findMany({where:transferWhere,include:{toTeam:{select:{id:true,name:true,code:true}},toAgent:{select:{id:true,name:true,email:true}}},take:10000}),
      db.accessTeam.findMany({where:{active:true,accessKilled:false},select:{id:true,name:true,code:true},orderBy:{name:'asc'}}),
    ]);

    const workers = new Map<string, any>();
    const getWorker = (id:string, name?:string|null, email?:string|null, team?:any) => {
      let w=workers.get(id); if(!w){w={userId:id,name:name||id,email:email||'',teams:new Set<string>(),hours:0,days:new Set<string>(),sessions:0,tasksCreated:0,tasksDone:0,ticketsHandled:0,responseTotal:0,responseCount:0,slaMet:0,slaEligible:0,transfers:0};workers.set(id,w);} if(team) w.teams.add(team.name); return w;
    };
    const now = new Date();
    for(const x of sessions){const w=getWorker(x.userId,x.user.name,x.user.email,x.team);const heartbeat=x.lastHeartbeatAt??x.startedAt;const staleAt=new Date(heartbeat.getTime()+15*60*1000);const end=x.endedAt??(staleAt<now?staleAt:now);const a=x.startedAt>from?x.startedAt:from,b=end<to?end:to;const sec=Math.max(0,(b.getTime()-a.getTime())/1000);w.hours+=sec/3600;w.sessions++;w.days.add(bucketKey(x.startedAt,'DAY'));}
    for(const t of tasks){if(t.createdAt>=from){const id=t.assigneeId||t.createdById;const name=t.assignee?.name||t.assignee?.email||id;const email=t.assignee?.email||'';const w=getWorker(id,name,email,t.team);w.tasksCreated++;}if(t.completedAt&&t.completedAt>=from&&t.completedAt<to&&t.assignee){const w=getWorker(t.assignee.id,t.assignee.name,t.assignee.email,t.team);w.tasksDone++;}}
    for(const t of tickets){const a=t.assignedAgent; if(!a) continue; const w=getWorker(a.id,a.name,a.email,t.assignedTeam);w.ticketsHandled++;const staffIds=new Set<string>(); if(t.assignedAgentId)staffIds.add(t.assignedAgentId);let responseAt:Date|null=null;for(const m of t.messages){if(staffIds.has(m.senderId)&&m.createdAt>=t.createdAt){responseAt=m.createdAt;break;}}if(responseAt){const mins=Math.max(0,(responseAt.getTime()-t.createdAt.getTime())/60000);w.responseTotal+=mins;w.responseCount++;const target=SLA_MINUTES[t.priority]??120;w.slaEligible++;if(mins<=target)w.slaMet++;}}
    for(const tr of transfers){const ids=[tr.fromAgentId,tr.toAgentId,tr.createdById].filter(Boolean) as string[];for(const id of new Set(ids)){const w=getWorker(id);w.transfers++;}}

    const summary=[...workers.values()].map(w=>{const avgResponse=w.responseCount?w.responseTotal/w.responseCount:null;const sla=w.slaEligible?w.slaMet/w.slaEligible*100:null;const hours=Math.max(w.hours,0.01);const taskRate=Math.min(100,w.tasksDone/(hours/8)*100);const ticketRate=Math.min(100,w.ticketsHandled/(hours/8)*100);const responseScore=avgResponse==null?0:Math.max(0,Math.min(100,100-(avgResponse/120)*100));const slaScore=sla??0;const productivity=Math.round((taskRate*.30+ticketRate*.25+responseScore*.20+slaScore*.25));return {userId:w.userId,name:w.name,email:w.email,teamNames:[...w.teams],hours:Number(w.hours.toFixed(2)),daysWorked:w.days.size,sessions:w.sessions,tasksCreated:w.tasksCreated,tasksDone:w.tasksDone,ticketsHandled:w.ticketsHandled,avgResponseMinutes:avgResponse==null?null:Number(avgResponse.toFixed(2)),transfers:w.transfers,slaEligible:w.slaEligible,slaMet:w.slaMet,slaCompliancePct:sla==null?null:Number(sla.toFixed(2)),productivityIndex:productivity};}).sort((a,b)=>b.productivityIndex-a.productivityIndex);

    const trends = new Map<string, any>();
    for(const r of sessions){const k=bucketKey(r.startedAt,q.bucket);const x=trends.get(k)||{period:k,hours:0,days:new Set<string>(),sessions:0};const heartbeat=r.lastHeartbeatAt??r.startedAt;const staleAt=new Date(heartbeat.getTime()+15*60*1000);const end=r.endedAt??(staleAt<now?staleAt:now);const a=r.startedAt>from?r.startedAt:from,b=end<to?end:to;x.hours+=Math.max(0,(b.getTime()-a.getTime())/3600000);x.days.add(r.startedAt.toISOString().slice(0,10));x.sessions++;trends.set(k,x);}
    for(const t of tasks){const k=bucketKey(t.completedAt||t.createdAt,q.bucket);const x=trends.get(k)||{period:k,hours:0,days:new Set<string>(),sessions:0,tasksDone:0,ticketsHandled:0,transfers:0};if(t.completedAt)x.tasksDone=(x.tasksDone||0)+1;trends.set(k,x);}
    for(const t of tickets){const k=bucketKey(t.updatedAt,q.bucket);const x=trends.get(k)||{period:k,hours:0,days:new Set<string>(),sessions:0,tasksDone:0,ticketsHandled:0,transfers:0};if(t.assignedAgentId)x.ticketsHandled=(x.ticketsHandled||0)+1;trends.set(k,x);}
    for(const tr of transfers){const k=bucketKey(tr.createdAt,q.bucket);const x=trends.get(k)||{period:k,hours:0,days:new Set<string>(),sessions:0,tasksDone:0,ticketsHandled:0,transfers:0};x.transfers=(x.transfers||0)+1;trends.set(k,x);}
    const trend=[...trends.values()].sort((a,b)=>a.period.localeCompare(b.period)).map(x=>({...x,days:undefined,hours:Number(x.hours.toFixed(2)),tasksDone:x.tasksDone||0,ticketsHandled:x.ticketsHandled||0,transfers:x.transfers||0}));
    return NextResponse.json({ok:true,period:{from:from.toISOString(),to:to.toISOString(),bucket:q.bucket},teams,summary,trend,definitions:{slaTargetsMinutes:SLA_MINUTES,productivityIndex:'30% task throughput + 25% ticket throughput + 20% response score + 25% SLA compliance; operational indicator, not payroll truth'}});
  } catch(e){return NextResponse.json({ok:false,error:apiError(e)},{status:authStatus(e)})}
}
