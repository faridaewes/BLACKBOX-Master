import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { apiError, authStatus } from '@/lib/auth';
import { PERMISSIONS, requirePermissionSession } from '@/lib/access-control';

const range=z.object({from:z.string().datetime(),to:z.string().datetime(),teamId:z.string().optional(),userId:z.string().optional()});
function csvCell(v:unknown){const s=String(v??'').replace(/"/g,'""');return `"${s}"`;}
async function scope(s:any, teamId?:string){
  if(s.role==='DEVELOPER') return;
  if(teamId){const m=await db.accessTeamMember.findUnique({where:{teamId_userId:{teamId,userId:s.userId}}}); if(!m) throw new Error('TEAM_ACCESS_DENIED'); return;}
}
export async function GET(req:Request){try{
  const s=await requirePermissionSession(PERMISSIONS.WORK_ACTIVITY_READ); const q=range.parse(Object.fromEntries(new URL(req.url).searchParams)); await scope(s,q.teamId);
  const from=new Date(q.from),to=new Date(q.to); if(to<=from) throw new Error('INVALID_DATE_RANGE');
  const where:any={startedAt:{lt:to},OR:[{endedAt:null},{endedAt:{gt:from}}]}; if(q.teamId)where.teamId=q.teamId;if(q.userId)where.userId=q.userId;
  const myTeams=await db.accessTeam.findMany({where:{active:true,accessKilled:false,members:{some:{userId:s.userId}}},select:{id:true,name:true,code:true},orderBy:{name:'asc'}});
  const sessions=await db.workSession.findMany({where,include:{user:{select:{id:true,name:true,email:true}},team:{select:{id:true,name:true,code:true}}},orderBy:{startedAt:'asc'},take:10000});
  const rows=sessions.map(x=>{const heartbeat=x.lastHeartbeatAt??x.startedAt; const staleAt=new Date(heartbeat.getTime()+15*60*1000); const end=x.endedAt??(staleAt<new Date()?staleAt:new Date()); const a=x.startedAt>from?x.startedAt:from,b=end<to?end:to; return {...x,durationSeconds:Math.max(0,Math.floor((b.getTime()-a.getTime())/1000))};});
  const totals=new Map<string,any>(); for(const r of rows){const k=r.userId;const t=totals.get(k)||{userId:k,name:r.user.name,email:r.user.email,seconds:0,days:new Set<string>(),sessions:0,teamNames:new Set<string>()};t.seconds+=r.durationSeconds;t.sessions++;t.days.add(r.startedAt.toISOString().slice(0,10));t.teamNames.add(r.team.name);totals.set(k,t)}
  const summary=[...totals.values()].map(t=>({...t,daysWorked:t.days.size,teamNames:[...t.teamNames],hours:Number((t.seconds/3600).toFixed(2)),days:undefined,seconds:undefined}));
  return NextResponse.json({ok:true,period:{from:from.toISOString(),to:to.toISOString()},myTeams,sessions:rows,summary});
}catch(e){return NextResponse.json({ok:false,error:apiError(e)},{status:authStatus(e)})}}

export async function POST(req:Request){try{
  const s=await requirePermissionSession(PERMISSIONS.WORK_ACTIVITY_READ); const b=z.object({action:z.enum(['START','HEARTBEAT','STOP','EVENT']),teamId:z.string(),sessionId:z.string().optional(),type:z.string().max(80).optional(),taskId:z.string().nullable().optional(),metadata:z.record(z.any()).nullable().optional(),note:z.string().max(500).nullable().optional()}).parse(await req.json());
  const member=await db.accessTeamMember.findUnique({where:{teamId_userId:{teamId:b.teamId,userId:s.userId}}}); if(s.role!=='DEVELOPER'&&!member)throw new Error('TEAM_ACCESS_DENIED');
  const now=new Date();
  if(b.action==='START'){const active=await db.workSession.findFirst({where:{userId:s.userId,endedAt:null}}); if(active)return NextResponse.json({ok:true,session:active,reused:true}); const session=await db.workSession.create({data:{userId:s.userId,teamId:b.teamId,startedAt:now,lastHeartbeatAt:now,source:'WEB',note:b.note||null}}); await db.workActivityEvent.create({data:{userId:s.userId,teamId:b.teamId,sessionId:session.id,type:'SESSION_STARTED',metadata:b.metadata||undefined}});return NextResponse.json({ok:true,session});}
  if(!b.sessionId)throw new Error('SESSION_REQUIRED'); const session=await db.workSession.findUnique({where:{id:b.sessionId}}); if(!session||session.userId!==s.userId)throw new Error('SESSION_NOT_FOUND');
  if(b.action==='HEARTBEAT'){const updated=await db.workSession.update({where:{id:session.id},data:{lastHeartbeatAt:now}});return NextResponse.json({ok:true,session:updated});}
  if(b.action==='STOP'){const updated=await db.workSession.update({where:{id:session.id},data:{endedAt:now,lastHeartbeatAt:now}});await db.workActivityEvent.create({data:{userId:s.userId,teamId:session.teamId,sessionId:session.id,type:'SESSION_STOPPED',metadata:b.metadata||undefined}});return NextResponse.json({ok:true,session:updated});}
  const ev=await db.workActivityEvent.create({data:{userId:s.userId,teamId:session.teamId,sessionId:session.id,taskId:b.taskId||null,type:b.type||'ACTIVITY',metadata:b.metadata||undefined}});return NextResponse.json({ok:true,event:ev});
}catch(e){return NextResponse.json({ok:false,error:apiError(e)},{status:authStatus(e)})}}

export async function PUT(req:Request){try{
  const s=await requirePermissionSession(PERMISSIONS.WORK_ACTIVITY_EXPORT); const q=range.parse(Object.fromEntries(new URL(req.url).searchParams)); await scope(s,q.teamId);
  const from=new Date(q.from),to=new Date(q.to); const where:any={startedAt:{lt:to},OR:[{endedAt:null},{endedAt:{gt:from}}]};if(q.teamId)where.teamId=q.teamId;if(q.userId)where.userId=q.userId;
  const rows=await db.workSession.findMany({where,include:{user:{select:{name:true,email:true}},team:{select:{name:true,code:true}}},orderBy:{startedAt:'asc'},take:10000});
  const header=['date','employee','email','team','start','end','hours','source'];const lines=[header.map(csvCell).join(',')]; for(const x of rows){const heartbeat=x.lastHeartbeatAt??x.startedAt; const staleAt=new Date(heartbeat.getTime()+15*60*1000); const end=x.endedAt??(staleAt<new Date()?staleAt:new Date());const a=x.startedAt>from?x.startedAt:from,b=end<to?end:to;const sec=Math.max(0,Math.floor((b.getTime()-a.getTime())/1000));lines.push([a.toISOString().slice(0,10),x.user.name,x.user.email,x.team.name,a.toISOString(),x.endedAt?.toISOString()||'',(sec/3600).toFixed(2),x.source].map(csvCell).join(','));}
  return new NextResponse(lines.join('\n'),{headers:{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':`attachment; filename="blackbox-work-activity-${from.toISOString().slice(0,10)}-${to.toISOString().slice(0,10)}.csv"`}});
}catch(e){return NextResponse.json({ok:false,error:apiError(e)},{status:authStatus(e)})}}
