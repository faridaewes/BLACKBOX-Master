import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';
import { requireSession, authStatus } from '@/lib/auth';
import { hasPermission, PERMISSIONS } from '@/lib/access-control';

/**
 * Daily workforce recap for supervisors / audit / payroll evidence.
 * Query: ?date=YYYY-MM-DD&teamId=optional&userId=optional
 * Allowed: DEVELOPER, or ADMIN with WORK_ACTIVITY_READ / AUDIT_READ
 */
export async function GET(req: Request) {
  try {
    const s = await requireSession();
    const allowed =
      s.role === 'DEVELOPER' ||
      (await hasPermission(s.userId, PERMISSIONS.WORK_ACTIVITY_READ as any)) ||
      (await hasPermission(s.userId, PERMISSIONS.AUDIT_READ));
    if (!allowed) {
      return NextResponse.json({ ok: false, error: 'FORBIDDEN' }, { status: 403 });
    }

    const url = new URL(req.url);
    const dateStr = url.searchParams.get('date') || new Date().toISOString().slice(0, 10);
    const teamId = url.searchParams.get('teamId') || undefined;
    const userId = url.searchParams.get('userId') || undefined;
    const dayStart = new Date(`${dateStr}T00:00:00.000Z`);
    const dayEnd = new Date(`${dateStr}T23:59:59.999Z`);

    const sessionWhere: any = {
      startedAt: { lte: dayEnd },
      OR: [{ endedAt: null }, { endedAt: { gte: dayStart } }],
    };
    if (teamId) sessionWhere.teamId = teamId;
    if (userId) sessionWhere.userId = userId;

    const sessions = await db.workSession.findMany({
      where: sessionWhere,
      include: {
        user: { select: { id: true, name: true, email: true, role: true } },
        team: { select: { id: true, code: true, name: true } },
      },
      orderBy: { startedAt: 'asc' },
      take: 500,
    });

    const eventWhere: any = { createdAt: { gte: dayStart, lte: dayEnd } };
    if (teamId) eventWhere.teamId = teamId;
    if (userId) eventWhere.userId = userId;

    const events = await db.workActivityEvent.findMany({
      where: eventWhere,
      include: {
        actor: { select: { id: true, name: true } },
        team: { select: { id: true, name: true, code: true } },
      },
      orderBy: { createdAt: 'asc' },
      take: 2000,
    });

    type Agg = {
      userId: string;
      name: string;
      email?: string;
      teamNames: Set<string>;
      sessions: { start: string; end: string | null; team: string }[];
      messageCount: number;
      claimCount: number;
      transferCount: number;
      closeCount: number;
      ticketIds: Set<string>;
      categories: Record<string, number>;
    };
    const byUser = new Map<string, Agg>();

    const ensure = (id: string, name: string, email?: string) => {
      if (!byUser.has(id)) {
        byUser.set(id, {
          userId: id,
          name,
          email,
          teamNames: new Set(),
          sessions: [],
          messageCount: 0,
          claimCount: 0,
          transferCount: 0,
          closeCount: 0,
          ticketIds: new Set(),
          categories: {},
        });
      }
      return byUser.get(id)!;
    };

    for (const sess of sessions) {
      const a = ensure(sess.userId, sess.user.name, sess.user.email || undefined);
      a.teamNames.add(sess.team.name);
      a.sessions.push({
        start: sess.startedAt.toISOString(),
        end: sess.endedAt ? sess.endedAt.toISOString() : null,
        team: sess.team.name,
      });
    }

    for (const e of events) {
      const a = ensure(e.userId, e.actor.name);
      a.teamNames.add(e.team.name);
      const meta = (e.metadata || {}) as any;
      if (meta.ticketId) a.ticketIds.add(String(meta.ticketId));
      if (meta.category) a.categories[String(meta.category)] = (a.categories[String(meta.category)] || 0) + 1;
      if (e.type === 'SUPPORT_MESSAGE') a.messageCount += 1;
      if (e.type === 'SUPPORT_CLAIM') a.claimCount += 1;
      if (e.type === 'SUPPORT_TRANSFER') a.transferCount += 1;
      if (e.type === 'SUPPORT_CLOSE') a.closeCount += 1;
    }

    const agents = [...byUser.values()].map((a) => {
      let workedMs = 0;
      for (const s of a.sessions) {
        const start = new Date(s.start).getTime();
        const end = s.end ? new Date(s.end).getTime() : Math.min(Date.now(), dayEnd.getTime());
        workedMs += Math.max(0, end - start);
      }
      return {
        userId: a.userId,
        name: a.name,
        email: a.email,
        teams: [...a.teamNames],
        sessions: a.sessions,
        workedHours: Math.round((workedMs / 3600000) * 100) / 100,
        uniqueTicketsHandled: a.ticketIds.size,
        messageCount: a.messageCount,
        claimCount: a.claimCount,
        transferCount: a.transferCount,
        closeCount: a.closeCount,
        categories: a.categories,
      };
    });

    return NextResponse.json({
      ok: true,
      date: dateStr,
      agentCount: agents.length,
      agents,
      eventCount: events.length,
      sessionCount: sessions.length,
    });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'REQUEST_FAILED' }, { status: authStatus(e) });
  }
}
