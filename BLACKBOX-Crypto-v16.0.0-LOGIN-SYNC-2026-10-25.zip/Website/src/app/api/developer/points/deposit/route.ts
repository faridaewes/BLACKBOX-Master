import { NextResponse } from 'next/server';
import { z } from 'zod';
import crypto from 'node:crypto';
import { db } from '@/lib/prisma';
import { authStatus, requireSession } from '@/lib/auth';
import { requirePrincipal, PERMISSIONS } from '@/lib/access-control';

/**
 * Virtual referral-point deposit — DEVELOPER (Principal) only.
 * Used for reward grants; not money, not purchasable.
 */
const schema = z.object({
  userId: z.string().min(1),
  amount: z.coerce.number().int().min(1).max(100_000_000),
  description: z.string().trim().min(3).max(500),
  idempotencyKey: z.string().trim().min(8).max(120).optional(),
});

// Permission contract: PERMISSIONS.TIER_ACCESS_CODE governs this reward/tier operation; principal guard remains mandatory.
export async function POST(req: Request) {
  try {
    // Strict: only Developer Principal path (or DEVELOPER role via requirePrincipal)
    let actor: { userId: string };
    try {
      actor = await requirePrincipal();
    } catch {
      const s = await requireSession();
      if (s.role !== 'DEVELOPER') {
        return NextResponse.json({ ok: false, error: 'DEVELOPER_ONLY' }, { status: 403 });
      }
      actor = { userId: s.userId };
    }

    const b = schema.parse(await req.json());
    const ref = b.idempotencyKey || crypto.randomUUID();
    const user = await db.user.findUnique({
      where: { id: b.userId },
      select: { id: true, role: true },
    });
    if (!user || user.role !== 'USER') {
      return NextResponse.json({ ok: false, error: 'TARGET_USER_NOT_FOUND_OR_NOT_USER' }, { status: 404 });
    }

    const row = await db.$transaction(async (tx) => {
      const exists = await tx.pointDeposit.findUnique({ where: { referenceId: ref } });
      if (exists) return exists;
      const d = await tx.pointDeposit.create({
        data: {
          userId: user.id,
          amount: b.amount,
          referenceId: ref,
          description: b.description,
          createdById: actor.userId,
        },
      });
      await tx.referralPointLedger.create({
        data: {
          userId: user.id,
          amount: b.amount,
          kind: 'DEVELOPER_DEPOSIT',
          referenceType: 'POINT_DEPOSIT',
          referenceId: d.id,
          description: b.description,
        },
      });
      await tx.auditLog.create({
        data: {
          actorId: actor.userId,
          action: 'DEVELOPER_POINT_DEPOSIT',
          targetType: 'USER',
          targetId: user.id,
          metadata: { amount: b.amount, referenceId: ref, description: b.description },
        },
      });
      return d;
    });

    return NextResponse.json({ ok: true, deposit: row });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'REQUEST_FAILED' }, { status: authStatus(e) });
  }
}
