import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { authStatus } from '@/lib/auth';
import { calculateSystemHealth, persistSystemHealthSnapshot } from '@/lib/system-health-v72';
export async function GET(){try{await requirePermissionSession(PERMISSIONS.SYSTEM_HEALTH);return NextResponse.json({ok:true,health:await calculateSystemHealth()},{headers:{'cache-control':'no-store'}})}catch(e){return NextResponse.json({ok:false,error:'HEALTH_ACCESS_DENIED'},{status:authStatus(e)===401||authStatus(e)===403?authStatus(e):500})}}
export async function POST(){try{await requirePermissionSession(PERMISSIONS.SYSTEM_HEALTH);return NextResponse.json({ok:true,health:await persistSystemHealthSnapshot()})}catch(e){return NextResponse.json({ok:false,error:'HEALTH_SNAPSHOT_FAILED'},{status:500})}}
