import { requireDeveloper } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { authStatus } from '@/lib/auth';
import { db } from '@/lib/prisma';
import { DEFAULT_ALMAI_REFERRAL, getAlmaiReferral, validAlmaiUrl } from '@/lib/almai';
const schema=z.object({url:z.string().trim().url().max(1000)});
export async function GET(){try{await requireDeveloper();return NextResponse.json({ok:true,url:await getAlmaiReferral(),defaultUrl:DEFAULT_ALMAI_REFERRAL});}catch(e){return NextResponse.json({ok:false,error:'ALMAI_CONFIG_ACCESS_DENIED'},{status:authStatus(e)});}}
export async function PUT(req:Request){try{const actor=await requireDeveloper();const b=schema.parse(await req.json());if(!validAlmaiUrl(b.url))return NextResponse.json({ok:false,error:'ALMAI_URL_MUST_BE_HTTPS_ALMAI_ID'},{status:400});const row=await db.platformSetting.upsert({where:{key:'ALMAI_REFERRAL_URL'},update:{value:b.url,updatedById:actor.userId},create:{key:'ALMAI_REFERRAL_URL',value:b.url,updatedById:actor.userId}});await db.auditLog.create({data:{actorId:actor.userId,action:'ALMAI_REFERRAL_URL_UPDATED',targetType:'PLATFORM_SETTING',targetId:row.key,metadata:{url:b.url}}});return NextResponse.json({ok:true,url:row.value});}catch(e){if(e instanceof z.ZodError)return NextResponse.json({ok:false,error:'INPUT_TIDAK_VALID'},{status:400});return NextResponse.json({ok:false,error:'ALMAI_CONFIG_UPDATE_FAILED'},{status:authStatus(e)});}}
export async function DELETE(){try{const actor=await requireDeveloper();await db.platformSetting.deleteMany({where:{key:'ALMAI_REFERRAL_URL'}});await db.auditLog.create({data:{actorId:actor.userId,action:'ALMAI_REFERRAL_URL_RESET',targetType:'PLATFORM_SETTING',targetId:'ALMAI_REFERRAL_URL',metadata:{}}});return NextResponse.json({ok:true,url:DEFAULT_ALMAI_REFERRAL});}catch(e){return NextResponse.json({ok:false,error:'ALMAI_CONFIG_RESET_FAILED'},{status:authStatus(e)});}}
