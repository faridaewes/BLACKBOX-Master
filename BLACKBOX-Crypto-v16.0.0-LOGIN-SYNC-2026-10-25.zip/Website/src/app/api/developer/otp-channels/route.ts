import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { requirePrincipal } from '@/lib/access-control';
import { authStatus } from '@/lib/auth';
import { loadTwilioConfig, loadWhatsAppConfig } from '@/lib/otp-channels';
import { loadSmtpConfig } from '@/lib/smtp';
import { encryptSecret } from '@/lib/secret-vault';

export async function GET() {
  try {
    await requirePrincipal();
    const [twilio, wa, smtp] = await Promise.all([
      loadTwilioConfig(),
      loadWhatsAppConfig(),
      loadSmtpConfig(),
    ]);
    return NextResponse.json({
      ok: true,
      channels: {
        email: { configured: !!smtp, label: 'Email (SMTP) — sudah di panel SMTP' },
        whatsapp: {
          configured: !!wa,
          phoneNumberId: wa?.phoneNumberId || '',
          tokenSet: !!wa?.accessToken,
        },
        sms: {
          configured: !!twilio,
          from: twilio?.from || '',
          accountSid: twilio?.accountSid ? `${twilio.accountSid.slice(0, 6)}…` : '',
        },
      },
      guide: {
        recommended: 'WhatsApp Cloud API (gratis kuota awal Meta) ATAU andalkan email saja dulu',
        note: 'Jika WhatsApp & Twilio belum diisi, kode verifikasi HP tetap dikirim ke EMAIL user (fallback).',
      },
    });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'FORBIDDEN' }, { status: authStatus(e) });
  }
}

const schema = z.object({
  channel: z.enum(['WHATSAPP', 'TWILIO', 'CLEAR_WHATSAPP', 'CLEAR_TWILIO']),
  accessToken: z.string().max(500).optional(),
  phoneNumberId: z.string().max(80).optional(),
  accountSid: z.string().max(80).optional(),
  authToken: z.string().max(80).optional(),
  from: z.string().max(40).optional(),
});

export async function POST(req: Request) {
  try {
    const s = await requirePrincipal();
    const b = schema.parse(await req.json());

    if (b.channel === 'WHATSAPP') {
      if (!b.accessToken || !b.phoneNumberId) {
        return NextResponse.json({ ok: false, error: 'WHATSAPP_FIELDS_REQUIRED' }, { status: 400 });
      }
      await db.systemControl.upsert({
        where: { key: 'WHATSAPP_CONFIG' },
        update: {
          value: { encrypted: encryptSecret({ accessToken: b.accessToken, phoneNumberId: b.phoneNumberId }) },
          updatedBy: s.userId,
        },
        create: {
          key: 'WHATSAPP_CONFIG',
          value: { encrypted: encryptSecret({ accessToken: b.accessToken, phoneNumberId: b.phoneNumberId }) },
          updatedBy: s.userId,
        },
      });
    } else if (b.channel === 'TWILIO') {
      if (!b.accountSid || !b.authToken || !b.from) {
        return NextResponse.json({ ok: false, error: 'TWILIO_FIELDS_REQUIRED' }, { status: 400 });
      }
      await db.systemControl.upsert({
        where: { key: 'TWILIO_CONFIG' },
        update: {
          value: { encrypted: encryptSecret({ accountSid: b.accountSid, authToken: b.authToken, from: b.from }) },
          updatedBy: s.userId,
        },
        create: {
          key: 'TWILIO_CONFIG',
          value: { encrypted: encryptSecret({ accountSid: b.accountSid, authToken: b.authToken, from: b.from }) },
          updatedBy: s.userId,
        },
      });
    } else if (b.channel === 'CLEAR_WHATSAPP') {
      await db.systemControl.deleteMany({ where: { key: 'WHATSAPP_CONFIG' } });
    } else if (b.channel === 'CLEAR_TWILIO') {
      await db.systemControl.deleteMany({ where: { key: 'TWILIO_CONFIG' } });
    }

    await db.auditLog.create({
      data: {
        actorId: s.userId,
        action: 'OTP_CHANNEL_CONFIG',
        targetType: 'SYSTEM',
        metadata: { channel: b.channel },
      },
    });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'REQUEST_FAILED' }, { status: authStatus(e) });
  }
}
