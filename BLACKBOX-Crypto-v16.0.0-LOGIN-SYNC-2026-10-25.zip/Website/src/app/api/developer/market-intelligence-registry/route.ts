import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { authStatus } from '@/lib/auth';
import { db } from '@/lib/prisma';
import { P5_REGISTRY_VERSION } from '@/lib/market-intelligence-registry-v120';
import { p5DegradedPayload, p5FailureStatus, safeP5 } from '@/lib/p5-runtime-resilience-v1181';

export async function GET(){
  try{
    await requirePermissionSession(PERMISSIONS.SYSTEM_HEALTH);
    const [latest,counts,anomalies,health]=await Promise.all([
      db.marketIntelligenceRegistryRun.findFirst({orderBy:{startedAt:'desc'}}),
      db.marketIntelligenceRegistry.groupBy({by:['marketType','status'],_count:{_all:true}}),
      db.marketCoverageAnomaly.count({where:{status:'OPEN'}}),
      db.marketDataProviderHealthSnapshot.findMany({orderBy:{capturedAt:'desc'},take:100}),
    ]);
    return NextResponse.json({ok:true,version:P5_REGISTRY_VERSION,latest,counts,openCoverageAnomalies:anomalies,providerHealth:health,executionAllowed:false});
  }catch(e){ const status=p5FailureStatus(e); if(status!==200) return NextResponse.json({ok:false,error:'AUTHENTICATION_REQUIRED'},{status:authStatus(e)}); return NextResponse.json({ok:true,...p5DegradedPayload('REGISTRY',e),version:P5_REGISTRY_VERSION,source:'CERTIFIED_REGISTRY',mode:'READ_ONLY_INTELLIGENCE'}, {status:200,headers:{'Cache-Control':'no-store'}});}
}
