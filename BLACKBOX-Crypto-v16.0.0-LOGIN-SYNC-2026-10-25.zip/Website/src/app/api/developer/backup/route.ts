import { NextResponse } from 'next/server';
import path from 'node:path';
import { z } from 'zod';
import { authStatus } from '@/lib/auth';
import { requirePrincipal } from '@/lib/access-control';
import { db } from '@/lib/prisma';
import { createAndEmailBackup } from '@/lib/backup';
import { evaluateBackupCompleteness } from '@/lib/backup-completeness';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { clientIp, rateLimitUserKey } from '@/lib/rate-limit';

function configuredDirs(){return (process.env.BACKUP_MASTER_DATA_DIRS||`${process.env.KYC_PRIVATE_DIR||'./private-kyc'},${process.env.USER_PRIVATE_DIR||'./private-users'}`).split(',').map(x=>x.trim()).filter(Boolean).map((dir,index)=>({index,label:path.basename(path.resolve(dir))||`MASTER_${index+1}`,configured:true}));}
const schema = z.object({ destinationEmail: z.string().trim().email().max(320), scope: z.enum(['DATABASE','FULL_SYSTEM']), masterDataDirectories: z.array(z.number().int().nonnegative()).max(100).optional() });
export async function GET(){try{await requirePrincipal(); const completeness=await evaluateBackupCompleteness('FULL_SYSTEM'); return NextResponse.json({ok:true,database:true,masterDataDirectories:configuredDirs(),completeness});}catch(e){return NextResponse.json({ok:false,error:'BACKUP_ACCESS_DENIED'},{status:authStatus(e)});}}
export async function POST(req: Request) {
  try {
    const actor = await requirePrincipal();
    const rl = await distributedRateLimit(`developer-backup:${rateLimitUserKey(actor.userId, "backup")}:${clientIp(req)}`, 2, 60 * 60);
    if (!rl.ok) return NextResponse.json({ ok: false, error: 'BACKUP_RATE_LIMITED', retryAfterSec: rl.retryAfterSec }, { status: 429 });
    const body = schema.parse(await req.json());
    const result = await createAndEmailBackup({ destinationEmail: body.destinationEmail, scope: body.scope, masterDataDirectories: body.masterDataDirectories, actorId: actor.userId, actorName: actor.name });
    await db.auditLog.create({ data: { actorId: actor.userId, action: result.scope === 'FULL_SYSTEM' ? 'FULL_SYSTEM_BACKUP_EMAILED' : 'DATABASE_BACKUP_EMAILED', targetType: 'SYSTEM_BACKUP', metadata: { destinationEmail: result.destinationEmail, filename: result.filename, sizeBytes: result.sizeBytes, sha256: result.sha256, tableCount: result.tableCount, masterFileCount: result.masterFileCount } } }).catch(() => {});
    return NextResponse.json({ ok: true, backup: result });
  } catch (e) {
    if (e instanceof z.ZodError) return NextResponse.json({ ok: false, error: 'BACKUP_INPUT_INVALID' }, { status: 400 });
    const message = e instanceof Error ? e.message : String(e);
    const safe = ['SMTP_NOT_CONFIGURED','BACKUP_SCOPE_INVALID','BACKUP_DATABASE_URL_MISSING','BACKUP_SNAPSHOT_EXPORT_FAILED','BACKUP_PG_DUMP_FAILED','BACKUP_MASTER_FILE_COUNT_EXCEEDED','BACKUP_MASTER_DATA_TOO_LARGE','BACKUP_ENCRYPTION_KEY_INVALID','BACKUP_EMAIL_INVALID','BACKUP_TOO_LARGE_FOR_EMAIL','BACKUP_EMAIL_DELIVERY_REJECTED','BACKUP_OBJECT_STORAGE_UPLOAD_FAILED','BACKUP_MASTER_DATA_DIRECTORIES_NOT_CONFIGURED','BACKUP_MASTER_SELECTION_REQUIRED','BACKUP_MASTER_SELECTION_INVALID','BACKUP_COMPLETENESS_CONTRACT_FAILED'].some(x => message.startsWith(x)) || message.startsWith('BACKUP_TABLE_TOO_LARGE') || message.startsWith('BACKUP_MASTER_DATA_DIRECTORY_MISSING:');
    return NextResponse.json({ ok: false, error: safe ? message : 'BACKUP_FAILED' }, { status: authStatus(e) === 401 || authStatus(e) === 403 ? authStatus(e) : 500 });
  }
}
