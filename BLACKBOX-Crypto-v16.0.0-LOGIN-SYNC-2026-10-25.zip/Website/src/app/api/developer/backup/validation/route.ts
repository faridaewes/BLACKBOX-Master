import { NextResponse } from 'next/server';
import { spawn } from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import { authStatus } from '@/lib/auth';
import { requirePrincipal } from '@/lib/access-control';
import { readBackupValidationStatus } from '@/lib/backup-validation';

const statusFile = path.resolve(process.env.BACKUP_RESTORE_STATUS_FILE || './private-backup/restore-status.json');
const lockFile = `${statusFile}.validation.lock`;

export async function GET() {
  try { await requirePrincipal(); return NextResponse.json({ ok:true, validation: await readBackupValidationStatus() }); }
  catch(e) { return NextResponse.json({ok:false,error:'VALIDATION_ACCESS_DENIED'},{status:authStatus(e)===401||authStatus(e)===403?authStatus(e):500}); }
}

export async function POST() {
  try {
    await requirePrincipal();
    try { const f=await fs.open(lockFile, 'wx'); await f.close(); }
    catch { return NextResponse.json({ok:false,error:'VALIDATION_ALREADY_RUNNING',validation:await readBackupValidationStatus()},{status:409}); }
    const script = path.resolve('./scripts/validate-restored-backup.mjs');
    const child = spawn(process.execPath, ['--experimental-strip-types', script], { detached:true, stdio:'ignore', env:{...process.env, BACKUP_RESTORE_STATUS_FILE:statusFile, BACKUP_VALIDATION_LOCK_FILE:lockFile} });
    child.unref();
    return NextResponse.json({ok:true,state:'STARTED',validation:await readBackupValidationStatus()});
  } catch(e) { return NextResponse.json({ok:false,error:'VALIDATION_START_FAILED'},{status:authStatus(e)===401||authStatus(e)===403?authStatus(e):500}); }
}
