import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { authStatus, requireSession } from '@/lib/auth';
import { requirePrincipal } from '@/lib/access-control';

/**
 * Recruit existing USER → ADMIN (or DEVELOPER REPRESENTATIVE path limited),
 * or demote ADMIN → USER. Developer-only.
 */
const promoteSchema = z.object({
  action: z.enum(['PROMOTE', 'DEMOTE', 'SUSPEND_WORK', 'RESTORE_WORK']),
  userId: z.string().min(1),
  role: z.enum(['ADMIN', 'USER']).optional(),
  teamId: z.string().optional(),
  reason: z.string().trim().min(3).max(500).optional(),
});

export async function GET() {
  try {
    const s = await requireSession();
    if (s.role !== 'DEVELOPER') {
      return NextResponse.json({ ok: false, error: 'DEVELOPER_ONLY' }, { status: 403 });
    }
    const [staff, users] = await Promise.all([
      db.user.findMany({
        where: { role: { in: ['ADMIN', 'DEVELOPER'] } },
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          status: true,
          developerLevel: true,
          createdAt: true,
          teamMemberships: {
            select: {
              team: { select: { id: true, code: true, name: true, leadUserId: true } },
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        take: 200,
      }),
      db.user.findMany({
        where: { role: 'USER', status: 'ACTIVE' },
        select: { id: true, name: true, email: true, createdAt: true },
        orderBy: { createdAt: 'desc' },
        take: 100,
      }),
    ]);
    const teams = await db.accessTeam.findMany({
      where: { active: true, accessKilled: false },
      select: { id: true, code: true, name: true, leadUserId: true },
      orderBy: { name: 'asc' },
      take: 100,
    });
    return NextResponse.json({ ok: true, staff, recruitableUsers: users, teams });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'REQUEST_FAILED' }, { status: authStatus(e) });
  }
}

export async function POST(req: Request) {
  try {
    const actor = await requireSession();
    if (actor.role !== 'DEVELOPER') {
      return NextResponse.json({ ok: false, error: 'DEVELOPER_ONLY' }, { status: 403 });
    }
    // Prefer principal for promote to ADMIN with broad rights; representatives can demote/suspend with care
    const b = promoteSchema.parse(await req.json());
    const target = await db.user.findUnique({
      where: { id: b.userId },
      select: { id: true, role: true, status: true, name: true, email: true, developerLevel: true },
    });
    if (!target) return NextResponse.json({ ok: false, error: 'USER_NOT_FOUND' }, { status: 404 });
    if (target.id === actor.userId) {
      return NextResponse.json({ ok: false, error: 'CANNOT_MODIFY_SELF' }, { status: 400 });
    }
    if (target.role === 'DEVELOPER' && target.developerLevel === 'PRINCIPAL') {
      return NextResponse.json({ ok: false, error: 'CANNOT_MODIFY_PRINCIPAL' }, { status: 403 });
    }

    if (b.action === 'PROMOTE') {
      if (target.role !== 'USER') {
        return NextResponse.json({ ok: false, error: 'TARGET_NOT_USER' }, { status: 400 });
      }
      const role = b.role || 'ADMIN';
      if (role !== 'ADMIN') {
        return NextResponse.json({ ok: false, error: 'ONLY_PROMOTE_TO_ADMIN' }, { status: 400 });
      }
      await db.$transaction(async (tx) => {
        await tx.user.update({ where: { id: target.id }, data: { role: 'ADMIN', status: 'ACTIVE' } });
        if (b.teamId) {
          const team = await tx.accessTeam.findUnique({ where: { id: b.teamId } });
          if (team) {
            await tx.accessTeamMember.upsert({
              where: { teamId_userId: { teamId: b.teamId, userId: target.id } },
              create: { teamId: b.teamId, userId: target.id, assignedById: actor.userId },
              update: {},
            });
          }
        }
        await tx.auditLog.create({
          data: {
            actorId: actor.userId,
            action: 'STAFF_PROMOTE',
            targetType: 'USER',
            targetId: target.id,
            metadata: { from: 'USER', to: 'ADMIN', teamId: b.teamId || null, reason: b.reason || null },
          },
        });
      });
      return NextResponse.json({ ok: true, message: `${target.name} dipromosikan menjadi ADMIN` });
    }

    if (b.action === 'DEMOTE') {
      if (target.role !== 'ADMIN') {
        return NextResponse.json({ ok: false, error: 'TARGET_NOT_ADMIN' }, { status: 400 });
      }
      await db.$transaction(async (tx) => {
        await tx.user.update({ where: { id: target.id }, data: { role: 'USER' } });
        await tx.accessTeamMember.deleteMany({ where: { userId: target.id } });
        await tx.adminAssignment.deleteMany({ where: { adminId: target.id } });
        // clear team lead if any
        await tx.accessTeam.updateMany({ where: { leadUserId: target.id }, data: { leadUserId: null } });
        await tx.auditLog.create({
          data: {
            actorId: actor.userId,
            action: 'STAFF_DEMOTE',
            targetType: 'USER',
            targetId: target.id,
            metadata: { from: 'ADMIN', to: 'USER', reason: b.reason || null },
          },
        });
      });
      return NextResponse.json({ ok: true, message: `${target.name} dikembalikan menjadi USER` });
    }

    if (b.action === 'SUSPEND_WORK') {
      // Suspend work access: set status SUSPENDED + kill team access flags via AccessKillEvent
      await db.$transaction(async (tx) => {
        await tx.user.update({
          where: { id: target.id },
          data: { status: 'SUSPENDED' },
        });
        await tx.session.deleteMany({ where: { userId: target.id } });
        await tx.accessKillEvent.create({
          data: {
            actorId: actor.userId,
            targetUserId: target.id,
            action: 'SUSPEND_WORK',
            reason: b.reason || 'Urgent suspend by developer',
          },
        });
        await tx.auditLog.create({
          data: {
            actorId: actor.userId,
            action: 'STAFF_SUSPEND_WORK',
            targetType: 'USER',
            targetId: target.id,
            metadata: { reason: b.reason || null },
          },
        });
      });
      return NextResponse.json({ ok: true, message: `Akses kerja ${target.name} di-suspend (urgent)` });
    }

    if (b.action === 'RESTORE_WORK') {
      await db.$transaction(async (tx) => {
        await tx.user.update({ where: { id: target.id }, data: { status: 'ACTIVE' } });
        await tx.accessKillEvent.create({
          data: {
            actorId: actor.userId,
            targetUserId: target.id,
            action: 'RESTORE_WORK',
            reason: b.reason || 'Work access restored',
          },
        });
        await tx.auditLog.create({
          data: {
            actorId: actor.userId,
            action: 'STAFF_RESTORE_WORK',
            targetType: 'USER',
            targetId: target.id,
            metadata: { reason: b.reason || null },
          },
        });
      });
      return NextResponse.json({ ok: true, message: `Akses kerja ${target.name} dipulihkan` });
    }

    return NextResponse.json({ ok: false, error: 'UNKNOWN_ACTION' }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'REQUEST_FAILED' }, { status: authStatus(e) });
  }
}
