import { requirePermissionSession, PERMISSIONS, hasPermission } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { authStatus, requireSession } from '@/lib/auth';
import { db } from '@/lib/prisma';
import { DEFAULT_COMMUNICATION_TEMPLATES, TEMPLATE_PLACEHOLDERS } from '@/lib/communication-templates';
const schema=z.object({action:z.enum(['CREATE','UPDATE','DELETE','ENABLE','DISABLE']),id:z.string().optional(),kind:z.enum(['USER_BROADCAST','OFFICIAL_BROADCAST','TRANSACTION_ALERT','TIER_ACTIVATION']).optional(),name:z.string().trim().min(2).max(80).optional(),titleTemplate:z.string().max(300).nullable().optional(),bodyTemplate:z.string().min(3).max(12000).optional()});
async function requireTemplateAccess(kind?:string){
  const s=await requireSession();
  const permission=kind==='TIER_ACTIVATION'?PERMISSIONS.TIER_NOTIFICATION_TEMPLATE_MANAGE:PERMISSIONS.COMMUNICATION_TEMPLATE_MANAGE;
  if(!(await hasPermission(s.userId,permission))) throw new Error('TEMPLATE_ACCESS_DENIED');
  return s;
}
function validateTransactionTemplate(kind:string|undefined,title:string|null|undefined,body:string|undefined){if(kind!=='TRANSACTION_ALERT')return;const text=`${title||''}\n${body||''}`;if(/\b(DEMO|PAPER|SIMULATION|SETTLEMENT)\b/i.test(text))throw new Error('TRANSACTION_TEMPLATE_FORBIDDEN_WORD');if(!body?.includes('{{alertId}}')||!body.includes('{{timestamp}}'))throw new Error('TRANSACTION_TEMPLATE_REQUIRED_FIELDS');}
export async function GET(){try{const s=await requireSession();const canGeneral=await hasPermission(s.userId,PERMISSIONS.COMMUNICATION_TEMPLATE_MANAGE);const canTier=await hasPermission(s.userId,PERMISSIONS.TIER_NOTIFICATION_TEMPLATE_MANAGE);if(!canGeneral&&!canTier)throw new Error('TEMPLATE_ACCESS_DENIED');const rows=await db.communicationTemplate.findMany({orderBy:[{kind:'asc'},{updatedAt:'desc'}]});return NextResponse.json({ok:true,templates:rows,defaults:DEFAULT_COMMUNICATION_TEMPLATES,placeholders:TEMPLATE_PLACEHOLDERS});}catch(e){return NextResponse.json({ok:false,error:'TEMPLATE_ACCESS_DENIED'},{status:authStatus(e)});}}
export async function POST(req:Request){try{const b=schema.parse(await req.json());if(b.action==='CREATE'){const actor=await requireTemplateAccess(b.kind);if(!b.kind||!b.name||!b.bodyTemplate)return NextResponse.json({ok:false,error:'TEMPLATE_FIELDS_REQUIRED'},{status:400});validateTransactionTemplate(b.kind,b.titleTemplate,b.bodyTemplate);const row=await db.communicationTemplate.create({data:{kind:b.kind,name:b.name,titleTemplate:b.titleTemplate??null,bodyTemplate:b.bodyTemplate,createdById:actor.userId}});await db.auditLog.create({data:{actorId:actor.userId,action:'COMMUNICATION_TEMPLATE_CREATED',targetType:'COMMUNICATION_TEMPLATE',targetId:row.id,metadata:{kind:row.kind,name:row.name}}});return NextResponse.json({ok:true,template:row});}
if(!b.id)return NextResponse.json({ok:false,error:'TEMPLATE_ID_REQUIRED'},{status:400});
const existingForAccess=await db.communicationTemplate.findUnique({where:{id:b.id},select:{kind:true}});
if(!existingForAccess)return NextResponse.json({ok:false,error:'TEMPLATE_NOT_FOUND'},{status:404});
const actorForExisting=await requireTemplateAccess(existingForAccess.kind);
if(b.action==='DELETE'){

await db.communicationTemplate.delete({where:{id:b.id}});await db.auditLog.create({data:{actorId:actorForExisting.userId,action:'COMMUNICATION_TEMPLATE_DELETED',targetType:'COMMUNICATION_TEMPLATE',targetId:b.id,metadata:{}}});return NextResponse.json({ok:true});}
const existing=b.id?await db.communicationTemplate.findUnique({where:{id:b.id}}):null;
validateTransactionTemplate(existing?.kind,b.titleTemplate??existing?.titleTemplate,b.bodyTemplate??existing?.bodyTemplate);
const data:any={};if(b.name!==undefined)data.name=b.name;if(b.titleTemplate!==undefined)data.titleTemplate=b.titleTemplate;if(b.bodyTemplate!==undefined)data.bodyTemplate=b.bodyTemplate;if(b.action==='ENABLE')data.enabled=true;if(b.action==='DISABLE')data.enabled=false;const row=await db.communicationTemplate.update({where:{id:b.id},data});await db.auditLog.create({data:{actorId:actorForExisting.userId,action:'COMMUNICATION_TEMPLATE_UPDATED',targetType:'COMMUNICATION_TEMPLATE',targetId:b.id,metadata:{action:b.action}}});return NextResponse.json({ok:true,template:row});
}catch(e){if(e instanceof z.ZodError)return NextResponse.json({ok:false,error:'INPUT_TIDAK_VALID'},{status:400});return NextResponse.json({ok:false,error:'TEMPLATE_OPERATION_FAILED'},{status:authStatus(e)});}}
