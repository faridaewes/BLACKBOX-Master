import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { authStatus, requireSession } from '@/lib/auth';
import { hasPermission, PERMISSIONS } from '@/lib/access-control';

const schema = z.object({
  action: z.enum(['ASSIGN', 'REVOKE', 'UPDATE']),
  userId: z.string().min(1),
  title: z.string().trim().min(1).max(160).optional(),
  specialization: z.string().trim().max(240).optional(),
  licenseNumber: z.string().max(120).optional(),
  company: z.string().max(160).optional(),
  bio: z.string().max(8000).optional(),
  photoUrl: z.string().max(2000).optional(),
  whatsapp: z.string().max(80).optional(),
  telegram: z.string().max(120).optional(),
  tiktok: z.string().max(160).optional(),
  phone: z.string().max(40).optional(),
  workflowStatus: z.enum(['DRAFT', 'REVIEW', 'PUBLISHED', 'ARCHIVED']).optional(),
  active: z.boolean().optional(),
  sortOrder: z.coerce.number().int().min(0).max(999).optional(),
});

async function assertCanManageWpa(userId: string, role: string) {
  if (role === 'DEVELOPER') return true;
  return hasPermission(userId, PERMISSIONS.WPA_MANAGE as any).catch(() => false)
    || hasPermission(userId, PERMISSIONS.PUBLIC_CONTENT_WRITE);
}

export async function GET() {
  try {
    const s = await requireSession();
    if (!(await assertCanManageWpa(s.userId, s.role))) {
      return NextResponse.json({ ok: false, error: 'FORBIDDEN' }, { status: 403 });
    }
    const [profiles, candidates] = await Promise.all([
      db.publicAdvisor.findMany({
        orderBy: { sortOrder: 'asc' },
        include: {
          user: { select: { id: true, name: true, email: true, role: true, status: true } },
        },
        take: 200,
      }),
      db.user.findMany({
        where: {
          role: 'USER',
          status: 'ACTIVE',
          wpaProfile: null,
        },
        select: { id: true, name: true, email: true, phone: true },
        orderBy: { createdAt: 'desc' },
        take: 150,
      }),
    ]);
    return NextResponse.json({ ok: true, profiles, candidates });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'REQUEST_FAILED' }, { status: authStatus(e) });
  }
}

export async function POST(req: Request) {
  try {
    const s = await requireSession();
    if (!(await assertCanManageWpa(s.userId, s.role))) {
      return NextResponse.json({ ok: false, error: 'FORBIDDEN' }, { status: 403 });
    }
    const b = schema.parse(await req.json());
    const user = await db.user.findUnique({
      where: { id: b.userId },
      select: { id: true, name: true, email: true, phone: true, role: true },
    });
    if (!user) return NextResponse.json({ ok: false, error: 'USER_NOT_FOUND' }, { status: 404 });
    if (user.role === 'DEVELOPER') {
      return NextResponse.json({ ok: false, error: 'CANNOT_ASSIGN_DEVELOPER' }, { status: 400 });
    }

    if (b.action === 'ASSIGN') {
      const existing = await db.publicAdvisor.findUnique({ where: { userId: user.id } });
      if (existing) {
        return NextResponse.json({ ok: false, error: 'USER_ALREADY_WPA' }, { status: 409 });
      }
      const row = await db.publicAdvisor.create({
        data: {
          userId: user.id,
          name: user.name,
          title: b.title || 'Wakil Penasihat Berjangka',
          specialization: b.specialization || null,
          licenseNumber: b.licenseNumber || null,
          company: b.company || null,
          photoUrl: b.photoUrl || null,
          bio: b.bio || `Profil WPA resmi atas nama ${user.name}.`,
          phone: b.phone || user.phone || null,
          whatsapp: b.whatsapp || user.phone || null,
          telegram: b.telegram || null,
          tiktok: b.tiktok || null,
          workflowStatus: b.workflowStatus || 'DRAFT',
          active: b.active !== false,
          sortOrder: b.sortOrder ?? 0,
          createdById: s.userId,
          publishedAt: (b.workflowStatus || 'DRAFT') === 'PUBLISHED' ? new Date() : null,
        },
      });
      await db.auditLog.create({
        data: {
          actorId: s.userId,
          action: 'WPA_ASSIGN',
          targetType: 'USER',
          targetId: user.id,
          metadata: { advisorId: row.id, status: row.workflowStatus },
        },
      });
      return NextResponse.json({ ok: true, profile: row, message: `${user.name} ditetapkan sebagai WPA` });
    }

    if (b.action === 'REVOKE') {
      const existing = await db.publicAdvisor.findUnique({ where: { userId: user.id } });
      if (!existing) {
        return NextResponse.json({ ok: false, error: 'USER_NOT_WPA' }, { status: 404 });
      }
      await db.publicAdvisor.update({
        where: { id: existing.id },
        data: {
          userId: null,
          active: false,
          workflowStatus: 'ARCHIVED',
        },
      });
      await db.auditLog.create({
        data: {
          actorId: s.userId,
          action: 'WPA_REVOKE',
          targetType: 'USER',
          targetId: user.id,
          metadata: { advisorId: existing.id },
        },
      });
      return NextResponse.json({ ok: true, message: `Status WPA ${user.name} dicabut — kembali sebagai user biasa` });
    }

    if (b.action === 'UPDATE') {
      const existing = await db.publicAdvisor.findUnique({ where: { userId: user.id } });
      if (!existing) {
        return NextResponse.json({ ok: false, error: 'USER_NOT_WPA' }, { status: 404 });
      }
      const data: any = {};
      for (const k of [
        'title',
        'specialization',
        'licenseNumber',
        'company',
        'bio',
        'photoUrl',
        'whatsapp',
        'telegram',
        'tiktok',
        'phone',
        'workflowStatus',
        'active',
        'sortOrder',
      ] as const) {
        if (b[k] !== undefined) data[k] = b[k];
      }
      if (b.workflowStatus === 'PUBLISHED') data.publishedAt = new Date();
      // keep display name in sync optionally
      data.name = user.name;
      const row = await db.publicAdvisor.update({ where: { id: existing.id }, data });
      await db.auditLog.create({
        data: {
          actorId: s.userId,
          action: 'WPA_UPDATE',
          targetType: 'USER',
          targetId: user.id,
          metadata: { advisorId: row.id, fields: Object.keys(data) },
        },
      });
      return NextResponse.json({ ok: true, profile: row });
    }

    return NextResponse.json({ ok: false, error: 'UNKNOWN_ACTION' }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'REQUEST_FAILED' }, { status: authStatus(e) });
  }
}
