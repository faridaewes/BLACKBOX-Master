import { NextResponse } from 'next/server';
import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { authStatus } from '@/lib/auth';
import { masterEraStatus } from '@/lib/era-release-orchestrator-current';
export const dynamic='force-dynamic';
export async function GET(){try{await requirePermissionSession(PERMISSIONS.SYSTEM_HEALTH);return NextResponse.json({ok:true,status:masterEraStatus()},{headers:{'cache-control':'no-store'}});}catch(e){return NextResponse.json({ok:false,error:'ERA_STATUS_ACCESS_DENIED'},{status:authStatus(e)})}}
