import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { authStatus, requireSession } from '@/lib/auth';
import { hasPermission, PERMISSIONS } from '@/lib/access-control';
import { notifyUser } from '@/lib/notify-user';

const schema = z.object({
  action: z.enum(['UNFREEZE_TRADING', 'UNBLOCK_ACCOUNT', 'NORMALIZE']),
  userId: z.string().min(1),
  reason: z.string().trim().min(3).max(500).optional(),
});

async function canHelp(userId: string, role: string) {
  if (role === 'DEVELOPER') return true;
  if (await hasPermission(userId, PERMISSIONS.USER_SUSPEND)) return true;
  if (await hasPermission(userId, PERMISSIONS.USER_READ)) return true;
  return false;
}

export async function POST(req: Request) {
  try {
    const s = await requireSession();
    if (!(await canHelp(s.userId, s.role))) {
      return NextResponse.json({ ok: false, error: 'FORBIDDEN' }, { status: 403 });
    }
    const b = schema.parse(await req.json());
    const user = await db.user.findUnique({
      where: { id: b.userId },
      select: { id: true, name: true, email: true, status: true, role: true },
    });
    if (!user) return NextResponse.json({ ok: false, error: 'USER_NOT_FOUND' }, { status: 404 });
    if (user.role === 'DEVELOPER') {
      return NextResponse.json({ ok: false, error: 'CANNOT_MODIFY_DEVELOPER' }, { status: 403 });
    }

    const reason = b.reason || 'Staff recovery';

    if (b.action === 'UNFREEZE_TRADING' || b.action === 'NORMALIZE') {
      await db.systemControl.deleteMany({ where: { key: `USER_TRADE_FREEZE:${user.id}` } }).catch(() => {});
      await db.auditLog.create({
        data: {
          actorId: s.userId,
          action: 'ACCOUNT_TRADE_UNFREEZE',
          targetType: 'USER',
          targetId: user.id,
          metadata: { reason },
        },
      });
    }

    if (b.action === 'UNBLOCK_ACCOUNT' || b.action === 'NORMALIZE') {
      if (user.status === 'SUSPENDED' || user.status === 'DISABLED') {
        // Only DEVELOPER can lift DISABLED; ADMIN can lift SUSPENDED
        if (user.status === 'DISABLED' && s.role !== 'DEVELOPER') {
          return NextResponse.json({ ok: false, error: 'ONLY_DEVELOPER_CAN_LIFT_DISABLED' }, { status: 403 });
        }
        await db.user.update({
          where: { id: user.id },
          data: { status: 'ACTIVE' },
        });
      }
      await db.auditLog.create({
        data: {
          actorId: s.userId,
          action: 'ACCOUNT_UNBLOCK',
          targetType: 'USER',
          targetId: user.id,
          metadata: { reason, previousStatus: user.status },
        },
      });
    }

    await notifyUser({
      userId: user.id,
      title: 'Akun dipulihkan',
      body:
        b.action === 'UNFREEZE_TRADING'
          ? 'Pembatasan trading pada akun Anda telah dibuka oleh petugas. Anda dapat menjalankan bot kembali sesuai paket.'
          : b.action === 'UNBLOCK_ACCOUNT'
            ? 'Blokir akun Anda telah dicabut. Silakan login kembali.'
            : 'Akun Anda telah dinormalkan (blokir & freeze trading dibersihkan) oleh petugas.',
      email: user.email,
      emailSubject: 'BLACKBOX — Akun dipulihkan',
      type: 'ACCOUNT_RECOVERY',
    }).catch(() => {});

    return NextResponse.json({
      ok: true,
      message:
        b.action === 'NORMALIZE'
          ? `${user.name}: unfreeze + unblock selesai`
          : b.action === 'UNFREEZE_TRADING'
            ? `${user.name}: trading unfreeze`
            : `${user.name}: akun dibuka`,
    });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'REQUEST_FAILED' }, { status: authStatus(e) });
  }
}
