import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { NextResponse } from 'next/server';
import { authStatus } from '@/lib/auth';
import { providerHealthSnapshot, resetProviderHealth } from '@/lib/provider-failover-v1181';
import { p4ProviderHealthSnapshot, resetP4ProviderHealth, P4_MARKET_RUNTIME_VERSION } from '@/lib/market-runtime-resilience-v1181-p4';

export async function GET(){
  try{
    await requirePermissionSession(PERMISSIONS.SYSTEM_HEALTH);
    const providers=providerHealthSnapshot();
    const marketRuntime=p4ProviderHealthSnapshot();
    return NextResponse.json({ok:true,version:'11.8.1-p0',marketRuntimeVersion:P4_MARKET_RUNTIME_VERSION,providers,marketRuntimeProviders:marketRuntime,summary:{total:providers.length,healthy:providers.filter(p=>p.state==='HEALTHY').length,degraded:providers.filter(p=>p.state==='DEGRADED').length,blocked:providers.filter(p=>p.state==='BLOCKED').length,offline:providers.filter(p=>['OFFLINE','TIMEOUT','RATE_LIMITED','AUTH_ERROR'].includes(p.state)).length}},{headers:{'cache-control':'no-store'}});
  }catch(e){return NextResponse.json({ok:false,error:'PROVIDER_HEALTH_ACCESS_DENIED'},{status:authStatus(e)});}
}

export async function POST(req:Request){
  try{
    await requirePermissionSession(PERMISSIONS.SYSTEM_HEALTH);
    const body=await req.json().catch(()=>({}));
    resetProviderHealth(typeof body?.provider==='string'?body.provider:undefined);
    resetP4ProviderHealth(typeof body?.provider==='string'?body.provider:undefined);
    return NextResponse.json({ok:true,reset:body?.provider||'ALL'});
  }catch(e){return NextResponse.json({ok:false,error:'PROVIDER_HEALTH_RESET_DENIED'},{status:authStatus(e)});}
}
