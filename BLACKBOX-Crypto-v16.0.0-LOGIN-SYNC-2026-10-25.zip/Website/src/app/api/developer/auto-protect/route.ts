import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { authStatus, requireSession } from '@/lib/auth';
import { requirePrincipal } from '@/lib/access-control';
import { resolveProtectEmail, triggerAutoProtect } from '@/lib/auto-protect';

export async function GET() {
  try {
    await requirePrincipal();
    const email = await resolveProtectEmail();
    const row = await db.systemControl.findUnique({ where: { key: 'AUTO_PROTECT_BACKUP_EMAIL' } });
    return NextResponse.json({
      ok: true,
      email: email,
      configured: !!email,
      stored: row?.value ?? null,
      note: 'Saat sinyal keamanan serius, sistem dapat mem-backup FULL_SYSTEM (ZIP terenkripsi) dan mengirim ke email ini.',
    });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'FORBIDDEN' }, { status: authStatus(e) });
  }
}

const schema = z.object({
  action: z.enum(['SET_EMAIL', 'TEST_BACKUP', 'TRIGGER_PROTECT']),
  email: z.string().email().optional(),
  haltTrading: z.boolean().optional(),
});

export async function POST(req: Request) {
  try {
    const s = await requirePrincipal();
    const b = schema.parse(await req.json());

    if (b.action === 'SET_EMAIL') {
      if (!b.email) return NextResponse.json({ ok: false, error: 'EMAIL_REQUIRED' }, { status: 400 });
      await db.systemControl.upsert({
        where: { key: 'AUTO_PROTECT_BACKUP_EMAIL' },
        update: { value: b.email.trim().toLowerCase(), updatedBy: s.userId },
        create: { key: 'AUTO_PROTECT_BACKUP_EMAIL', value: b.email.trim().toLowerCase(), updatedBy: s.userId },
      });
      await db.auditLog.create({
        data: {
          actorId: s.userId,
          action: 'AUTO_PROTECT_EMAIL_SET',
          targetType: 'SYSTEM',
          metadata: { email: b.email.trim().toLowerCase() },
        },
      });
      return NextResponse.json({ ok: true, email: b.email.trim().toLowerCase() });
    }

    if (b.action === 'TEST_BACKUP' || b.action === 'TRIGGER_PROTECT') {
      const result = await triggerAutoProtect({
        reason: b.action === 'TEST_BACKUP' ? 'EMERGENCY_BACKUP' : 'MANUAL_DEVELOPER',
        detail: b.action === 'TEST_BACKUP' ? 'Developer test backup' : 'Manual protect trigger',
        actorId: s.userId,
        haltTrading: !!b.haltTrading,
        forceBackup: true,
      });
      return NextResponse.json({ ok: !!result.ok, result });
    }

    return NextResponse.json({ ok: false, error: 'UNKNOWN' }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'REQUEST_FAILED' }, { status: authStatus(e) });
  }
}
