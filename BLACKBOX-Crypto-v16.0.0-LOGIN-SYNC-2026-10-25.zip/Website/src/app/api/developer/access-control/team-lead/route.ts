import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { apiError, authStatus } from '@/lib/auth';
import { PERMISSIONS, requireHighRiskAccess, requirePrincipal, requirePermission } from '@/lib/access-control';

const schema=z.object({teamId:z.string().min(1),userId:z.string().min(1),reason:z.string().min(5).max(500)});
export async function POST(req:Request){
  try{
    const actor=await requirePrincipal(); const b=schema.parse(await req.json()); await requirePermission(actor.userId,PERMISSIONS.TEAM_ADMIN);
    const team=await db.accessTeam.findUnique({where:{id:b.teamId}}); const lead=await db.user.findUnique({where:{id:b.userId},select:{id:true,role:true,status:true,accessKilled:true,developerLevel:true}});
    if(!team||!lead||lead.status!=='ACTIVE'||lead.accessKilled)return NextResponse.json({ok:false,error:'TEAM_OR_LEAD_NOT_FOUND'},{status:404});
    if(lead.role==='DEVELOPER'&&lead.developerLevel!=='REPRESENTATIVE')return NextResponse.json({ok:false,error:'PRINCIPAL_CANNOT_BE_TEAM_LEAD'},{status:403});
    const member=await db.accessTeamMember.findUnique({where:{teamId_userId:{teamId:team.id,userId:lead.id}}}); if(!member)return NextResponse.json({ok:false,error:'TEAM_LEAD_MUST_BE_MEMBER'},{status:409});
    await requireHighRiskAccess(req,'SET_TEAM_LEAD','ACCESS_TEAM',team.id);
    const row=await db.accessTeam.update({where:{id:team.id},data:{leadUserId:lead.id}});
    await db.auditLog.create({data:{actorId:actor.userId,action:'ACCESS_TEAM_LEAD_SET',targetType:'ACCESS_TEAM',targetId:team.id,metadata:{leadUserId:lead.id,reason:b.reason}}});
    return NextResponse.json({ok:true,team:row});
  }catch(e){if(e instanceof z.ZodError)return NextResponse.json({ok:false,error:'INPUT_TIDAK_VALID'},{status:400});return NextResponse.json({ok:false,error:apiError(e)},{status:authStatus(e)})}
}
