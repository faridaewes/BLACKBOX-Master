import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { apiError, authStatus, requireMfa } from '@/lib/auth';
import { PERMISSIONS, requirePermissionSession, requirePrincipal } from '@/lib/access-control';

const schema = z.object({action:z.string().min(2).max(100),targetType:z.string().max(80).nullable().optional(),targetId:z.string().max(200).nullable().optional(),reason:z.string().min(5).max(500),expiresMinutes:z.number().int().min(1).max(30).default(10)});

export async function GET(){
  try { await requirePrincipal(); const rows=await db.accessApproval.findMany({orderBy:{createdAt:'desc'},take:100,include:{requestedBy:{select:{id:true,name:true,email:true,role:true,developerLevel:true}},approvedBy:{select:{id:true,name:true,email:true,role:true,developerLevel:true}}}}); return NextResponse.json({ok:true,approvals:rows}); }
  catch(e){return NextResponse.json({ok:false,error:apiError(e)},{status:authStatus(e)})}
}

export async function POST(req:Request){
  try {
    const actor=await requirePermissionSession(PERMISSIONS.APPROVAL_REQUEST);
    const b=schema.parse(await req.json());
    const row=await db.accessApproval.create({data:{action:b.action,targetType:b.targetType??null,targetId:b.targetId??null,requestedById:actor.userId,status:'PENDING',reason:b.reason,expiresAt:new Date(Date.now()+b.expiresMinutes*60_000)}});
    await db.auditLog.create({data:{actorId:actor.userId,action:'ACCESS_APPROVAL_REQUESTED',targetType:b.targetType??'ACCESS_APPROVAL',targetId:row.id,metadata:{requestedAction:b.action,targetId:b.targetId??null,reason:b.reason}}});
    return NextResponse.json({ok:true,approval:row});
  } catch(e){if(e instanceof z.ZodError)return NextResponse.json({ok:false,error:'INPUT_TIDAK_VALID'},{status:400});return NextResponse.json({ok:false,error:apiError(e)},{status:authStatus(e)})}
}

export async function PATCH(req:Request){
  try {
    const actor=await requirePrincipal();
    await requireMfa(req);
    const b=z.object({approvalId:z.string().min(1),decision:z.enum(['APPROVE','REJECT']),reason:z.string().min(3).max(500).optional()}).parse(await req.json());
    const row=await db.accessApproval.findUnique({where:{id:b.approvalId}});
    if(!row||row.status!=='PENDING'||row.expiresAt<=new Date())return NextResponse.json({ok:false,error:'APPROVAL_NOT_PENDING'},{status:409});
    const status=b.decision==='APPROVE'?'APPROVED':'REJECTED';
    const updated=await db.accessApproval.update({where:{id:row.id},data:{status,approvedById:actor.userId,approvedAt:new Date(),reason:b.reason?`${row.reason} | ${b.reason}`:row.reason}});
    await db.auditLog.create({data:{actorId:actor.userId,action:`ACCESS_APPROVAL_${status}`,targetType:row.targetType??'ACCESS_APPROVAL',targetId:row.id,metadata:{requestedById:row.requestedById,requestedAction:row.action}}});
    return NextResponse.json({ok:true,approval:updated});
  } catch(e){if(e instanceof z.ZodError)return NextResponse.json({ok:false,error:'INPUT_TIDAK_VALID'},{status:400});return NextResponse.json({ok:false,error:apiError(e)},{status:authStatus(e)})}
}
