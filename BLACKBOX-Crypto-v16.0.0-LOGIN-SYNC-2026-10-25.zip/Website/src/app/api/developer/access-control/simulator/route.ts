import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/prisma';
import { apiError, authStatus } from '@/lib/auth';
import { PERMISSIONS, hasPermission, requirePrincipal } from '@/lib/access-control';

export async function GET(req:Request){
  try {
    const actor=await requirePrincipal();
    const userId=new URL(req.url).searchParams.get('userId');
    if(!userId)return NextResponse.json({ok:false,error:'USER_ID_REQUIRED'},{status:400});
    const target=await db.user.findUnique({where:{id:userId},select:{id:true,name:true,email:true,role:true,developerLevel:true,status:true,accessKilled:true,accessTeamMemberships:{include:{team:{select:{id:true,code:true,name:true,accessKilled:true}}}},accessGrants:{where:{revokedAt:null}}}});
    if(!target)return NextResponse.json({ok:false,error:'USER_NOT_FOUND'},{status:404});
    const permissions=[]; for(const permission of Object.values(PERMISSIONS)) if(await hasPermission(target.id,permission)) permissions.push(permission);
    return NextResponse.json({ok:true,actorId:actor.userId,target,permissions,denied:Object.values(PERMISSIONS).filter(x=>!permissions.includes(x)),evaluatedAt:new Date().toISOString()});
  } catch(e){return NextResponse.json({ok:false,error:apiError(e)},{status:authStatus(e)})}
}
