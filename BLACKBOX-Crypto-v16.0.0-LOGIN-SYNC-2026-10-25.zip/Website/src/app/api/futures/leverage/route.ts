import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { getEntitlements } from '@/lib/entitlements';
import { evaluateFuturesLeverage } from '@/lib/futures-leverage-intelligence';

const schema=z.object({
  userMaxLeverage:z.coerce.number().int().min(1).max(20),
  providerMaxLeverage:z.coerce.number().int().min(1).max(125).optional(),
  volatilityPct:z.coerce.number().finite().nonnegative().optional(),
  regime:z.string().trim().max(40).optional(),
  confidencePct:z.coerce.number().finite().min(0).max(100).optional(),
  dataQualityPct:z.coerce.number().finite().min(0).max(100).optional(),
  riskMode:z.enum(['NORMAL','CAUTIOUS','DEFENSIVE','BLOCKED']).optional(),
  liquidationBufferPct:z.coerce.number().finite().min(0).max(100).optional(),
  requestedLeverage:z.coerce.number().int().min(1).max(20).optional()
});

export async function POST(req:Request){
  try{
    const s=await requireVerifiedSession();
    const ent=await getEntitlements(s.userId,s.role);
    if(!ent.marketTypes.includes('FUTURES')) return NextResponse.json({ok:false,error:'MARKET_TYPE_NOT_ENTITLED'},{status:403});
    const b=schema.parse(await req.json());
    return NextResponse.json({ok:true,marketType:'FUTURES',readOnly:true,executionAllowed:false,decision:evaluateFuturesLeverage(b)});
  }catch(e){return NextResponse.json({ok:false,error:e instanceof z.ZodError?'INPUT_INVALID':String(e instanceof Error?e.message:e)},{status:authStatus(e)});}
}
