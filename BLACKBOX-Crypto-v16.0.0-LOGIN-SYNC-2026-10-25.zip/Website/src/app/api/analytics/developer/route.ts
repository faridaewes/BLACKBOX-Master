import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import {NextResponse}from"next/server";import{getOperationsAnalytics}from"@/lib/analytics/operations";
export async function GET(){try{await requirePermissionSession(PERMISSIONS.SYSTEM_HEALTH);return NextResponse.json(await getOperationsAnalytics())}catch{return NextResponse.json({error:"FORBIDDEN"},{status:403})}}
