import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { NextResponse } from "next/server";
import { db } from "@/lib/prisma";
import { apiError,  authStatus } from "@/lib/auth";

export async function GET() {
  try {
    const s = await requirePermissionSession(PERMISSIONS.USER_READ);
    if (s.role === "DEVELOPER") {
      const users = await db.user.count({ where: { role: "USER" } });
      const activeUsers = await db.user.count({ where: { role: "USER", status: "ACTIVE" } });
      const activeBots = await db.bot.count({ where: { status: "RUNNING" } });
      return NextResponse.json({ ok:true, scope:"GLOBAL", totalUsers:users, activeUsers, activeBots });
    }
    const assignments = await db.adminAssignment.findMany({ where: { adminId: s.userId }, select: { userId: true } });
    const ids = assignments.map(x => x.userId);
    const [totalUsers, activeUsers, activeBots, dashboardActive, tickets] = await Promise.all([
      db.user.count({ where: { id: { in: ids }, role: "USER" } }),
      db.user.count({ where: { id: { in: ids }, role: "USER", status: "ACTIVE" } }),
      db.bot.count({ where: { userId: { in: ids }, status: "RUNNING" } }),
      db.userActivityEvent.count({ where: { userId: { in: ids }, type: "DASHBOARD_VIEW", occurredAt: { gte: new Date(Date.now()-15*60_000) } } }),
      db.supportTicket.count({ where: { userId: { in: ids }, status: { in: ["OPEN","IN_PROGRESS"] } } })
    ]);
    return NextResponse.json({ ok:true, scope:"ASSIGNED", totalUsers, activeUsers, activeBots, dashboardActive, openTickets:tickets });
  } catch (e) {
    return NextResponse.json({ ok:false, error:apiError(e) }, { status:authStatus(e) });
  }
}
