import { rateLimitUserKey } from '@/lib/rate-limit';
import { NextResponse } from 'next/server';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { evaluatePriority123 } from '@/lib/trading-intelligence-priority123-v1121';
export async function POST(req:Request){
  try { const s=await requireVerifiedSession(); const rl=await distributedRateLimit(rateLimitUserKey(s.userId, "priority123"),10,60); if(!rl.ok)return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429});
    const body=await req.json(); const result=evaluatePriority123(body||{}); return NextResponse.json({ok:true,mode:'INTELLIGENCE_ONLY',executionAllowed:false,noOrderSigning:true,noOrderSubmission:true,noRouterAuthorization:true,result},{headers:{'Cache-Control':'no-store'}});
  } catch(e){ const status=authStatus(e); if(status===401||status===403)return NextResponse.json({ok:false,error:'REQUEST_NOT_AUTHORIZED'},{status}); return NextResponse.json({ok:false,error:'PRIORITY123_EVALUATION_FAILED',executionAllowed:false,failClosed:true},{status:500}); }
}
