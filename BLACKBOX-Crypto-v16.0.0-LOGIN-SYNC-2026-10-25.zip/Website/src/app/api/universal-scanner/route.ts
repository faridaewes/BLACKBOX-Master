import { rateLimitUserKey } from '@/lib/rate-limit';
import { NextResponse } from 'next/server';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { distributedRateLimit } from '@/lib/distributed-rate-limit';
import { scanUniversalMarkets, UNIVERSAL_SCANNER_VERSION, type ScannerMarketType } from '@/lib/universal-scanner-v83';
import { db } from '@/lib/prisma';
import { MARKET_DATA_RUNTIME_P3_VERSION } from '@/lib/market-data-runtime-v118-p3';
import { registryIsFresh, P5_REGISTRY_VERSION } from '@/lib/market-intelligence-registry-v120';
import { p5DegradedPayload, p5FailureStatus, safeP5 } from '@/lib/p5-runtime-resilience-v1181';

const allowed = new Set(['ALL','SPOT','FUTURES','DEX']);
const chains = new Set(['all','solana','base','bsc','ethereum','arbitrum','polygon','avalanche']);
const finite = (v: string|null, fallback: number, min: number, max: number) => { const n=Number(v); return Number.isFinite(n)?Math.max(min,Math.min(max,n)):fallback; };

export async function GET(req: Request) {
  try {
    const s = await requireVerifiedSession();
    const rl = await distributedRateLimit(rateLimitUserKey(s.userId, "universal-scanner-v118"), 4, 60);
    if (!rl.ok) return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429,headers:{'Retry-After':String(rl.retryAfterSec)}});
    const u = new URL(req.url);
    const marketType = (u.searchParams.get('marketType')||'ALL').toUpperCase();
    const chain = (u.searchParams.get('chain')||'all').toLowerCase();
    const limit = Math.floor(finite(u.searchParams.get('limit'),50,1,200));
    if (!allowed.has(marketType)) return NextResponse.json({ok:false,error:'INVALID_MARKET_TYPE'},{status:400});
    if (!chains.has(chain)) return NextResponse.json({ok:false,error:'INVALID_CHAIN'},{status:400});
    // P5: HTTP scanner is registry-backed and read-only. Provider fan-out is performed by the background registry worker.
    const rows=await db.marketIntelligenceRegistry.findMany({where:{status:'CERTIFIED',marketType:marketType==='ALL'?undefined:marketType},orderBy:{lastCertifiedAt:'desc'},take:50000});
    const fresh=rows.filter((r:any)=>registryIsFresh(r));
    const q=(u.searchParams.get('q')||'').trim().toLowerCase();
    const filtered= fresh.filter((r:any)=>{
      const m=({...((r.marketPayload||{}) as any),marketType:r.marketType,venue:r.venue||r.provider,p4Evidence:{status:'READY',evidenceComplete:r.evidenceComplete,timeframeCoverage:r.timeframeCoverage,p4Score:r.p4Score,regime:r.regime,regimeScore:r.regimeScore,breakout:r.breakout,doji:r.doji,liquidityUsd:r.liquidityUsd,volume24h:r.volume24h,spreadBps:r.spreadBps,orderBook:r.orderBookScore==null?undefined:{score:r.orderBookScore},derivatives:r.derivatives,dexPool:r.dexPool,timeframes:r.timeframes,blockers:r.blockers,warnings:r.warnings,observedAt:r.lastObservedAt}});
      if(chain!=='all' && String(m.chainId||'').toLowerCase()!==chain) return false;
      if(q && !`${m.symbol||''} ${m.dexId||''} ${m.chainId||''} ${r.provider}`.toLowerCase().includes(q)) return false;
      r.__scannerMarket=m; return true;
    }).map((r:any)=>r.__scannerMarket);
    const providerErrors:string[]=[];
    const p3Reconciled={rows:filtered,coverage:{inventory:filtered.length,ready:filtered.length,blocked:rows.length-filtered.length}};
    const result=scanUniversalMarkets(filtered,{minTrust:finite(u.searchParams.get('minTrust'),70,0,100),minLiquidityUsd:finite(u.searchParams.get('minLiquidityUsd'),25000,0,1e9),minVolumeUsd:finite(u.searchParams.get('minVolumeUsd'),10000,0,1e10),maxRugRisk:finite(u.searchParams.get('maxRugRisk'),60,0,100),maxSpreadBps:finite(u.searchParams.get('maxSpreadBps'),150,0,5000),maxPriceImpactPct:finite(u.searchParams.get('maxPriceImpactPct'),2.5,0,50),minQuantScore:finite(u.searchParams.get('minQuantScore'),55,0,100),minOpportunityScore:finite(u.searchParams.get('minOpportunityScore'),62,0,100),minPrecisionScore:finite(u.searchParams.get('minPrecisionScore'),72,0,100)},limit);
    const observedByKey = new Map(filtered.map(m=>[m.key, m.observedAt]));
    const sourceByKey = new Map(filtered.map(m=>[m.key, m]));
    const rowsByKey = new Map(result.rows.map(r=>[r.key, r]));
    const snapshots=result.rows.slice(0,500).map(r=>({marketKey:r.key,marketType:r.marketType,scannerVersion:UNIVERSAL_SCANNER_VERSION,riskEngineVersion:r.riskEngineVersion,status:r.status,stage:r.stage,precisionScore:r.precisionScore,dataTrustScore:r.dataTrustScore,truthStatus:r.trustStatus||'UNKNOWN',truthScore:r.truthScore,riskStatus:r.riskStatus,riskScore:r.riskScore,riskPositionSizeMultiplier:r.riskPositionSizeMultiplier,intelligenceStatus:r.intelligenceStatus,intelligenceAllowed:r.intelligenceAllowed,executionAllowed:false,liquidityUsd:r.liquidityUsd,volume24h:r.volume24h,spreadBps:(filtered.find(m=>m.key===r.key)?.spreadBps??null),priceImpactPct:(filtered.find(m=>m.key===r.key)?.priceImpactPct??null),volatilityPct:Math.abs(filtered.find(m=>m.key===r.key)?.priceChange1h??0),reasons:r.reasons,riskFlags:r.riskFlags,observedAt:observedByKey.get(r.key)?new Date(observedByKey.get(r.key) as any):null}));
    let persistenceOk=true;
    if(snapshots.length){ const persisted=await safeP5(()=>db.$transaction(async (tx:any)=>{
      await tx.scannerIntelligenceSnapshot.createMany({data:snapshots.map(x=>({marketKey:x.marketKey,marketType:x.marketType,scannerVersion:x.scannerVersion,riskEngineVersion:x.riskEngineVersion,status:x.status,stage:x.stage,precisionScore:x.precisionScore,dataTrustScore:x.dataTrustScore,truthStatus:x.truthStatus,truthScore:x.truthScore,riskStatus:x.riskStatus,riskScore:x.riskScore,riskPositionSizeMultiplier:x.riskPositionSizeMultiplier,intelligenceStatus:x.intelligenceStatus,intelligenceAllowed:x.intelligenceAllowed,executionAllowed:false,liquidityUsd:x.liquidityUsd,volume24h:x.volume24h,spreadBps:x.spreadBps,priceImpactPct:x.priceImpactPct,volatilityPct:x.volatilityPct,reasons:x.reasons,riskFlags:x.riskFlags,observedAt:x.observedAt}))});
      await tx.marketRiskSnapshot.createMany({data:snapshots.map(x=>({marketKey:x.marketKey,marketType:x.marketType,version:'11.6.0',truthStatus:x.truthStatus,truthScore:x.truthScore,riskStatus:x.riskStatus,riskScore:x.riskScore,positionSizeMultiplier:x.riskPositionSizeMultiplier,liquidityUsd:x.liquidityUsd,volume24h:x.volume24h,spreadBps:x.spreadBps,priceImpactPct:x.priceImpactPct,volatilityPct:x.volatilityPct,scannerScore:x.precisionScore,reasons:x.riskFlags,evidence:{scannerVersion:x.scannerVersion,riskEngineVersion:x.riskEngineVersion},observedAt:x.observedAt}))});
      await tx.intelligenceControlSnapshot.createMany({data:snapshots.map(x=>({marketKey:x.marketKey,marketType:x.marketType,version:UNIVERSAL_SCANNER_VERSION,truthAllowed:x.truthStatus==='TRUSTED',truthStatus:x.truthStatus,truthScore:x.truthScore,truthBlockers:x.truthStatus==='TRUSTED'?[]:['TRUTH_GATE'],riskStatus:x.riskStatus,riskScore:x.riskScore,riskPositionSizeMultiplier:x.riskPositionSizeMultiplier,intelligenceStatus:x.intelligenceStatus,intelligenceAllowed:x.intelligenceAllowed,executionAllowed:false,noOrderSigning:true,noOrderSubmission:true,noRouterAuthorization:true,reasons:x.reasons,observedAt:x.observedAt}))});
      await tx.marketRiskConsistencySnapshot.createMany({data:snapshots.map(x=>{const r=rowsByKey.get(x.marketKey); if(!r) throw new Error(`SCANNER_ROW_MISSING:${x.marketKey}`); return {marketKey:x.marketKey,marketType:x.marketType,version:'11.6.0',consistencyStatus:r.consistencyStatus,truthStatus:x.truthStatus,truthScore:x.truthScore,scannerScore:x.precisionScore,scannerStatus:x.status,riskStatus:x.riskStatus,riskScore:x.riskScore,blockers:r.consistencyStatus==='BLOCKED'?r.riskFlags:[],warnings:[],observedAt:x.observedAt}})});
      await tx.decisionCycleSnapshot.createMany({data:snapshots.map(x=>{const r=rowsByKey.get(x.marketKey); if(!r) throw new Error(`SCANNER_ROW_MISSING:${x.marketKey}`); return {marketKey:x.marketKey,marketType:x.marketType,version:'11.7.0',regime:r.regime,regimeScore:Math.round(r.precisionScore),shortHorizonScore:r.precisionScore,mediumHorizonScore:r.precisionScore,longHorizonScore:r.precisionScore,alignmentScore:r.decisionAlignment,usable:r.regimeUsable,reasons:r.reasons,observedAt:x.observedAt}})});
      await tx.aiEvidenceReadinessSnapshot.createMany({data:snapshots.map(x=>{const r=rowsByKey.get(x.marketKey); if(!r) throw new Error(`SCANNER_ROW_MISSING:${x.marketKey}`); return {marketKey:x.marketKey,marketType:x.marketType,version:UNIVERSAL_SCANNER_VERSION,status:r.aiEvidenceStatus,score:r.precisionScore,aiAllowed:r.aiEvidenceAllowed,executionAllowed:false,noOrderSigning:true,noOrderSubmission:true,noRouterAuthorization:true,reasons:r.reasons,evidence:{truthScore:x.truthScore,consistencyStatus:r.consistencyStatus,regime:r.regime,decisionAlignment:r.decisionAlignment},observedAt:x.observedAt}})});
      await tx.marketDataProvenanceSnapshot.createMany({data:filtered.slice(0,500).map(m=>({marketKey:m.key,marketType:m.marketType,provider:String(m.provider||m.venue||'UNKNOWN'),source:String(m.source||m.provider||m.venue||'UNKNOWN'),sourceUpdatedAt:m.sourceUpdatedAt?new Date(m.sourceUpdatedAt as any):null,observedAt:m.observedAt?new Date(m.observedAt as any):null,fetchedAt:m.fetchedAt?new Date(m.fetchedAt as any):null,clockSkewMs:null,freshnessMs:null,sourceAgeMs:null,payloadHash:null,schemaVersion:'11.3.0',status:rowsByKey.get(m.key)?.trustStatus||'BLOCKED',blockers:[],warnings:[]}))});
      await tx.marketIntelligenceDeepSnapshot.createMany({
        data: filtered.map(m => {
          const e = m.p4Evidence;
          return {
            marketKey: m.key, marketType: m.marketType,
            provider: String(m.provider || m.venue || m.dexId || 'UNKNOWN'),
            version: '11.8.1-p4', status: e?.status || 'BLOCKED',
            timeframeCoverage: e?.timeframeCoverage || 0, p4Score: Number(m.p4Score || 0),
            regime: e?.regime || 'UNKNOWN', regimeScore: e?.regimeScore || 0,
            breakout: Boolean(e?.breakout), doji: Boolean(e?.doji),
            liquidityUsd: Number(m.liquidityUsd || 0), volume24h: Number(m.volume24h || 0),
            spreadBps: e?.spreadBps ?? m.spreadBps ?? null,
            orderBookScore: e?.orderBook?.score ?? null,
            derivatives: e?.derivatives || null, dexPool: e?.dexPool || null,
            timeframes: Object.fromEntries(Object.entries(e?.timeframes || {}).map(([tf, x]: any) => [tf, {
              integrity: x.integrity, pattern: x.pattern, trend: x.trend, momentum: x.momentum,
              volatility: x.volatility, volumeRatio: x.volumeRatio, breakout: x.breakout, doji: x.doji,
            }])),
            blockers: e?.blockers || ['P4_EVIDENCE_MISSING'], warnings: e?.warnings || [],
            evidenceComplete: Boolean(e?.evidenceComplete),
            observedAt: e?.observedAt ? new Date(e.observedAt) : m.observedAt ? new Date(m.observedAt as any) : null,
          };
        }),
      });
    }));
    persistenceOk=persisted.ok;
    }
    return NextResponse.json({ok:true,...result,providerErrors,marketType,chain,p3Version:MARKET_DATA_RUNTIME_P3_VERSION,p4Version:'11.8.1-p4',p5Version:P5_REGISTRY_VERSION,p4Coverage:{inventory:filtered.length,ready:filtered.filter(m=>m.p4Evidence?.status==='READY').length,blocked:filtered.filter(m=>m.p4Evidence?.status!=='READY').length},p3Coverage:p3Reconciled.coverage,persistedSnapshots:persistenceOk?snapshots.length:0,mode:'READ_ONLY_INTELLIGENCE',executionAllowed:false,registry:{inventory:rows.length,fresh:filtered.length,stale:rows.length-filtered.length},contract:{executionAllowed:false,scannerIsNotAnOrderRouter:true,marketDataCoverage:p3Reconciled.coverage}}, {headers:{'Cache-Control':'no-store'}});
  } catch(e) { const status=p5FailureStatus(e); if(status!==200) return NextResponse.json({ok:false,error:'AUTHENTICATION_REQUIRED'},{status:authStatus(e)}); return NextResponse.json({ok:true,...p5DegradedPayload('REGISTRY',e),source:'CERTIFIED_REGISTRY',mode:'READ_ONLY_INTELLIGENCE',executionAllowed:false},{status:200,headers:{'Cache-Control':'no-store'}}); }
}
