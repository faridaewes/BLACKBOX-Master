import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { evaluateFinancialIntelligence, FINANCIAL_INTELLIGENCE_VERSION } from '@/lib/financial-intelligence-v70';

async function build(userId:string){
 const [snap,positions,closed,realizedAgg]=await Promise.all([
  db.portfolioSnapshot.findFirst({where:{userId},orderBy:{snapshotDate:'desc'}}),
  db.position.findMany({where:{bot:{userId},status:'OPEN'},select:{symbol:true,sizeUsd:true,quantity:true,currentPrice:true,entryPrice:true,pnl:true,liquidityUsd:true}}),
  db.position.findMany({where:{bot:{userId},status:'CLOSED'},select:{pnl:true}}),
  db.portfolioEvent.aggregate({where:{userId,type:'TRADE',side:'SELL'},_sum:{pnl:true}})
 ]);
 const equity=Number(snap?.equity||0), exposure=positions.reduce((a,p)=>a+(Number(p.sizeUsd)||Number(p.quantity)*Number(p.currentPrice)||0),0);
 const wins=closed.filter(p=>Number(p.pnl||0)>0).length;
 const gp=closed.reduce((a,p)=>a+Math.max(0,Number(p.pnl||0)),0), gl=closed.reduce((a,p)=>a+Math.max(0,-Number(p.pnl||0)),0);
 const top=positions.reduce((m,p)=>{const x=Number(p.sizeUsd)||Number(p.quantity)*Number(p.currentPrice)||0; m.set(p.symbol,(m.get(p.symbol)||0)+x); return m;},new Map<string,number>());
 const concentration=exposure>0?Math.max(...[...top.values()].map(x=>x/exposure*100),0):0;
 return {snap,closed,result:evaluateFinancialIntelligence({equity,balance:snap?.balance,realizedPnl:Number(snap?.realizedPnl??realizedAgg._sum.pnl??0),unrealizedPnl:snap?.unrealizedPnl,drawdownPct:snap?.drawdown,openPositions:positions.length,exposureUsd:exposure,concentrationPct:concentration,winRatePct:closed.length?wins/closed.length*100:0,completedTrades:closed.length,grossProfit:gp,grossLoss:gl,riskBudgetPct:10,liquidityUsd:positions.reduce((a,p)=>a+Number(p.liquidityUsd||0),0)})};
}

export async function GET(){try{const s=await requireVerifiedSession();const {snap,closed,result}=await build(s.userId);return NextResponse.json({ok:true,version:FINANCIAL_INTELLIGENCE_VERSION,result,asOf:new Date().toISOString(),dataQuality:{snapshot:!!snap,closedTrades:closed.length}});}catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)});}}

/** Explicit persistence endpoint. Dashboard GET remains read-only; callers decide when to create an audit snapshot. */
export async function POST(){try{const s=await requireVerifiedSession();const {result}=await build(s.userId);const row=await db.financialIntelligenceSnapshot.create({data:{userId:s.userId,version:result.version,health:result.health,action:result.action,score:result.score,equity:result.equity,realizedPnl:result.realizedPnl,unrealizedPnl:result.unrealizedPnl,drawdownPct:result.drawdownPct,exposureUsd:result.exposureUsd,exposurePct:result.exposurePct,concentrationPct:result.concentrationPct,openPositions:result.openPositions,winRatePct:result.winRatePct,completedTrades:result.completedTrades,profitFactor:result.profitFactor===Infinity?null:result.profitFactor,riskBudgetPct:result.riskBudgetPct,riskUsedPct:result.riskUsedPct,liquidityCoveragePct:result.liquidityCoveragePct,warnings:result.warnings,recommendations:result.recommendations}});return NextResponse.json({ok:true,snapshotId:row.id,result});}catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)});}}
