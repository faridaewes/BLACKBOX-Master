import { BLACKBOX_RELEASE_VERSION } from '@/lib/release-version';
import { NextResponse } from 'next/server';
import { PROVE_EVERYTHING_PHASES, PROVE_EVERYTHING_POSITIONING, PROVE_EVERYTHING_PRINCIPLES, certificationSummary } from '@/lib/prove-everything-v1121';

export async function GET() {
  return NextResponse.json({
    release: BLACKBOX_RELEASE_VERSION,
    positioning: PROVE_EVERYTHING_POSITIONING,
    phases: PROVE_EVERYTHING_PHASES,
    summary: certificationSummary(),
    principles: PROVE_EVERYTHING_PRINCIPLES,
  }, { headers: { 'Cache-Control': 'no-store' } });
}
