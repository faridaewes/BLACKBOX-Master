import { NextResponse } from 'next/server';
import { requireVerifiedSession, authStatus } from '@/lib/auth';
import { db } from '@/lib/prisma';
import { requireDailySignalTier } from '@/lib/daily-trading-signals';

export async function GET(req: Request) {
  try {
    const s = await requireVerifiedSession();
    await requireDailySignalTier(s.userId, s.role);
    const u = new URL(req.url);
    const marketType = u.searchParams.get('marketType');
    const date = u.searchParams.get('date');
    const day = date ? new Date(`${date}T00:00:00.000Z`) : new Date(Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), new Date().getUTCDate()));
    const next = new Date(day.getTime() + 24 * 60 * 60 * 1000);
    const rows = await db.dailyTradingSignal.findMany({
      where: { signalDate: day, ...(marketType && ['SPOT','FUTURES','DEX'].includes(marketType) ? { marketType } : {}) },
      orderBy: [{ score: 'desc' }, { confidence: 'desc' }], take: 200,
    });
    return NextResponse.json({ ok: true, signalDate: day, expiresAt: next, signals: rows, executionAllowed: false, readOnly: true });
  } catch (e) {
    const code = (e as Error)?.message;
    if (code === 'ACTIVE_TIER_REQUIRED') return NextResponse.json({ ok: false, error: 'ACTIVE_TIER_REQUIRED', message: 'Signal Trading Daily hanya tersedia untuk user dengan layanan/tier aktif.' }, { status: 403 });
    return NextResponse.json({ ok: false, error: 'REQUEST_FAILED' }, { status: authStatus(e) });
  }
}
