import { NextResponse } from 'next/server';
import { requirePermissionSession, PERMISSIONS } from '@/lib/access-control';
import { generateDailyTradingSignals } from '@/lib/daily-trading-signals';
export async function POST(){try{const s=await requirePermissionSession(PERMISSIONS.SYSTEM_HEALTH);const result=await generateDailyTradingSignals();return NextResponse.json({ok:true,result,actorId:s.userId});}catch(e){return NextResponse.json({ok:false,error:(e as Error)?.message||'GENERATION_FAILED'},{status:403});}}
