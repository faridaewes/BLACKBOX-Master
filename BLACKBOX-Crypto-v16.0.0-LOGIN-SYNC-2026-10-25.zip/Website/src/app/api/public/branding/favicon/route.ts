import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';
import fs from 'node:fs/promises';
import path from 'node:path';
const FALLBACK = '/favicon.png';
const allowed = /^\/uploads\/branding\/favicon-[a-f0-9-]+\.(?:png|svg|ico)$/i;
export async function GET() {
  try {
    const s = await db.platformSetting.findUnique({ where: { key: 'BRAND_FAVICON_URL' } });
    const url = String(s?.value || FALLBACK);
    if (!allowed.test(url)) return new NextResponse(await fs.readFile(path.resolve('public' + FALLBACK)), { headers: { 'Content-Type': 'image/png', 'Cache-Control': 'public, max-age=60', 'X-Content-Type-Options': 'nosniff' } });
    const file = path.join(path.resolve(process.env.PUBLIC_UPLOAD_DIR || './public/uploads'), 'branding', path.basename(url));
    const data = await fs.readFile(file);
    const ext = path.extname(file).slice(1).toLowerCase();
    const type = ext === 'svg' ? 'image/svg+xml' : ext === 'ico' ? 'image/x-icon' : 'image/png';
    return new NextResponse(data, { headers: { 'Content-Type': type, 'Cache-Control': 'public, max-age=60, stale-while-revalidate=300', 'X-Content-Type-Options': 'nosniff' } });
  } catch {
    return new NextResponse(await fs.readFile(path.resolve('public' + FALLBACK)), { headers: { 'Content-Type': 'image/png', 'Cache-Control': 'public, max-age=60', 'X-Content-Type-Options': 'nosniff' } });
  }
}
