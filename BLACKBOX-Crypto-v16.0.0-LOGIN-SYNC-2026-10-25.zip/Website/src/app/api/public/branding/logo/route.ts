import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';
import fs from 'node:fs/promises';
import path from 'node:path';

const FALLBACK = '/brand/blackbox-logo.png';
const allowed = /^\/uploads\/branding\/(?:logo|favicon)-[a-f0-9-]+\.(?:png|svg|webp)$/i;
export async function GET() {
  try {
    const s = await db.platformSetting.findUnique({ where: { key: 'BRAND_LOGO_URL' } });
    const url = String(s?.value || FALLBACK);
    if (!allowed.test(url)) { const fallback = await fs.readFile(path.resolve('public' + FALLBACK)); return new NextResponse(fallback, { headers: { 'Content-Type': 'image/png', 'Cache-Control': 'public, max-age=60', 'X-Content-Type-Options': 'nosniff' } }); }
    const file = path.join(path.resolve(process.env.PUBLIC_UPLOAD_DIR || './public/uploads'), 'branding', path.basename(url));
    const data = await fs.readFile(file);
    const ext = path.extname(file).slice(1).toLowerCase();
    const type = ext === 'svg' ? 'image/svg+xml' : ext === 'webp' ? 'image/webp' : 'image/png';
    return new NextResponse(data, { headers: { 'Content-Type': type, 'Cache-Control': 'public, max-age=60, stale-while-revalidate=300', 'X-Content-Type-Options': 'nosniff' } });
  } catch {
    const fallback = await fs.readFile(path.resolve('public' + FALLBACK));
    return new NextResponse(fallback, { headers: { 'Content-Type': 'image/png', 'Cache-Control': 'public, max-age=60', 'X-Content-Type-Options': 'nosniff' } });
  }
}
