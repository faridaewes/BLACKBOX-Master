import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';
import { MAX_REFERRAL_DEPTH } from '@/lib/referral-reward-v91';

export async function GET() {
  try {
    const rows = await db.$queryRaw<any[]>`
      WITH RECURSIVE walk AS (
        SELECT child."id" AS "memberId", parent."id" AS "ancestorId", 1 AS "level"
        FROM "User" child JOIN "User" parent ON parent."id" = child."referredById"
        UNION ALL
        SELECT w."memberId", parent."id", w."level" + 1
        FROM walk w JOIN "User" child ON child."id" = w."ancestorId"
        JOIN "User" parent ON parent."id" = child."referredById"
        WHERE w."level" < ${MAX_REFERRAL_DEPTH}
      ), agg AS (
        SELECT "ancestorId" AS "userId", COUNT(*)::int AS "networkSize",
          COUNT(*) FILTER (WHERE "level"=1)::int AS "directCount"
        FROM walk GROUP BY "ancestorId"
      )
      SELECT u."username", u."name", u."avatarUrl", a."networkSize", a."directCount"
      FROM agg a JOIN "User" u ON u."id"=a."userId"
      WHERE u."status"='ACTIVE' AND a."networkSize">0
      ORDER BY a."networkSize" DESC, a."directCount" DESC, u."username" ASC
      LIMIT 5
    `;
    const leaderboard = rows.map((r, i) => ({
      rank: i + 1,
      username: String(r.username),
      name: String(r.name || ''),
      avatarUrl: r.avatarUrl ? String(r.avatarUrl) : null,
      networkSize: Number(r.networkSize || 0),
      directCount: Number(r.directCount || 0),
    }));
    return NextResponse.json({ ok: true, updatedAt: new Date().toISOString(), depth: MAX_REFERRAL_DEPTH, leaderboard }, { headers: { 'Cache-Control': 'public, max-age=15, stale-while-revalidate=30' } });
  } catch {
    return NextResponse.json({ ok: false, error: 'LEADERBOARD_UNAVAILABLE' }, { status: 503, headers: { 'Cache-Control': 'no-store' } });
  }
}
