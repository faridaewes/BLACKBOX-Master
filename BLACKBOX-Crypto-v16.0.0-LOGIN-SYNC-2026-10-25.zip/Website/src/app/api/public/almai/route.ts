import { NextResponse } from 'next/server';
import { getAlmaiReferral } from '@/lib/almai';
export async function GET(){return NextResponse.json({ok:true,url:await getAlmaiReferral()},{headers:{'cache-control':'no-store'}})}
