import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';
import { paymentLogoUrl } from '@/lib/payment-catalog';

const PUBLIC_KEYS = new Set(['activeBots','concurrentPositions','exchanges','scanSeconds','marketPairs','ai','marketTypes','features','durationDays','realTrading','futures','dex','spot','leverage','support','scanner','executionIntelligence','portfolio','signals','backtest','prioritySupport','apiAccess']);
const LABELS: Record<string,string> = {
  activeBots:'Bot aktif simultan', concurrentPositions:'Posisi simultan', exchanges:'Exchange', scanSeconds:'Interval scanner (detik)',
  marketPairs:'Market/pairs yang dipindai', ai:'AI / Intelligence', marketTypes:'Jenis market', durationDays:'Durasi (hari)',
  realTrading:'Real trading', futures:'Futures', dex:'DEX', spot:'Spot', leverage:'Batas leverage', support:'Support',
  scanner:'Market scanner', executionIntelligence:'Execution Intelligence', portfolio:'Portfolio analytics', signals:'Signal intelligence',
  backtest:'Backtest', prioritySupport:'Priority support', apiAccess:'API access', features:'Fitur tambahan'
};
function publicEntitlements(value: unknown) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
  const src = value as Record<string, unknown>;
  return Object.fromEntries(Object.entries(src).filter(([k]) => PUBLIC_KEYS.has(k)));
}
function detailEntries(ent: Record<string,unknown>) {
  return Object.entries(ent).map(([key,value]) => ({key,label:LABELS[key] || key, value}));
}
export async function GET() {
  try {
    const [plans, wa, tg, pc] = await Promise.all([
      db.accessPlan.findMany({ where: { active: true }, orderBy: { name: 'asc' }, select: { id: true, name: true, description: true, entitlements: true, priceMinor:true, currency:true, paymentEnabled:true, imageUrl:true, imageAlt:true, imageWidth:true, imageHeight:true, imageSize:true } }),
      db.platformSetting.findUnique({ where: { key: 'SERVICE_WHATSAPP' }, select: { value: true } }),
      db.platformSetting.findUnique({ where: { key: 'SERVICE_TELEGRAM' }, select: { value: true } }),
      db.platformSetting.findUnique({ where: { key: 'PAYMENT_CONFIG' }, select: { value: true } }),
    ]);
    return NextResponse.json({
      ok: true,
      plans: plans.map(p => { const ent = publicEntitlements(p.entitlements); return { id:p.id, name:p.name, description:p.description, priceMinor:p.priceMinor, currency:p.currency, paymentEnabled:p.paymentEnabled, imageUrl:p.imageSize ? `/api/public/tiers/${p.id}/image` : (p.imageUrl || `/brand/tiers/${String(p.name).toLowerCase().replace(/[^a-z0-9]+/g,'-')}.svg`), imageAlt:p.imageAlt || `${p.name} tier`, imageWidth:p.imageWidth, imageHeight:p.imageHeight, entitlements:ent, details:detailEntries(ent) }; }),
      contact: { whatsapp: wa?.value || null, telegram: tg?.value || null },
      paymentConfig: (()=>{try{const c=pc?.value?JSON.parse(pc.value):null;return c?{enabled:!!c.enabled,providerMode:c.providerMode,methods:c.enabled?(c.methods||[]).filter((m:any)=>m.active!==false).map((m:any)=>({id:m.id,name:m.name,type:m.type,accountName:m.accountName||'',accountNumber:m.accountNumber||'',instructions:m.instructions||'',logoKey:m.logoKey||null,iconUrl:paymentLogoUrl(m.logoKey,m.type)})):[]}:null}catch{return null}})(),
      generatedAt: new Date().toISOString(),
    }, { headers: { 'Cache-Control':'public,max-age=60' } });
  } catch { return NextResponse.json({ok:false,error:'SERVICE_UNAVAILABLE'},{status:503}); }
}
