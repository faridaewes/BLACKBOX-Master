import { NextResponse } from 'next/server';
import { availablePhoneOtpChannels } from '@/lib/otp-channels';

export async function GET() {
  try {
    const ch = await availablePhoneOtpChannels();
    return NextResponse.json({
      ok: true,
      options: [
        { id: 'WHATSAPP', label: 'WhatsApp saja', available: ch.whatsapp },
        { id: 'SMS', label: 'SMS saja', available: ch.sms },
      ],
      note: 'Jika saluran belum dikonfigurasi admin, kode tetap bisa dikirim cadangan ke email.',
    });
  } catch {
    return NextResponse.json({
      ok: true,
      options: [
        { id: 'WHATSAPP', label: 'WhatsApp saja', available: false },
        { id: 'SMS', label: 'SMS saja', available: false },
      ],
    });
  }
}
