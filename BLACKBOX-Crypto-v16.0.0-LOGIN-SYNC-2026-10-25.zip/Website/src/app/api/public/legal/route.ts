import { NextResponse } from 'next/server';
import { db } from '@/lib/prisma';

const PUBLIC_TYPES=['TERMS','PRIVACY','RISK','BOT_START','BOT_CONFIGURATION','SETUP_STEP','REAL_EXECUTION','REGISTRATION','ALMA_ADVISOR_REGISTRATION','REGULATORY_DISCLOSURE','TRADING_RULES','CONNECTION_AUTHORIZATION'] as const;
export async function GET(req:Request){
  const url=new URL(req.url);
  const requested=(url.searchParams.get('types')||'').split(',').map(x=>x.trim()).filter(Boolean);
  const types=(requested.length?requested:PUBLIC_TYPES).filter((x):x is typeof PUBLIC_TYPES[number]=>PUBLIC_TYPES.includes(x as any));
  const docs=await db.legalDocument.findMany({where:{type:{in:types},active:true,workflowState:'PUBLISHED'},orderBy:{createdAt:'desc'}});
  const latest=new Map<string,any>();
  for(const d of docs) if(!latest.has(d.type)) latest.set(d.type,{type:d.type,version:d.version,title:d.title,body:d.body,contentHash:d.contentHash,updatedAt:d.publishedAt||d.createdAt});
  return NextResponse.json({ok:true,documents:[...latest.values()]},{headers:{'Cache-Control':'public,max-age=300'}});
}
