import { NextResponse } from 'next/server';
import { requireSession } from '@/lib/auth';
import { getUnifiedSuperApp } from '@/lib/platform/superapp';
export const dynamic='force-dynamic';
export async function GET(){try{await requireSession(); return NextResponse.json(await getUnifiedSuperApp(),{headers:{'cache-control':'no-store'}})}catch{return NextResponse.json({ok:false,error:'PLATFORM_UNAVAILABLE'},{status:503})}}
