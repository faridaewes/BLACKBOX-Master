import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession, authStatus } from '@/lib/auth';
import { hasPermission } from '@/lib/access-control';
import { buildAuditReport } from '@/lib/audit-report';
const schema = z.object({ from:z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), to:z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), userId:z.string().optional(), actorId:z.string().optional(), action:z.string().max(80).optional(), targetType:z.string().max(80).optional(), limit:z.coerce.number().int().min(1).max(1000).optional() });
export async function GET(req:Request){try{const session=await requireSession();if(session.role!=="DEVELOPER"&&session.role!=="ADMIN"&&!(await hasPermission(session.userId,"AUDIT_READ")))throw new Error("PERMISSION_DENIED");const url=new URL(req.url);const q=schema.parse(Object.fromEntries(url.searchParams.entries()));const report=await buildAuditReport(session,q);return NextResponse.json({ok:true,...report},{headers:{'Cache-Control':'private,no-store'}});}catch(e){return NextResponse.json({ok:false,error:'REQUEST_FAILED'},{status:authStatus(e)});}}
