import { rateLimitUserKey } from '@/lib/rate-limit';
import { NextResponse } from "next/server";
import { requireVerifiedSession, authStatus } from "@/lib/auth";
import { distributedRateLimit } from "@/lib/distributed-rate-limit";
import { db } from "@/lib/prisma";
import { registryIsFresh, P5_REGISTRY_VERSION } from "@/lib/market-intelligence-registry-v120";
import { estimateRugRisk, scoreBreakdown, PRESETS, sanitizeGuardrails } from "@/lib/paper/engine";
import { buildHybridSignal } from "@/lib/signal-engine";
import { p5DegradedPayload, p5FailureStatus, safeP5 } from '@/lib/p5-runtime-resilience-v1181';

const allowed = new Set(["ALL","SPOT","FUTURES","DEX"]);
const chains = new Set(["all","solana","base","bsc","ethereum","arbitrum","polygon","avalanche"]);
const finite = (v:string|null,d:number,a:number,b:number)=>{const n=Number(v);return Number.isFinite(n)?Math.max(a,Math.min(b,n)):d};

function toMarket(row:any){
  const p=(row.marketPayload||{}) as any;
  return {
    key:row.marketKey,
    symbol:String(row.symbol||p.symbol||row.marketKey),
    chainId:String(p.chainId||p.chain||""),
    dexId:String(p.dexId||row.venue||row.provider||"registry"),
    priceUsd:Number(p.priceUsd||0),
    priceChange5m:Number(p.priceChange5m||0),
    priceChange1h:Number(p.priceChange1h||0),
    liquidityUsd:Number(row.liquidityUsd||p.liquidityUsd||0),
    volume24h:Number(row.volume24h||p.volume24h||0),
    buys24h:Number(p.buys24h||0),
    sells24h:Number(p.sells24h||0),
    fdv:Number(p.fdv||0),
    pairAgeHours:p.pairAgeHours==null?null:Number(p.pairAgeHours),
    source:"CERTIFIED_REGISTRY" as const,
    observedAt:row.lastObservedAt||row.lastCertifiedAt,
    sourceUpdatedAt:p.sourceUpdatedAt,
    fetchedAt:p.fetchedAt,
    candlePattern:p.candlePattern||"CERTIFIED_MARKET",
    candleReason:p.candleReason||"Certified P4/P5 market evidence.",
    analysisComplete:Boolean(row.evidenceComplete && Number(row.timeframeCoverage)>=100),
    marketType:row.marketType,
    provider:row.provider,
    p4Score:Number(row.p4Score||0),
    timeframeCoverage:Number(row.timeframeCoverage||0),
    regime:row.regime,
    freshness:row.timeframeFreshness,
  };
}

export async function GET(req:Request){
  try{
    const s=await requireVerifiedSession();
    const rl=await distributedRateLimit(rateLimitUserKey(s.userId, "market-screener"),12,60);
    if(!rl.ok)return NextResponse.json({ok:false,error:"TOO_MANY_REQUESTS",retryAfterSec:rl.retryAfterSec},{status:429,headers:{"Retry-After":String(rl.retryAfterSec)}});
    const u=new URL(req.url);
    const marketType=(u.searchParams.get("marketType")||"ALL").toUpperCase();
    const chain=(u.searchParams.get("chain")||"all").toLowerCase();
    const q=(u.searchParams.get("q")||"").toLowerCase().trim();
    const sort=u.searchParams.get("sort")||"score";
    const page=Math.max(1,Math.min(1000,Number(u.searchParams.get("page")||1)));
    const pageSize=Math.min(250,Math.max(25,Number(u.searchParams.get("pageSize")||100)));
    if(!allowed.has(marketType))return NextResponse.json({ok:false,error:"INVALID_MARKET_TYPE"},{status:400});
    if(!chains.has(chain))return NextResponse.json({ok:false,error:"INVALID_CHAIN"},{status:400});

    const g=sanitizeGuardrails(undefined,PRESETS.balanced);
    const registryRows=await db.marketIntelligenceRegistry.findMany({
      where:{status:"CERTIFIED",marketType:marketType==="ALL"?undefined:marketType},
      orderBy:{lastCertifiedAt:"desc"},take:50000,
    });
    const fresh=registryRows.filter((r:any)=>registryIsFresh(r));
    const stale=registryRows.length-fresh.length;
    let markets=fresh.map(toMarket).filter((m:any)=>chain==="all"||m.chainId.toLowerCase()===chain);
    if(q)markets=markets.filter((m:any)=>`${m.symbol} ${m.dexId} ${m.chainId} ${m.provider}`.toLowerCase().includes(q));

    let rows=markets.map((m:any)=>{
      const rug=estimateRugRisk(m), breakdown=scoreBreakdown(m);
      const signal=buildHybridSignal({deterministicScore:breakdown.total,deterministicConfidence:breakdown.confidence,momentum5m:m.priceChange5m,momentum1h:m.priceChange1h,liquidityUsd:m.liquidityUsd,minLiquidityUsd:g.minLiquidityUsd,rugRisk:rug,maxRugRisk:g.maxRugRisk,candlePattern:m.candlePattern,candleReason:m.candleReason,minScore:g.minAiScore});
      const pass=m.analysisComplete&&signal.action==="BUY";
      return {key:m.key,symbol:m.symbol,marketType:m.marketType,chain:m.chainId,dex:m.dexId,price:m.priceUsd,ch5m:m.priceChange5m,ch1h:m.priceChange1h,liquidity:m.liquidityUsd,volume24h:m.volume24h,rug,score:signal.score,deterministicScore:signal.deterministicScore,confidence:signal.confidence,signal:signal.action,signalStatus:signal.status,reasons:signal.reasons,riskFlags:signal.riskFlags,candle:m.candlePattern,candleReason:m.candleReason,analysisComplete:m.analysisComplete,breakdown,pass,lastCertifiedAt:m.observedAt,provider:m.provider,p4Score:m.p4Score,timeframeCoverage:m.timeframeCoverage,regime:m.regime};
    });
    const passedCount=rows.filter(r=>r.pass).length;
    const completeCount=rows.filter(r=>r.analysisComplete).length;
    const cmp:Record<string,(a:any,b:any)=>number>={score:(a,b)=>b.score-a.score,momentum:(a,b)=>b.ch5m-a.ch5m,liquidity:(a,b)=>b.liquidity-a.liquidity,rug:(a,b)=>a.rug-b.rug,volume:(a,b)=>b.volume24h-a.volume24h};
    rows.sort(cmp[sort]||cmp.score);
    const total=rows.length,start=(page-1)*pageSize,paged=rows.slice(start,start+pageSize);
    const note=registryRows.length===0
      ? "Certified Market Intelligence Registry belum memiliki data. Provider langsung tidak dipanggil dari UI, sehingga pembatasan lokasi exchange tidak memecahkan halaman. Jalankan worker Market Intelligence Registry pada environment networked untuk mengisi data."
      : stale>0
        ? `Registry: ${fresh.length} certified-fresh · ${stale} stale/blocked. UI hanya menampilkan evidence yang masih fresh.`
        : `Registry P5: ${fresh.length} certified-fresh market.`;
    return NextResponse.json({ok:true,source:"CERTIFIED_REGISTRY",mode:"READ_ONLY_INTELLIGENCE",registryVersion:P5_REGISTRY_VERSION,executionAllowed:false,note,marketType,chain,total,page,pageSize,pages:Math.max(1,Math.ceil(total/pageSize)),passed:passedCount,analyzed:completeCount,guardrails:{minAiScore:g.minAiScore,maxRugRisk:g.maxRugRisk,minLiquidityUsd:g.minLiquidityUsd},rows:paged,registry:{inventory:registryRows.length,fresh:fresh.length,stale},contract:{providerFanout:false,executionAllowed:false,noOrderSigning:true,noOrderSubmission:true,noRouterAuthorization:true}},{headers:{"Cache-Control":"no-store"}});
  }catch(e){ const status=p5FailureStatus(e); if(status!==200) return NextResponse.json({ok:false,error:'AUTHENTICATION_REQUIRED'},{status:authStatus(e)}); return NextResponse.json({ok:true,...p5DegradedPayload('REGISTRY',e),version:P5_REGISTRY_VERSION,source:'CERTIFIED_REGISTRY',mode:'READ_ONLY_INTELLIGENCE'}, {status:200,headers:{'Cache-Control':'no-store'}});}
}
