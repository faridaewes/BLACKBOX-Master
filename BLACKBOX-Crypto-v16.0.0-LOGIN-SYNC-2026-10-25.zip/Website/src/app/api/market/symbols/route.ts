import { rateLimitUserKey } from '@/lib/rate-limit';
import {NextResponse} from 'next/server';
import {requireVerifiedSession,authStatus} from '@/lib/auth';
import {getEntitlements} from '@/lib/entitlements';
import {discoverExchangeSymbols} from '@/lib/paper/feed';
import {distributedRateLimit} from '@/lib/distributed-rate-limit';
import {configuredProviderChain,withProviderFailover} from '@/lib/provider-failover-v1181';
const cache=new Map<string,{at:number;symbols:string[]}>();
const DEMO_SYMBOLS={SPOT:['BTC/USDT','ETH/USDT','SOL/USDT','BNB/USDT','XRP/USDT','ADA/USDT','DOGE/USDT'],FUTURES:['BTC/USDT','ETH/USDT','SOL/USDT','BNB/USDT','XRP/USDT','DOGE/USDT']};
export async function GET(req:Request){
  try{
    const s=await requireVerifiedSession();
    const rl=await distributedRateLimit(rateLimitUserKey(s.userId, "market-symbols"),12,60);
    if(!rl.ok)return NextResponse.json({ok:false,error:'TOO_MANY_REQUESTS',retryAfterSec:rl.retryAfterSec},{status:429,headers:{'Retry-After':String(rl.retryAfterSec)}});
    const u=new URL(req.url);
    const requestedMarketType=(u.searchParams.get('marketType')||'SPOT').toUpperCase() as 'SPOT'|'FUTURES'|'DEX';
    if(!['SPOT','FUTURES'].includes(requestedMarketType))return NextResponse.json({ok:true,symbols:[]});
    const marketType=requestedMarketType as 'SPOT'|'FUTURES';
    const ent=await getEntitlements(s.userId,s.role);
    const demoMode=(u.searchParams.get('mode')||'').toUpperCase()==='DEMO';
    if(!demoMode&&!ent.marketTypes.includes(marketType))return NextResponse.json({ok:false,error:'MARKET_TYPE_NOT_ENTITLED'},{status:403});
    const exchangeId=process.env.MARKET_EXCHANGE||'binance';
    const cacheKey=`${exchangeId}:${marketType}`;
    const hit=cache.get(cacheKey);
    if(hit&&Date.now()-hit.at<300000)return NextResponse.json({ok:true,exchange:exchangeId,marketType,total:hit.symbols.length,symbols:hit.symbols});
    try{
      const result=await withProviderFailover(configuredProviderChain(exchangeId),async provider=>{
        const {default:ccxt}=await import('ccxt');
        const Ctor=(ccxt as any)[provider];
        if(!Ctor)throw new Error('EXCHANGE_NOT_SUPPORTED');
        const ex=new Ctor({enableRateLimit:true,timeout:Number(process.env.EXCHANGE_REQUEST_TIMEOUT_MS||15000),options:{defaultType:marketType==='FUTURES'?'future':'spot'}});
        try{
          await ex.loadMarkets();
          const symbols=discoverExchangeSymbols(ex.markets,marketType as 'SPOT'|'FUTURES');
          if(!symbols.length)throw new Error('NO_MARKET_SYMBOLS');
          return symbols;
        }finally{await ex.close?.().catch(()=>{})}
      });
      cache.set(cacheKey,{at:Date.now(),symbols:result.value});
      return NextResponse.json({ok:true,exchange:result.provider,marketType,total:result.value.length,symbols:result.value,degraded:result.degraded,failover:{provider:result.provider,attempts:result.attempts}});
    }catch(e){
      if(demoMode)return NextResponse.json({ok:true,exchange:'demo-fallback',marketType,total:DEMO_SYMBOLS[marketType].length,symbols:DEMO_SYMBOLS[marketType],degraded:true,note:`Semua provider exchange gagal (${e instanceof Error?e.message:'PROVIDER_ERROR'}). DEMO memakai universe deterministik.`});
      throw e;
    }
  }catch(e){
    return NextResponse.json({ok:false,error:'MARKET_PROVIDER_UNAVAILABLE',message:'Market provider sementara tidak tersedia. Coba lagi atau gunakan DEMO.',technicalError:process.env.NODE_ENV==='production'?undefined:String(e instanceof Error?e.message:e)},{status:authStatus(e)===401||authStatus(e)===403?authStatus(e):503});
  }
}
