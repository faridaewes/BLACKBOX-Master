'use client';

import { useEffect } from 'react';

export default function GlobalRouteError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => { console.error('[BLACKBOX_ROUTE_ERROR]', error); }, [error]);
  return (
    <main className="page" style={{minHeight:'70vh',display:'grid',placeItems:'center'}}>
      <section className="panel" style={{maxWidth:720,width:'100%'}}>
        <div className="panelBody">
          <span className="badge amber">RECOVERY MODE</span>
          <h1>BLACKBOX tetap aman</h1>
          <p className="small">Halaman mengalami exception di browser. Data trading tidak dieksekusi dari halaman error ini.</p>
          <div className="banner red">Client-side exception tertangani. Silakan muat ulang halaman.</div>
          <button className="btn primary" onClick={() => reset()}>COBA LAGI</button>
        </div>
      </section>
    </main>
  );
}
