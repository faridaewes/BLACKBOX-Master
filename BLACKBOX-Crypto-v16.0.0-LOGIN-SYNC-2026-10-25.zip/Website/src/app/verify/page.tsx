'use client';
import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';

export default function VerifyPage() {
  const r = useRouter();
  const q = useSearchParams();
  const [userId, setUserId] = useState(q.get('userId') || '');
  const [channel, setChannel] = useState<'EMAIL' | 'PHONE'>('EMAIL');
  const [phoneOtpChannel, setPhoneOtpChannel] = useState<'WHATSAPP' | 'SMS'>('WHATSAPP');
  const [token, setToken] = useState('');
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  const verify = async () => {
    setBusy(true);
    setMsg('');
    try {
      const x = await fetch('/api/auth/verify', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ userId, channel, token }),
      });
      const j = await x.json();
      setMsg(
        j.ok
          ? `${channel} terverifikasi. ${
              j.emailVerified && j.phoneVerified
                ? 'Semua verifikasi selesai. Silakan login.'
                : 'Lanjutkan verifikasi channel berikutnya.'
            }`
          : j.error || 'Verifikasi gagal',
      );
      if (j.ok && j.emailVerified && j.phoneVerified) r.push('/login');
    } finally {
      setBusy(false);
    }
  };

  const resend = async () => {
    setBusy(true);
    setMsg('');
    try {
      const body: any = { userId, channel };
      if (channel === 'PHONE') body.phoneOtpChannel = phoneOtpChannel;
      const x = await fetch('/api/auth/resend', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
      });
      const j = await x.json();
      const via =
        channel === 'PHONE'
          ? phoneOtpChannel === 'WHATSAPP'
            ? 'WhatsApp'
            : 'SMS'
          : 'Email';
      setMsg(
        j.ok
          ? `OTP dikirim via ${via}.${j.devToken ? ` DEV TOKEN: ${j.devToken}` : ''}${
              j.channel === 'EMAIL_FALLBACK' ? ' (cadangan email)' : ''
            }`
          : j.error || 'Gagal mengirim OTP',
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="container">
      <div className="card auth">
        <span className="badge">BLACKBOX VERIFICATION</span>
        <h1>Verifikasi akun</h1>
        <input placeholder="User ID" value={userId} onChange={(e) => setUserId(e.target.value)} />
        <select
          className="input"
          value={channel}
          onChange={(e) => setChannel(e.target.value as 'EMAIL' | 'PHONE')}
        >
          <option value="EMAIL">EMAIL</option>
          <option value="PHONE">NOMOR HP</option>
        </select>

        {channel === 'PHONE' && (
          <div
            className="phoneChannelPick"
            style={{
              margin: '10px 0',
              padding: 12,
              borderRadius: 12,
              border: '1px solid rgba(255,211,67,.2)',
            }}
          >
            <div style={{ fontWeight: 600, marginBottom: 8 }}>Kirim kode nomor via</div>
            <label style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
              <input
                type="radio"
                checked={phoneOtpChannel === 'WHATSAPP'}
                onChange={() => setPhoneOtpChannel('WHATSAPP')}
              />
              WhatsApp saja
            </label>
            <label style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <input
                type="radio"
                checked={phoneOtpChannel === 'SMS'}
                onChange={() => setPhoneOtpChannel('SMS')}
              />
              SMS saja
            </label>
          </div>
        )}

        <input
          placeholder="6 digit OTP"
          inputMode="numeric"
          maxLength={6}
          value={token}
          onChange={(e) => setToken(e.target.value)}
        />
        {msg && <p className="hint">{msg}</p>}
        <div className="actions">
          <button
            className="btn primary"
            disabled={busy || !userId || !/^\d{6}$/.test(token)}
            onClick={verify}
          >
            VERIFIKASI
          </button>
          <button className="btn ghost" disabled={busy || !userId} onClick={resend}>
            KIRIM ULANG OTP
          </button>
        </div>
        <a href="/login">Kembali ke login</a>
      </div>
    </main>
  );
}
