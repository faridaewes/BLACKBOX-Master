'use client';
import Link from 'next/link';
import LegalAgreementCenter from '@/components/LegalAgreementCenter';
export default function AdminLegalPage(){return <main className="page"><div className="pageTitle"><div><h1>LEGAL & AGREEMENT CENTER</h1><p>Registry persetujuan, evidence, pencarian user, export, dan version control dokumen legal.</p></div><Link className="btn ghost" href="/admin">KEMBALI ADMIN</Link></div><LegalAgreementCenter/></main>}
