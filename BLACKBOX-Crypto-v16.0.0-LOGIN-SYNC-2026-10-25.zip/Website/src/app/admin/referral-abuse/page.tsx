'use client';
import { useEffect, useState } from 'react';
import BlackboxNav from '@/components/BlackboxNav';

export default function ReferralAbuse() {
  const [rows, setRows] = useState<any[]>([]);
  const [msg, setMsg] = useState('');
  const [filter, setFilter] = useState('ALL');
  const load = async () => {
    const q = filter === 'ALL' ? '' : `?status=${filter}`;
    const r = await fetch(`/api/admin/referral/abuse${q}`, { cache: 'no-store' });
    const j = await r.json();
    if (j.ok) setRows(j.risks || []); else setMsg(j.error || 'Gagal memuat');
  };
  useEffect(() => { load(); }, [filter]);
  const review = async (userId: string, status: string) => {
    const r = await fetch('/api/admin/referral/abuse', { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ userId, action: 'REVIEW', status, note: `Manual ${status} review v9.7` }) });
    const j = await r.json(); setMsg(j.ok ? `Risk ${status}.` : j.error || 'Gagal'); if (j.ok) load();
  };
  const reassess = async (userId: string) => {
    const r = await fetch('/api/admin/referral/abuse', { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ userId, action: 'REASSESS' }) });
    const j = await r.json(); setMsg(j.ok ? `Reassess: ${j.risk?.status} / ${j.risk?.score}` : j.error || 'Gagal'); if (j.ok) load();
  };
  return <><BlackboxNav/><main className="page"><div className="pageTitle"><div><h1>REFERRAL ANTI-ABUSE INTELLIGENCE</h1><p>v9.7 · deteksi velocity, shared IP/device, cluster downline dan kontrol campaign reward.</p></div></div>{msg && <div className="banner amber">{msg}</div>}<section className="panel"><div className="panelHead"><span className="panelTitle">RISK QUEUE</span></div><div className="panelBody"><div className="actions" style={{marginBottom:12}}>{['ALL','BLOCKED','REVIEW','CLEAR'].map(x=><button key={x} className={`btn ${filter===x?'primary':'ghost'}`} onClick={()=>setFilter(x)}>{x}</button>)}</div><div className="tableWrap"><table className="table"><thead><tr><th>USER</th><th>SCORE</th><th>STATUS</th><th>SIGNALS</th><th>DIRECT</th><th>24H REG</th><th>IP</th><th>DEVICE</th><th>ACTIONS</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td>@{r.user?.username}</td><td><b>{r.score}</b></td><td>{r.status}</td><td>{(r.flags||[]).join(', ')||'—'}</td><td>{r.metrics?.directCount??0}</td><td>{r.metrics?.registrations24h??0}</td><td>{r.metrics?.sharedIpWithSponsor??0}</td><td>{r.metrics?.sharedDeviceWithSponsor??0}</td><td><div className="actions"><button className="btn ghost" onClick={()=>reassess(r.userId)}>REASSESS</button><button className="btn ghost" onClick={()=>review(r.userId,'CLEAR')}>CLEAR</button><button className="btn danger" onClick={()=>review(r.userId,'BLOCKED')}>BLOCK</button></div></td></tr>)}</tbody></table></div><p className="hint">BLOCKED hanya menahan campaign reward baru; referral ledger inti tidak dihapus otomatis. Clawback tetap memerlukan keputusan admin yang teraudit.</p></div></section></main></>;
}
