'use client';
import { useEffect, useState } from 'react';
import BlackboxNav from '@/components/BlackboxNav';

export default function ReferralNetworkAdmin() {
  const [q, setQ] = useState('');
  const [users, setUsers] = useState<any[]>([]);
  const [userId, setUserId] = useState('');
  const [newSponsorId, setNewSponsorId] = useState('');
  const [reason, setReason] = useState('');
  const [msg, setMsg] = useState('');
  const load = async () => { const r = await fetch(`/api/admin/referral/network?q=${encodeURIComponent(q)}`, { cache: 'no-store' }); const j = await r.json(); if (j.ok) setUsers(j.users || []); else setMsg(j.error || 'Gagal memuat'); };
  useEffect(() => { load(); }, []);
  const move = async () => {
    setMsg('');
    const r = await fetch('/api/admin/referral/network', { method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({ userId, newSponsorId, reason }) });
    const j = await r.json();
    setMsg(j.ok ? `Berhasil memindahkan @${j.username} beserta ${j.subtreeSize} anggota subtree ke @${j.newSponsorUsername}.` : j.error || 'Gagal memindahkan jaringan');
    if (j.ok) { setUserId(''); setNewSponsorId(''); setReason(''); await load(); }
  };
  return <><BlackboxNav/><main className="page"><div className="pageTitle"><div><h1>REFERRAL NETWORK CONTROL</h1><p>v10.0 · pindahkan user beserta seluruh subtree tanpa memutus jaringan, ledger, atau riwayat reward.</p></div></div>{msg&&<div className="banner amber">{msg}</div>}<section className="panel"><div className="panelHead"><span className="panelTitle">MOVE SUBTREE</span></div><div className="panelBody"><div className="two"><div><label className="small">USER YANG DIPINDAHKAN</label><select className="input" value={userId} onChange={e=>setUserId(e.target.value)}><option value="">Pilih user</option>{users.map(u=><option key={u.id} value={u.id}>@{u.username} · sponsor @{u.referredBy?.username||'ROOT'}</option>)}</select></div><div><label className="small">SPONSOR / JARINGAN TUJUAN</label><select className="input" value={newSponsorId} onChange={e=>setNewSponsorId(e.target.value)}><option value="">Pilih sponsor tujuan</option>{users.map(u=><option key={u.id} value={u.id}>@{u.username}</option>)}</select></div></div><input className="input" style={{marginTop:12}} placeholder="Alasan perpindahan (wajib audit, opsional isi)" value={reason} onChange={e=>setReason(e.target.value)}/><button className="btn danger" style={{marginTop:12}} disabled={!userId||!newSponsorId||userId===newSponsorId} onClick={move}>MOVE USER + ENTIRE SUBTREE</button><p className="hint">v10.0 mempertahankan seluruh user ID, username, referral code, point ledger, reward history dan anggota di bawah user. Yang berubah hanya sponsor langsung user yang dipindahkan. Sistem menolak cycle dan perpindahan yang membuat kedalaman melebihi L10.</p></div></section><section className="panel"><div className="panelHead"><span className="panelTitle">NETWORK DIRECTORY</span></div><div className="panelBody"><div className="actions"><input className="input" placeholder="Cari username/email" value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==='Enter'&&load()}/><button className="btn ghost" onClick={load}>SEARCH</button></div><div className="tableWrap"><table className="table"><thead><tr><th>USERNAME</th><th>NAME</th><th>SPONSOR</th><th>REFERRAL LINK CODE</th></tr></thead><tbody>{users.map(u=><tr key={u.id}><td>@{u.username}</td><td>{u.name}</td><td>{u.referredBy?.username?`@${u.referredBy.username}`:'ROOT'}</td><td>{u.referralCode||'—'}</td></tr>)}</tbody></table></div></div></section></main></>;
}
