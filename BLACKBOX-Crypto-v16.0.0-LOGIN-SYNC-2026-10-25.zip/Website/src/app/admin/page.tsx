'use client';
import MaintenanceControl from '@/components/MaintenanceControl';
import { useEffect, useState, useCallback } from 'react';
import Link from 'next/link';
import AdminUsers from '@/components/AdminUsers';
import AccessCodeManager from '@/components/AccessCodeManager';
import KycReview from '@/components/KycReview';
import AuditCenter from '@/components/AuditCenter';
import AdminActivityTracker from '@/components/AdminActivityTracker';
import ProfileIdentity from '@/components/ProfileIdentity';
import Broadcaster from '@/components/Broadcaster';
import PrivilegedAccounts from '@/components/PrivilegedAccounts';
import PaymentAdminCenter from '@/components/PaymentAdminCenter';
import PlanManager from '@/components/PlanManager';
import PaymentConfigManager from '@/components/PaymentConfigManager';

type Overview = { role: string; flags: { globalHalt: boolean; apiRevoked: boolean; maintenance: boolean }; counts: Record<string, number>; audit: { action: string; targetType: string | null; createdAt: string }[] };

function EmergencyBox({ action, phrase, label, danger = true, value, onChange, onRun }: { action:string; phrase:string; label:string; danger?:boolean; value:string; onChange:(v:string)=>void; onRun:()=>void }) {
  return <div style={{ marginBottom: 14 }}><div className="hint">Ketik <b>{phrase}</b> untuk mengaktifkan tombol</div><div className="actions"><input className="input" value={value} onChange={(e)=>onChange(e.target.value)} placeholder={phrase}/><button className={'btn '+(danger?'danger':'')} disabled={value.trim()!==phrase} onClick={onRun}>{label}</button></div></div>;
}

export default function Admin() {
  const [o, setO] = useState<Overview | null>(null);
  const [err, setErr] = useState('');
  const [msg, setMsg] = useState('');
  const [confirm, setConfirm] = useState<Record<string, string>>({});

  const load = useCallback(async () => {
    const r = await fetch('/api/admin/overview'); const j = await r.json();
    if (j.ok) { setO(j); setErr(''); } else setErr(j.error || 'Gagal memuat');
  }, []);
  useEffect(() => { load(); const t = setInterval(load, 5000); return () => clearInterval(t); }, [load]);

  const act = async (action: string, phrase: string) => {
    setMsg('');
    const r = await fetch('/api/emergency', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action, confirm: confirm[action] || '' }) });
    const j = await r.json();
    setMsg(j.ok ? `Berhasil (${action}) — terdampak: ${j.affected ?? '-'}` : `Gagal: ${j.error}`);
    if (j.ok) setConfirm({ ...confirm, [action]: '' });
    load();
  };

  if (err) return <><AdminActivityTracker/><main className="page"><div className="warning">{err}</div><Link className="btn ghost" href="/dashboard">Kembali</Link></main></>;
  if (!o) return <><AdminActivityTracker/><main className="page"><p>Memuat…</p></main></>;
  const isDev = o.role === 'DEVELOPER';
  return <><AdminActivityTracker/><main className="page">
    <ProfileIdentity />
    <div className="pageTitle"><div><h1>BLACKBOX Admin Console</h1><p>Peran: {o.role}. Semua aksi tercatat di audit log.</p></div><Link className="btn ghost" href="/dashboard">User View</Link></div>
    {o.flags.globalHalt && <div className="warning">🔴 GLOBAL TRADING HALT AKTIF — semua bot dihentikan dan bot baru tidak bisa dijalankan.</div>}
    {o.flags.maintenance && <div className="warning">🛠 MAINTENANCE MODE AKTIF — dikelola oleh Developer Superuser.</div>}
    <div className="actions" style={{marginBottom:16}}><Link className="btn ghost" href="/admin/referral-os">REFERRAL & REWARD OS</Link><Link className="btn ghost" href="/admin/referral-campaigns">REFERRAL CAMPAIGN ENGINE</Link><Link className="btn ghost" href="/admin/referral-abuse">REFERRAL ANTI-ABUSE</Link><Link className="btn ghost" href="/admin/referral-network">REFERRAL NETWORK CONTROL</Link><Link className="btn ghost" href="/admin/reports">REPORT CENTER</Link><Link className="btn ghost" href="/admin/legal">LEGAL & AGREEMENTS</Link></div><div className="metrics">
      <div className="metric"><div className="metricLabel">USER AKTIF</div><div className="kpi">{o.counts.activeUsers} / {o.counts.users}</div></div>
      <div className="metric"><div className="metricLabel">BOT RUNNING</div><div className="kpi">{o.counts.running} / {o.counts.bots}</div></div>
      <div className="metric"><div className="metricLabel">POSISI TERBUKA</div><div className="kpi">{o.counts.openPositions}</div></div>
      <div className="metric"><div className="metricLabel">PANGGILAN AI</div><div className="kpi">{o.counts.aiCalls}</div></div>
    </div>
    {msg && <div className="hint">{msg}</div>}
    <div className="two">
      <section className="panel"><div className="panelHead"><span className="panelTitle">EMERGENCY CONTROLS</span></div><div className="panelBody">
        <EmergencyBox action="STOP_ALL_BOTS" phrase="STOP ALL BLACKBOX" label={o.flags.globalHalt ? 'HALT AKTIF' : 'STOP ALL BOTS'} value={confirm.STOP_ALL_BOTS||''} onChange={(v)=>setConfirm({...confirm,STOP_ALL_BOTS:v})} onRun={()=>act('STOP_ALL_BOTS','STOP ALL BLACKBOX')} />
        <EmergencyBox action="GLOBAL_API_REVOKE" phrase="REVOKE ALL API" label={o.flags.apiRevoked ? 'SUDAH DICABUT' : 'GLOBAL API REVOKE'} value={confirm.GLOBAL_API_REVOKE||''} onChange={(v)=>setConfirm({...confirm,GLOBAL_API_REVOKE:v})} onRun={()=>act('GLOBAL_API_REVOKE','REVOKE ALL API')} />
        {isDev && <>
          <EmergencyBox action="LIFT_GLOBAL_HALT" phrase="RESUME BLACKBOX" label="CABUT GLOBAL HALT" danger={false} value={confirm.LIFT_GLOBAL_HALT||''} onChange={(v)=>setConfirm({...confirm,LIFT_GLOBAL_HALT:v})} onRun={()=>act('LIFT_GLOBAL_HALT','RESUME BLACKBOX')} /><EmergencyBox action="LIFT_API_REVOKE" phrase="RESTORE API ACCESS" label="RESTORE API" danger={false} value={confirm.LIFT_API_REVOKE||''} onChange={(v)=>setConfirm({...confirm,LIFT_API_REVOKE:v})} onRun={()=>act('LIFT_API_REVOKE','RESTORE API ACCESS')} />
        </>}
        <p className="hint">STOP ALL tidak menjual aset otomatis. API REVOKE hanya menonaktifkan koneksi di BLACKBOX; hapus/ganti API key di exchange Anda juga.</p>
      </div></section>
      <section className="panel"><div className="panelHead"><span className="panelTitle">AUDIT LOG TERAKHIR</span></div><div className="panelBody log">
        {o.audit.length === 0 && 'Belum ada aktivitas.'}
        {o.audit.map((a, i) => <div key={i}>{new Date(a.createdAt).toLocaleString('id-ID')} · <b>{a.action}</b> {a.targetType || ''}</div>)}
      </div></section>
    </div>

    <AuditCenter role={o.role as any} />
    <MaintenanceControl />
    {isDev && <PrivilegedAccounts />}
    <AdminUsers role={o.role} />
    <Broadcaster role={o.role as 'DEVELOPER'|'ADMIN'} />
    <AccessCodeManager />
    <KycReview />
    <PaymentAdminCenter />
    <PlanManager />
    <PaymentConfigManager />
    <section className="panel section"><div className="panelHead"><span className="panelTitle">KEBIJAKAN</span></div><div className="panelBody log">
      <b>SECRETS</b> tidak pernah ditampilkan ke admin; seed phrase/private key tidak disimpan. <b>REAL MODE</b> terkunci sampai REAL_TRADING_ENABLED=true dan koneksi valid.
    </div></section>
  </main></>;
}
