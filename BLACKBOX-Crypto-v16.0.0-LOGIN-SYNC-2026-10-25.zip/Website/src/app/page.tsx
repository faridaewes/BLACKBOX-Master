import Link from 'next/link';
import BrandBanner from '@/components/BrandBanner';
import BlackboxLogo from '@/components/BlackboxLogo';
import { BLACKBOX_RELEASE_VERSION } from '@/lib/release-version';

const modules = [
  { tag: 'INTEL', title: 'AI Brain', desc: 'Signal intelligence dengan konfirmasi deterministik. AI mengusulkan — risk engine yang memutuskan.' },
  { tag: 'RISK', title: 'Risk & Safety Kernel', desc: 'Fail-closed gates, drawdown control, daily loss limit, dan Safety Kernel ENTRY/EXIT.' },
  { tag: 'EXEC', title: 'Paper Execution', desc: 'Simulasi fill realistis: slippage, fee, impact. REAL trading terkunci default.' },
  { tag: 'ROUTE', title: 'Router Intelligence', desc: 'Quote ranking multi-provider dengan penalti impact, fee, dan latency.' },
  { tag: 'OPS', title: 'Command Center', desc: 'Bot Control terpadu: START/STOP, engine health, journal penolakan, dry-run.' },
  { tag: 'LEDGER', title: 'Audit & Referral', desc: 'Referral ledger idempotent, access code, tier claim, dan jejak audit penuh.' },
];

const pipeline = ['SCAN', 'THINK', 'RISK', 'ROUTE', 'FILL', 'MONITOR', 'LEARN'];

export default function Home() {
  return (
    <main className="lp">
      <div className="lpGridFx" aria-hidden />
      <div className="lpOrb lpOrbA" aria-hidden />
      <div className="lpOrb lpOrbB" aria-hidden />

      <header className="lpTop">
        <div className="lpBrand">
          <BlackboxLogo />
        </div>
        <nav className="lpNav">
          <a href="#modules">Modules</a>
          <a href="#pipeline">Pipeline</a>
          <a href="#safety">Safety</a>
          <a href="/wpa">WPA</a>
          <Link href="/login">Sign in</Link>
          <Link className="lpNavCta" href="/register">Create account</Link>
        </nav>
      </header>

      <BrandBanner />

      <section className="lpHero">
        <div className="lpHeroBadge">
          <span className="lpPulse" />
          SYSTEM ONLINE · PAPER-FIRST · RISK CONTROLLED
        </div>
        <h1 className="lpTitle">
          <span className="lpTitleDim">ENTER THE</span>
          <span className="lpTitleMain">BLACKBOX</span>
          <span className="lpTitleSub">CRYPTO COMMAND CENTER</span>
        </h1>
        <p className="lpLead">
          Hybrid intelligent trading OS. Dari market scan hingga position management —
          setiap keputusan melewati risk gate dan safety kernel. Dibangun untuk operator
          yang menuntut kontrol, bukan spekulasi buta.
        </p>
        <div className="lpCtaRow">
          <Link className="lpBtn primary" href="/dashboard">
            <span className="lpBtnGlow" />
            OPEN COMMAND CENTER
          </Link>
          <Link className="lpBtn ghost" href="/login">SIGN IN</Link>
          <Link className="lpBtn ghost" href="/register">CREATE ACCOUNT</Link>
        </div>
        <div className="lpStats">
          <div className="lpStat"><b>FAIL-CLOSED</b><span>Real trading default off</span></div>
          <div className="lpStat"><b>SAFETY KERNEL</b><span>ENTRY · EXIT · EMERGENCY</span></div>
          <div className="lpStat"><b>PAPER ENGINE</b><span>Full simulation loop</span></div>
          <div className="lpStat"><b>v{BLACKBOX_RELEASE_VERSION}</b><span>Certification hardened</span></div>
        </div>
      </section>

      <section className="lpPipe" id="pipeline">
        <div className="lpSectionLabel">DECISION PIPELINE</div>
        <div className="lpPipeTrack">
          {pipeline.map((s, i) => (
            <div className="lpPipeNode" key={s}>
              <div className="lpPipeDot">{String(i + 1).padStart(2, '0')}</div>
              <div className="lpPipeName">{s}</div>
              {i < pipeline.length - 1 && <div className="lpPipeLine" />}
            </div>
          ))}
        </div>
      </section>

      <section className="lpModules" id="modules">
        <div className="lpSectionLabel">CORE MODULES</div>
        <h2 className="lpSectionTitle">Built like infrastructure.<br />Not a gambling terminal.</h2>
        <div className="lpModuleGrid">
          {modules.map((m) => (
            <article className="lpModuleCard" key={m.title}>
              <span className="lpModuleTag">{m.tag}</span>
              <h3>{m.title}</h3>
              <p>{m.desc}</p>
              <div className="lpModuleBar" />
            </article>
          ))}
        </div>
      </section>

      <section className="lpSafety" id="safety">
        <div className="lpSafetyInner">
          <div className="lpSectionLabel">SECURITY POSTURE</div>
          <h2 className="lpSectionTitle">Trust is earned by what the system refuses to do.</h2>
          <ul className="lpSafetyList">
            <li>REAL execution locked until explicit certification gates pass</li>
            <li>No seed phrase / private key storage in application layer</li>
            <li>Session verified against database on every privileged request</li>
            <li>AES-256-GCM envelope (BBX2) with explicit key rotation support</li>
            <li>Operator halt, maintenance mode, and distributed rate limits</li>
          </ul>
          <Link className="lpBtn primary" href="/register">START WITH PAPER MODE</Link>
        </div>
        <div className="lpSafetyPanel" aria-hidden>
          <div className="lpTerminal">
            <div className="lpTermTop"><span /><span /><span /></div>
            <pre>{`> safety.kernel.status
ENTRY     · ARMED
EXIT      · ARMED
EMERGENCY · ARMED
REAL      · LOCKED
AUTH      · DB-VERIFIED
ENGINE    · STANDBY

> risk.gate.policy
failClosed = true
dailyLoss  = enforced
drawdown   = enforced`}</pre>
          </div>
        </div>
      </section>

    </main>
  );
}
