"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function ChangePasswordPage(){
  const router=useRouter();
  const [oldp,setOldp]=useState("");
  const [newp,setNewp]=useState("");
  const [confirm,setConfirm]=useState("");
  const [mfa,setMfa]=useState("");
  const [err,setErr]=useState("");
  const [busy,setBusy]=useState(false);
  useEffect(()=>{fetch('/api/auth/status',{cache:'no-store'}).then(r=>r.json()).then(j=>{if(!j?.ok) router.replace('/login');});},[router]);
  const submit=async()=>{
    setErr("");
    if(newp!==confirm){setErr('Konfirmasi password tidak sama.');return;}
    setBusy(true);
    try{
      const r=await fetch('/api/auth/password/change',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({currentPassword:oldp,newPassword:newp,mfaCode:mfa||undefined})});
      const j=await r.json();
      if(!j.ok){setErr(j.error||'Gagal mengganti password.');return;}
      router.replace('/dashboard');
      router.refresh();
    }finally{setBusy(false)}
  };
  return <main className="container"><div className="card auth"><span className="badge">BLACKBOX SECURITY</span><h1>Ganti Password</h1><p className="small">Password awal/temporary wajib diganti sebelum mengakses dashboard.</p><input placeholder="Password saat ini" type="password" value={oldp} onChange={e=>setOldp(e.target.value)}/><input placeholder="Password baru (min. 12 karakter)" type="password" value={newp} onChange={e=>setNewp(e.target.value)}/><input placeholder="Ulangi password baru" type="password" value={confirm} onChange={e=>setConfirm(e.target.value)}/><input placeholder="Kode MFA jika aktif" inputMode="numeric" maxLength={6} value={mfa} onChange={e=>setMfa(e.target.value.replace(/\D/g,''))}/>{err&&<p className="risk">{err}</p>}<button className="btn" onClick={submit} disabled={busy||!oldp||!newp||!confirm}>{busy?'MENYIMPAN…':'GANTI PASSWORD & LANJUTKAN'}</button></div></main>;
}
