import { redirect } from 'next/navigation';
import { normalizePublicReferralCode } from '@/lib/referral-link';

export default async function ReferralLanding({ params }: { params: Promise<{ referralCode: string }> }) {
  const { referralCode } = await params;
  const code = normalizePublicReferralCode(referralCode);
  if (!code || !/^[a-z0-9_-]{4,64}$/.test(code)) redirect('/register');
  redirect(`/register?ref=${encodeURIComponent(code)}`);
}
