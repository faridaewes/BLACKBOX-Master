import crypto from "node:crypto";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { BRAND } from "@/lib/brand";

export default async function PortfolioShare({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
  const share = await prisma.portfolioShare.findUnique({ where: { tokenHash }, include: { user: { select: { name: true } } } });
  if (!share || (share.expiresAt && share.expiresAt < new Date())) notFound();
  return <main className="container"><div className="card" style={{maxWidth:760,margin:'60px auto'}}><span className="badge">VERIFIED SHARE</span><h1>{share.title}</h1><p className="muted">{BRAND.name} • {BRAND.technology}</p>{share.showIdentity&&<p>Trader: <b>{share.user.name}</b></p>}<div className="grid"><div className="card"><div className="muted">PERIODE</div><h3>{share.period}</h3></div><div className="card"><div className="muted">PNL</div><h3>{share.pnl} ({share.pnlPercent}%)</h3></div><div className="card"><div className="muted">TRADES</div><h3>{share.trades}</h3></div><div className="card"><div className="muted">WIN RATE</div><h3>{share.winRate}%</h3></div></div><p className="risk" style={{marginTop:16}}>{BRAND.riskText}</p><p className="muted" style={{marginTop:20}}>Developed by {BRAND.developer}.</p></div></main>;
}
