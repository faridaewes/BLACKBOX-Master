'use client';
import { BLACKBOX_FOOTER_SHORT_DISCLAIMER } from '@/lib/legal-content';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import WpaProfileCard, { type WpaAdvisor } from '@/components/WpaProfileCard';
import BlackboxLogo from '@/components/BlackboxLogo';

export default function WpaDirectoryPage() {
  const [rows, setRows] = useState<WpaAdvisor[]>([]);
  const [q, setQ] = useState('');
  const [err, setErr] = useState('');

  useEffect(() => {
    fetch(`/api/public/advisors?q=${encodeURIComponent(q)}`, { cache: 'no-store' })
      .then((r) => r.json())
      .then((j) => {
        if (j.ok) setRows(j.advisors || []);
        else setErr(j.error || 'Gagal memuat');
      })
      .catch(() => setErr('Gagal memuat profil WPA'));
  }, [q]);

  return (
    <main className="wpaPage">
      <header className="wpaTopBar">
        <Link href="/" className="wpaBrand">
          <BlackboxLogo />
        </Link>
        <nav className="wpaTopNav">
          <Link href="/public-info">Info Publik</Link>
          <Link href="/login">Masuk</Link>
          <Link className="wpaTopCta" href="/register">
            Daftar
          </Link>
        </nav>
      </header>

      <section className="wpaIntro">
        <div className="wpaIntroBadge">WAKIL PENASIHAT BERJANGKA · PUBLIK</div>
        <h1>Direktori WPA</h1>
        <p>
          Profil penasihat yang dipublikasikan resmi melalui BLACKBOX. Data dikelola Developer dan
          dapat diverifikasi pada sumber lisensi terkait.
        </p>
      </section>

      <div className="wpaDirectoryTools"><input className="input" placeholder="Cari nama, spesialisasi, perusahaan…" value={q} onChange={e=>setQ(e.target.value)}/><Link className="wpaTopCta" href="/wpa/apply">Daftar Menjadi WPA</Link></div>
      {err && <div className="banner">{err}</div>}

      <section className="wpaGrid">
        {rows.map((a, i) => (
          <WpaProfileCard key={a.id} advisor={a} featured={i === 0} />
        ))}
        {!rows.length && !err && (
          <div className="wpaEmpty">Belum ada profil WPA yang dipublikasikan.</div>
        )}
      </section>

      <footer className="wpaFooterNote">
        <b>DISCLAIMER BLACKBOX TECHNOLOGY</b><br/>
        {BLACKBOX_FOOTER_SHORT_DISCLAIMER}
      </footer>
    </main>
  );
}
