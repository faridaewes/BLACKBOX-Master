'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import WpaProfileCard, { type WpaAdvisor } from '@/components/WpaProfileCard';
import BlackboxLogo from '@/components/BlackboxLogo';

function wa(v?: string | null) { if (!v) return null; const n=String(v).replace(/\D/g,''); return n ? `https://wa.me/${n}` : null; }
function tg(v?: string | null) { if (!v) return null; return String(v).startsWith('http') ? String(v) : `https://t.me/${String(v).replace('@','')}`; }

export default function WpaDetailPage() {
  const id=String(useParams()?.id||'');
  const [a,setA]=useState<WpaAdvisor|null>(null);
  const [err,setErr]=useState('');
  const [form,setForm]=useState({name:'',phone:'',purpose:'',message:''});
  const [msg,setMsg]=useState('');
  const [following,setFollowing]=useState(false);
  const [selectedService,setSelectedService]=useState<any>(null);
  const [catalog,setCatalog]=useState<any>(null);
  const [enrollMsg,setEnrollMsg]=useState('');

  useEffect(()=>{
    if(!id) return;
    fetch('/api/public/advisors',{cache:'no-store'}).then(r=>r.json()).then(j=>{
      const x=(j.advisors||[]).find((v:any)=>v.id===id);
      if(x) setA(x); else setErr('Profil tidak ditemukan atau belum dipublikasikan');
    }).catch(()=>setErr('Gagal memuat'));
  },[id]);

  const follow=async()=>{
    const r=await fetch('/api/wpa/follow',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({advisorId:id})});
    const j=await r.json(); setFollowing(!!j.ok);
  };

  const inquire=async(service?:any)=>{
    const purpose=service?`Daftar layanan: ${service.name}`:form.purpose;
    const r=await fetch('/api/wpa/inquiry',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({...form,purpose,advisorId:id,message:form.message||`Saya ingin melanjutkan komunikasi terkait ${service?.name||'layanan WPA'}.`})});
    const j=await r.json(); setMsg(j.ok?'Permintaan konsultasi terkirim. Silakan lanjutkan komunikasi pribadi dengan WPA.':j.error||'Gagal');
  };

  const chooseService=async(service:any)=>{
    setSelectedService(service); setEnrollMsg(''); setCatalog(null);
    const r=await fetch(`/api/wpa/catalog?advisorId=${encodeURIComponent(id)}&serviceId=${encodeURIComponent(service.id)}`,{cache:'no-store'});
    const j=await r.json(); if(j.ok) setCatalog(j); else setEnrollMsg(j.error||'Katalog tier tidak tersedia.');
  };

  const enroll=async(planId:string)=>{
    if(!selectedService) return;
    setEnrollMsg('Mengirim permintaan ke WPA…');
    const r=await fetch('/api/wpa/enrollments',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({advisorId:id,serviceId:selectedService.id,planId})});
    const j=await r.json();
    if(j.ok){
      setEnrollMsg('Permintaan layanan dikirim. Setelah WPA menyetujui, Anda dapat mengaktifkan Tier BLACKBOX melalui halaman redeem.');
      setCatalog((x:any)=>({...x,enrollments:[...(x?.enrollments||[]),j.enrollment]}));
    } else setEnrollMsg(j.error==='UNAUTHORIZED'?'Silakan login terlebih dahulu.':j.error||'Gagal mengirim permintaan.');
  };

  return <main className="wpaPage">
    <header className="wpaTopBar"><Link href="/wpa" className="wpaBrand"><BlackboxLogo compact/></Link><nav className="wpaTopNav"><Link href="/wpa">Semua WPA</Link><Link href="/public-info">Info Publik</Link></nav></header>
    <section className="wpaDetailWrap">
      {err&&<div className="banner">{err}</div>}
      {a&&<>
        <WpaProfileCard advisor={a} featured/>
        <div className="wpaDetailGrid">
          <section className="panel">
            <div className="panelHead"><span className="panelTitle">LAYANAN WPA</span><button className="btn ghost" onClick={follow}>{following?'MENGIKUTI':'IKUTI WPA'}</button></div>
            <div className="panelBody">
              {a.services?.length ? a.services.map((s:any)=>{
                const w=wa(a.whatsapp||a.phone); const t=tg(a.telegram); const open=selectedService?.id===s.id;
                return <div key={s.id}>
                  <div className="listItem">
                    <span><b>{s.name}</b><div className="small">{s.description||s.category||'Pendampingan WPA'}{s.durationMinutes?` · ${s.durationMinutes} menit`:''}</div></span>
                    <span className="wpaCtaRow">
                      {w&&<a className="wpaBtn primary" href={w} target="_blank" rel="noreferrer">WhatsApp</a>}
                      {!w&&t&&<a className="wpaBtn primary" href={t} target="_blank" rel="noreferrer">Telegram</a>}
                      <button className="wpaBtn ghost" onClick={()=>void chooseService(s)}>Pilih Layanan</button>
                      <button className="wpaBtn ghost" onClick={()=>inquire(s)}>Hubungi / Inquiry</button>
                    </span>
                  </div>
                  {open&&<div className="panel" style={{margin:'10px 0'}}>
                    <div className="panelBody">
                      <b>Tier BLACKBOX tersedia</b>
                      <p className="small">Pilih tier yang ingin diaktifkan bersama layanan WPA. Tidak ada harga layanan WPA yang diproses di BLACKBOX.</p>
                      {catalog?.plans?.length ? catalog.plans.map((p:any)=><div className="listItem" key={p.id}>
                        <span><b>{p.name}</b><div className="small">{p.description||'Fitur Tier BLACKBOX aktif sesuai katalog saat ini.'}</div></span>
                        <button className="wpaBtn primary" onClick={()=>void enroll(p.id)}>Ajukan</button>
                      </div>) : <p className="muted">Memuat tier…</p>}
                      {catalog?.enrollments?.map((e:any)=><div className="banner" key={e.id}>
                        Status layanan {e.status}. {e.status==='APPROVED'&&<a className="btn ghost" href={`/dashboard/access?wpaEnrollmentId=${encodeURIComponent(e.id)}&planId=${encodeURIComponent(e.planId)}`}>AKTIFKAN TIER</a>}
                      </div>)}
                      {enrollMsg&&<div className="banner">{enrollMsg}</div>}
                    </div>
                  </div>}
                </div>;
              }) : <p className="muted">Belum ada layanan aktif.</p>}
              <h3 style={{marginTop:18}}>Sertifikasi / Kredensial</h3>
              {a.certifications?.map(c=><div className="listItem" key={c.id}><span><b>{c.authority}</b><div className="small">{c.credential} {c.credentialNumber?`· ${c.credentialNumber}`:''}</div></span><span>{c.status}</span></div>)}
            </div>
          </section>
          <section className="panel">
            <div className="panelHead"><span className="panelTitle">KOMUNIKASI PRIBADI</span></div>
            <div className="panelBody formGrid">
              <p className="muted">BLACKBOX tidak memproses pendaftaran CWPA/WPA atau pembayaran layanan. Tombol layanan membuka komunikasi langsung dengan WPA atau mengirim inquiry internal sebagai fallback.</p>
              <input className="input" placeholder="Nama lengkap" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
              <input className="input" placeholder="WhatsApp / telepon" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/>
              <input className="input" placeholder="Tujuan konsultasi" value={form.purpose} onChange={e=>setForm({...form,purpose:e.target.value})}/>
              <textarea className="input" rows={5} placeholder="Pesan" value={form.message} onChange={e=>setForm({...form,message:e.target.value})}/>
              <button className="btn primary" onClick={()=>inquire()}>KIRIM INQUIRY</button>
              {msg&&<div className="banner">{msg}</div>}
            </div>
          </section>
        </div>
      </>}
    </section>
  </main>;
}
