import './globals.css';
import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import Script from 'next/script';
import LiveChatWidget from '@/components/LiveChatWidget';
import SocialFooter from '@/components/SocialFooter';

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  colorScheme: 'dark',
};

export const metadata: Metadata = {
  title: 'BLACKBOX Crypto',
  description: 'BLACKBOX Crypto — intelligent, risk-controlled crypto trading command center.',
  icons: { icon: '/api/public/branding/favicon', shortcut: '/api/public/branding/favicon', apple: '/api/public/branding/favicon' },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="id" suppressHydrationWarning>
      <head>
        <meta name="format-detection" content="telephone=no, date=no, email=no, address=no" />
      </head>
      <body suppressHydrationWarning>
        <Script id="bbx-prehydration-guard" strategy="beforeInteractive">
          {`(() => {
            try {
              const scrub = (root) => {
                if (!root || root.nodeType !== 1) return;
                if (root.hasAttribute && root.hasAttribute('__gcruniqueid')) root.removeAttribute('__gcruniqueid');
                if (root.querySelectorAll) root.querySelectorAll('[__gcruniqueid]').forEach((el) => el.removeAttribute('__gcruniqueid'));
              };
              scrub(document.documentElement);
              const observer = new MutationObserver((records) => {
                for (const record of records) {
                  if (record.type === 'attributes' && record.attributeName === '__gcruniqueid') scrub(record.target);
                  if (record.type === 'childList') record.addedNodes.forEach(scrub);
                }
              });
              observer.observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ['__gcruniqueid'] });
              window.addEventListener('load', () => setTimeout(() => observer.disconnect(), 10000), { once: true });
            } catch {}
          })();`}
        </Script>
        <div className="shell">{children}
        <SocialFooter />
        <LiveChatWidget /></div>
      </body>
    </html>
  );
}
