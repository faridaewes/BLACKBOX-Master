'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import WpaProfileCard, { type WpaAdvisor } from '@/components/WpaProfileCard';

export default function PublicInfo() {
  const [a, setA] = useState<WpaAdvisor[]>([]);
  const [l, setL] = useState<any[]>([]);

  useEffect(() => {
    Promise.all([
      fetch('/api/public/advisors').then((r) => r.json()),
      fetch('/api/public/leaderboard').then((r) => r.json()),
    ])
      .then(([x, y]) => {
        if (x.ok) setA(x.advisors || []);
        if (y.ok) setL(y.leaderboard || []);
      })
      .catch(() => {});
  }, []);

  return (
    <main className="page">
      <div className="pageTitle">
        <div>
          <h1>PUBLIC INFORMATION CENTER</h1>
          <p>Regulasi, WPA, tier, dan leaderboard BLACKBOX.</p>
        </div>
        <Link className="btn ghost" href="/wpa">
          Direktori WPA
        </Link>
      </div>

      <section className="panel section">
        <h2>Regulasi Aset Keuangan Digital & Aset Kripto Indonesia</h2>
        <p>Ringkasan ini mengikuti sumber regulator resmi dan bukan nasihat hukum.</p>
        <ul>
          <li>POJK 27 Tahun 2024 berlaku sejak 10 Januari 2025.</li>
          <li>POJK 23 Tahun 2025 mengubah POJK 27/2024 dan berlaku 10 November 2025.</li>
          <li>PADK 3 Tahun 2026 berlaku 1 September 2026 untuk ketentuan pelaksanaan dan pelaporan lebih lanjut.</li>
        </ul>
        <div className="small">
          Sumber resmi: OJK. Regulasi dapat berubah; lakukan pemeriksaan pada sumber regulator sebelum bertindak.
        </div>
      </section>

      <section className="panel section wpaSection">
        <div className="wpaSectionHead">
          <div>
            <h2>Wakil Penasihat Berjangka (WPA)</h2>
            <p className="muted">
              Tampil seperti direktori profesional — foto, lisensi, kanal kontak, dan ajakan hubungi yang jelas.
            </p>
          </div>
          <Link className="btn primary" href="/wpa">
            Lihat semua WPA
          </Link>
        </div>
        <div className="wpaGrid">
          {a.map((x, i) => (
            <WpaProfileCard key={x.id} advisor={x} featured={i === 0} />
          ))}
          {!a.length && <div className="small">Belum ada profil WPA aktif.</div>}
        </div>
      </section>

      <section className="panel section">
        <h2>TOP 5 NETWORK LEADERBOARD</h2>
        <div className="three">
          {l.map((x) => (
            <div className="listItem" key={x.user.id}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={x.user.avatarUrl || '/favicon.png'}
                alt=""
                style={{ width: 36, height: 36, borderRadius: 10, objectFit: 'cover' }}
              />
              <span>
                <b>{x.user.name}</b>
                <div className="small">{x.score != null ? `Score ${x.score}` : ''}</div>
              </span>
            </div>
          ))}
          {!l.length && <div className="small">Leaderboard belum tersedia.</div>}
        </div>
      </section>
    </main>
  );
}
