'use client';
import BlackboxLogo from '@/components/BlackboxLogo';
import {useEffect,useState} from 'react';
import Link from 'next/link';

export default function LegalPage(){
 const [docs,setDocs]=useState<any[]>([]); const [loading,setLoading]=useState(true);
 useEffect(()=>{fetch('/api/public/legal',{cache:'no-store'}).then(r=>r.json()).then(j=>setDocs(j.documents||[])).finally(()=>setLoading(false))},[]);
 return <main className="page"><div className="pageTitle"><div><BlackboxLogo compact/><h1>LEGAL · CONSENT · RISK</h1><p>Dokumen yang menjadi dasar penggunaan BLACKBOX dan bukti persetujuan pengguna.</p></div><Link className="btn ghost" href="/regulations">REGULATORY CENTER</Link></div>
 <div className="banner amber">BLACKBOX adalah platform teknologi pendukung. BLACKBOX tidak menghimpun atau mengelola dana pengguna. Untuk layanan Penasihat Berjangka, ikuti proses resmi PT Alma Indonesia Raya. Dokumen ini bukan pengganti nasihat hukum dan wajib ditinjau sesuai perubahan regulasi.</div>
 {loading?<div className="panel"><div className="panelBody">Memuat dokumen…</div></div>:docs.map(d=><section className="panel section" key={d.type}><div className="panelHead"><span className="panelTitle">{d.title}</span><span className="pill">{d.type} · {d.version}</span></div><div className="panelBody"><div style={{whiteSpace:'pre-wrap',lineHeight:1.7,fontSize:12,color:'var(--muted)'}}>{d.body}</div></div></section>)}
 <section className="panel section"><div className="panelHead"><span className="panelTitle">PT ALMA INDONESIA RAYA</span></div><div className="panelBody"><p className="small">Untuk fitur yang terhubung dengan layanan Penasihat Berjangka, pengguna wajib menyelesaikan pendaftaran dan perjanjian layanan melalui kanal resmi PT Alma Indonesia Raya.</p><a className="btn primary" href="https://www.almai.id/" target="_blank" rel="noreferrer">BUKA ALMAI.ID</a></div></section>
 </main>
}
