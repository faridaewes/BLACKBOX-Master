'use client';
import {useEffect,useState} from 'react';
const fmt=(v:any)=>Array.isArray(v)?v.join(', '):v&&typeof v==='object'?Object.entries(v).map(([k,x])=>`${k}: ${Array.isArray(x)?x.join(', '):String(x)}`).join(' · '):String(v);
export default function Services(){
 const[d,setD]=useState<any>(null);
 useEffect(()=>{fetch('/api/public/tiers',{cache:'no-store'}).then(r=>r.json()).then(setD).catch(()=>setD({ok:false}))},[]);
 if(!d)return <main className="page"><div className="panel">Memuat layanan…</div></main>;
 if(!d.ok)return <main className="page"><div className="banner red">Layanan sementara tidak dapat dimuat.</div></main>;
 return <main className="page"><div className="pageTitle"><div><div className="actions" style={{marginBottom:8}}><a className="btn ghost" href="/regulations">REGULASI & PENASIHAT BERJANGKA</a></div><h1>BLACKBOX SERVICES & TIERS</h1><p>Pilih paket berdasarkan kebutuhan Anda. Detail di bawah berasal dari konfigurasi server dan dapat berubah sesuai kebijakan Developer.</p></div></div>
 <div className="three">{(d.plans||[]).map((p:any)=><section className="card" key={p.id}><span className="badge">TIER</span><h2>{p.name}</h2><p className="small">{p.description||'Paket layanan BLACKBOX.'}</p><div className="sideList">{(p.details||[]).map((x:any)=><div className="listItem" key={x.key}><span>{x.label}</span><b>{fmt(x.value)}</b></div>)}</div><div className="actions" style={{marginTop:12}}>{d.contact?.whatsapp&&<a className="btn primary" href={`https://wa.me/${String(d.contact.whatsapp).replace(/\D/g,'')}?text=${encodeURIComponent(`Saya tertarik dengan Tier ${p.name} BLACKBOX Crypto`)}`}>HUBUNGI WHATSAPP</a>}{d.contact?.telegram&&<a className="btn ghost" href={String(d.contact.telegram).startsWith('http')?d.contact.telegram:`https://t.me/${d.contact.telegram.replace('@','')}`}>TELEGRAM ADMIN</a>}</div></section>)}</div>
 <section className="panel section"><div className="panelHead"><span className="panelTitle">CARA AKTIVASI & AKUMULASI TIER</span></div><div className="panelBody"><p className="small">Tier dapat diperpanjang/diakumulasikan melalui Access Code maupun penukaran poin referral sesuai ketentuan. Grant baru ditambahkan setelah masa tier aktif yang sudah ada sehingga tidak saling menimpa.</p><p className="small">Trading aset kripto memiliki risiko tinggi. Informasi paket bukan jaminan keuntungan.</p></div></section></main>
}
