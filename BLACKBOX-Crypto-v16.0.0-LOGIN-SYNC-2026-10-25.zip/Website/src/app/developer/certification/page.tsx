'use client';
import { useEffect, useState } from 'react';

export default function CertificationCommandCenter() {
  const [data, setData] = useState<any>(null);
  const load = () =>
    fetch('/api/developer/certification', { cache: 'no-store' })
      .then((r) => r.json())
      .then(setData)
      .catch(() => {});

  useEffect(() => {
    load();
    const id = setInterval(load, 5000);
    return () => clearInterval(id);
  }, []);

  return (
    <main className="container">
      <div className="card">
        <span className="badge">v16.0.0 CERTIFICATION OS</span>
        <h1>Total Certification Command Center</h1>
        <p className="muted">
          P0/P1/P2 runtime, recovery, security, sandbox, database, Android, DR, performance,
          business dan observability. Status external tidak pernah dinaikkan menjadi PASS tanpa evidence runtime.
        </p>
        {data && (
          <>
            <div className="grid">
              <div className="card">
                <div className="muted">OVERALL</div>
                <h2>{data.overall}</h2>
              </div>
              <div className="card">
                <div className="muted">RELEASE</div>
                <h2>{data.release}</h2>
              </div>
              <div className="card">
                <div className="muted">REAL TRADING</div>
                <h2>DISABLED</h2>
              </div>
            </div>
            <div style={{ overflowX: 'auto', marginTop: 16 }}>
              <table>
                <thead>
                  <tr>
                    <th>Priority</th>
                    <th>Gate</th>
                    <th>Status</th>
                    <th>Evidence</th>
                  </tr>
                </thead>
                <tbody>
                  {data.gates?.map((g: any) => (
                    <tr key={g.id}>
                      <td>
                        <b>{g.priority}</b>
                      </td>
                      <td>{g.title}</td>
                      <td>
                        <b>{g.status}</b>
                      </td>
                      <td>{g.evidence || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="risk" style={{ marginTop: 16 }}>
              executionAllowed=false · noOrderSigning=true · noOrderSubmission=true · noRouterAuthorization=true ·
              failClosed=true
            </div>
          </>
        )}
      </div>
    </main>
  );
}
