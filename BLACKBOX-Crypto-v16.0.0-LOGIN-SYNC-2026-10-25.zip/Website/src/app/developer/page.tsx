"use client";
import { useEffect, useState } from "react";
import AccessCodeManager from "@/components/AccessCodeManager";
import PlanManager from "@/components/PlanManager";
import MaintenanceControl from "@/components/MaintenanceControl";
import AuditCenter from "@/components/AuditCenter";
import AdminActivityTracker from "@/components/AdminActivityTracker";
import ProfileIdentity from "@/components/ProfileIdentity";
import Broadcaster from "@/components/Broadcaster";
import DeveloperBackup from "@/components/DeveloperBackup";
import TelegramCommunicationCenter from "@/components/TelegramCommunicationCenter";
import DeveloperDemoTradingPanel from "@/components/DeveloperDemoTradingPanel";
import CommunicationTemplateManager from "@/components/CommunicationTemplateManager";
import AlmaiReferralManager from "@/components/AlmaiReferralManager";
import ServiceContactManager from "@/components/ServiceContactManager";
import ServiceCatalogManager from "@/components/ServiceCatalogManager";
import PointDepositManager from "@/components/PointDepositManager";
import PaymentConfigManager from "@/components/PaymentConfigManager";
import PaymentAdminCenter from "@/components/PaymentAdminCenter";
import SocialLinksManager from "@/components/SocialLinksManager";
import BrandingManager from "@/components/BrandingManager";
import AdvisorManager from "@/components/AdvisorManager";
import AnnouncementManager from "@/components/AnnouncementManager";
import AccessControlCenter from "@/components/AccessControlCenter";
import StaffRecruitmentPanel from "@/components/StaffRecruitmentPanel";
import WpaAssignPanel from "@/components/WpaAssignPanel";
import AutoProtectPanel from "@/components/AutoProtectPanel";
import SmtpConfigPanel from "@/components/SmtpConfigPanel";
import AccountRecoveryPanel from "@/components/AccountRecoveryPanel";
import OtpChannelsPanel from "@/components/OtpChannelsPanel";
import LegalAgreementCenter from "@/components/LegalAgreementCenter";


type User = { id:string; name:string; email:string; phone:string; role:"DEVELOPER"|"ADMIN"|"USER"; status:string; kycStatus:string; createdAt:string; assignedUsers?:{id:string;name:string;email:string}[] };

export default function DeveloperPage(){
  const [data,setData]=useState<any>(null);
  const [users,setUsers]=useState<User[]>([]);
  const [busy,setBusy]=useState("");
  const load=()=>{
    fetch('/api/analytics/developer').then(r=>r.json()).then(setData);
    fetch('/api/developer/users').then(r=>r.json()).then(j=>setUsers(j.users||[]));
  };
  useEffect(load,[]);
  const action=async(body:any)=>{
    setBusy(JSON.stringify(body));
    const r=await fetch('/api/developer/users',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});
    const j=await r.json(); if(!j.ok) alert(j.error||'Operasi gagal'); setBusy(""); load();
  };
  const admins=users.filter(u=>u.role==="ADMIN");
  const normalUsers=users.filter(u=>u.role==="USER");
  return <><AdminActivityTracker/><main className="container">
  <div className="devOpsNav">
    <a href="#staff-recruit">Staff</a>
    <a href="#account-recovery">Recovery</a>
    <a href="#wpa-assign">WPA</a>
    <a href="#access-control">Access Control</a>
    <a href="#backup">Backup</a>
    <a href="#smtp-config">SMTP</a>
    <a href="#otp-channels">OTP HP</a>
    <a href="#auto-protect">Auto-Protect</a>
    <a href="#points">Point Deposit</a>
    <a href="#referral-ops">Referral</a>
    <a href="#comms">Komunikasi</a>
    <a href="#payments">Payments</a>
    <a href="#audit">Audit</a><a href="/admin/legal">Legal & Agreements</a>
  </div>
  <div id="staff-recruit"><StaffRecruitmentPanel /></div>
  <div id="account-recovery"><AccountRecoveryPanel /></div>
  <div id="wpa-assign"><WpaAssignPanel /></div>
  <div id="smtp-config"><SmtpConfigPanel /></div>
  <div id="otp-channels"><OtpChannelsPanel /></div>
  <div id="auto-protect"><AutoProtectPanel /></div>

    <ProfileIdentity />
    <div className="risk">PERINGATAN RISIKO: Trading aset kripto berisiko tinggi. Tidak ada jaminan keuntungan.</div>
    <div className="card"><span className="badge">DEVELOPER COMMAND CENTER</span><h1>Blackbox Technology Operations</h1><div className="actions" style={{marginTop:12}}><a className="btn primary" href="/admin">ADMIN CONSOLE</a><a className="btn ghost" href="/dashboard">MEMBER VIEW</a></div><p className="muted">Developer → Admin → User → Bot. Developer adalah level tertinggi.</p></div>
    <div className="card section"><h2>Developer Operations</h2><p className="muted">Akses tertinggi: operasional, user support, exchange, risk, signal, execution, audit, dan emergency control.</p><div className="actions"><a className="btn" href="/admin">Admin & User Management</a><a className="btn" href="/dashboard/access">Access Code</a><a className="btn" href="/dashboard/connections">Exchange Connections</a><a className="btn" href="/dashboard/screener">Market & Screener</a><a className="btn" href="/dashboard/ai-brain">AI / Signal</a><a className="btn" href="/dashboard/trades">Trade History</a><a className="btn" href="/dashboard/support">Support</a><a className="btn" href="/dashboard/settings">Settings</a><a className="btn" href="/admin/reports">Reports / User Tracking</a><a className="btn" href="/developer/disaster-recovery">Disaster Recovery</a><a className="btn" href="/developer/system-health">System Health</a><a className="btn primary" href="/developer/access-control">Access & Workforce</a><a className="btn" href="/dashboard/trading-control">Trading Intelligence & Execution Control System</a><a className="btn primary" href="/dashboard/prove-everything">PROVE EVERYTHING Certification</a><a className="btn primary" href="/developer/certification">Total Certification Command Center</a><a className="btn primary" href="/developer/certification">Total Certification Command Center</a><a className="btn primary" href="/dashboard/payments">Payment Center</a></div></div>
    {data&&<div className="grid" style={{marginTop:16}}>{[['Active Users',data.activeUsers],['Total Users',data.totalUsers],['User Baru 7 Hari',data.newUsers7d],['User Baru 30 Hari',data.newUsers30d],['Bot Aktif',data.activeBots],['Dashboard Aktif 15m',data.dashboardActive],['Admin Aktif',data.activeAdmins],['Ticket Ditangani 30h',data.supportHandled]].map(([a,b])=><div className="card" key={a as string}><div className="muted">{a}</div><h2>{b}</h2></div>)}</div>}
    <div className="card" style={{marginTop:16}}><h2>Admin → User Assignment</h2><p className="muted">Admin hanya dapat melihat dan mengelola USER yang secara eksplisit ditugaskan Developer.</p>
      <div style={{overflowX:'auto'}}><table><thead><tr><th>Admin</th><th>User Ditugaskan</th><th>Tambah User</th></tr></thead><tbody>
      {admins.map(a=><tr key={a.id}><td><b>{a.name}</b><div className="small">{a.email}</div></td><td>{a.assignedUsers?.length ? a.assignedUsers.map(u=><span className="pill" key={u.id} style={{marginRight:6}}>{u.name}</span>) : <span className="small">Belum ada</span>}</td><td><select className="input" defaultValue="" disabled={busy!==""} onChange={e=>{if(e.target.value) action({action:"ASSIGN_USER",adminId:a.id,userId:e.target.value});}}><option value="">Pilih USER…</option>{normalUsers.filter(u=>!a.assignedUsers?.some(x=>x.id===u.id)).map(u=><option key={u.id} value={u.id}>{u.name} — {u.email}</option>)}</select></td></tr>)}
      {!admins.length&&<tr><td colSpan={3}>Belum ada Admin.</td></tr>}
      </tbody></table></div>
    </div>
    <div className="card" style={{marginTop:16}}><h2>User & Role Management</h2><p className="muted">Hanya Developer yang dapat mengubah role.</p><div style={{overflowX:'auto'}}><table><thead><tr><th>Nama</th><th>Email</th><th>Role</th><th>Status</th><th>Aksi</th></tr></thead><tbody>{users.map(u=><tr key={u.id}><td>{u.name}</td><td>{u.email}</td><td>{u.role}</td><td>{u.status}</td><td>{u.role==='DEVELOPER'?<span>PROTECTED</span>:<><button className="btn" disabled={busy!==""} onClick={()=>action({action:'SET_ROLE',userId:u.id,role:'ADMIN'})}>MAKE ADMIN</button> <button className="btn ghost" disabled={busy!==""} onClick={()=>action({action:'SET_ROLE',userId:u.id,role:'USER'})}>MAKE USER</button> <button className="btn" disabled={busy!==""} onClick={()=>action({action:'SET_STATUS',userId:u.id,status:u.status==='SUSPENDED'?'ACTIVE':'SUSPENDED'})}>{u.status==='SUSPENDED'?'ACTIVATE':'SUSPEND'}</button> <button className="btn danger" disabled={busy!==""} onClick={()=>{if(confirm('Hapus akun permanen?'))action({action:'DELETE_ACCOUNT',userId:u.id,confirmation:'DELETE PERMANENTLY'})}}>DELETE</button></>}</td></tr>)}</tbody></table></div></div>
    <AccessControlCenter />
    <MaintenanceControl />
    <AuditCenter role="DEVELOPER" />
    <LegalAgreementCenter />
    <AccessCodeManager />
    <PlanManager />
    <PaymentConfigManager />
    <PaymentAdminCenter />
    <Broadcaster role="DEVELOPER" />
    <TelegramCommunicationCenter />
    <DeveloperDemoTradingPanel />
    <CommunicationTemplateManager />
    <AlmaiReferralManager />
    <DeveloperBackup />
    <AnnouncementManager />
    <BrandingManager />
    <AdvisorManager />
    <ServiceContactManager />
    <ServiceCatalogManager />
    <PointDepositManager />
    <SocialLinksManager />
    {data&&<div className="card" style={{marginTop:16}}><h2>Admin Activity</h2><table><thead><tr><th>Admin</th><th>Module</th><th>Aktivitas</th><th>User</th><th>Last Seen</th></tr></thead><tbody>{data.recentAdminActivities.map((x:any)=><tr key={x.id}><td>{x.admin.name}</td><td>{x.module}</td><td>{x.action}</td><td>{x.usersHandled}</td><td>{new Date(x.lastSeenAt).toLocaleString('id-ID')}</td></tr>)}</tbody></table></div>}
  </main></>
}
