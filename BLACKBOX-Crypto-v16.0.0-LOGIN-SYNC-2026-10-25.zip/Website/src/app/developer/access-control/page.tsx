import AccessControlCenter from '@/components/AccessControlCenter';
import WorkforceActivityPanel from '@/components/WorkforceActivityPanel';
import TeamWorkforcePanel from '@/components/TeamWorkforcePanel';
import WorkforcePerformanceCenter from '@/components/WorkforcePerformanceCenter';
export default function DeveloperAccessControlPage(){return <main className="container"><div className="card"><span className="badge">DEVELOPER</span><h1>Access & Workforce Management</h1><p className="muted">Team, Ketua Tim, Task, Permission Simulator, Access Review, Approval dan Emergency Control.</p></div><AccessControlCenter/><TeamWorkforcePanel/><WorkforceActivityPanel/><WorkforcePerformanceCenter/></main>}
