import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { verifyEdgeSessionToken } from "@/lib/auth-edge";
import { isAllowedOrigin } from "@/lib/origin";

const PUBLIC = (p: string) =>
  p === "/login" ||
  p === "/register" ||
  p === "/verify" ||
  p.startsWith("/api/auth") ||
  p.startsWith("/api/health/") ||
  p === "/api/health" ||
  p.startsWith("/api/public/") ||
  p.startsWith("/api/mobile/") ||
  p.startsWith("/share");

function addHeaders(res: NextResponse){
  res.headers.set("X-Content-Type-Options","nosniff");
  res.headers.set("X-Frame-Options","DENY");
  res.headers.set("Referrer-Policy","strict-origin-when-cross-origin");
  res.headers.set("Permissions-Policy","camera=(), microphone=(), geolocation=()");
  res.headers.set("Cross-Origin-Opener-Policy","same-origin");
  res.headers.set("Content-Security-Policy","default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; img-src 'self' data: blob: https:; style-src 'self' 'unsafe-inline'; font-src 'self' data: https:; connect-src 'self' https:; script-src 'self' 'unsafe-inline' https://accounts.google.com; frame-src 'self' https://accounts.google.com; upgrade-insecure-requests");
  if(process.env.NODE_ENV==="production")res.headers.set("Strict-Transport-Security","max-age=31536000; includeSubDomains; preload");
  return res;
}

export async function middleware(req: NextRequest) {
  const p = req.nextUrl.pathname;
  // API runtime is deployed independently from the web client. In API mode,
  // never serve dashboard/admin/developer HTML; the same codebase can safely
  // run as a dedicated API process without changing any existing routes.
  const apiRuntimeOnly = process.env.BLACKBOX_RUNTIME_ROLE === "API";
  if (apiRuntimeOnly && !p.startsWith("/api/")) {
    return NextResponse.json({ ok:false, error:"API_RUNTIME_ONLY" }, { status:404 });
  }
  const correlationId = req.headers.get("x-correlation-id") || crypto.randomUUID();
  const requestId = req.headers.get("x-request-id") || crypto.randomUUID();
  const traceId = req.headers.get("x-trace-id") || crypto.randomUUID();
  const requestHeaders = new Headers(req.headers);
  requestHeaders.set("x-correlation-id", correlationId);
  requestHeaders.set("x-request-id", requestId);
  requestHeaders.set("x-trace-id", traceId);
  const isApi = p.startsWith("/api/");

  // Security checks must run before the public-route bypass. "Public" means
  // authentication is not required; it does not mean a mutating request may
  // bypass Origin/Referer validation or the API method allow-list.
  if (isApi && !["GET","HEAD","OPTIONS","POST","PUT","PATCH","DELETE"].includes(req.method)) {
    return NextResponse.json({ok:false,error:"METHOD_NOT_ALLOWED"},{status:405});
  }

  if (isApi && !["GET","HEAD","OPTIONS"].includes(req.method)) {
    // CSRF mitigation for cookie sessions and public auth endpoints. A browser
    // POST with a foreign Origin must be rejected even before a session exists.
    const origin = req.headers.get("origin");
    const referer = req.headers.get("referer");
    if (origin) {
      if (!isAllowedOrigin(req, origin)) return addHeaders(NextResponse.json({ok:false,error:"ORIGIN_NOT_ALLOWED"},{status:403}));
    } else if (referer) {
      try {
        const refOrigin = new URL(referer).origin;
        if (!isAllowedOrigin(req, refOrigin)) return addHeaders(NextResponse.json({ok:false,error:"ORIGIN_NOT_ALLOWED"},{status:403}));
      } catch {
        return addHeaders(NextResponse.json({ok:false,error:"ORIGIN_NOT_ALLOWED"},{status:403}));
      }
    } else if (process.env.NODE_ENV === "production" && req.cookies.get("blackbox_session")?.value) {
      return addHeaders(NextResponse.json({ok:false,error:"ORIGIN_REQUIRED"},{status:403}));
    }
  }
  if (PUBLIC(p)) { const res=NextResponse.next({request:{headers:requestHeaders}}); addHeaders(res); res.headers.set("x-correlation-id", correlationId); res.headers.set("x-request-id", requestId); res.headers.set("x-trace-id", traceId); return res; }
  const deny = (status: number, error: string) =>
    isApi ? NextResponse.json({ ok: false, error }, { status }) : NextResponse.redirect(new URL("/login", req.url));
  const token = req.cookies.get("blackbox_session")?.value;
  if (!token) return deny(401, "UNAUTHENTICATED");
  let payload: Record<string, unknown>;
  const verified = await verifyEdgeSessionToken(token);
  if (!verified) return deny(401, "UNAUTHENTICATED");
  payload = verified as unknown as Record<string, unknown>;
  const role = String(payload.role || "");
  // Pemeriksaan kasar di edge; otorisasi final (role + status dari DB) dilakukan di server.
  const mustChange=payload.mustChangePassword===true;
  if(mustChange && !p.startsWith("/dashboard/security") && p!=="/api/security" && !p.startsWith("/api/auth/password")) return isApi ? NextResponse.json({ok:false,error:"PASSWORD_CHANGE_REQUIRED"},{status:428}) : NextResponse.redirect(new URL("/dashboard/security",req.url));
  if (p.startsWith("/developer") && role !== "DEVELOPER") return NextResponse.redirect(new URL("/dashboard", req.url));
  if (p.startsWith("/admin") && !["ADMIN", "DEVELOPER"].includes(role)) return NextResponse.redirect(new URL("/dashboard", req.url));
  const res=NextResponse.next({request:{headers:requestHeaders}}); addHeaders(res); res.headers.set("x-correlation-id", correlationId); res.headers.set("x-request-id", requestId); res.headers.set("x-trace-id", traceId); return res;
}
export const config = { matcher: ["/dashboard/:path*", "/admin/:path*", "/developer/:path*", "/api/:path*"] };
