# BLACKBOX Crypto — Security posture (honest)

No web app is “unhackable”. This package hardens **defaults** so a normal VPS deploy is not wide open.

## Already built into the app

| Area | Control |
|------|---------|
| **Ports** | App binds `127.0.0.1:3000` by default (not `0.0.0.0`). Postgres has **no host port** — only Docker network. |
| **Auth** | Rate limits + hashed keys; login progressive protect; MFA available; session cookies httpOnly/sameSite/secure. |
| **CSRF** | Origin/Referer checks on mutating API + SameSite cookies. |
| **Headers** | CSP, X-Frame-Options DENY, nosniff, HSTS (prod), COOP — middleware + next.config. |
| **Data** | `DATA_ENCRYPTION_KEY` / backup encryption; secrets via `.env` not in git. |
| **Auto-protect** | `src/lib/auto-protect.ts` — on flood/intrusion signals can freeze trading path + trigger encrypted backup email. |
| **Login abuse** | `login-protect` stages → reset suggestion → trade freeze. |
| **Execution** | Real trading fail-closed by default (`REAL_TRADING_ENABLED=false`). |

## What you still need at the edge (critical for “many users”)

| Threat | App alone | Recommended edge |
|--------|-----------|------------------|
| **DDoS / volumetric** | Rate limit helps a little | **Cloudflare / WAF / host DDoS** in front of VPS |
| **Bot scraping** | Rate limit + auth | WAF bot fight + CAPTCHA if needed |
| **0-day in Node/OS** | — | Patch OS, Docker images, minimal open ports |
| **Stolen `.env`** | Encryption at rest for some fields | Disk encryption, restricted SSH, no secret in chat |

## Host hardening (run once on VPS)

```bash
sudo bash ops/security-hardening.sh
```

Enables firewall defaults: SSH + HTTP/HTTPS only; reminds not to publish 5432/3000 publicly.

## Deploy checklist (security)

1. `BLACKBOX_BIND_HOST=127.0.0.1` (default) — reverse proxy terminates TLS  
2. Strong `AUTH_SECRET`, encryption keys, unique `POSTGRES_PASSWORD`  
3. `TRUST_PROXY=true` **only** behind trusted reverse proxy  
4. Upstash Redis for shared rate limits under multi-user load  
5. Cloudflare (or similar) proxy orange-cloud for DDoS  
6. Keep packages updated; never expose Postgres to the internet  
