# BLACKBOX Crypto v16.0.0 — Release Certification Blockers

This source package has received source-level repairs and static/regression verification. It is **not production-certified** while the clean-install and external runtime gates below remain incomplete.

## First run: clean install and website gates

Run from the `Website/` directory using Node.js `22.16.x` and npm `10.9.x`:

```bash
node --version
npm --version
npm run registry:preflight
npm ci --include=dev --no-audit --no-fund --engine-strict
npm run lock:verify
npx prisma validate
npx prisma generate
npm run typecheck
npm test
npm run build
```

The preflight in the audit environment failed with `EAI_AGAIN` for the npm registry and two configured mirrors. `npm ci --offline` also failed with `ENOTCACHED` because the cache is incomplete. Fix DNS, proxy/firewall or runner network access, rerun preflight, and perform a clean install. Do not bypass registry verification, synthesize lockfile integrity, skip install scripts blindly, or copy partial `node_modules` from another host.

## PostgreSQL migration and restore safety

Use a disposable PostgreSQL database and set `DATABASE_URL` to that database before running:

```bash
npx prisma migrate deploy
```

Verify schema/tables, indexes, constraints, idempotent seed/bootstrap behavior, and readiness endpoints. Before deploying to an existing database, take a backup and successfully restore it to an isolated target. Compare `_prisma_migrations` with the migration directories and actual schema. Do not delete migration records, rewrite production history, or mark migrations as applied just to silence errors.

## Android certification

The Android project is separate under `APK-Android/`. Use Java 21 and Android SDK/build tools 35. From the repository root the canonical Android build scripts/workflow use this folder. Certify Gradle download/wrapper checksum, debug/release build, API-origin configuration, emulator/device installation, login/session, network/API error handling, push, deep links and release signing. No Android build/device PASS is claimed by the local source audit.

## External integration, reliability and trading safety

After the website build succeeds, test login and all role dashboards, protected APIs, browser console/network, access-control boundaries, restart/recovery, backup/restore, rate limits, STOP ALL BOT and failure recovery. Also test SMTP/FCM/Telegram delivery, exchange sandbox orders and reconciliation, DEX risk checks, load/WAF and target infrastructure. A service test file existing is not evidence the external service completed a real round-trip.

Keep `REAL_TRADING_ENABLED=false` and live execution authorization disabled until data quality, trading safety, exchange reconciliation, DR and external approval gates pass independently.

## Latest local evidence (2026-10-24)

- Full Node regression suite: **830/830 PASS**, no failures/skips.
- Lockfile verifier: **PASS**, 439 package entries and 28 direct dependencies.
- JS/MJS/CJS syntax checks: **436 files PASS**, zero errors.
- Active workflow YAML parser: **7/7 PASS**.
- v16 deployment-consistency gate: **PASS**.
- Release guardian: **STRUCTURAL_PASS**; production authorization disabled.
- Public-secret audit: **PASS**, 1,953 files scanned.
- Obsolete unreferenced release/audit snapshots: 27 archived under `docs/archive/2026-10-24-v16-audit-snapshots/`.
- npm registry preflight: **BLOCKED_EXTERNAL_RUNTIME** due `EAI_AGAIN`; offline install failed `ENOTCACHED`.
- Prisma/PostgreSQL, dependency-backed typecheck, Next production build, browser E2E, Android Gradle/device, external integrations, DR and load/WAF: **NOT TESTED / BLOCKED_EXTERNAL_RUNTIME**.

See `AUDIT-REPAIR-RESULT-2026-10-24.md` and `certification/evidence/current/audit-repair-result-2026-10-24.json` for the consolidated audit record.
