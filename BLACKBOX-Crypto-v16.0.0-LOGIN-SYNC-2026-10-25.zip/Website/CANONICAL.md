# BLACKBOX v16.0.0 — Canonical Release Contract

- Release: **16.0.0**
- Package manager: **npm@10.9.2**
- Node: **22.16.x** (minimum 22.11)
- Android: **versionName 16.0.0 / versionCode 160000**
- Database: **PostgreSQL 16 / Prisma**
- Latest migration: **0142_v1600_canonical_runtime_execution**
- Real trading default: **OFF / fail-closed**

Canonical release surfaces must remain synchronized across package/version, lockfile, Android, Prisma schema/migrations, APIs, workers, configuration, tests, Docker, CI, and deployment scripts.

Use `npm run release:certification-preflight` before installation and `npm run release:sync-audit` after extraction or release changes.
