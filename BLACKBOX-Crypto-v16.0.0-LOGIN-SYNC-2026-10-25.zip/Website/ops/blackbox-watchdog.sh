#!/usr/bin/env bash
set -euo pipefail
URL="${BLACKBOX_HEALTH_URL:-https://YOUR-BLACKBOX-DOMAIN.example.com/api/health}"
STATE="${BLACKBOX_WATCHDOG_STATE:-/var/lib/blackbox-watchdog.state}"
ALERT="${BLACKBOX_ALERT_WEBHOOK:-}"
code=$(curl -k -sS -o /tmp/blackbox-health.json -w '%{http_code}' --max-time 10 "$URL" || true)
status=DOWN
[[ "$code" == "200" ]] && status=UP
prev=$(cat "$STATE" 2>/dev/null || echo UNKNOWN)
if [[ "$status" != "$prev" ]]; then
  printf '%s' "$status" > "$STATE"
  if [[ -n "$ALERT" ]]; then curl -sS -X POST -H 'content-type: application/json' --data "{\"status\":\"$status\",\"timestamp\":\"$(date -Is)\",\"httpCode\":\"$code\"}" "$ALERT" >/dev/null || true; fi
fi
[[ "$status" == "UP" ]] || exit 2
