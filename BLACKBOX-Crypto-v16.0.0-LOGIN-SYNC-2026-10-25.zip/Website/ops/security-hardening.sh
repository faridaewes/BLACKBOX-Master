#!/usr/bin/env bash
# BLACKBOX host security defaults (UFW). Run once as root on the VPS.
# Does NOT claim to stop all cyber attacks — reduces accidental exposure.
set -euo pipefail
if [[ "$(id -u)" -ne 0 ]]; then
  echo "Run: sudo bash ops/security-hardening.sh"
  exit 1
fi

echo "==> BLACKBOX host hardening (firewall baseline)"

if command -v ufw >/dev/null 2>&1; then
  ufw default deny incoming
  ufw default allow outgoing
  ufw allow OpenSSH 2>/dev/null || ufw allow 22/tcp
  ufw allow 80/tcp
  ufw allow 443/tcp
  # Do NOT open 3000 or 5432 publicly — app stays on 127.0.0.1, DB internal only
  ufw --force enable
  ufw status verbose
else
  echo "ufw not installed. Install: apt-get install -y ufw"
  echo "Manual: allow only 22,80,443; never publish PostgreSQL."
fi

echo
echo "==> Reminders"
echo " - BLACKBOX_BIND_HOST=127.0.0.1 in .env (default in compose)"
echo " - Put Nginx/Caddy + TLS (or Cloudflare) in front of 127.0.0.1:3000"
echo " - Do not docker-publish 5432"
echo " - Enable autostart: sudo bash scripts/enable-autostart.sh"
echo " - DDoS: use Cloudflare/WAF at DNS edge"
echo "Done."
