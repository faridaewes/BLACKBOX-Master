# BLACKBOX 24/7 & auto-recovery (VPS)

## Layers of resilience

| Layer | Mechanism | Recovers from |
|-------|-----------|----------------|
| 1 | `restart: unless-stopped` on Docker services | Process/container crash |
| 2 | Docker Engine enabled on boot | Host reboot (containers come back) |
| 3 | `systemd` unit `blackbox.service` | Ensures `docker compose up -d` after boot |
| 4 | Optional `health-watchdog.sh` (cron) | Stack stuck without self-heal |

## One-time setup on VPS

```bash
# After deploy files are on the server (e.g. /opt/blackbox):
cd /opt/blackbox
sudo bash scripts/enable-autostart.sh /opt/blackbox

# Verify
systemctl status blackbox
docker compose ps
curl -sS http://127.0.0.1:3000/api/health
```

## After server power loss / reboot

1. OS boots → `docker.service` starts  
2. `blackbox.service` runs `docker compose up -d`  
3. Postgres healthy → migrate (if needed) → app + workers with `unless-stopped`  
4. Site answers on port 3000 (or your reverse proxy)

## 24/7 multi-user recommendations

1. **Reverse proxy** (Nginx/Caddy) with TLS in front of `127.0.0.1:3000`
2. **Redis / Upstash** for shared rate limits across instances
3. **Disk**: monitor PostgreSQL volume `blackbox_pg`
4. **RAM**: prefer ≥2–4 GB for app + db + workers
5. **Backups**: schedule DB + `BACKUP_ENCRYPTION_KEY` off-box
6. Keep `REAL_TRADING_ENABLED=false` until certified

## Disable autostart

```bash
sudo systemctl disable --now blackbox.service
```
