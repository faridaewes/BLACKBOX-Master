# BLACKBOX Crypto v16.0.0 — Independent Audit and Repair Report

Audit date: 2026-10-24  
Scope: the supplied consolidated master ZIP, website/API/workers, tests, Prisma schema/migrations, deployment/configuration files, Android source/build configuration, and release workflows.  
Release decision: **STATIC / UNIT CHECKS PASS; PRODUCTION CERTIFICATION BLOCKED.**

## Executive result

The archive was unpacked into a temporary audit workspace and inspected independently rather than relying on prior repair claims. Two security defects were identified and repaired. The latest full Node test suite passed **846/846 tests**. The final syntax gate passed with **681 files scanned and zero reported syntax errors**. The whole-project audit inspected **2,195 files**, reported zero JavaScript syntax failures and zero invalid JSON files, and found no high-confidence public-secret patterns.

This is not a claim that every runtime integration works. No usable PostgreSQL service, Docker engine, Android SDK/Gradle distribution, deployed Google OAuth client/browser session, or Windows VPS was available for live certification. A clean `npm ci` attempt did not finish within the environment's execution limit; it was stopped and its partial `node_modules` tree was removed. Consequently, typecheck, Prisma CLI validation/generation, and production build remain unverified.

## Repairs made

### 1. Google login and registration nonce binding — fixed at source level

- Added `Website/src/app/api/auth/google/nonce/route.ts` to issue a cryptographically random, short-lived challenge (10 minutes), bound to an HttpOnly, SameSite=Lax cookie, marked no-store, and rate-limited fail-closed.
- Updated both `Website/src/app/login/page.tsx` and `Website/src/app/register/page.tsx` to obtain the challenge from the server rather than inventing a browser-only nonce.
- Updated `Website/src/app/api/auth/google/route.ts` to compare the client value to the server-issued cookie, verify the Google ID token's issuer, configured audience and cookie-bound nonce, and require a verified email plus a non-empty subject. The challenge cookie is cleared on every POST response.
- Google login now creates a session only for a local account whose status is exactly `ACTIVE`. Pending, suspended, disabled, unknown, invalid-token, unverified-email, mismatched-audience, and invalid-nonce cases do not reach `createSession`.
- Updated regression contracts so both login and registration pages are checked against the server challenge flow.

**Not live-certified:** these are source-level and contract tests, not a real Google provider/browser round-trip.

### 2. CSRF checks on public authentication endpoints — fixed at source level

- Reordered `Website/src/middleware.ts` so API method allow-list and mutating-request Origin/Referer checks execute before the `PUBLIC` route bypass.
- Public routes remain unauthenticated where intended, but “public” no longer means a mutating request skips CSRF/origin validation.
- Added a regression test enforcing the ordering and refreshed the read-only middleware integrity digest to the reviewed source SHA-256: `7e15c5a300a4301468147b9a5b45da2d40aea9c1acd2c741069e1d3c2ac58660`.

### 3. Historical Prisma prefix collisions — made explicit and guarded without renaming

- Added `Website/scripts/migration-history-audit.mjs`, `Website/prisma/MIGRATION-HISTORY.md`, a package command (`npm run migration:history-audit`), and a regression test.
- The audit reports 143 migration directories, unique full directory names, and migration SQL present for every directory. It verifies that the only duplicate four-digit prefixes are the expected `0007`, `0008`, and `0010` pairs.
- Historical migration directories and SQL were not renamed or rewritten. Prisma uses the full migration directory name and stores checksums in `_prisma_migrations`; changing deployed migration names or bytes without database evidence can create history/checksum conflicts or unsafe replay.

**Still required:** compare migration history/checksums with each existing database and run `prisma migrate deploy` on a fresh isolated PostgreSQL database plus a backup/restore drill.

## Verification evidence from this environment

| Check | Result | Notes |
|---|---|---|
| `npm test` | **PASS — 846/846** | Entire unit/contract suite on final security changes |
| `npm run audit:syntax` | **PASS** | 681 files; 0 syntax gate errors |
| `node scripts/whole-project-audit.mjs` | **PASS** | 2,195 files inspected; 0 reported JS syntax failures; 0 invalid JSON; no high-confidence public-secret patterns |
| `npm run lock:verify` | **PASS** | 439 package entries, 28 direct dependencies verified, integrity fields present |
| `npm run v16:deployment-consistency` | **PASS** | Release/version/config/migration/workflow structural checks passed; rerun in CI before release |
| `npm run migration:history-audit` | **PASS** | 143 migration dirs; unique full names; no missing `migration.sql`; expected numeric-prefix collisions only |
| `npm run v16:static-audit` | **PASS** | 1,092 files scanned; 414 JS files checked; zero JS and TS-gate errors |
| `npm run middleware:integrity` | **PASS** | Reviewed middleware digest matches |
| `npm run validate:env` | **PASS** | No env-contract errors; local/default paper-mode warning remains expected |
| Shell/Python syntax checks | **PASS** | Checked project shell launchers and Python source files; generated `__pycache__` removed before packaging |

The `v16:static-release-audit` runner was updated to check independent JavaScript files with bounded concurrency after a serial rerun exceeded the environment execution limit. The refreshed final run passed with 1,092 source/script/test files scanned, 414 JavaScript files checked, zero JavaScript failures, and zero TypeScript-gate failures.

## Blocked / not passed — do not infer success

| Gate | Status | Reason / required next action |
|---|---|---|
| Clean dependency install (`npm ci`) | **BLOCKED / TIMED OUT** | Did not complete in this environment. Run in a network-enabled certification environment and retain logs. |
| TypeScript typecheck | **NOT VERIFIED** | The repository's typecheck script refuses to bootstrap dependencies implicitly; rerun after successful `npm ci`. |
| Prisma format/validate/generate | **NOT VERIFIED** | Prisma CLI was not successfully installed/available. Run after clean install. |
| Production Next.js build | **NOT VERIFIED** | Depends on successful dependency installation and Prisma generation. |
| Fresh PostgreSQL migrations | **NOT RUN** | No PostgreSQL service/tools available here. Test an empty database and inspect `_prisma_migrations`. |
| Migration on an existing database | **NOT RUN** | Requires a protected copy of the actual database migration history and checksums. |
| Backup/restore drill | **NOT RUN** | Requires database and backup storage plus verification of restored tables/row counts. |
| Real Google OAuth browser flow | **NOT RUN** | Requires configured Google OAuth origins/client ID, deployed app, browser, and runtime database. |
| Android Gradle/APK/device build | **NOT RUN** | Android SDK and downloaded Gradle distribution were not available. The wrapper distribution URL is pinned with a checksum; the full build still must run elsewhere. |
| Docker Compose deployment / VPS recovery | **NOT RUN** | Docker and a Windows/Linux VPS were not available. |
| Live exchange / DEX trading certification | **NOT RUN** | Must remain disabled; a source build or passing unit suite is not trading authorization. |

## Release recommendation

Use this ZIP as an audited source candidate for staging, not as a production-certified release. The two source-level security repairs and regression tests are included. Before production, complete the blocked gates above and attach environment-specific evidence. Never rename or edit applied migration history without reviewing the target database. Never put credentials in this archive. Keep real trading off until the separate execution-safety and operational certification passes.
